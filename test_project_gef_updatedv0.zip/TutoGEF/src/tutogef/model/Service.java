package tutogef.model;

public class Service extends Node {
	private int etage;

	public void setEtage(int etage) {
		this.etage = etage;
	}

	public int getEtage() {
		return this.etage;
	}
}
