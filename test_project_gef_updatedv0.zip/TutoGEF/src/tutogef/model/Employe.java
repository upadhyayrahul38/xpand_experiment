package tutogef.model;

public class Employe extends Node {
	private String prenom;

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getPrenom() {
		return this.prenom;
	}
}
