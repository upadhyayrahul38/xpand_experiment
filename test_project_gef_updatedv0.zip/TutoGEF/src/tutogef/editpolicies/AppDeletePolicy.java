package tutogef.editpolicies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.ComponentEditPolicy;
import org.eclipse.gef.requests.GroupRequest;

import tutogef.commands.DeleteCommand;
import tutogef.model.Node;

public class AppDeletePolicy extends ComponentEditPolicy {
	
	@Override
	protected Command createDeleteCommand(GroupRequest deleteRequest) {
		 DeleteCommand command = new DeleteCommand();
		 command.setModel((Node)(getHost().getModel()));
		 command.setParentModel((Node)(getHost().getParent().getModel()));
		return command;
	}

}
