package tutogef.commands;

import org.eclipse.gef.commands.Command;

import tutogef.model.Node;

public class DeleteCommand extends Command {
      private Node model;
      private Node parentModel;
      
      @Override
    public void execute() {
        this.parentModel.removeChild(model);    
    }
      
      public void setModel(Node model) {
		this.model = model;
	}
      
      public void setParentModel(Node parentModel) {
		this.parentModel = parentModel;
	}
      
	@Override
	public void undo() {
		this.parentModel.addChild(model);

	}
}
