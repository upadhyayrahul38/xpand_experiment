/**
 */
package architecturetool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Datatype Enum</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see architecturetool.ArchitecturetoolPackage#getDatatypeEnum()
 * @model
 * @generated
 */
public enum DatatypeEnum implements Enumerator {
	/**
	 * The '<em><b>BOOLEAN</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BOOLEAN_VALUE
	 * @generated
	 * @ordered
	 */
	BOOLEAN(0, "BOOLEAN", "boolean"),

	/**
	 * The '<em><b>SINT8</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SINT8_VALUE
	 * @generated
	 * @ordered
	 */
	SINT8(1, "SINT8", "sint8"),

	/**
	 * The '<em><b>UNIT8</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNIT8_VALUE
	 * @generated
	 * @ordered
	 */
	UNIT8(2, "UNIT8", "uint8"),

	/**
	 * The '<em><b>SINT16</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SINT16_VALUE
	 * @generated
	 * @ordered
	 */
	SINT16(3, "SINT16", "sint16"),

	/**
	 * The '<em><b>UNIT16</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNIT16_VALUE
	 * @generated
	 * @ordered
	 */
	UNIT16(4, "UNIT16", "uint16"),

	/**
	 * The '<em><b>SINT32</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SINT32_VALUE
	 * @generated
	 * @ordered
	 */
	SINT32(5, "SINT32", "sint32"),

	/**
	 * The '<em><b>UNIT32</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNIT32_VALUE
	 * @generated
	 * @ordered
	 */
	UNIT32(6, "UNIT32", "uint32"),

	/**
	 * The '<em><b>FLOAT32</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FLOAT32_VALUE
	 * @generated
	 * @ordered
	 */
	FLOAT32(7, "FLOAT32", "float32");

	/**
	 * The '<em><b>BOOLEAN</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>BOOLEAN</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BOOLEAN
	 * @model literal="boolean"
	 * @generated
	 * @ordered
	 */
	public static final int BOOLEAN_VALUE = 0;

	/**
	 * The '<em><b>SINT8</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SINT8</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SINT8
	 * @model literal="sint8"
	 * @generated
	 * @ordered
	 */
	public static final int SINT8_VALUE = 1;

	/**
	 * The '<em><b>UNIT8</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>UNIT8</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNIT8
	 * @model literal="uint8"
	 * @generated
	 * @ordered
	 */
	public static final int UNIT8_VALUE = 2;

	/**
	 * The '<em><b>SINT16</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SINT16</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SINT16
	 * @model literal="sint16"
	 * @generated
	 * @ordered
	 */
	public static final int SINT16_VALUE = 3;

	/**
	 * The '<em><b>UNIT16</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>UNIT16</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNIT16
	 * @model literal="uint16"
	 * @generated
	 * @ordered
	 */
	public static final int UNIT16_VALUE = 4;

	/**
	 * The '<em><b>SINT32</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SINT32</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SINT32
	 * @model literal="sint32"
	 * @generated
	 * @ordered
	 */
	public static final int SINT32_VALUE = 5;

	/**
	 * The '<em><b>UNIT32</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>UNIT32</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNIT32
	 * @model literal="uint32"
	 * @generated
	 * @ordered
	 */
	public static final int UNIT32_VALUE = 6;

	/**
	 * The '<em><b>FLOAT32</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>FLOAT32</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FLOAT32
	 * @model literal="float32"
	 * @generated
	 * @ordered
	 */
	public static final int FLOAT32_VALUE = 7;

	/**
	 * An array of all the '<em><b>Datatype Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final DatatypeEnum[] VALUES_ARRAY =
		new DatatypeEnum[] {
			BOOLEAN,
			SINT8,
			UNIT8,
			SINT16,
			UNIT16,
			SINT32,
			UNIT32,
			FLOAT32,
		};

	/**
	 * A public read-only list of all the '<em><b>Datatype Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<DatatypeEnum> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Datatype Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static DatatypeEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			DatatypeEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Datatype Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static DatatypeEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			DatatypeEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Datatype Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static DatatypeEnum get(int value) {
		switch (value) {
			case BOOLEAN_VALUE: return BOOLEAN;
			case SINT8_VALUE: return SINT8;
			case UNIT8_VALUE: return UNIT8;
			case SINT16_VALUE: return SINT16;
			case UNIT16_VALUE: return UNIT16;
			case SINT32_VALUE: return SINT32;
			case UNIT32_VALUE: return UNIT32;
			case FLOAT32_VALUE: return FLOAT32;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private DatatypeEnum(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //DatatypeEnum
