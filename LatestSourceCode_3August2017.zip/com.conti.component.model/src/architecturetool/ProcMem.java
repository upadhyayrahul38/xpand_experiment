/**
 */
package architecturetool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Proc Mem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.ProcMem#getSafetyEnum <em>Safety Enum</em>}</li>
 *   <li>{@link architecturetool.ProcMem#getAccessSpeedEnum <em>Access Speed Enum</em>}</li>
 *   <li>{@link architecturetool.ProcMem#getCycleEnum <em>Cycle Enum</em>}</li>
 *   <li>{@link architecturetool.ProcMem#getBudget <em>Budget</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getProcMem()
 * @model
 * @generated
 */
public interface ProcMem extends EObject {

	/**
	 * Returns the value of the '<em><b>Safety Enum</b></em>' attribute.
	 * The literals are from the enumeration {@link architecturetool.ProcMem_Safety}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Safety Enum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Safety Enum</em>' attribute.
	 * @see architecturetool.ProcMem_Safety
	 * @see #setSafetyEnum(ProcMem_Safety)
	 * @see architecturetool.ArchitecturetoolPackage#getProcMem_SafetyEnum()
	 * @model
	 * @generated
	 */
	ProcMem_Safety getSafetyEnum();

	/**
	 * Sets the value of the '{@link architecturetool.ProcMem#getSafetyEnum <em>Safety Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Safety Enum</em>' attribute.
	 * @see architecturetool.ProcMem_Safety
	 * @see #getSafetyEnum()
	 * @generated
	 */
	void setSafetyEnum(ProcMem_Safety value);

	/**
	 * Returns the value of the '<em><b>Access Speed Enum</b></em>' attribute.
	 * The literals are from the enumeration {@link architecturetool.ProcMem_AccessSpeed}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Access Speed Enum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Access Speed Enum</em>' attribute.
	 * @see architecturetool.ProcMem_AccessSpeed
	 * @see #setAccessSpeedEnum(ProcMem_AccessSpeed)
	 * @see architecturetool.ArchitecturetoolPackage#getProcMem_AccessSpeedEnum()
	 * @model
	 * @generated
	 */
	ProcMem_AccessSpeed getAccessSpeedEnum();

	/**
	 * Sets the value of the '{@link architecturetool.ProcMem#getAccessSpeedEnum <em>Access Speed Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Access Speed Enum</em>' attribute.
	 * @see architecturetool.ProcMem_AccessSpeed
	 * @see #getAccessSpeedEnum()
	 * @generated
	 */
	void setAccessSpeedEnum(ProcMem_AccessSpeed value);

	/**
	 * Returns the value of the '<em><b>Cycle Enum</b></em>' attribute.
	 * The literals are from the enumeration {@link architecturetool.ProcMem_Cycle}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cycle Enum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cycle Enum</em>' attribute.
	 * @see architecturetool.ProcMem_Cycle
	 * @see #setCycleEnum(ProcMem_Cycle)
	 * @see architecturetool.ArchitecturetoolPackage#getProcMem_CycleEnum()
	 * @model
	 * @generated
	 */
	ProcMem_Cycle getCycleEnum();

	/**
	 * Sets the value of the '{@link architecturetool.ProcMem#getCycleEnum <em>Cycle Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cycle Enum</em>' attribute.
	 * @see architecturetool.ProcMem_Cycle
	 * @see #getCycleEnum()
	 * @generated
	 */
	void setCycleEnum(ProcMem_Cycle value);

	/**
	 * Returns the value of the '<em><b>Budget</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Budget</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Budget</em>' attribute.
	 * @see #setBudget(String)
	 * @see architecturetool.ArchitecturetoolPackage#getProcMem_Budget()
	 * @model
	 * @generated
	 */
	String getBudget();

	/**
	 * Sets the value of the '{@link architecturetool.ProcMem#getBudget <em>Budget</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Budget</em>' attribute.
	 * @see #getBudget()
	 * @generated
	 */
	void setBudget(String value);
} // ProcMem
