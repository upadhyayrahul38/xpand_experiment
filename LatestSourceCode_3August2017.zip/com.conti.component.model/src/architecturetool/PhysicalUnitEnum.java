/**
 */
package architecturetool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Physical Unit Enum</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see architecturetool.ArchitecturetoolPackage#getPhysicalUnitEnum()
 * @model
 * @generated
 */
public enum PhysicalUnitEnum implements Enumerator {
	/**
	 * The '<em><b>NOUNIT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NOUNIT_VALUE
	 * @generated
	 * @ordered
	 */
	NOUNIT(0, "NOUNIT", "-"),

	/**
	 * The '<em><b>METER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #METER_VALUE
	 * @generated
	 * @ordered
	 */
	METER(1, "METER", "m"),

	/**
	 * The '<em><b>SQUAREMETER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SQUAREMETER_VALUE
	 * @generated
	 * @ordered
	 */
	SQUAREMETER(0, "SQUAREMETER", "m^2"),

	/**
	 * The '<em><b>SECOND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SECOND_VALUE
	 * @generated
	 * @ordered
	 */
	SECOND(3, "SECOND", "s"),

	/**
	 * The '<em><b>METERPERSECOND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #METERPERSECOND_VALUE
	 * @generated
	 * @ordered
	 */
	METERPERSECOND(4, "METERPERSECOND", "m/s"),

	/**
	 * The '<em><b>METERSQUAREDPERSECONDSQUARED</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #METERSQUAREDPERSECONDSQUARED_VALUE
	 * @generated
	 * @ordered
	 */
	METERSQUAREDPERSECONDSQUARED(5, "METERSQUAREDPERSECONDSQUARED", "(m/s)^2"),

	/**
	 * The '<em><b>METERPERSECONDSQUARED</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #METERPERSECONDSQUARED_VALUE
	 * @generated
	 * @ordered
	 */
	METERPERSECONDSQUARED(6, "METERPERSECONDSQUARED", "m/s^2"),

	/**
	 * The '<em><b>METERPERSECONDCUBED</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #METERPERSECONDCUBED_VALUE
	 * @generated
	 * @ordered
	 */
	METERPERSECONDCUBED(7, "METERPERSECONDCUBED", "m/s^3"),

	/**
	 * The '<em><b>METERPERSECONDSQUAREDSQUARED</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #METERPERSECONDSQUAREDSQUARED_VALUE
	 * @generated
	 * @ordered
	 */
	METERPERSECONDSQUAREDSQUARED(8, "METERPERSECONDSQUAREDSQUARED", "(m/s^2)^2"),

	/**
	 * The '<em><b>RADIAN</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RADIAN_VALUE
	 * @generated
	 * @ordered
	 */
	RADIAN(9, "RADIAN", "rad"),

	/**
	 * The '<em><b>RADIANPERSECOND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RADIANPERSECOND_VALUE
	 * @generated
	 * @ordered
	 */
	RADIANPERSECOND(10, "RADIANPERSECOND", "rad/s"),

	/**
	 * The '<em><b>RADIANPERSECONDSQUARED</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RADIANPERSECONDSQUARED_VALUE
	 * @generated
	 * @ordered
	 */
	RADIANPERSECONDSQUARED(11, "RADIANPERSECONDSQUARED", "(rad/s)^2"),

	/**
	 * The '<em><b>NEWTON</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NEWTON_VALUE
	 * @generated
	 * @ordered
	 */
	NEWTON(12, "NEWTON", "N"),

	/**
	 * The '<em><b>DEGREECENTIGRADE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEGREECENTIGRADE_VALUE
	 * @generated
	 * @ordered
	 */
	DEGREECENTIGRADE(13, "DEGREECENTIGRADE", "degC"),

	/**
	 * The '<em><b>NEWTONMETER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NEWTONMETER_VALUE
	 * @generated
	 * @ordered
	 */
	NEWTONMETER(14, "NEWTONMETER", "Nm"),

	/**
	 * The '<em><b>NEWTONPERRAD</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NEWTONPERRAD_VALUE
	 * @generated
	 * @ordered
	 */
	NEWTONPERRAD(15, "NEWTONPERRAD", "N/raD"),

	/**
	 * The '<em><b>KILOGRAM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KILOGRAM_VALUE
	 * @generated
	 * @ordered
	 */
	KILOGRAM(16, "KILOGRAM", "kg"),

	/**
	 * The '<em><b>RADIANSECONSQUAREDPERMETER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RADIANSECONSQUAREDPERMETER_VALUE
	 * @generated
	 * @ordered
	 */
	RADIANSECONSQUAREDPERMETER(17, "RADIANSECONSQUAREDPERMETER", "rads^2/m"),

	/**
	 * The '<em><b>DECIBEL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DECIBEL_VALUE
	 * @generated
	 * @ordered
	 */
	DECIBEL(18, "DECIBEL", "dBr"),

	/**
	 * The '<em><b>CURVATURE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CURVATURE_VALUE
	 * @generated
	 * @ordered
	 */
	CURVATURE(19, "CURVATURE", "1/m"),

	/**
	 * The '<em><b>CURVATURERATE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CURVATURERATE_VALUE
	 * @generated
	 * @ordered
	 */
	CURVATURERATE(20, "CURVATURERATE", "1/m^2"),

	/**
	 * The '<em><b>KILOMETER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KILOMETER_VALUE
	 * @generated
	 * @ordered
	 */
	KILOMETER(21, "KILOMETER", "km"),

	/**
	 * The '<em><b>KILOMETERPERHOUR</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KILOMETERPERHOUR_VALUE
	 * @generated
	 * @ordered
	 */
	KILOMETERPERHOUR(22, "KILOMETERPERHOUR", "km/h"),

	/**
	 * The '<em><b>DEGREE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEGREE_VALUE
	 * @generated
	 * @ordered
	 */
	DEGREE(23, "DEGREE", "deg"),

	/**
	 * The '<em><b>PERCENT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PERCENT_VALUE
	 * @generated
	 * @ordered
	 */
	PERCENT(24, "PERCENT", "%"),

	/**
	 * The '<em><b>MILLISECOND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MILLISECOND_VALUE
	 * @generated
	 * @ordered
	 */
	MILLISECOND(25, "MILLISECOND", "ms"),

	/**
	 * The '<em><b>DECIBELPERSQUAREMETER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DECIBELPERSQUAREMETER_VALUE
	 * @generated
	 * @ordered
	 */
	DECIBELPERSQUAREMETER(26, "DECIBELPERSQUAREMETER", "dBsqm"),

	/**
	 * The '<em><b>DEGREEPERSECOND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEGREEPERSECOND_VALUE
	 * @generated
	 * @ordered
	 */
	DEGREEPERSECOND(27, "DEGREEPERSECOND", "deg/s"),

	/**
	 * The '<em><b>PERCENTPERSECOND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PERCENTPERSECOND_VALUE
	 * @generated
	 * @ordered
	 */
	PERCENTPERSECOND(28, "PERCENTPERSECOND", "%/s"),

	/**
	 * The '<em><b>PIXEL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PIXEL_VALUE
	 * @generated
	 * @ordered
	 */
	PIXEL(29, "PIXEL", "px"),

	/**
	 * The '<em><b>MICROSECOND</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MICROSECOND_VALUE
	 * @generated
	 * @ordered
	 */
	MICROSECOND(30, "MICROSECOND", "us"),

	/**
	 * The '<em><b>BYTE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BYTE_VALUE
	 * @generated
	 * @ordered
	 */
	BYTE(31, "BYTE", "byte"),

	/**
	 * The '<em><b>BIT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BIT_VALUE
	 * @generated
	 * @ordered
	 */
	BIT(32, "BIT", "bit");

	/**
	 * The '<em><b>NOUNIT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NOUNIT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NOUNIT
	 * @model literal="-"
	 * @generated
	 * @ordered
	 */
	public static final int NOUNIT_VALUE = 0;

	/**
	 * The '<em><b>METER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>METER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #METER
	 * @model literal="m"
	 * @generated
	 * @ordered
	 */
	public static final int METER_VALUE = 1;

	/**
	 * The '<em><b>SQUAREMETER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SQUAREMETER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SQUAREMETER
	 * @model literal="m^2"
	 * @generated
	 * @ordered
	 */
	public static final int SQUAREMETER_VALUE = 0;

	/**
	 * The '<em><b>SECOND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SECOND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SECOND
	 * @model literal="s"
	 * @generated
	 * @ordered
	 */
	public static final int SECOND_VALUE = 3;

	/**
	 * The '<em><b>METERPERSECOND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>METERPERSECOND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #METERPERSECOND
	 * @model literal="m/s"
	 * @generated
	 * @ordered
	 */
	public static final int METERPERSECOND_VALUE = 4;

	/**
	 * The '<em><b>METERSQUAREDPERSECONDSQUARED</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>METERSQUAREDPERSECONDSQUARED</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #METERSQUAREDPERSECONDSQUARED
	 * @model literal="(m/s)^2"
	 * @generated
	 * @ordered
	 */
	public static final int METERSQUAREDPERSECONDSQUARED_VALUE = 5;

	/**
	 * The '<em><b>METERPERSECONDSQUARED</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>METERPERSECONDSQUARED</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #METERPERSECONDSQUARED
	 * @model literal="m/s^2"
	 * @generated
	 * @ordered
	 */
	public static final int METERPERSECONDSQUARED_VALUE = 6;

	/**
	 * The '<em><b>METERPERSECONDCUBED</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>METERPERSECONDCUBED</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #METERPERSECONDCUBED
	 * @model literal="m/s^3"
	 * @generated
	 * @ordered
	 */
	public static final int METERPERSECONDCUBED_VALUE = 7;

	/**
	 * The '<em><b>METERPERSECONDSQUAREDSQUARED</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>METERPERSECONDSQUAREDSQUARED</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #METERPERSECONDSQUAREDSQUARED
	 * @model literal="(m/s^2)^2"
	 * @generated
	 * @ordered
	 */
	public static final int METERPERSECONDSQUAREDSQUARED_VALUE = 8;

	/**
	 * The '<em><b>RADIAN</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RADIAN</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RADIAN
	 * @model literal="rad"
	 * @generated
	 * @ordered
	 */
	public static final int RADIAN_VALUE = 9;

	/**
	 * The '<em><b>RADIANPERSECOND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RADIANPERSECOND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RADIANPERSECOND
	 * @model literal="rad/s"
	 * @generated
	 * @ordered
	 */
	public static final int RADIANPERSECOND_VALUE = 10;

	/**
	 * The '<em><b>RADIANPERSECONDSQUARED</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RADIANPERSECONDSQUARED</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RADIANPERSECONDSQUARED
	 * @model literal="(rad/s)^2"
	 * @generated
	 * @ordered
	 */
	public static final int RADIANPERSECONDSQUARED_VALUE = 11;

	/**
	 * The '<em><b>NEWTON</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NEWTON</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NEWTON
	 * @model literal="N"
	 * @generated
	 * @ordered
	 */
	public static final int NEWTON_VALUE = 12;

	/**
	 * The '<em><b>DEGREECENTIGRADE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DEGREECENTIGRADE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DEGREECENTIGRADE
	 * @model literal="degC"
	 * @generated
	 * @ordered
	 */
	public static final int DEGREECENTIGRADE_VALUE = 13;

	/**
	 * The '<em><b>NEWTONMETER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NEWTONMETER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NEWTONMETER
	 * @model literal="Nm"
	 * @generated
	 * @ordered
	 */
	public static final int NEWTONMETER_VALUE = 14;

	/**
	 * The '<em><b>NEWTONPERRAD</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NEWTONPERRAD</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NEWTONPERRAD
	 * @model literal="N/raD"
	 * @generated
	 * @ordered
	 */
	public static final int NEWTONPERRAD_VALUE = 15;

	/**
	 * The '<em><b>KILOGRAM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>KILOGRAM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #KILOGRAM
	 * @model literal="kg"
	 * @generated
	 * @ordered
	 */
	public static final int KILOGRAM_VALUE = 16;

	/**
	 * The '<em><b>RADIANSECONSQUAREDPERMETER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RADIANSECONSQUAREDPERMETER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RADIANSECONSQUAREDPERMETER
	 * @model literal="rads^2/m"
	 * @generated
	 * @ordered
	 */
	public static final int RADIANSECONSQUAREDPERMETER_VALUE = 17;

	/**
	 * The '<em><b>DECIBEL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DECIBEL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DECIBEL
	 * @model literal="dBr"
	 * @generated
	 * @ordered
	 */
	public static final int DECIBEL_VALUE = 18;

	/**
	 * The '<em><b>CURVATURE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CURVATURE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CURVATURE
	 * @model literal="1/m"
	 * @generated
	 * @ordered
	 */
	public static final int CURVATURE_VALUE = 19;

	/**
	 * The '<em><b>CURVATURERATE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CURVATURERATE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CURVATURERATE
	 * @model literal="1/m^2"
	 * @generated
	 * @ordered
	 */
	public static final int CURVATURERATE_VALUE = 20;

	/**
	 * The '<em><b>KILOMETER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>KILOMETER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #KILOMETER
	 * @model literal="km"
	 * @generated
	 * @ordered
	 */
	public static final int KILOMETER_VALUE = 21;

	/**
	 * The '<em><b>KILOMETERPERHOUR</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>KILOMETERPERHOUR</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #KILOMETERPERHOUR
	 * @model literal="km/h"
	 * @generated
	 * @ordered
	 */
	public static final int KILOMETERPERHOUR_VALUE = 22;

	/**
	 * The '<em><b>DEGREE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DEGREE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DEGREE
	 * @model literal="deg"
	 * @generated
	 * @ordered
	 */
	public static final int DEGREE_VALUE = 23;

	/**
	 * The '<em><b>PERCENT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>PERCENT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PERCENT
	 * @model literal="%"
	 * @generated
	 * @ordered
	 */
	public static final int PERCENT_VALUE = 24;

	/**
	 * The '<em><b>MILLISECOND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>MILLISECOND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MILLISECOND
	 * @model literal="ms"
	 * @generated
	 * @ordered
	 */
	public static final int MILLISECOND_VALUE = 25;

	/**
	 * The '<em><b>DECIBELPERSQUAREMETER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DECIBELPERSQUAREMETER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DECIBELPERSQUAREMETER
	 * @model literal="dBsqm"
	 * @generated
	 * @ordered
	 */
	public static final int DECIBELPERSQUAREMETER_VALUE = 26;

	/**
	 * The '<em><b>DEGREEPERSECOND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DEGREEPERSECOND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DEGREEPERSECOND
	 * @model literal="deg/s"
	 * @generated
	 * @ordered
	 */
	public static final int DEGREEPERSECOND_VALUE = 27;

	/**
	 * The '<em><b>PERCENTPERSECOND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>PERCENTPERSECOND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PERCENTPERSECOND
	 * @model literal="%/s"
	 * @generated
	 * @ordered
	 */
	public static final int PERCENTPERSECOND_VALUE = 28;

	/**
	 * The '<em><b>PIXEL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>PIXEL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PIXEL
	 * @model literal="px"
	 * @generated
	 * @ordered
	 */
	public static final int PIXEL_VALUE = 29;

	/**
	 * The '<em><b>MICROSECOND</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>MICROSECOND</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MICROSECOND
	 * @model literal="us"
	 * @generated
	 * @ordered
	 */
	public static final int MICROSECOND_VALUE = 30;

	/**
	 * The '<em><b>BYTE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>BYTE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BYTE
	 * @model literal="byte"
	 * @generated
	 * @ordered
	 */
	public static final int BYTE_VALUE = 31;

	/**
	 * The '<em><b>BIT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>BIT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BIT
	 * @model literal="bit"
	 * @generated
	 * @ordered
	 */
	public static final int BIT_VALUE = 32;

	/**
	 * An array of all the '<em><b>Physical Unit Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final PhysicalUnitEnum[] VALUES_ARRAY =
		new PhysicalUnitEnum[] {
			NOUNIT,
			METER,
			SQUAREMETER,
			SECOND,
			METERPERSECOND,
			METERSQUAREDPERSECONDSQUARED,
			METERPERSECONDSQUARED,
			METERPERSECONDCUBED,
			METERPERSECONDSQUAREDSQUARED,
			RADIAN,
			RADIANPERSECOND,
			RADIANPERSECONDSQUARED,
			NEWTON,
			DEGREECENTIGRADE,
			NEWTONMETER,
			NEWTONPERRAD,
			KILOGRAM,
			RADIANSECONSQUAREDPERMETER,
			DECIBEL,
			CURVATURE,
			CURVATURERATE,
			KILOMETER,
			KILOMETERPERHOUR,
			DEGREE,
			PERCENT,
			MILLISECOND,
			DECIBELPERSQUAREMETER,
			DEGREEPERSECOND,
			PERCENTPERSECOND,
			PIXEL,
			MICROSECOND,
			BYTE,
			BIT,
		};

	/**
	 * A public read-only list of all the '<em><b>Physical Unit Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<PhysicalUnitEnum> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Physical Unit Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PhysicalUnitEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PhysicalUnitEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Physical Unit Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PhysicalUnitEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PhysicalUnitEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Physical Unit Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PhysicalUnitEnum get(int value) {
		switch (value) {
			case NOUNIT_VALUE: return NOUNIT;
			case METER_VALUE: return METER;
			case SECOND_VALUE: return SECOND;
			case METERPERSECOND_VALUE: return METERPERSECOND;
			case METERSQUAREDPERSECONDSQUARED_VALUE: return METERSQUAREDPERSECONDSQUARED;
			case METERPERSECONDSQUARED_VALUE: return METERPERSECONDSQUARED;
			case METERPERSECONDCUBED_VALUE: return METERPERSECONDCUBED;
			case METERPERSECONDSQUAREDSQUARED_VALUE: return METERPERSECONDSQUAREDSQUARED;
			case RADIAN_VALUE: return RADIAN;
			case RADIANPERSECOND_VALUE: return RADIANPERSECOND;
			case RADIANPERSECONDSQUARED_VALUE: return RADIANPERSECONDSQUARED;
			case NEWTON_VALUE: return NEWTON;
			case DEGREECENTIGRADE_VALUE: return DEGREECENTIGRADE;
			case NEWTONMETER_VALUE: return NEWTONMETER;
			case NEWTONPERRAD_VALUE: return NEWTONPERRAD;
			case KILOGRAM_VALUE: return KILOGRAM;
			case RADIANSECONSQUAREDPERMETER_VALUE: return RADIANSECONSQUAREDPERMETER;
			case DECIBEL_VALUE: return DECIBEL;
			case CURVATURE_VALUE: return CURVATURE;
			case CURVATURERATE_VALUE: return CURVATURERATE;
			case KILOMETER_VALUE: return KILOMETER;
			case KILOMETERPERHOUR_VALUE: return KILOMETERPERHOUR;
			case DEGREE_VALUE: return DEGREE;
			case PERCENT_VALUE: return PERCENT;
			case MILLISECOND_VALUE: return MILLISECOND;
			case DECIBELPERSQUAREMETER_VALUE: return DECIBELPERSQUAREMETER;
			case DEGREEPERSECOND_VALUE: return DEGREEPERSECOND;
			case PERCENTPERSECOND_VALUE: return PERCENTPERSECOND;
			case PIXEL_VALUE: return PIXEL;
			case MICROSECOND_VALUE: return MICROSECOND;
			case BYTE_VALUE: return BYTE;
			case BIT_VALUE: return BIT;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private PhysicalUnitEnum(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //PhysicalUnitEnum
