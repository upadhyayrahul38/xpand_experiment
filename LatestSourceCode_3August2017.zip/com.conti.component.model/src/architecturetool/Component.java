/**
 */
package architecturetool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.Component#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.Component#getSubcomponent <em>Subcomponent</em>}</li>
 *   <li>{@link architecturetool.Component#isExternalStaticMemUsed <em>External Static Mem Used</em>}</li>
 *   <li>{@link architecturetool.Component#getPorts <em>Ports</em>}</li>
 *   <li>{@link architecturetool.Component#getRunnables <em>Runnables</em>}</li>
 *   <li>{@link architecturetool.Component#getGenerator <em>Generator</em>}</li>
 *   <li>{@link architecturetool.Component#getFlows <em>Flows</em>}</li>
 *   <li>{@link architecturetool.Component#getParameters <em>Parameters</em>}</li>
 *   <li>{@link architecturetool.Component#getProcmem <em>Procmem</em>}</li>
 *   <li>{@link architecturetool.Component#getDataStructureName <em>Data Structure Name</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getComponent()
 * @model
 * @generated
 */
public interface Component extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link architecturetool.Component#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Subcomponent</b></em>' containment reference list.
	 * The list contents are of type {@link architecturetool.SubComponent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subcomponent</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subcomponent</em>' containment reference list.
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Subcomponent()
	 * @model containment="true"
	 * @generated
	 */
	EList<SubComponent> getSubcomponent();

	/**
	 * Returns the value of the '<em><b>External Static Mem Used</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>External Static Mem Used</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>External Static Mem Used</em>' attribute.
	 * @see #setExternalStaticMemUsed(boolean)
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_ExternalStaticMemUsed()
	 * @model
	 * @generated
	 */
	boolean isExternalStaticMemUsed();

	/**
	 * Sets the value of the '{@link architecturetool.Component#isExternalStaticMemUsed <em>External Static Mem Used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>External Static Mem Used</em>' attribute.
	 * @see #isExternalStaticMemUsed()
	 * @generated
	 */
	void setExternalStaticMemUsed(boolean value);
	
	/**
	 * @generated NOT
	 * @return Boolean
	 */
	boolean getExternalStaticMemUsed();

	/**
	 * Returns the value of the '<em><b>Ports</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ports</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ports</em>' containment reference.
	 * @see #setPorts(Ports)
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Ports()
	 * @model containment="true"
	 * @generated
	 */
	Ports getPorts();

	/**
	 * Sets the value of the '{@link architecturetool.Component#getPorts <em>Ports</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ports</em>' containment reference.
	 * @see #getPorts()
	 * @generated
	 */
	void setPorts(Ports value);

	/**
	 * Returns the value of the '<em><b>Runnables</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Runnables</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Runnables</em>' containment reference.
	 * @see #setRunnables(Runnables)
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Runnables()
	 * @model containment="true"
	 * @generated
	 */
	Runnables getRunnables();

	/**
	 * Sets the value of the '{@link architecturetool.Component#getRunnables <em>Runnables</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Runnables</em>' containment reference.
	 * @see #getRunnables()
	 * @generated
	 */
	void setRunnables(Runnables value);

	/**
	 * Returns the value of the '<em><b>Generator</b></em>' containment reference list.
	 * The list contents are of type {@link architecturetool.Generator}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Generator</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Generator</em>' containment reference list.
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Generator()
	 * @model containment="true"
	 * @generated
	 */
	EList<Generator> getGenerator();

	/**
	 * Returns the value of the '<em><b>Flows</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Flows</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Flows</em>' containment reference.
	 * @see #setFlows(Flows)
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Flows()
	 * @model containment="true"
	 * @generated
	 */
	Flows getFlows();

	/**
	 * Sets the value of the '{@link architecturetool.Component#getFlows <em>Flows</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Flows</em>' containment reference.
	 * @see #getFlows()
	 * @generated
	 */
	void setFlows(Flows value);

	/**
	 * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link architecturetool.Parameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameters</em>' containment reference list.
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Parameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<Parameter> getParameters();

	/**
	 * Returns the value of the '<em><b>Procmem</b></em>' containment reference list.
	 * The list contents are of type {@link architecturetool.ProcMem}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Procmem</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Procmem</em>' containment reference list.
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_Procmem()
	 * @model containment="true"
	 * @generated
	 */
	EList<ProcMem> getProcmem();

	/**
	 * Returns the value of the '<em><b>Data Structure Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Structure Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Structure Name</em>' attribute.
	 * @see #setDataStructureName(String)
	 * @see architecturetool.ArchitecturetoolPackage#getComponent_DataStructureName()
	 * @model
	 * @generated
	 */
	String getDataStructureName();

	/**
	 * Sets the value of the '{@link architecturetool.Component#getDataStructureName <em>Data Structure Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Structure Name</em>' attribute.
	 * @see #getDataStructureName()
	 * @generated
	 */
	void setDataStructureName(String value);

} // Component
