/**
 */
package architecturetool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Flow</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.Flow#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.Flow#getValue <em>Value</em>}</li>
 *   <li>{@link architecturetool.Flow#getRequestPort <em>Request Port</em>}</li>
 *   <li>{@link architecturetool.Flow#getProviderPort <em>Provider Port</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getFlow()
 * @model
 * @generated
 */
public interface Flow extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see architecturetool.ArchitecturetoolPackage#getFlow_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link architecturetool.Flow#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(int)
	 * @see architecturetool.ArchitecturetoolPackage#getFlow_Value()
	 * @model
	 * @generated
	 */
	int getValue();

	/**
	 * Sets the value of the '{@link architecturetool.Flow#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(int value);

	/**
	 * Returns the value of the '<em><b>Request Port</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Request Port</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Request Port</em>' reference.
	 * @see #setRequestPort(Port)
	 * @see architecturetool.ArchitecturetoolPackage#getFlow_RequestPort()
	 * @model
	 * @generated
	 */
	Port getRequestPort();

	/**
	 * Sets the value of the '{@link architecturetool.Flow#getRequestPort <em>Request Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Request Port</em>' reference.
	 * @see #getRequestPort()
	 * @generated
	 */
	void setRequestPort(Port value);

	/**
	 * Returns the value of the '<em><b>Provider Port</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provider Port</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provider Port</em>' reference.
	 * @see #setProviderPort(Port)
	 * @see architecturetool.ArchitecturetoolPackage#getFlow_ProviderPort()
	 * @model
	 * @generated
	 */
	Port getProviderPort();

	/**
	 * Sets the value of the '{@link architecturetool.Flow#getProviderPort <em>Provider Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Provider Port</em>' reference.
	 * @see #getProviderPort()
	 * @generated
	 */
	void setProviderPort(Port value);

} // Flow
