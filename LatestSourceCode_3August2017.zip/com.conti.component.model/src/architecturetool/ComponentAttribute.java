/**
 */
package architecturetool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.ComponentAttribute#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.ComponentAttribute#getDescription <em>Description</em>}</li>
 *   <li>{@link architecturetool.ComponentAttribute#getTypeAccuracy <em>Type Accuracy</em>}</li>
 *   <li>{@link architecturetool.ComponentAttribute#getArraySize <em>Array Size</em>}</li>
 *   <li>{@link architecturetool.ComponentAttribute#getPhysicalUnit <em>Physical Unit</em>}</li>
 *   <li>{@link architecturetool.ComponentAttribute#getAccuracy <em>Accuracy</em>}</li>
 *   <li>{@link architecturetool.ComponentAttribute#getInterfaceVersion <em>Interface Version</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute()
 * @model
 * @generated
 */
public interface ComponentAttribute extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link architecturetool.ComponentAttribute#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute_Description()
	 * @model required="true"
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link architecturetool.ComponentAttribute#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Type Accuracy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type Accuracy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type Accuracy</em>' attribute.
	 * @see #setTypeAccuracy(float)
	 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute_TypeAccuracy()
	 * @model
	 * @generated
	 */
	float getTypeAccuracy();

	/**
	 * Sets the value of the '{@link architecturetool.ComponentAttribute#getTypeAccuracy <em>Type Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type Accuracy</em>' attribute.
	 * @see #getTypeAccuracy()
	 * @generated
	 */
	void setTypeAccuracy(float value);

	/**
	 * Returns the value of the '<em><b>Array Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Array Size</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Array Size</em>' attribute.
	 * @see #setArraySize(int)
	 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute_ArraySize()
	 * @model id="true"
	 * @generated
	 */
	int getArraySize();

	/**
	 * Sets the value of the '{@link architecturetool.ComponentAttribute#getArraySize <em>Array Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Array Size</em>' attribute.
	 * @see #getArraySize()
	 * @generated
	 */
	void setArraySize(int value);

	/**
	 * Returns the value of the '<em><b>Physical Unit</b></em>' attribute.
	 * The literals are from the enumeration {@link architecturetool.PhysicalUnitEnum}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Physical Unit</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Physical Unit</em>' attribute.
	 * @see architecturetool.PhysicalUnitEnum
	 * @see #setPhysicalUnit(PhysicalUnitEnum)
	 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute_PhysicalUnit()
	 * @model
	 * @generated
	 */
	PhysicalUnitEnum getPhysicalUnit();

	/**
	 * Sets the value of the '{@link architecturetool.ComponentAttribute#getPhysicalUnit <em>Physical Unit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Physical Unit</em>' attribute.
	 * @see architecturetool.PhysicalUnitEnum
	 * @see #getPhysicalUnit()
	 * @generated
	 */
	void setPhysicalUnit(PhysicalUnitEnum value);

	/**
	 * Returns the value of the '<em><b>Accuracy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Accuracy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Accuracy</em>' attribute.
	 * @see #setAccuracy(float)
	 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute_Accuracy()
	 * @model
	 * @generated
	 */
	float getAccuracy();

	/**
	 * Sets the value of the '{@link architecturetool.ComponentAttribute#getAccuracy <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Accuracy</em>' attribute.
	 * @see #getAccuracy()
	 * @generated
	 */
	void setAccuracy(float value);

	/**
	 * Returns the value of the '<em><b>Interface Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interface Version</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interface Version</em>' attribute.
	 * @see #setInterfaceVersion(int)
	 * @see architecturetool.ArchitecturetoolPackage#getComponentAttribute_InterfaceVersion()
	 * @model
	 * @generated
	 */
	int getInterfaceVersion();

	/**
	 * Sets the value of the '{@link architecturetool.ComponentAttribute#getInterfaceVersion <em>Interface Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interface Version</em>' attribute.
	 * @see #getInterfaceVersion()
	 * @generated
	 */
	void setInterfaceVersion(int value);

} // ComponentAttribute
