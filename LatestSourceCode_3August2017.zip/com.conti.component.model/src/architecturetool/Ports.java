/**
 */
package architecturetool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ports</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.Ports#getPort <em>Port</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getPorts()
 * @model
 * @generated
 */
public interface Ports extends EObject {
	/**
	 * Returns the value of the '<em><b>Port</b></em>' containment reference list.
	 * The list contents are of type {@link architecturetool.Port}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Port</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' containment reference list.
	 * @see architecturetool.ArchitecturetoolPackage#getPorts_Port()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Port> getPort();

} // Ports
