/**
 */
package architecturetool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Flows</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.Flows#getFlow <em>Flow</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getFlows()
 * @model
 * @generated
 */
public interface Flows extends EObject {
	/**
	 * Returns the value of the '<em><b>Flow</b></em>' containment reference list.
	 * The list contents are of type {@link architecturetool.Flow}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Flow</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Flow</em>' containment reference list.
	 * @see architecturetool.ArchitecturetoolPackage#getFlows_Flow()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Flow> getFlow();

} // Flows
