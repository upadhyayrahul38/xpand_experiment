/**
 */
package architecturetool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Proc Mem Safety</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see architecturetool.ArchitecturetoolPackage#getProcMem_Safety()
 * @model
 * @generated
 */
public enum ProcMem_Safety implements Enumerator {
	/**
	 * The '<em><b>QM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #QM_VALUE
	 * @generated
	 * @ordered
	 */
	QM(0, "QM", "QM"),

	/**
	 * The '<em><b>ASILA</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ASILA_VALUE
	 * @generated
	 * @ordered
	 */
	ASILA(1, "ASILA", "ASILA"), /**
	 * The '<em><b>ASILB</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ASILB_VALUE
	 * @generated
	 * @ordered
	 */
	ASILB(2, "ASILB", "ASILB"), /**
	 * The '<em><b>ASILC</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ASILC_VALUE
	 * @generated
	 * @ordered
	 */
	ASILC(3, "ASILC", "ASILC"), /**
	 * The '<em><b>ASILD</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ASILD_VALUE
	 * @generated
	 * @ordered
	 */
	ASILD(4, "ASILD", "ASILD");

	/**
	 * The '<em><b>QM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>QM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #QM
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int QM_VALUE = 0;

	/**
	 * The '<em><b>ASILA</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ASILA</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ASILA
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ASILA_VALUE = 1;

	/**
	 * The '<em><b>ASILB</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ASILB</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ASILB
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ASILB_VALUE = 2;

	/**
	 * The '<em><b>ASILC</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ASILC</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ASILC
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ASILC_VALUE = 3;

	/**
	 * The '<em><b>ASILD</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ASILD</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ASILD
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ASILD_VALUE = 4;

	/**
	 * An array of all the '<em><b>Proc Mem Safety</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final ProcMem_Safety[] VALUES_ARRAY =
		new ProcMem_Safety[] {
			QM,
			ASILA,
			ASILB,
			ASILC,
			ASILD,
		};

	/**
	 * A public read-only list of all the '<em><b>Proc Mem Safety</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<ProcMem_Safety> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Proc Mem Safety</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ProcMem_Safety get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ProcMem_Safety result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Proc Mem Safety</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ProcMem_Safety getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ProcMem_Safety result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Proc Mem Safety</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ProcMem_Safety get(int value) {
		switch (value) {
			case QM_VALUE: return QM;
			case ASILA_VALUE: return ASILA;
			case ASILB_VALUE: return ASILB;
			case ASILC_VALUE: return ASILC;
			case ASILD_VALUE: return ASILD;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ProcMem_Safety(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //ProcMem_Safety
