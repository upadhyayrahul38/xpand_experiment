/**
 */
package architecturetool.impl;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Flow;
import architecturetool.Port;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Flow</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.FlowImpl#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.impl.FlowImpl#getValue <em>Value</em>}</li>
 *   <li>{@link architecturetool.impl.FlowImpl#getRequestPort <em>Request Port</em>}</li>
 *   <li>{@link architecturetool.impl.FlowImpl#getProviderPort <em>Provider Port</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FlowImpl extends MinimalEObjectImpl.Container implements Flow {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected static final int VALUE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected int value = VALUE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRequestPort() <em>Request Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequestPort()
	 * @generated
	 * @ordered
	 */
	protected Port requestPort;

	/**
	 * The cached value of the '{@link #getProviderPort() <em>Provider Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProviderPort()
	 * @generated
	 * @ordered
	 */
	protected Port providerPort;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FlowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.FLOW;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.FLOW__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(int newValue) {
		int oldValue = value;
		value = newValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.FLOW__VALUE, oldValue, value));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port getRequestPort() {
		if (requestPort != null && requestPort.eIsProxy()) {
			InternalEObject oldRequestPort = (InternalEObject)requestPort;
			requestPort = (Port)eResolveProxy(oldRequestPort);
			if (requestPort != oldRequestPort) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ArchitecturetoolPackage.FLOW__REQUEST_PORT, oldRequestPort, requestPort));
			}
		}
		return requestPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port basicGetRequestPort() {
		return requestPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRequestPort(Port newRequestPort) {
		Port oldRequestPort = requestPort;
		requestPort = newRequestPort;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.FLOW__REQUEST_PORT, oldRequestPort, requestPort));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port getProviderPort() {
		if (providerPort != null && providerPort.eIsProxy()) {
			InternalEObject oldProviderPort = (InternalEObject)providerPort;
			providerPort = (Port)eResolveProxy(oldProviderPort);
			if (providerPort != oldProviderPort) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ArchitecturetoolPackage.FLOW__PROVIDER_PORT, oldProviderPort, providerPort));
			}
		}
		return providerPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port basicGetProviderPort() {
		return providerPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProviderPort(Port newProviderPort) {
		Port oldProviderPort = providerPort;
		providerPort = newProviderPort;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.FLOW__PROVIDER_PORT, oldProviderPort, providerPort));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.FLOW__NAME:
				return getName();
			case ArchitecturetoolPackage.FLOW__VALUE:
				return getValue();
			case ArchitecturetoolPackage.FLOW__REQUEST_PORT:
				if (resolve) return getRequestPort();
				return basicGetRequestPort();
			case ArchitecturetoolPackage.FLOW__PROVIDER_PORT:
				if (resolve) return getProviderPort();
				return basicGetProviderPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.FLOW__NAME:
				setName((String)newValue);
				return;
			case ArchitecturetoolPackage.FLOW__VALUE:
				setValue((Integer)newValue);
				return;
			case ArchitecturetoolPackage.FLOW__REQUEST_PORT:
				setRequestPort((Port)newValue);
				return;
			case ArchitecturetoolPackage.FLOW__PROVIDER_PORT:
				setProviderPort((Port)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.FLOW__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ArchitecturetoolPackage.FLOW__VALUE:
				setValue(VALUE_EDEFAULT);
				return;
			case ArchitecturetoolPackage.FLOW__REQUEST_PORT:
				setRequestPort((Port)null);
				return;
			case ArchitecturetoolPackage.FLOW__PROVIDER_PORT:
				setProviderPort((Port)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.FLOW__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ArchitecturetoolPackage.FLOW__VALUE:
				return value != VALUE_EDEFAULT;
			case ArchitecturetoolPackage.FLOW__REQUEST_PORT:
				return requestPort != null;
			case ArchitecturetoolPackage.FLOW__PROVIDER_PORT:
				return providerPort != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", value: ");
		result.append(value);
		result.append(')');
		return result.toString();
	}

} //FlowImpl
