/**
 */
package architecturetool.impl;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.ProcMem;

import architecturetool.ProcMem_AccessSpeed;
import architecturetool.ProcMem_Cycle;
import architecturetool.ProcMem_Safety;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Proc Mem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.ProcMemImpl#getSafetyEnum <em>Safety Enum</em>}</li>
 *   <li>{@link architecturetool.impl.ProcMemImpl#getAccessSpeedEnum <em>Access Speed Enum</em>}</li>
 *   <li>{@link architecturetool.impl.ProcMemImpl#getCycleEnum <em>Cycle Enum</em>}</li>
 *   <li>{@link architecturetool.impl.ProcMemImpl#getBudget <em>Budget</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ProcMemImpl extends MinimalEObjectImpl.Container implements ProcMem {
	/**
	 * The default value of the '{@link #getSafetyEnum() <em>Safety Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafetyEnum()
	 * @generated
	 * @ordered
	 */
	protected static final ProcMem_Safety SAFETY_ENUM_EDEFAULT = ProcMem_Safety.QM;
	/**
	 * The cached value of the '{@link #getSafetyEnum() <em>Safety Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafetyEnum()
	 * @generated
	 * @ordered
	 */
	protected ProcMem_Safety safetyEnum = SAFETY_ENUM_EDEFAULT;
	/**
	 * The default value of the '{@link #getAccessSpeedEnum() <em>Access Speed Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessSpeedEnum()
	 * @generated
	 * @ordered
	 */
	protected static final ProcMem_AccessSpeed ACCESS_SPEED_ENUM_EDEFAULT = ProcMem_AccessSpeed.SLOW;
	/**
	 * The cached value of the '{@link #getAccessSpeedEnum() <em>Access Speed Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessSpeedEnum()
	 * @generated
	 * @ordered
	 */
	protected ProcMem_AccessSpeed accessSpeedEnum = ACCESS_SPEED_ENUM_EDEFAULT;
	/**
	 * The default value of the '{@link #getCycleEnum() <em>Cycle Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCycleEnum()
	 * @generated
	 * @ordered
	 */
	protected static final ProcMem_Cycle CYCLE_ENUM_EDEFAULT = ProcMem_Cycle.INTRA_CYCLE;
	/**
	 * The cached value of the '{@link #getCycleEnum() <em>Cycle Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCycleEnum()
	 * @generated
	 * @ordered
	 */
	protected ProcMem_Cycle cycleEnum = CYCLE_ENUM_EDEFAULT;
	/**
	 * The default value of the '{@link #getBudget() <em>Budget</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBudget()
	 * @generated
	 * @ordered
	 */
	protected static final String BUDGET_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getBudget() <em>Budget</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBudget()
	 * @generated
	 * @ordered
	 */
	protected String budget = BUDGET_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProcMemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.PROC_MEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcMem_Safety getSafetyEnum() {
		return safetyEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSafetyEnum(ProcMem_Safety newSafetyEnum) {
		ProcMem_Safety oldSafetyEnum = safetyEnum;
		safetyEnum = newSafetyEnum == null ? SAFETY_ENUM_EDEFAULT : newSafetyEnum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PROC_MEM__SAFETY_ENUM, oldSafetyEnum, safetyEnum));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcMem_AccessSpeed getAccessSpeedEnum() {
		return accessSpeedEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAccessSpeedEnum(ProcMem_AccessSpeed newAccessSpeedEnum) {
		ProcMem_AccessSpeed oldAccessSpeedEnum = accessSpeedEnum;
		accessSpeedEnum = newAccessSpeedEnum == null ? ACCESS_SPEED_ENUM_EDEFAULT : newAccessSpeedEnum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PROC_MEM__ACCESS_SPEED_ENUM, oldAccessSpeedEnum, accessSpeedEnum));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcMem_Cycle getCycleEnum() {
		return cycleEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCycleEnum(ProcMem_Cycle newCycleEnum) {
		ProcMem_Cycle oldCycleEnum = cycleEnum;
		cycleEnum = newCycleEnum == null ? CYCLE_ENUM_EDEFAULT : newCycleEnum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PROC_MEM__CYCLE_ENUM, oldCycleEnum, cycleEnum));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBudget() {
		return budget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBudget(String newBudget) {
		String oldBudget = budget;
		budget = newBudget;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PROC_MEM__BUDGET, oldBudget, budget));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.PROC_MEM__SAFETY_ENUM:
				return getSafetyEnum();
			case ArchitecturetoolPackage.PROC_MEM__ACCESS_SPEED_ENUM:
				return getAccessSpeedEnum();
			case ArchitecturetoolPackage.PROC_MEM__CYCLE_ENUM:
				return getCycleEnum();
			case ArchitecturetoolPackage.PROC_MEM__BUDGET:
				return getBudget();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.PROC_MEM__SAFETY_ENUM:
				setSafetyEnum((ProcMem_Safety)newValue);
				return;
			case ArchitecturetoolPackage.PROC_MEM__ACCESS_SPEED_ENUM:
				setAccessSpeedEnum((ProcMem_AccessSpeed)newValue);
				return;
			case ArchitecturetoolPackage.PROC_MEM__CYCLE_ENUM:
				setCycleEnum((ProcMem_Cycle)newValue);
				return;
			case ArchitecturetoolPackage.PROC_MEM__BUDGET:
				setBudget((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.PROC_MEM__SAFETY_ENUM:
				setSafetyEnum(SAFETY_ENUM_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PROC_MEM__ACCESS_SPEED_ENUM:
				setAccessSpeedEnum(ACCESS_SPEED_ENUM_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PROC_MEM__CYCLE_ENUM:
				setCycleEnum(CYCLE_ENUM_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PROC_MEM__BUDGET:
				setBudget(BUDGET_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.PROC_MEM__SAFETY_ENUM:
				return safetyEnum != SAFETY_ENUM_EDEFAULT;
			case ArchitecturetoolPackage.PROC_MEM__ACCESS_SPEED_ENUM:
				return accessSpeedEnum != ACCESS_SPEED_ENUM_EDEFAULT;
			case ArchitecturetoolPackage.PROC_MEM__CYCLE_ENUM:
				return cycleEnum != CYCLE_ENUM_EDEFAULT;
			case ArchitecturetoolPackage.PROC_MEM__BUDGET:
				return BUDGET_EDEFAULT == null ? budget != null : !BUDGET_EDEFAULT.equals(budget);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (SafetyEnum: ");
		result.append(safetyEnum);
		result.append(", AccessSpeedEnum: ");
		result.append(accessSpeedEnum);
		result.append(", CycleEnum: ");
		result.append(cycleEnum);
		result.append(", Budget: ");
		result.append(budget);
		result.append(')');
		return result.toString();
	}

} //ProcMemImpl
