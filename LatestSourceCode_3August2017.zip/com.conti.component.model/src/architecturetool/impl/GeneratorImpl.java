/**
 */
package architecturetool.impl;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.DataStructure;
import architecturetool.Generator;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Generator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.GeneratorImpl#getDatastructure <em>Datastructure</em>}</li>
 *   <li>{@link architecturetool.impl.GeneratorImpl#getEnum <em>Enum</em>}</li>
 *   <li>{@link architecturetool.impl.GeneratorImpl#getAttribute <em>Attribute</em>}</li>
 *   <li>{@link architecturetool.impl.GeneratorImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GeneratorImpl extends MinimalEObjectImpl.Container implements Generator {
	/**
	 * The cached value of the '{@link #getDatastructure() <em>Datastructure</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatastructure()
	 * @generated
	 * @ordered
	 */
	protected EList<DataStructure> datastructure;

	/**
	 * The cached value of the '{@link #getEnum() <em>Enum</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnum()
	 * @generated
	 * @ordered
	 */
	protected EList<architecturetool.Enum> enum_;

	/**
	 * The cached value of the '{@link #getAttribute() <em>Attribute</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttribute()
	 * @generated
	 * @ordered
	 */
	protected EList<Attribute> attribute;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GeneratorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.GENERATOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataStructure> getDatastructure() {
		if (datastructure == null) {
			datastructure = new EObjectContainmentEList<DataStructure>(DataStructure.class, this, ArchitecturetoolPackage.GENERATOR__DATASTRUCTURE);
		}
		return datastructure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<architecturetool.Enum> getEnum() {
		if (enum_ == null) {
			enum_ = new EObjectContainmentEList<architecturetool.Enum>(architecturetool.Enum.class, this, ArchitecturetoolPackage.GENERATOR__ENUM);
		}
		return enum_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Attribute> getAttribute() {
		if (attribute == null) {
			attribute = new EObjectContainmentEList<Attribute>(Attribute.class, this, ArchitecturetoolPackage.GENERATOR__ATTRIBUTE);
		}
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.GENERATOR__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ArchitecturetoolPackage.GENERATOR__DATASTRUCTURE:
				return ((InternalEList<?>)getDatastructure()).basicRemove(otherEnd, msgs);
			case ArchitecturetoolPackage.GENERATOR__ENUM:
				return ((InternalEList<?>)getEnum()).basicRemove(otherEnd, msgs);
			case ArchitecturetoolPackage.GENERATOR__ATTRIBUTE:
				return ((InternalEList<?>)getAttribute()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.GENERATOR__DATASTRUCTURE:
				return getDatastructure();
			case ArchitecturetoolPackage.GENERATOR__ENUM:
				return getEnum();
			case ArchitecturetoolPackage.GENERATOR__ATTRIBUTE:
				return getAttribute();
			case ArchitecturetoolPackage.GENERATOR__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.GENERATOR__DATASTRUCTURE:
				getDatastructure().clear();
				getDatastructure().addAll((Collection<? extends DataStructure>)newValue);
				return;
			case ArchitecturetoolPackage.GENERATOR__ENUM:
				getEnum().clear();
				getEnum().addAll((Collection<? extends architecturetool.Enum>)newValue);
				return;
			case ArchitecturetoolPackage.GENERATOR__ATTRIBUTE:
				getAttribute().clear();
				getAttribute().addAll((Collection<? extends Attribute>)newValue);
				return;
			case ArchitecturetoolPackage.GENERATOR__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.GENERATOR__DATASTRUCTURE:
				getDatastructure().clear();
				return;
			case ArchitecturetoolPackage.GENERATOR__ENUM:
				getEnum().clear();
				return;
			case ArchitecturetoolPackage.GENERATOR__ATTRIBUTE:
				getAttribute().clear();
				return;
			case ArchitecturetoolPackage.GENERATOR__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.GENERATOR__DATASTRUCTURE:
				return datastructure != null && !datastructure.isEmpty();
			case ArchitecturetoolPackage.GENERATOR__ENUM:
				return enum_ != null && !enum_.isEmpty();
			case ArchitecturetoolPackage.GENERATOR__ATTRIBUTE:
				return attribute != null && !attribute.isEmpty();
			case ArchitecturetoolPackage.GENERATOR__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //GeneratorImpl
