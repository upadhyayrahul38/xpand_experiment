/**
 */
package architecturetool.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.Generator;
import architecturetool.Parameter;
import architecturetool.Port;
import architecturetool.PortListType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.PortImpl#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.impl.PortImpl#getPortDirection <em>Port Direction</em>}</li>
 *   <li>{@link architecturetool.impl.PortImpl#getParameter <em>Parameter</em>}</li>
 *   <li>{@link architecturetool.impl.PortImpl#getType <em>Type</em>}</li>
 *   <li>{@link architecturetool.impl.PortImpl#getVirtualAddressBlock <em>Virtual Address Block</em>}</li>
 *   <li>{@link architecturetool.impl.PortImpl#isShowAllTypes <em>Show All Types</em>}</li>
 *   <li>{@link architecturetool.impl.PortImpl#getPortTypeCompoName <em>Port Type Compo Name</em>}</li>
 *   <li>{@link architecturetool.impl.PortImpl#isInternalPort <em>Internal Port</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PortImpl extends MinimalEObjectImpl.Container implements Port {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPortDirection() <em>Port Direction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortDirection()
	 * @generated
	 * @ordered
	 */
	protected static final PortListType PORT_DIRECTION_EDEFAULT = PortListType.REQUEST;

	/**
	 * The cached value of the '{@link #getPortDirection() <em>Port Direction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortDirection()
	 * @generated
	 * @ordered
	 */
	protected PortListType portDirection = PORT_DIRECTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getParameter() <em>Parameter</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameter()
	 * @generated
	 * @ordered
	 */
	protected Parameter parameter;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected DataStructure type;

	/**
	 * The default value of the '{@link #getVirtualAddressBlock() <em>Virtual Address Block</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVirtualAddressBlock()
	 * @generated
	 * @ordered
	 */
	protected static final String VIRTUAL_ADDRESS_BLOCK_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVirtualAddressBlock() <em>Virtual Address Block</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVirtualAddressBlock()
	 * @generated
	 * @ordered
	 */
	protected String virtualAddressBlock = VIRTUAL_ADDRESS_BLOCK_EDEFAULT;

	/**
	 * The default value of the '{@link #isShowAllTypes() <em>Show All Types</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isShowAllTypes()
	 * @generated
	 * @ordered
	 */
	protected static final boolean SHOW_ALL_TYPES_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isShowAllTypes() <em>Show All Types</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isShowAllTypes()
	 * @generated
	 * @ordered
	 */
	protected boolean showAllTypes = SHOW_ALL_TYPES_EDEFAULT;

	/**
	 * The default value of the '{@link #getPortTypeCompoName() <em>Port Type Compo Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortTypeCompoName()
	 * @generated
	 * @ordered
	 */
	protected static final String PORT_TYPE_COMPO_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPortTypeCompoName() <em>Port Type Compo Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortTypeCompoName()
	 * @generated
	 * @ordered
	 */
	protected String portTypeCompoName = PORT_TYPE_COMPO_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #isInternalPort() <em>Internal Port</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isInternalPort()
	 * @generated
	 * @ordered
	 */
	protected static final boolean INTERNAL_PORT_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isInternalPort() <em>Internal Port</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isInternalPort()
	 * @generated
	 * @ordered
	 */
	protected boolean internalPort = INTERNAL_PORT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.PORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortListType getPortDirection() {
		return portDirection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPortDirection(PortListType newPortDirection) {
		PortListType oldPortDirection = portDirection;
		portDirection = newPortDirection == null ? PORT_DIRECTION_EDEFAULT : newPortDirection;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__PORT_DIRECTION, oldPortDirection, portDirection));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter getParameter() {
		if (parameter != null && parameter.eIsProxy()) {
			InternalEObject oldParameter = (InternalEObject)parameter;
			parameter = (Parameter)eResolveProxy(oldParameter);
			if (parameter != oldParameter) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ArchitecturetoolPackage.PORT__PARAMETER, oldParameter, parameter));
			}
		}
		return parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter basicGetParameter() {
		return parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParameter(Parameter newParameter) {
		Parameter oldParameter = parameter;
		parameter = newParameter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__PARAMETER, oldParameter, parameter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataStructure getType() {
		if (type != null && type.eIsProxy()) {
			InternalEObject oldType = (InternalEObject)type;
			type = (DataStructure)eResolveProxy(oldType);
			if (type != oldType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ArchitecturetoolPackage.PORT__TYPE, oldType, type));
			}
		}
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataStructure basicGetType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(DataStructure newType) {
		DataStructure oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getVirtualAddressBlock() {
		return virtualAddressBlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVirtualAddressBlock(String newVirtualAddressBlock) {
		String oldVirtualAddressBlock = virtualAddressBlock;
		virtualAddressBlock = newVirtualAddressBlock;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__VIRTUAL_ADDRESS_BLOCK, oldVirtualAddressBlock, virtualAddressBlock));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isShowAllTypes() {
		return showAllTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setShowAllTypes(boolean newShowAllTypes) {
		boolean oldShowAllTypes = showAllTypes;
		showAllTypes = newShowAllTypes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__SHOW_ALL_TYPES, oldShowAllTypes, showAllTypes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPortTypeCompoName() {
		return portTypeCompoName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setPortTypeCompoName(String newPortTypeCompoName) {
		String oldPortTypeCompoName = portTypeCompoName;
		portTypeCompoName = getPortType_ComponentName();
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__PORT_TYPE_COMPO_NAME, oldPortTypeCompoName, portTypeCompoName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isInternalPort() {
		return internalPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInternalPort(boolean newInternalPort) {
		boolean oldInternalPort = internalPort;
		internalPort = newInternalPort;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.PORT__INTERNAL_PORT, oldInternalPort, internalPort));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.PORT__NAME:
				return getName();
			case ArchitecturetoolPackage.PORT__PORT_DIRECTION:
				return getPortDirection();
			case ArchitecturetoolPackage.PORT__PARAMETER:
				if (resolve) return getParameter();
				return basicGetParameter();
			case ArchitecturetoolPackage.PORT__TYPE:
				if (resolve) return getType();
				return basicGetType();
			case ArchitecturetoolPackage.PORT__VIRTUAL_ADDRESS_BLOCK:
				return getVirtualAddressBlock();
			case ArchitecturetoolPackage.PORT__SHOW_ALL_TYPES:
				return isShowAllTypes();
			case ArchitecturetoolPackage.PORT__PORT_TYPE_COMPO_NAME:
				return getPortTypeCompoName();
			case ArchitecturetoolPackage.PORT__INTERNAL_PORT:
				return isInternalPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.PORT__NAME:
				setName((String)newValue);
				return;
			case ArchitecturetoolPackage.PORT__PORT_DIRECTION:
				setPortDirection((PortListType)newValue);
				return;
			case ArchitecturetoolPackage.PORT__PARAMETER:
				setParameter((Parameter)newValue);
				return;
			case ArchitecturetoolPackage.PORT__TYPE:
				setType((DataStructure)newValue);
				return;
			case ArchitecturetoolPackage.PORT__VIRTUAL_ADDRESS_BLOCK:
				setVirtualAddressBlock((String)newValue);
				return;
			case ArchitecturetoolPackage.PORT__SHOW_ALL_TYPES:
				setShowAllTypes((Boolean)newValue);
				return;
			case ArchitecturetoolPackage.PORT__PORT_TYPE_COMPO_NAME:
				setPortTypeCompoName((String)newValue);
				return;
			case ArchitecturetoolPackage.PORT__INTERNAL_PORT:
				setInternalPort((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.PORT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PORT__PORT_DIRECTION:
				setPortDirection(PORT_DIRECTION_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PORT__PARAMETER:
				setParameter((Parameter)null);
				return;
			case ArchitecturetoolPackage.PORT__TYPE:
				setType((DataStructure)null);
				return;
			case ArchitecturetoolPackage.PORT__VIRTUAL_ADDRESS_BLOCK:
				setVirtualAddressBlock(VIRTUAL_ADDRESS_BLOCK_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PORT__SHOW_ALL_TYPES:
				setShowAllTypes(SHOW_ALL_TYPES_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PORT__PORT_TYPE_COMPO_NAME:
				setPortTypeCompoName(PORT_TYPE_COMPO_NAME_EDEFAULT);
				return;
			case ArchitecturetoolPackage.PORT__INTERNAL_PORT:
				setInternalPort(INTERNAL_PORT_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.PORT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ArchitecturetoolPackage.PORT__PORT_DIRECTION:
				return portDirection != PORT_DIRECTION_EDEFAULT;
			case ArchitecturetoolPackage.PORT__PARAMETER:
				return parameter != null;
			case ArchitecturetoolPackage.PORT__TYPE:
				return type != null;
			case ArchitecturetoolPackage.PORT__VIRTUAL_ADDRESS_BLOCK:
				return VIRTUAL_ADDRESS_BLOCK_EDEFAULT == null ? virtualAddressBlock != null : !VIRTUAL_ADDRESS_BLOCK_EDEFAULT.equals(virtualAddressBlock);
			case ArchitecturetoolPackage.PORT__SHOW_ALL_TYPES:
				return showAllTypes != SHOW_ALL_TYPES_EDEFAULT;
			case ArchitecturetoolPackage.PORT__PORT_TYPE_COMPO_NAME:
				return PORT_TYPE_COMPO_NAME_EDEFAULT == null ? portTypeCompoName != null : !PORT_TYPE_COMPO_NAME_EDEFAULT.equals(portTypeCompoName);
			case ArchitecturetoolPackage.PORT__INTERNAL_PORT:
				return internalPort != INTERNAL_PORT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", portDirection: ");
		result.append(portDirection);
		result.append(", virtualAddressBlock: ");
		result.append(virtualAddressBlock);
		result.append(", showAllTypes: ");
		result.append(showAllTypes);
		result.append(", portTypeCompoName: ");
		result.append(portTypeCompoName);
		result.append(", internalPort: ");
		result.append(internalPort);
		result.append(')');
		return result.toString();
	}
	
	
	
	

	/**
	 * @generated NOT 
	 */
	@Override
	public boolean getShowAllTypes() {
	  return	showAllTypes;
		
	}
	
	/**
	 * @generated NOT 
	 */
	@Override
	public String getPortType_ComponentName() {

		DataStructure dataStruct = this.getType();
		EObject eContainer = dataStruct;
		if (dataStruct != null && (dataStruct.getType() == null || dataStruct.getType().trim().isEmpty())) {
			if (dataStruct != null) {
				for (int i = 0;; i++) {
					if (eContainer instanceof Generator) {
						Generator generator = (Generator) eContainer;
						break;
					} else {
						eContainer = eContainer.eContainer();
					}
				}
				Generator generator = (Generator) eContainer;
				if (generator.eContainer() instanceof Component) {
					Component component = (Component) generator.eContainer();
					if (component.getName() != null) {
						if (this.getName() == null || this.getName().trim().isEmpty()) {
							return component.getName().trim() + "_" + this.getType().getName().trim();
						} else {
							return component.getName().trim() + "_" + this.getType().getName().trim(); // this.getName().trim()
						}
					}
				}
				return null;
			}
		} else if (dataStruct != null && dataStruct.getType() != null && !dataStruct.getType().trim().isEmpty()) {
			int length = dataStruct.getType().length();
			return dataStruct.getType();
		} else if (dataStruct == null) {
			if (this.eContainer != null && this.eContainer.eContainer() != null) {
				Component component = (Component) this.eContainer.eContainer();
				if (component.getName() != null) {
					return component.getName().trim() + "_" + this.getName().trim();
				}
			}
		}
		return null;
	}

} //PortImpl
