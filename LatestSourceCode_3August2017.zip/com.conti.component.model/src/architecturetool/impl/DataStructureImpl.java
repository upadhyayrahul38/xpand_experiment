/**
 */
package architecturetool.impl;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.DataStructure;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Data Structure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.DataStructureImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link architecturetool.impl.DataStructureImpl#getReferences <em>References</em>}</li>
 *   <li>{@link architecturetool.impl.DataStructureImpl#getStructs <em>Structs</em>}</li>
 *   <li>{@link architecturetool.impl.DataStructureImpl#getAbsolutereference <em>Absolutereference</em>}</li>
 *   <li>{@link architecturetool.impl.DataStructureImpl#getType <em>Type</em>}</li>
 *   <li>{@link architecturetool.impl.DataStructureImpl#isUsed_by_Ports <em>Used by Ports</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DataStructureImpl extends ComponentAttributeImpl implements DataStructure {
	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList<Attribute> attributes;

	/**
	 * The cached value of the '{@link #getReferences() <em>References</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReferences()
	 * @generated
	 * @ordered
	 */
	protected EList<DataStructure> references;

	/**
	 * The cached value of the '{@link #getStructs() <em>Structs</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStructs()
	 * @generated
	 * @ordered
	 */
	protected EList<DataStructure> structs;

	/**
	 * The cached value of the '{@link #getAbsolutereference() <em>Absolutereference</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbsolutereference()
	 * @generated
	 * @ordered
	 */
	protected EList<AbsoluteRefrence> absolutereference;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #isUsed_by_Ports() <em>Used by Ports</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isUsed_by_Ports()
	 * @generated
	 * @ordered
	 */
	protected static final boolean USED_BY_PORTS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isUsed_by_Ports() <em>Used by Ports</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isUsed_by_Ports()
	 * @generated
	 * @ordered
	 */
	protected boolean used_by_Ports = USED_BY_PORTS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DataStructureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.DATA_STRUCTURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Attribute> getAttributes() {
		if (attributes == null) {
			attributes = new EObjectContainmentEList<Attribute>(Attribute.class, this, ArchitecturetoolPackage.DATA_STRUCTURE__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataStructure> getReferences() {
		if (references == null) {
			references = new EObjectResolvingEList<DataStructure>(DataStructure.class, this, ArchitecturetoolPackage.DATA_STRUCTURE__REFERENCES);
		}
		return references;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataStructure> getStructs() {
		if (structs == null) {
			structs = new EObjectContainmentEList<DataStructure>(DataStructure.class, this, ArchitecturetoolPackage.DATA_STRUCTURE__STRUCTS);
		}
		return structs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AbsoluteRefrence> getAbsolutereference() {
		if (absolutereference == null) {
			absolutereference = new EObjectContainmentEList<AbsoluteRefrence>(AbsoluteRefrence.class, this, ArchitecturetoolPackage.DATA_STRUCTURE__ABSOLUTEREFERENCE);
		}
		return absolutereference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.DATA_STRUCTURE__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isUsed_by_Ports() {
		return used_by_Ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUsed_by_Ports(boolean newUsed_by_Ports) {
		boolean oldUsed_by_Ports = used_by_Ports;
		used_by_Ports = newUsed_by_Ports;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.DATA_STRUCTURE__USED_BY_PORTS, oldUsed_by_Ports, used_by_Ports));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ArchitecturetoolPackage.DATA_STRUCTURE__ATTRIBUTES:
				return ((InternalEList<?>)getAttributes()).basicRemove(otherEnd, msgs);
			case ArchitecturetoolPackage.DATA_STRUCTURE__STRUCTS:
				return ((InternalEList<?>)getStructs()).basicRemove(otherEnd, msgs);
			case ArchitecturetoolPackage.DATA_STRUCTURE__ABSOLUTEREFERENCE:
				return ((InternalEList<?>)getAbsolutereference()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.DATA_STRUCTURE__ATTRIBUTES:
				return getAttributes();
			case ArchitecturetoolPackage.DATA_STRUCTURE__REFERENCES:
				return getReferences();
			case ArchitecturetoolPackage.DATA_STRUCTURE__STRUCTS:
				return getStructs();
			case ArchitecturetoolPackage.DATA_STRUCTURE__ABSOLUTEREFERENCE:
				return getAbsolutereference();
			case ArchitecturetoolPackage.DATA_STRUCTURE__TYPE:
				return getType();
			case ArchitecturetoolPackage.DATA_STRUCTURE__USED_BY_PORTS:
				return isUsed_by_Ports();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.DATA_STRUCTURE__ATTRIBUTES:
				getAttributes().clear();
				getAttributes().addAll((Collection<? extends Attribute>)newValue);
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__REFERENCES:
				getReferences().clear();
				getReferences().addAll((Collection<? extends DataStructure>)newValue);
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__STRUCTS:
				getStructs().clear();
				getStructs().addAll((Collection<? extends DataStructure>)newValue);
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__ABSOLUTEREFERENCE:
				getAbsolutereference().clear();
				getAbsolutereference().addAll((Collection<? extends AbsoluteRefrence>)newValue);
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__TYPE:
				setType((String)newValue);
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__USED_BY_PORTS:
				setUsed_by_Ports((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.DATA_STRUCTURE__ATTRIBUTES:
				getAttributes().clear();
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__REFERENCES:
				getReferences().clear();
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__STRUCTS:
				getStructs().clear();
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__ABSOLUTEREFERENCE:
				getAbsolutereference().clear();
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case ArchitecturetoolPackage.DATA_STRUCTURE__USED_BY_PORTS:
				setUsed_by_Ports(USED_BY_PORTS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.DATA_STRUCTURE__ATTRIBUTES:
				return attributes != null && !attributes.isEmpty();
			case ArchitecturetoolPackage.DATA_STRUCTURE__REFERENCES:
				return references != null && !references.isEmpty();
			case ArchitecturetoolPackage.DATA_STRUCTURE__STRUCTS:
				return structs != null && !structs.isEmpty();
			case ArchitecturetoolPackage.DATA_STRUCTURE__ABSOLUTEREFERENCE:
				return absolutereference != null && !absolutereference.isEmpty();
			case ArchitecturetoolPackage.DATA_STRUCTURE__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case ArchitecturetoolPackage.DATA_STRUCTURE__USED_BY_PORTS:
				return used_by_Ports != USED_BY_PORTS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Type: ");
		result.append(type);
		result.append(", Used_by_Ports: ");
		result.append(used_by_Ports);
		result.append(')');
		return result.toString();
	}

} //DataStructureImpl
