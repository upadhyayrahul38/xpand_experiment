/**
 */
package architecturetool.impl;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.ComponentAttribute;
import architecturetool.PhysicalUnitEnum;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Component Attribute</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.ComponentAttributeImpl#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentAttributeImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentAttributeImpl#getTypeAccuracy <em>Type Accuracy</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentAttributeImpl#getArraySize <em>Array Size</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentAttributeImpl#getPhysicalUnit <em>Physical Unit</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentAttributeImpl#getAccuracy <em>Accuracy</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentAttributeImpl#getInterfaceVersion <em>Interface Version</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ComponentAttributeImpl extends MinimalEObjectImpl.Container implements ComponentAttribute {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getTypeAccuracy() <em>Type Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypeAccuracy()
	 * @generated
	 * @ordered
	 */
	protected static final float TYPE_ACCURACY_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTypeAccuracy() <em>Type Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypeAccuracy()
	 * @generated
	 * @ordered
	 */
	protected float typeAccuracy = TYPE_ACCURACY_EDEFAULT;

	/**
	 * The default value of the '{@link #getArraySize() <em>Array Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArraySize()
	 * @generated
	 * @ordered
	 */
	protected static final int ARRAY_SIZE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getArraySize() <em>Array Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArraySize()
	 * @generated
	 * @ordered
	 */
	protected int arraySize = ARRAY_SIZE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPhysicalUnit() <em>Physical Unit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhysicalUnit()
	 * @generated
	 * @ordered
	 */
	protected static final PhysicalUnitEnum PHYSICAL_UNIT_EDEFAULT = PhysicalUnitEnum.NOUNIT;

	/**
	 * The cached value of the '{@link #getPhysicalUnit() <em>Physical Unit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhysicalUnit()
	 * @generated
	 * @ordered
	 */
	protected PhysicalUnitEnum physicalUnit = PHYSICAL_UNIT_EDEFAULT;

	/**
	 * The default value of the '{@link #getAccuracy() <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccuracy()
	 * @generated
	 * @ordered
	 */
	protected static final float ACCURACY_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getAccuracy() <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccuracy()
	 * @generated
	 * @ordered
	 */
	protected float accuracy = ACCURACY_EDEFAULT;

	/**
	 * The default value of the '{@link #getInterfaceVersion() <em>Interface Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceVersion()
	 * @generated
	 * @ordered
	 */
	protected static final int INTERFACE_VERSION_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getInterfaceVersion() <em>Interface Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceVersion()
	 * @generated
	 * @ordered
	 */
	protected int interfaceVersion = INTERFACE_VERSION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComponentAttributeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__DESCRIPTION, oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getTypeAccuracy() {
		return typeAccuracy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTypeAccuracy(float newTypeAccuracy) {
		float oldTypeAccuracy = typeAccuracy;
		typeAccuracy = newTypeAccuracy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__TYPE_ACCURACY, oldTypeAccuracy, typeAccuracy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getArraySize() {
		return arraySize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArraySize(int newArraySize) {
		int oldArraySize = arraySize;
		arraySize = newArraySize;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ARRAY_SIZE, oldArraySize, arraySize));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalUnitEnum getPhysicalUnit() {
		return physicalUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhysicalUnit(PhysicalUnitEnum newPhysicalUnit) {
		PhysicalUnitEnum oldPhysicalUnit = physicalUnit;
		physicalUnit = newPhysicalUnit == null ? PHYSICAL_UNIT_EDEFAULT : newPhysicalUnit;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT, oldPhysicalUnit, physicalUnit));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getAccuracy() {
		return accuracy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAccuracy(float newAccuracy) {
		float oldAccuracy = accuracy;
		accuracy = newAccuracy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ACCURACY, oldAccuracy, accuracy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getInterfaceVersion() {
		return interfaceVersion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInterfaceVersion(int newInterfaceVersion) {
		int oldInterfaceVersion = interfaceVersion;
		interfaceVersion = newInterfaceVersion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__INTERFACE_VERSION, oldInterfaceVersion, interfaceVersion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__NAME:
				return getName();
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__DESCRIPTION:
				return getDescription();
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__TYPE_ACCURACY:
				return getTypeAccuracy();
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ARRAY_SIZE:
				return getArraySize();
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT:
				return getPhysicalUnit();
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ACCURACY:
				return getAccuracy();
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__INTERFACE_VERSION:
				return getInterfaceVersion();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__NAME:
				setName((String)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__DESCRIPTION:
				setDescription((String)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__TYPE_ACCURACY:
				setTypeAccuracy((Float)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ARRAY_SIZE:
				setArraySize((Integer)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT:
				setPhysicalUnit((PhysicalUnitEnum)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ACCURACY:
				setAccuracy((Float)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__INTERFACE_VERSION:
				setInterfaceVersion((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__DESCRIPTION:
				setDescription(DESCRIPTION_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__TYPE_ACCURACY:
				setTypeAccuracy(TYPE_ACCURACY_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ARRAY_SIZE:
				setArraySize(ARRAY_SIZE_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT:
				setPhysicalUnit(PHYSICAL_UNIT_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ACCURACY:
				setAccuracy(ACCURACY_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__INTERFACE_VERSION:
				setInterfaceVersion(INTERFACE_VERSION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__DESCRIPTION:
				return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__TYPE_ACCURACY:
				return typeAccuracy != TYPE_ACCURACY_EDEFAULT;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ARRAY_SIZE:
				return arraySize != ARRAY_SIZE_EDEFAULT;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT:
				return physicalUnit != PHYSICAL_UNIT_EDEFAULT;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__ACCURACY:
				return accuracy != ACCURACY_EDEFAULT;
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE__INTERFACE_VERSION:
				return interfaceVersion != INTERFACE_VERSION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", description: ");
		result.append(description);
		result.append(", typeAccuracy: ");
		result.append(typeAccuracy);
		result.append(", arraySize: ");
		result.append(arraySize);
		result.append(", physicalUnit: ");
		result.append(physicalUnit);
		result.append(", accuracy: ");
		result.append(accuracy);
		result.append(", interfaceVersion: ");
		result.append(interfaceVersion);
		result.append(')');
		return result.toString();
	}

} //ComponentAttributeImpl
