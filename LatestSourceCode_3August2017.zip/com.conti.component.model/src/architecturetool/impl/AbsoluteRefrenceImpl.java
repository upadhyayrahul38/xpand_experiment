/**
 */
package architecturetool.impl;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.DataStructure;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Absolute Refrence</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.AbsoluteRefrenceImpl#getDatastructure <em>Datastructure</em>}</li>
 *   <li>{@link architecturetool.impl.AbsoluteRefrenceImpl#getAttribute <em>Attribute</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AbsoluteRefrenceImpl extends ComponentAttributeImpl implements AbsoluteRefrence {
	/**
	 * The cached value of the '{@link #getDatastructure() <em>Datastructure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatastructure()
	 * @generated
	 * @ordered
	 */
	protected DataStructure datastructure;

	/**
	 * The cached value of the '{@link #getAttribute() <em>Attribute</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttribute()
	 * @generated
	 * @ordered
	 */
	protected Attribute attribute;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbsoluteRefrenceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.ABSOLUTE_REFRENCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataStructure getDatastructure() {
		if (datastructure != null && datastructure.eIsProxy()) {
			InternalEObject oldDatastructure = (InternalEObject)datastructure;
			datastructure = (DataStructure)eResolveProxy(oldDatastructure);
			if (datastructure != oldDatastructure) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ArchitecturetoolPackage.ABSOLUTE_REFRENCE__DATASTRUCTURE, oldDatastructure, datastructure));
			}
		}
		return datastructure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataStructure basicGetDatastructure() {
		return datastructure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDatastructure(DataStructure newDatastructure) {
		DataStructure oldDatastructure = datastructure;
		datastructure = newDatastructure;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.ABSOLUTE_REFRENCE__DATASTRUCTURE, oldDatastructure, datastructure));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attribute getAttribute() {
		if (attribute != null && attribute.eIsProxy()) {
			InternalEObject oldAttribute = (InternalEObject)attribute;
			attribute = (Attribute)eResolveProxy(oldAttribute);
			if (attribute != oldAttribute) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ArchitecturetoolPackage.ABSOLUTE_REFRENCE__ATTRIBUTE, oldAttribute, attribute));
			}
		}
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attribute basicGetAttribute() {
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAttribute(Attribute newAttribute) {
		Attribute oldAttribute = attribute;
		attribute = newAttribute;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.ABSOLUTE_REFRENCE__ATTRIBUTE, oldAttribute, attribute));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__DATASTRUCTURE:
				if (resolve) return getDatastructure();
				return basicGetDatastructure();
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__ATTRIBUTE:
				if (resolve) return getAttribute();
				return basicGetAttribute();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__DATASTRUCTURE:
				setDatastructure((DataStructure)newValue);
				return;
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__ATTRIBUTE:
				setAttribute((Attribute)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__DATASTRUCTURE:
				setDatastructure((DataStructure)null);
				return;
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__ATTRIBUTE:
				setAttribute((Attribute)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__DATASTRUCTURE:
				return datastructure != null;
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE__ATTRIBUTE:
				return attribute != null;
		}
		return super.eIsSet(featureID);
	}

} //AbsoluteRefrenceImpl
