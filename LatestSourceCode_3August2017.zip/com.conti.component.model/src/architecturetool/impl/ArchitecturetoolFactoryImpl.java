/**
 */
package architecturetool.impl;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.AttributeTypeEnum;
import architecturetool.BuildUnit;
import architecturetool.CPU;
import architecturetool.Component;
import architecturetool.ComponentAttribute;
import architecturetool.ComponentInstance;
import architecturetool.DataStructure;
import architecturetool.DatatypeEnum;
import architecturetool.ECU;
import architecturetool.Flow;
import architecturetool.Flows;
import architecturetool.FunctionalRequirement;
import architecturetool.Generator;
import architecturetool.ISR;
import architecturetool.Literal;
import architecturetool.MCC;
import architecturetool.Memory;
import architecturetool.MemoryBudget;
import architecturetool.MemoryPartition;
import architecturetool.MemoryRegion;
import architecturetool.NoNameElement;
import architecturetool.Node;
import architecturetool.OSApplication;
import architecturetool.Parameter;
import architecturetool.ParameterConditionEnum;
import architecturetool.Peripheral;
import architecturetool.PhysicalUnitEnum;
import architecturetool.Port;
import architecturetool.PortListType;
import architecturetool.Ports;
import architecturetool.ProcMem;
import architecturetool.ProcMem_AccessSpeed;
import architecturetool.ProcMem_Cycle;
import architecturetool.ProcMem_Safety;
import architecturetool.ResourceBudget;
import architecturetool.Root;
import architecturetool.Runnables;
import architecturetool.RuntimeBudget;
import architecturetool.SubComponent;
import architecturetool.Task;
import architecturetool.UNIT;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ArchitecturetoolFactoryImpl extends EFactoryImpl implements ArchitecturetoolFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ArchitecturetoolFactory init() {
		try {
			ArchitecturetoolFactory theArchitecturetoolFactory = (ArchitecturetoolFactory)EPackage.Registry.INSTANCE.getEFactory(ArchitecturetoolPackage.eNS_URI);
			if (theArchitecturetoolFactory != null) {
				return theArchitecturetoolFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ArchitecturetoolFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ArchitecturetoolFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case ArchitecturetoolPackage.NODE: return createNode();
			case ArchitecturetoolPackage.TASK: return createTask();
			case ArchitecturetoolPackage.COMPONENT: return createComponent();
			case ArchitecturetoolPackage.RUNNABLE: return createRunnable();
			case ArchitecturetoolPackage.COMPONENT_INSTANCE: return createComponentInstance();
			case ArchitecturetoolPackage.ECU: return createECU();
			case ArchitecturetoolPackage.CPU: return createCPU();
			case ArchitecturetoolPackage.FUNCTIONAL_REQUIREMENT: return createFunctionalRequirement();
			case ArchitecturetoolPackage.RESOURCE_BUDGET: return createResourceBudget();
			case ArchitecturetoolPackage.RUNTIME_BUDGET: return createRuntimeBudget();
			case ArchitecturetoolPackage.MEMORY_BUDGET: return createMemoryBudget();
			case ArchitecturetoolPackage.MCC: return createMCC();
			case ArchitecturetoolPackage.NO_NAME_ELEMENT: return createNoNameElement();
			case ArchitecturetoolPackage.SUB_COMPONENT: return createSubComponent();
			case ArchitecturetoolPackage.BUILD_UNIT: return createBuildUnit();
			case ArchitecturetoolPackage.OS_APPLICATION: return createOSApplication();
			case ArchitecturetoolPackage.ISR: return createISR();
			case ArchitecturetoolPackage.MEMORY: return createMemory();
			case ArchitecturetoolPackage.MEMORY_PARTITION: return createMemoryPartition();
			case ArchitecturetoolPackage.PORT: return createPort();
			case ArchitecturetoolPackage.ATTRIBUTE: return createAttribute();
			case ArchitecturetoolPackage.DATA_STRUCTURE: return createDataStructure();
			case ArchitecturetoolPackage.PARAMETER: return createParameter();
			case ArchitecturetoolPackage.COMPONENT_ATTRIBUTE: return createComponentAttribute();
			case ArchitecturetoolPackage.ABSOLUTE_REFRENCE: return createAbsoluteRefrence();
			case ArchitecturetoolPackage.ENUM: return createEnum();
			case ArchitecturetoolPackage.LITERAL: return createLiteral();
			case ArchitecturetoolPackage.PORTS: return createPorts();
			case ArchitecturetoolPackage.RUNNABLES: return createRunnables();
			case ArchitecturetoolPackage.GENERATOR: return createGenerator();
			case ArchitecturetoolPackage.FLOW: return createFlow();
			case ArchitecturetoolPackage.FLOWS: return createFlows();
			case ArchitecturetoolPackage.ROOT: return createRoot();
			case ArchitecturetoolPackage.MEMORY_REGION: return createMemoryRegion();
			case ArchitecturetoolPackage.PROC_MEM: return createProcMem();
			case ArchitecturetoolPackage.PERIPHERAL: return createPeripheral();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case ArchitecturetoolPackage.PORT_LIST_TYPE:
				return createPortListTypeFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.DATATYPE_ENUM:
				return createDatatypeEnumFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.PHYSICAL_UNIT_ENUM:
				return createPhysicalUnitEnumFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.UNIT:
				return createUNITFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.ATTRIBUTE_TYPE_ENUM:
				return createAttributeTypeEnumFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.PARAMETER_CONDITION_ENUM:
				return createParameterConditionEnumFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.PROC_MEM_SAFETY:
				return createProcMem_SafetyFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.PROC_MEM_ACCESS_SPEED:
				return createProcMem_AccessSpeedFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.PROC_MEM_CYCLE:
				return createProcMem_CycleFromString(eDataType, initialValue);
			case ArchitecturetoolPackage.STACK_INT:
				return createStackIntFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case ArchitecturetoolPackage.PORT_LIST_TYPE:
				return convertPortListTypeToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.DATATYPE_ENUM:
				return convertDatatypeEnumToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.PHYSICAL_UNIT_ENUM:
				return convertPhysicalUnitEnumToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.UNIT:
				return convertUNITToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.ATTRIBUTE_TYPE_ENUM:
				return convertAttributeTypeEnumToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.PARAMETER_CONDITION_ENUM:
				return convertParameterConditionEnumToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.PROC_MEM_SAFETY:
				return convertProcMem_SafetyToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.PROC_MEM_ACCESS_SPEED:
				return convertProcMem_AccessSpeedToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.PROC_MEM_CYCLE:
				return convertProcMem_CycleToString(eDataType, instanceValue);
			case ArchitecturetoolPackage.STACK_INT:
				return convertStackIntToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Node createNode() {
		NodeImpl node = new NodeImpl();
		return node;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Task createTask() {
		TaskImpl task = new TaskImpl();
		return task;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Component createComponent() {
		ComponentImpl component = new ComponentImpl();
		return component;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public architecturetool.Runnable createRunnable() {
		RunnableImpl runnable = new RunnableImpl();
		return runnable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ComponentInstance createComponentInstance() {
		ComponentInstanceImpl componentInstance = new ComponentInstanceImpl();
		return componentInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ECU createECU() {
		ECUImpl ecu = new ECUImpl();
		return ecu;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CPU createCPU() {
		CPUImpl cpu = new CPUImpl();
		return cpu;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionalRequirement createFunctionalRequirement() {
		FunctionalRequirementImpl functionalRequirement = new FunctionalRequirementImpl();
		return functionalRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResourceBudget createResourceBudget() {
		ResourceBudgetImpl resourceBudget = new ResourceBudgetImpl();
		return resourceBudget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RuntimeBudget createRuntimeBudget() {
		RuntimeBudgetImpl runtimeBudget = new RuntimeBudgetImpl();
		return runtimeBudget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MemoryBudget createMemoryBudget() {
		MemoryBudgetImpl memoryBudget = new MemoryBudgetImpl();
		return memoryBudget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MCC createMCC() {
		MCCImpl mcc = new MCCImpl();
		return mcc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NoNameElement createNoNameElement() {
		NoNameElementImpl noNameElement = new NoNameElementImpl();
		return noNameElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubComponent createSubComponent() {
		SubComponentImpl subComponent = new SubComponentImpl();
		return subComponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuildUnit createBuildUnit() {
		BuildUnitImpl buildUnit = new BuildUnitImpl();
		return buildUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OSApplication createOSApplication() {
		OSApplicationImpl osApplication = new OSApplicationImpl();
		return osApplication;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ISR createISR() {
		ISRImpl isr = new ISRImpl();
		return isr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Memory createMemory() {
		MemoryImpl memory = new MemoryImpl();
		return memory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MemoryPartition createMemoryPartition() {
		MemoryPartitionImpl memoryPartition = new MemoryPartitionImpl();
		return memoryPartition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port createPort() {
		PortImpl port = new PortImpl();
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attribute createAttribute() {
		AttributeImpl attribute = new AttributeImpl();
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataStructure createDataStructure() {
		DataStructureImpl dataStructure = new DataStructureImpl();
		return dataStructure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter createParameter() {
		ParameterImpl parameter = new ParameterImpl();
		return parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ComponentAttribute createComponentAttribute() {
		ComponentAttributeImpl componentAttribute = new ComponentAttributeImpl();
		return componentAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbsoluteRefrence createAbsoluteRefrence() {
		AbsoluteRefrenceImpl absoluteRefrence = new AbsoluteRefrenceImpl();
		return absoluteRefrence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public architecturetool.Enum createEnum() {
		EnumImpl enum_ = new EnumImpl();
		return enum_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Literal createLiteral() {
		LiteralImpl literal = new LiteralImpl();
		return literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ports createPorts() {
		PortsImpl ports = new PortsImpl();
		return ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Runnables createRunnables() {
		RunnablesImpl runnables = new RunnablesImpl();
		return runnables;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Generator createGenerator() {
		GeneratorImpl generator = new GeneratorImpl();
		return generator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Flow createFlow() {
		FlowImpl flow = new FlowImpl();
		return flow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Flows createFlows() {
		FlowsImpl flows = new FlowsImpl();
		return flows;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Root createRoot() {
		RootImpl root = new RootImpl();
		return root;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MemoryRegion createMemoryRegion() {
		MemoryRegionImpl memoryRegion = new MemoryRegionImpl();
		return memoryRegion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcMem createProcMem() {
		ProcMemImpl procMem = new ProcMemImpl();
		return procMem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Peripheral createPeripheral() {
		PeripheralImpl peripheral = new PeripheralImpl();
		return peripheral;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortListType createPortListTypeFromString(EDataType eDataType, String initialValue) {
		PortListType result = PortListType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPortListTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DatatypeEnum createDatatypeEnumFromString(EDataType eDataType, String initialValue) {
		DatatypeEnum result = DatatypeEnum.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDatatypeEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalUnitEnum createPhysicalUnitEnumFromString(EDataType eDataType, String initialValue) {
		PhysicalUnitEnum result = PhysicalUnitEnum.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPhysicalUnitEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UNIT createUNITFromString(EDataType eDataType, String initialValue) {
		UNIT result = UNIT.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertUNITToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeTypeEnum createAttributeTypeEnumFromString(EDataType eDataType, String initialValue) {
		AttributeTypeEnum result = AttributeTypeEnum.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAttributeTypeEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ParameterConditionEnum createParameterConditionEnumFromString(EDataType eDataType, String initialValue) {
		ParameterConditionEnum result = ParameterConditionEnum.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertParameterConditionEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcMem_Safety createProcMem_SafetyFromString(EDataType eDataType, String initialValue) {
		ProcMem_Safety result = ProcMem_Safety.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertProcMem_SafetyToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcMem_AccessSpeed createProcMem_AccessSpeedFromString(EDataType eDataType, String initialValue) {
		ProcMem_AccessSpeed result = ProcMem_AccessSpeed.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertProcMem_AccessSpeedToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcMem_Cycle createProcMem_CycleFromString(EDataType eDataType, String initialValue) {
		ProcMem_Cycle result = ProcMem_Cycle.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertProcMem_CycleToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Integer createStackIntFromString(EDataType eDataType, String initialValue) {
		return (Integer)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertStackIntToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ArchitecturetoolPackage getArchitecturetoolPackage() {
		return (ArchitecturetoolPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ArchitecturetoolPackage getPackage() {
		return ArchitecturetoolPackage.eINSTANCE;
	}

} //ArchitecturetoolFactoryImpl
