/**
 */
package architecturetool.impl;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.MemoryPartition;

import architecturetool.MemoryRegion;
import java.util.Collection;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Memory Partition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.MemoryPartitionImpl#getMemoryregion <em>Memoryregion</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MemoryPartitionImpl extends MinimalEObjectImpl.Container implements MemoryPartition {
	/**
	 * The cached value of the '{@link #getMemoryregion() <em>Memoryregion</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMemoryregion()
	 * @generated
	 * @ordered
	 */
	protected EList<MemoryRegion> memoryregion;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MemoryPartitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.MEMORY_PARTITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MemoryRegion> getMemoryregion() {
		if (memoryregion == null) {
			memoryregion = new EObjectResolvingEList<MemoryRegion>(MemoryRegion.class, this, ArchitecturetoolPackage.MEMORY_PARTITION__MEMORYREGION);
		}
		return memoryregion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.MEMORY_PARTITION__MEMORYREGION:
				return getMemoryregion();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.MEMORY_PARTITION__MEMORYREGION:
				getMemoryregion().clear();
				getMemoryregion().addAll((Collection<? extends MemoryRegion>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.MEMORY_PARTITION__MEMORYREGION:
				getMemoryregion().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.MEMORY_PARTITION__MEMORYREGION:
				return memoryregion != null && !memoryregion.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //MemoryPartitionImpl
