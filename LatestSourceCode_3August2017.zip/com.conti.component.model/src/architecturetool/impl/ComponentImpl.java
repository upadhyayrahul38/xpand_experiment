/**
 */
package architecturetool.impl;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.Flows;
import architecturetool.Generator;
import architecturetool.Parameter;
import architecturetool.Ports;
import architecturetool.ProcMem;
import architecturetool.Runnables;
import architecturetool.SubComponent;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Component</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.impl.ComponentImpl#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getSubcomponent <em>Subcomponent</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#isExternalStaticMemUsed <em>External Static Mem Used</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getPorts <em>Ports</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getRunnables <em>Runnables</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getGenerator <em>Generator</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getFlows <em>Flows</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getParameters <em>Parameters</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getProcmem <em>Procmem</em>}</li>
 *   <li>{@link architecturetool.impl.ComponentImpl#getDataStructureName <em>Data Structure Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ComponentImpl extends MinimalEObjectImpl.Container implements Component {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSubcomponent() <em>Subcomponent</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubcomponent()
	 * @generated
	 * @ordered
	 */
	protected EList<SubComponent> subcomponent;

	/**
	 * The default value of the '{@link #isExternalStaticMemUsed() <em>External Static Mem Used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isExternalStaticMemUsed()
	 * @generated
	 * @ordered
	 */
	protected static final boolean EXTERNAL_STATIC_MEM_USED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isExternalStaticMemUsed() <em>External Static Mem Used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isExternalStaticMemUsed()
	 * @generated
	 * @ordered
	 */
	protected boolean externalStaticMemUsed = EXTERNAL_STATIC_MEM_USED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPorts() <em>Ports</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPorts()
	 * @generated
	 * @ordered
	 */
	protected Ports ports;

	/**
	 * The cached value of the '{@link #getRunnables() <em>Runnables</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRunnables()
	 * @generated
	 * @ordered
	 */
	protected Runnables runnables;

	/**
	 * The cached value of the '{@link #getGenerator() <em>Generator</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGenerator()
	 * @generated
	 * @ordered
	 */
	protected EList<Generator> generator;

	/**
	 * The cached value of the '{@link #getFlows() <em>Flows</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFlows()
	 * @generated
	 * @ordered
	 */
	protected Flows flows;

	/**
	 * The cached value of the '{@link #getParameters() <em>Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameters()
	 * @generated
	 * @ordered
	 */
	protected EList<Parameter> parameters;

	/**
	 * The cached value of the '{@link #getProcmem() <em>Procmem</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProcmem()
	 * @generated
	 * @ordered
	 */
	protected EList<ProcMem> procmem;

	/**
	 * The default value of the '{@link #getDataStructureName() <em>Data Structure Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataStructureName()
	 * @generated
	 * @ordered
	 */
	protected static final String DATA_STRUCTURE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataStructureName() <em>Data Structure Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataStructureName()
	 * @generated
	 * @ordered
	 */
	protected String dataStructureName = DATA_STRUCTURE_NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComponentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ArchitecturetoolPackage.Literals.COMPONENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SubComponent> getSubcomponent() {
		if (subcomponent == null) {
			subcomponent = new EObjectContainmentEList<SubComponent>(SubComponent.class, this, ArchitecturetoolPackage.COMPONENT__SUBCOMPONENT);
		}
		return subcomponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isExternalStaticMemUsed() {
		return externalStaticMemUsed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExternalStaticMemUsed(boolean newExternalStaticMemUsed) {
		boolean oldExternalStaticMemUsed = externalStaticMemUsed;
		externalStaticMemUsed = newExternalStaticMemUsed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__EXTERNAL_STATIC_MEM_USED, oldExternalStaticMemUsed, externalStaticMemUsed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ports getPorts() {
		return ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPorts(Ports newPorts, NotificationChain msgs) {
		Ports oldPorts = ports;
		ports = newPorts;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__PORTS, oldPorts, newPorts);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPorts(Ports newPorts) {
		if (newPorts != ports) {
			NotificationChain msgs = null;
			if (ports != null)
				msgs = ((InternalEObject)ports).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ArchitecturetoolPackage.COMPONENT__PORTS, null, msgs);
			if (newPorts != null)
				msgs = ((InternalEObject)newPorts).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ArchitecturetoolPackage.COMPONENT__PORTS, null, msgs);
			msgs = basicSetPorts(newPorts, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__PORTS, newPorts, newPorts));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Runnables getRunnables() {
		return runnables;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRunnables(Runnables newRunnables, NotificationChain msgs) {
		Runnables oldRunnables = runnables;
		runnables = newRunnables;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__RUNNABLES, oldRunnables, newRunnables);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRunnables(Runnables newRunnables) {
		if (newRunnables != runnables) {
			NotificationChain msgs = null;
			if (runnables != null)
				msgs = ((InternalEObject)runnables).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ArchitecturetoolPackage.COMPONENT__RUNNABLES, null, msgs);
			if (newRunnables != null)
				msgs = ((InternalEObject)newRunnables).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ArchitecturetoolPackage.COMPONENT__RUNNABLES, null, msgs);
			msgs = basicSetRunnables(newRunnables, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__RUNNABLES, newRunnables, newRunnables));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Generator> getGenerator() {
		if (generator == null) {
			generator = new EObjectContainmentEList<Generator>(Generator.class, this, ArchitecturetoolPackage.COMPONENT__GENERATOR);
		}
		return generator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Flows getFlows() {
		return flows;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFlows(Flows newFlows, NotificationChain msgs) {
		Flows oldFlows = flows;
		flows = newFlows;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__FLOWS, oldFlows, newFlows);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFlows(Flows newFlows) {
		if (newFlows != flows) {
			NotificationChain msgs = null;
			if (flows != null)
				msgs = ((InternalEObject)flows).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ArchitecturetoolPackage.COMPONENT__FLOWS, null, msgs);
			if (newFlows != null)
				msgs = ((InternalEObject)newFlows).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ArchitecturetoolPackage.COMPONENT__FLOWS, null, msgs);
			msgs = basicSetFlows(newFlows, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ArchitecturetoolPackage.COMPONENT__FLOWS, newFlows, newFlows));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Parameter> getParameters() {
		if (parameters == null) {
			parameters = new EObjectContainmentEList<Parameter>(Parameter.class, this, ArchitecturetoolPackage.COMPONENT__PARAMETERS);
		}
		return parameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ProcMem> getProcmem() {
		if (procmem == null) {
			procmem = new EObjectContainmentEList<ProcMem>(ProcMem.class, this, ArchitecturetoolPackage.COMPONENT__PROCMEM);
		}
		return procmem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public String getDataStructureName() {
		return dataStructureName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setDataStructureName(String newDataStructureName) {
		String oldDataStructureName = dataStructureName;
		String name = newDataStructureName;
		String string = null;
		for (int i = 1; i < name.length(); i++) {
			if (Character.isUpperCase(name.charAt(i))) {
				StringBuilder str = new StringBuilder(name);
				string = str.insert(i, "_").toString().toUpperCase();
			}
		}
		dataStructureName = string;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ArchitecturetoolPackage.COMPONENT__DATA_STRUCTURE_NAME, oldDataStructureName, dataStructureName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT__SUBCOMPONENT:
				return ((InternalEList<?>)getSubcomponent()).basicRemove(otherEnd, msgs);
			case ArchitecturetoolPackage.COMPONENT__PORTS:
				return basicSetPorts(null, msgs);
			case ArchitecturetoolPackage.COMPONENT__RUNNABLES:
				return basicSetRunnables(null, msgs);
			case ArchitecturetoolPackage.COMPONENT__GENERATOR:
				return ((InternalEList<?>)getGenerator()).basicRemove(otherEnd, msgs);
			case ArchitecturetoolPackage.COMPONENT__FLOWS:
				return basicSetFlows(null, msgs);
			case ArchitecturetoolPackage.COMPONENT__PARAMETERS:
				return ((InternalEList<?>)getParameters()).basicRemove(otherEnd, msgs);
			case ArchitecturetoolPackage.COMPONENT__PROCMEM:
				return ((InternalEList<?>)getProcmem()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT__NAME:
				return getName();
			case ArchitecturetoolPackage.COMPONENT__SUBCOMPONENT:
				return getSubcomponent();
			case ArchitecturetoolPackage.COMPONENT__EXTERNAL_STATIC_MEM_USED:
				return isExternalStaticMemUsed();
			case ArchitecturetoolPackage.COMPONENT__PORTS:
				return getPorts();
			case ArchitecturetoolPackage.COMPONENT__RUNNABLES:
				return getRunnables();
			case ArchitecturetoolPackage.COMPONENT__GENERATOR:
				return getGenerator();
			case ArchitecturetoolPackage.COMPONENT__FLOWS:
				return getFlows();
			case ArchitecturetoolPackage.COMPONENT__PARAMETERS:
				return getParameters();
			case ArchitecturetoolPackage.COMPONENT__PROCMEM:
				return getProcmem();
			case ArchitecturetoolPackage.COMPONENT__DATA_STRUCTURE_NAME:
				return getDataStructureName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT__NAME:
				setName((String)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__SUBCOMPONENT:
				getSubcomponent().clear();
				getSubcomponent().addAll((Collection<? extends SubComponent>)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__EXTERNAL_STATIC_MEM_USED:
				setExternalStaticMemUsed((Boolean)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__PORTS:
				setPorts((Ports)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__RUNNABLES:
				setRunnables((Runnables)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__GENERATOR:
				getGenerator().clear();
				getGenerator().addAll((Collection<? extends Generator>)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__FLOWS:
				setFlows((Flows)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__PARAMETERS:
				getParameters().clear();
				getParameters().addAll((Collection<? extends Parameter>)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__PROCMEM:
				getProcmem().clear();
				getProcmem().addAll((Collection<? extends ProcMem>)newValue);
				return;
			case ArchitecturetoolPackage.COMPONENT__DATA_STRUCTURE_NAME:
				setDataStructureName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT__SUBCOMPONENT:
				getSubcomponent().clear();
				return;
			case ArchitecturetoolPackage.COMPONENT__EXTERNAL_STATIC_MEM_USED:
				setExternalStaticMemUsed(EXTERNAL_STATIC_MEM_USED_EDEFAULT);
				return;
			case ArchitecturetoolPackage.COMPONENT__PORTS:
				setPorts((Ports)null);
				return;
			case ArchitecturetoolPackage.COMPONENT__RUNNABLES:
				setRunnables((Runnables)null);
				return;
			case ArchitecturetoolPackage.COMPONENT__GENERATOR:
				getGenerator().clear();
				return;
			case ArchitecturetoolPackage.COMPONENT__FLOWS:
				setFlows((Flows)null);
				return;
			case ArchitecturetoolPackage.COMPONENT__PARAMETERS:
				getParameters().clear();
				return;
			case ArchitecturetoolPackage.COMPONENT__PROCMEM:
				getProcmem().clear();
				return;
			case ArchitecturetoolPackage.COMPONENT__DATA_STRUCTURE_NAME:
				setDataStructureName(DATA_STRUCTURE_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ArchitecturetoolPackage.COMPONENT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ArchitecturetoolPackage.COMPONENT__SUBCOMPONENT:
				return subcomponent != null && !subcomponent.isEmpty();
			case ArchitecturetoolPackage.COMPONENT__EXTERNAL_STATIC_MEM_USED:
				return externalStaticMemUsed != EXTERNAL_STATIC_MEM_USED_EDEFAULT;
			case ArchitecturetoolPackage.COMPONENT__PORTS:
				return ports != null;
			case ArchitecturetoolPackage.COMPONENT__RUNNABLES:
				return runnables != null;
			case ArchitecturetoolPackage.COMPONENT__GENERATOR:
				return generator != null && !generator.isEmpty();
			case ArchitecturetoolPackage.COMPONENT__FLOWS:
				return flows != null;
			case ArchitecturetoolPackage.COMPONENT__PARAMETERS:
				return parameters != null && !parameters.isEmpty();
			case ArchitecturetoolPackage.COMPONENT__PROCMEM:
				return procmem != null && !procmem.isEmpty();
			case ArchitecturetoolPackage.COMPONENT__DATA_STRUCTURE_NAME:
				return DATA_STRUCTURE_NAME_EDEFAULT == null ? dataStructureName != null : !DATA_STRUCTURE_NAME_EDEFAULT.equals(dataStructureName);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", externalStaticMemUsed: ");
		result.append(externalStaticMemUsed);
		result.append(", dataStructureName: ");
		result.append(dataStructureName);
		result.append(')');
		return result.toString();
	}

	/**
	 * @generated NOT
	 */
	@Override
	public boolean getExternalStaticMemUsed() {
		// TODO Auto-generated method stub
		return externalStaticMemUsed;
	}

} //ComponentImpl
