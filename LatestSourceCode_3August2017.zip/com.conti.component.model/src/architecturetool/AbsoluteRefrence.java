/**
 */
package architecturetool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Absolute Refrence</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.AbsoluteRefrence#getDatastructure <em>Datastructure</em>}</li>
 *   <li>{@link architecturetool.AbsoluteRefrence#getAttribute <em>Attribute</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getAbsoluteRefrence()
 * @model
 * @generated
 */
public interface AbsoluteRefrence extends ComponentAttribute {
	/**
	 * Returns the value of the '<em><b>Datastructure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Datastructure</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Datastructure</em>' reference.
	 * @see #setDatastructure(DataStructure)
	 * @see architecturetool.ArchitecturetoolPackage#getAbsoluteRefrence_Datastructure()
	 * @model
	 * @generated
	 */
	DataStructure getDatastructure();

	/**
	 * Sets the value of the '{@link architecturetool.AbsoluteRefrence#getDatastructure <em>Datastructure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Datastructure</em>' reference.
	 * @see #getDatastructure()
	 * @generated
	 */
	void setDatastructure(DataStructure value);

	/**
	 * Returns the value of the '<em><b>Attribute</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute</em>' reference.
	 * @see #setAttribute(Attribute)
	 * @see architecturetool.ArchitecturetoolPackage#getAbsoluteRefrence_Attribute()
	 * @model
	 * @generated
	 */
	Attribute getAttribute();

	/**
	 * Sets the value of the '{@link architecturetool.AbsoluteRefrence#getAttribute <em>Attribute</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attribute</em>' reference.
	 * @see #getAttribute()
	 * @generated
	 */
	void setAttribute(Attribute value);

} // AbsoluteRefrence
