/**
 */
package architecturetool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Memory Region</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.MemoryRegion#getStartAddress <em>Start Address</em>}</li>
 *   <li>{@link architecturetool.MemoryRegion#getEndAddress <em>End Address</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getMemoryRegion()
 * @model
 * @generated
 */
public interface MemoryRegion extends EObject {
	/**
	 * Returns the value of the '<em><b>Start Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start Address</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start Address</em>' attribute.
	 * @see #setStartAddress(int)
	 * @see architecturetool.ArchitecturetoolPackage#getMemoryRegion_StartAddress()
	 * @model
	 * @generated
	 */
	int getStartAddress();

	/**
	 * Sets the value of the '{@link architecturetool.MemoryRegion#getStartAddress <em>Start Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start Address</em>' attribute.
	 * @see #getStartAddress()
	 * @generated
	 */
	void setStartAddress(int value);

	/**
	 * Returns the value of the '<em><b>End Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End Address</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End Address</em>' attribute.
	 * @see #setEndAddress(int)
	 * @see architecturetool.ArchitecturetoolPackage#getMemoryRegion_EndAddress()
	 * @model
	 * @generated
	 */
	int getEndAddress();

	/**
	 * Sets the value of the '{@link architecturetool.MemoryRegion#getEndAddress <em>End Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End Address</em>' attribute.
	 * @see #getEndAddress()
	 * @generated
	 */
	void setEndAddress(int value);

} // MemoryRegion
