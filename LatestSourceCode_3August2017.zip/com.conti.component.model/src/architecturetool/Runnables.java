/**
 */
package architecturetool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Runnables</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.Runnables#getRunnable <em>Runnable</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getRunnables()
 * @model
 * @generated
 */
public interface Runnables extends EObject {
	/**
	 * Returns the value of the '<em><b>Runnable</b></em>' containment reference list.
	 * The list contents are of type {@link architecturetool.Runnable}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Runnable</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Runnable</em>' containment reference list.
	 * @see architecturetool.ArchitecturetoolPackage#getRunnables_Runnable()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<architecturetool.Runnable> getRunnable();

} // Runnables
