/**
 */
package architecturetool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.Attribute#getDataType <em>Data Type</em>}</li>
 *   <li>{@link architecturetool.Attribute#getEnum <em>Enum</em>}</li>
 *   <li>{@link architecturetool.Attribute#getAttributeType <em>Attribute Type</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends ComponentAttribute {
	/**
	 * Returns the value of the '<em><b>Data Type</b></em>' attribute.
	 * The literals are from the enumeration {@link architecturetool.DatatypeEnum}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Type</em>' attribute.
	 * @see architecturetool.DatatypeEnum
	 * @see #setDataType(DatatypeEnum)
	 * @see architecturetool.ArchitecturetoolPackage#getAttribute_DataType()
	 * @model required="true"
	 * @generated
	 */
	DatatypeEnum getDataType();

	/**
	 * Sets the value of the '{@link architecturetool.Attribute#getDataType <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type</em>' attribute.
	 * @see architecturetool.DatatypeEnum
	 * @see #getDataType()
	 * @generated
	 */
	void setDataType(DatatypeEnum value);

	/**
	 * Returns the value of the '<em><b>Enum</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Enum</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Enum</em>' reference.
	 * @see #setEnum(architecturetool.Enum)
	 * @see architecturetool.ArchitecturetoolPackage#getAttribute_Enum()
	 * @model
	 * @generated
	 */
	architecturetool.Enum getEnum();

	/**
	 * Sets the value of the '{@link architecturetool.Attribute#getEnum <em>Enum</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Enum</em>' reference.
	 * @see #getEnum()
	 * @generated
	 */
	void setEnum(architecturetool.Enum value);

	/**
	 * Returns the value of the '<em><b>Attribute Type</b></em>' attribute.
	 * The default value is <code>"BASIC_TYPE"</code>.
	 * The literals are from the enumeration {@link architecturetool.AttributeTypeEnum}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute Type</em>' attribute.
	 * @see architecturetool.AttributeTypeEnum
	 * @see #setAttributeType(AttributeTypeEnum)
	 * @see architecturetool.ArchitecturetoolPackage#getAttribute_AttributeType()
	 * @model default="BASIC_TYPE" required="true"
	 * @generated
	 */
	AttributeTypeEnum getAttributeType();

	/**
	 * Sets the value of the '{@link architecturetool.Attribute#getAttributeType <em>Attribute Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attribute Type</em>' attribute.
	 * @see architecturetool.AttributeTypeEnum
	 * @see #getAttributeType()
	 * @generated
	 */
	void setAttributeType(AttributeTypeEnum value);

} // Attribute
