/**
 */
package architecturetool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Memory Budget</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see architecturetool.ArchitecturetoolPackage#getMemoryBudget()
 * @model
 * @generated
 */
public interface MemoryBudget extends EObject {
} // MemoryBudget
