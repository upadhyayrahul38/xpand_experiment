/**
 */
package architecturetool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link architecturetool.Port#getName <em>Name</em>}</li>
 *   <li>{@link architecturetool.Port#getPortDirection <em>Port Direction</em>}</li>
 *   <li>{@link architecturetool.Port#getParameter <em>Parameter</em>}</li>
 *   <li>{@link architecturetool.Port#getType <em>Type</em>}</li>
 *   <li>{@link architecturetool.Port#getVirtualAddressBlock <em>Virtual Address Block</em>}</li>
 *   <li>{@link architecturetool.Port#isShowAllTypes <em>Show All Types</em>}</li>
 *   <li>{@link architecturetool.Port#getPortTypeCompoName <em>Port Type Compo Name</em>}</li>
 *   <li>{@link architecturetool.Port#isInternalPort <em>Internal Port</em>}</li>
 * </ul>
 *
 * @see architecturetool.ArchitecturetoolPackage#getPort()
 * @model
 * @generated
 */
public interface Port extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link architecturetool.Port#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Port Direction</b></em>' attribute.
	 * The literals are from the enumeration {@link architecturetool.PortListType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Port Direction</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port Direction</em>' attribute.
	 * @see architecturetool.PortListType
	 * @see #setPortDirection(PortListType)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_PortDirection()
	 * @model required="true"
	 * @generated
	 */
	PortListType getPortDirection();

	/**
	 * Sets the value of the '{@link architecturetool.Port#getPortDirection <em>Port Direction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Port Direction</em>' attribute.
	 * @see architecturetool.PortListType
	 * @see #getPortDirection()
	 * @generated
	 */
	void setPortDirection(PortListType value);

	/**
	 * Returns the value of the '<em><b>Parameter</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameter</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameter</em>' reference.
	 * @see #setParameter(Parameter)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_Parameter()
	 * @model
	 * @generated
	 */
	Parameter getParameter();

	/**
	 * Sets the value of the '{@link architecturetool.Port#getParameter <em>Parameter</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parameter</em>' reference.
	 * @see #getParameter()
	 * @generated
	 */
	void setParameter(Parameter value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(DataStructure)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_Type()
	 * @model required="true"
	 * @generated
	 */
	DataStructure getType();

	/**
	 * Sets the value of the '{@link architecturetool.Port#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(DataStructure value);

	/**
	 * Returns the value of the '<em><b>Virtual Address Block</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Virtual Address Block</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Virtual Address Block</em>' attribute.
	 * @see #setVirtualAddressBlock(String)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_VirtualAddressBlock()
	 * @model
	 * @generated
	 */
	String getVirtualAddressBlock();

	/**
	 * Sets the value of the '{@link architecturetool.Port#getVirtualAddressBlock <em>Virtual Address Block</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Virtual Address Block</em>' attribute.
	 * @see #getVirtualAddressBlock()
	 * @generated
	 */
	void setVirtualAddressBlock(String value);

	/**
	 * Returns the value of the '<em><b>Show All Types</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Show All Types</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Show All Types</em>' attribute.
	 * @see #setShowAllTypes(boolean)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_ShowAllTypes()
	 * @model
	 * @generated
	 */
	boolean isShowAllTypes();

	/**
	 * Sets the value of the '{@link architecturetool.Port#isShowAllTypes <em>Show All Types</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Show All Types</em>' attribute.
	 * @see #isShowAllTypes()
	 * @generated
	 */
	void setShowAllTypes(boolean value);
	/**
	 * Returns the value of the '<em><b>Port Type Compo Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Port Type Compo Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port Type Compo Name</em>' attribute.
	 * @see #setPortTypeCompoName(String)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_PortTypeCompoName()
	 * @model
	 * @generated
	 */
	String getPortTypeCompoName();

	/**
	 * Sets the value of the '{@link architecturetool.Port#getPortTypeCompoName <em>Port Type Compo Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Port Type Compo Name</em>' attribute.
	 * @see #getPortTypeCompoName()
	 * @generated
	 */
	void setPortTypeCompoName(String value);

	/**
	 * Returns the value of the '<em><b>Internal Port</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Internal Port</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Internal Port</em>' attribute.
	 * @see #setInternalPort(boolean)
	 * @see architecturetool.ArchitecturetoolPackage#getPort_InternalPort()
	 * @model
	 * @generated
	 */
	boolean isInternalPort();

	/**
	 * Sets the value of the '{@link architecturetool.Port#isInternalPort <em>Internal Port</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Internal Port</em>' attribute.
	 * @see #isInternalPort()
	 * @generated
	 */
	void setInternalPort(boolean value);

	/**
	 * @generated NOT
	 * @return
	 */
	boolean getShowAllTypes();
	/**
	 * @generated NOT
	 * @return
	 */
	String getPortType_ComponentName();

} // Port
