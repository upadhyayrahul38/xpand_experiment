/**
 */
package architecturetool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Runtime Budget</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see architecturetool.ArchitecturetoolPackage#getRuntimeBudget()
 * @model
 * @generated
 */
public interface RuntimeBudget extends EObject {
} // RuntimeBudget
