package com.conti.component.ui.templates;

import architecturetool.*;
import architecturetool.Runnable;
import org.eclipse.emf.common.util.EList;

public class PortHeadergenerator
{
  protected static String nl;
  public static synchronized PortHeadergenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    PortHeadergenerator result = new PortHeadergenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "#ifndef ";
  protected final String TEXT_2 = "_MAIN_H_INCLUDED" + NL + "#define ";
  protected final String TEXT_3 = "_MAIN_H_INCLUDED" + NL + "" + NL + "#include \"ga_global.h\"" + NL + "" + NL + "#ifdef __cplusplus" + NL + "extern \"C\" {" + NL + "#endif";
  protected final String TEXT_4 = NL + "/*********************/" + NL + "/* request port list */" + NL + "/*********************/  ";
  protected final String TEXT_5 = NL + "typedef struct {";
  protected final String TEXT_6 = NL + "#ifdef ";
  protected final String TEXT_7 = NL + "#if(";
  protected final String TEXT_8 = "> 0)";
  protected final String TEXT_9 = NL;
  protected final String TEXT_10 = "_";
  protected final String TEXT_11 = "      const*";
  protected final String TEXT_12 = "    ";
  protected final String TEXT_13 = NL;
  protected final String TEXT_14 = "_";
  protected final String TEXT_15 = "      const*";
  protected final String TEXT_16 = ";" + NL + "#endif" + NL + "#else" + NL + "#error \"undefined ";
  protected final String TEXT_17 = "\"" + NL + "#endif";
  protected final String TEXT_18 = NL;
  protected final String TEXT_19 = "_";
  protected final String TEXT_20 = "  const* ";
  protected final String TEXT_21 = ";";
  protected final String TEXT_22 = NL;
  protected final String TEXT_23 = "_";
  protected final String TEXT_24 = "  const* ";
  protected final String TEXT_25 = ";";
  protected final String TEXT_26 = NL + " }";
  protected final String TEXT_27 = "_ReqPorts;" + NL + "    ";
  protected final String TEXT_28 = NL + "    " + NL + " ";
  protected final String TEXT_29 = NL + "/*********************/" + NL + "/* provide port list */" + NL + "/*********************/";
  protected final String TEXT_30 = NL + "typedef struct {";
  protected final String TEXT_31 = NL;
  protected final String TEXT_32 = " *p_";
  protected final String TEXT_33 = ";";
  protected final String TEXT_34 = NL;
  protected final String TEXT_35 = " *p_";
  protected final String TEXT_36 = ";";
  protected final String TEXT_37 = NL + " }";
  protected final String TEXT_38 = "_ProPorts;" + NL + "    ";
  protected final String TEXT_39 = NL + "void ";
  protected final String TEXT_40 = "_Exec (";
  protected final String TEXT_41 = "_ReqPorts const*const reqPort,";
  protected final String TEXT_42 = " GS_t_SimInitDAP *const p_SimInit, GS_t_NonSimInitDAP *const p_NonSimInit";
  protected final String TEXT_43 = ",";
  protected final String TEXT_44 = "_ProPorts const*const proPort";
  protected final String TEXT_45 = ");    \t";
  protected final String TEXT_46 = NL + "void ";
  protected final String TEXT_47 = "_Exec (";
  protected final String TEXT_48 = "_ReqPorts const*const reqPort ";
  protected final String TEXT_49 = " ";
  protected final String TEXT_50 = ",";
  protected final String TEXT_51 = "_ProPorts const*const proPort";
  protected final String TEXT_52 = ");";
  protected final String TEXT_53 = NL + NL + "\t";
  protected final String TEXT_54 = NL + "#ifdef __cplusplus" + NL + "}" + NL + "#endif" + NL + "#endif /*DAP_EXT_H_INCLUDED*/";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     Component component = (Component) argument; 
    stringBuffer.append(TEXT_1);
    stringBuffer.append(component.getName().toUpperCase());
    stringBuffer.append(TEXT_2);
    stringBuffer.append(component.getName().toUpperCase());
    stringBuffer.append(TEXT_3);
    
boolean hasRequestPort = false;
boolean hasProviderPort = false;
EList<Runnable> itsRunnable = component.getRunnables().getRunnable();
for (Runnable runnable : itsRunnable) {
    EList<Port> port = runnable.getPorts();
    for (Port port2 : port) {
    if(port2.getPortDirection().equals(PortListType.REQUEST)) {
    	hasRequestPort = true;
    } else {
    	hasProviderPort = true;
    }
    }
    }
    if(hasRequestPort) {
    stringBuffer.append(TEXT_4);
    
for (Runnable runnable : itsRunnable) {
    stringBuffer.append(TEXT_5);
    EList<Port> port = runnable.getPorts();for (Port port2 : port) {
     if(port2.getParameter()!= null){
    stringBuffer.append(TEXT_6);
    stringBuffer.append(port2.getParameter().getName());
    stringBuffer.append(TEXT_7);
    stringBuffer.append(port2.getParameter().getName());
    stringBuffer.append(TEXT_8);
     if(port2.getName()==null){
    stringBuffer.append(TEXT_9);
    stringBuffer.append(component.getName());
    stringBuffer.append(TEXT_10);
    stringBuffer.append(port2.getType().getName());
    stringBuffer.append(TEXT_11);
    stringBuffer.append(port2.getType().getName().substring(0,1).toLowerCase()+port2.getType().getName().substring(1,port2.getType().getName().length()));
    } else {
    stringBuffer.append(TEXT_12);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(component.getName());
    stringBuffer.append(TEXT_14);
    stringBuffer.append(port2.getName());
    stringBuffer.append(TEXT_15);
    stringBuffer.append(port2.getName().substring(0, 1).toLowerCase()+port2.getName().substring(1,port2.getName().length()));
    }
    stringBuffer.append(TEXT_16);
    stringBuffer.append(port2.getParameter().getName());
    stringBuffer.append(TEXT_17);
    } else {
    if(port2.getPortDirection().equals(PortListType.REQUEST)){
     if(port2.getName()==null){
    stringBuffer.append(TEXT_18);
    stringBuffer.append(component.getName());
    stringBuffer.append(TEXT_19);
    stringBuffer.append(port2.getType().getName());
    stringBuffer.append(TEXT_20);
    stringBuffer.append(port2.getType().getName().substring(0,1).toLowerCase()+port2.getType().getName().substring(1,port2.getType().getName().length()));
    stringBuffer.append(TEXT_21);
    }else{
    stringBuffer.append(TEXT_22);
    stringBuffer.append(component.getName());
    stringBuffer.append(TEXT_23);
    stringBuffer.append(port2.getName());
    stringBuffer.append(TEXT_24);
    stringBuffer.append(port2.getName().substring(0, 1).toLowerCase()+port2.getName().substring(1,port2.getName().length()));
    stringBuffer.append(TEXT_25);
    }
    }
    }
    }
    stringBuffer.append(TEXT_26);
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_27);
    }
    }
    stringBuffer.append(TEXT_28);
    if(hasProviderPort) {
    stringBuffer.append(TEXT_29);
    
for (Runnable runnable : itsRunnable) {
    stringBuffer.append(TEXT_30);
    EList<Port> port = runnable.getPorts();for (Port port2 : port) {
     if(port2.getPortDirection().equals(PortListType.PROVIDER)) {
     if(port2.getName()==null){
    stringBuffer.append(TEXT_31);
    stringBuffer.append(port2.getType().getName());
    stringBuffer.append(TEXT_32);
    stringBuffer.append(port2.getType().getName());
    stringBuffer.append(TEXT_33);
    } else {
    stringBuffer.append(TEXT_34);
    stringBuffer.append(port2.getName());
    stringBuffer.append(TEXT_35);
    stringBuffer.append(port2.getName());
    stringBuffer.append(TEXT_36);
    }
    }
    }
    stringBuffer.append(TEXT_37);
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_38);
    }
    }


    for (Runnable runnable : itsRunnable) {
    if(component.isExternalStaticMemUsed()) {
    stringBuffer.append(TEXT_39);
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_40);
     if(hasRequestPort) {
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_41);
    }
    stringBuffer.append(TEXT_42);
     if(hasProviderPort) { 
    stringBuffer.append(TEXT_43);
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_44);
     }
    stringBuffer.append(TEXT_45);
    } else {
    stringBuffer.append(TEXT_46);
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_47);
     if(hasRequestPort) {
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_48);
    }
     if(hasProviderPort) { 
    stringBuffer.append(TEXT_49);
    if(hasRequestPort) {
    stringBuffer.append(TEXT_50);
    }
    stringBuffer.append(runnable.getName());
    stringBuffer.append(TEXT_51);
    }
    stringBuffer.append(TEXT_52);
    }
    stringBuffer.append(TEXT_53);
    }
    stringBuffer.append(TEXT_54);
    return stringBuffer.toString();
  }
}
