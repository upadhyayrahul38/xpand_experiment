package com.conti.component.ui.wizard;

import java.awt.GridLayout;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;

import com.conti.component.ui.view.ProjectView;

import org.eclipse.swt.widgets.Combo;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ComboViewer;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

public class ArchitectureToolFileWizardPage extends WizardPage {
	private static class ViewerLabelProvider extends LabelProvider {
		public Image getImage(Object element) {
			return super.getImage(element);
		}
		public String getText(Object element) {
			if (element instanceof IProject) {
				IProject iProject = (IProject) element;
				return iProject.getName();
			}
			return super.getText(element);
		}
	}
	private Text txtFilename;
	private ComboViewer comboViewer;
	private Combo combo;
	private Combo comboFileType;

	protected ArchitectureToolFileWizardPage(String pageName) {
		super(pageName);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new org.eclipse.swt.layout.GridLayout(2, false));
		
		Label lblProjectName = new Label(container, SWT.NONE);
		lblProjectName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblProjectName.setText("Project Name");
		
		comboViewer = new ComboViewer(container, SWT.READ_ONLY);
		combo = comboViewer.getCombo();
		combo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		comboViewer.setLabelProvider(new ViewerLabelProvider());
		comboViewer.setContentProvider(ArrayContentProvider.getInstance());
		comboViewer.setInput( ResourcesPlugin.getWorkspace().getRoot().getProjects());
		ISelection selection = null;
		IStructuredSelection iStructuredSelection = null;
		Object firstElement = null;
		IViewPart[] views = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getViews();
		IProject project = null;
		for (IViewPart iViewPart : views) {
			if (iViewPart.getTitle().equals("Project"))
			{
				ProjectView projView = ((ProjectView) iViewPart.getSite().getPart());
				selection = projView.getSelection();
				iStructuredSelection = (IStructuredSelection) selection;
				firstElement = iStructuredSelection.getFirstElement();
                if(firstElement instanceof IProject) {
                	project =((IProject)firstElement);
                }
			}
		}
		String name2 = project.getName();
		comboViewer.setSelection(iStructuredSelection);
		combo.addKeyListener(new KeyListener() {

			@Override
			public void keyReleased(KeyEvent e) {
				if (!combo.getText().isEmpty() && !txtFilename.getText().isEmpty() && !(comboFileType.getSelectionIndex()==-1)) {
					setPageComplete(true);
				} else {
					setPageComplete(false);
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
			}
		});
		
		Label lblFileType = new Label(container, SWT.NONE);
		lblFileType.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFileType.setText("File Type");
		
		comboFileType = new Combo(container, SWT.READ_ONLY);
		comboFileType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (!combo.getText().isEmpty() && !txtFilename.getText().isEmpty() && !(comboFileType.getSelectionIndex()==-1)) {
					setPageComplete(true);
				} else {
					setPageComplete(false);
				}
			}
		});
		comboFileType.setItems(new String[] {"Component Architecture File", "Project Architecture  File"});
		comboFileType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
				
		Label lblFileName = new Label(container, SWT.NONE);
		lblFileName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFileName.setText("File Name");
		
		txtFilename = new Text(container, SWT.BORDER);
		txtFilename.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtFilename.addKeyListener(new KeyListener() {

			@Override
			public void keyReleased(KeyEvent e) {
				if (!combo.getText().isEmpty() && !txtFilename.getText().isEmpty() && !(comboFileType.getSelectionIndex()==-1)) {
					setPageComplete(true);
				} else {
					setPageComplete(false);
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
			}
		});
		setPageComplete(false);
	}
	public String getProjectName() {
		return combo.getText();
	}

	public String getFileName() {
		return txtFilename.getText();
	}
}
