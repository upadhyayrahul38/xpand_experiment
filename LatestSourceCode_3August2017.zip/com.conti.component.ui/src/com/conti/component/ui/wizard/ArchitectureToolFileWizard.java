package com.conti.component.ui.wizard;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Collections;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.NoNameElement;

public class ArchitectureToolFileWizard extends Wizard implements INewWizard {

	private ArchitectureToolFileWizardPage architectureToolFileWizardPage;

	public ArchitectureToolFileWizard() {
		// TODO Auto-generated constructor stub
	}
@Override
public void addPages() {
	 architectureToolFileWizardPage = new ArchitectureToolFileWizardPage("page 1");
	addPage(architectureToolFileWizardPage);
}
	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean performFinish() {
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IProject project = root.getProject(architectureToolFileWizardPage.getProjectName());

		IFile file = project.getFile(architectureToolFileWizardPage.getFileName() + ".architecturetool");
		if (!file.exists()) {
			try {
				file.create(null, IResource.NONE, null);
			} catch (CoreException e) {
				e.printStackTrace();
			}
		}
		ResourceSet rset = new ResourceSetImpl();
		rset.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
		rset.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool",
				new XMIResourceFactoryImpl());
		Resource resource = rset.createResource(URI.createURI(file.getFullPath().toString()));
		NoNameElement createNoNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
		MCC createMCC = ArchitecturetoolFactory.eINSTANCE.createMCC();
		ECU createECU = ArchitecturetoolFactory.eINSTANCE.createECU();
		createNoNameElement.getMcc().add(createMCC);
		createNoNameElement.getEcus().add(createECU);
		resource.getContents().add(createNoNameElement);
		try {
			resource.save(Collections.EMPTY_MAP);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}

}
