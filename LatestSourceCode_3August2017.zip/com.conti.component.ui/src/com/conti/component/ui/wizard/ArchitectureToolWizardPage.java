package com.conti.component.ui.wizard;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Combo;

public class ArchitectureToolWizardPage extends WizardPage {
	private Text txtprojectName;

	private Text txtFilename;
	private Composite container;
	private Label lblFilePath;
	private Text txtPath;
	private Button button;
	private Button btnCreateANew;
	private Combo comboFileType;
	private Label lblFileType;

	protected ArchitectureToolWizardPage(String pageName) {
		super(pageName);
		setTitle("Create New Architecture Tool");

	}

	@Override
	public void createControl(Composite parent) {
		setPageComplete(false);
		container = new Composite(parent, SWT.NULL);

		container.setLayout(new GridLayout(3, false));

		Label lblProjectName = new Label(container, SWT.NONE);
		lblProjectName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblProjectName.setText("Project Name");

		txtprojectName = new Text(container, SWT.BORDER);
		txtprojectName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtprojectName.addKeyListener(new KeyListener() {

			@Override
			public void keyReleased(KeyEvent e) {
				if (!txtprojectName.getText().isEmpty() ) {
					boolean endsWith = false;
					IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
					 for (IProject iProject : projects) {
						 endsWith = iProject.getName().endsWith(txtprojectName.getText());
					}
					 if(endsWith){
						 setPageComplete(false);
						 setErrorMessage("A project with that name already exists in the workspace");
					 }
					 else
					setPageComplete(true);
				} else {
					setPageComplete(false);
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
			}
		});
		 
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		btnCreateANew = new Button(container, SWT.CHECK);
		btnCreateANew.setText("Create A New File");
		btnCreateANew.setSelection(false);

		new Label(container, SWT.NONE);
		
		lblFileType = new Label(container, SWT.NONE);
		lblFileType.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFileType.setText("File Type");
		lblFileType.setVisible(false);
		
		comboFileType = new Combo(container, SWT.READ_ONLY);
		comboFileType.setItems(new String[] {"Component Architecture File", "Project Architecture  File"});
		comboFileType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		comboFileType.setVisible(false);
		new Label(container, SWT.NONE);

		Label lblFileName = new Label(container, SWT.NONE);
		lblFileName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFileName.setText("File Name");

		txtFilename = new Text(container, SWT.BORDER);
		txtFilename.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtFilename.setVisible(false);
		lblFileName.setVisible(false);

		btnCreateANew.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if(btnCreateANew.getSelection())
				{
					setPageComplete(false);
					txtFilename.setVisible(true);
					lblFileName.setVisible(true);
					comboFileType.setVisible(true);
					lblFileType.setVisible(true);
					txtFilename.addKeyListener(new KeyListener() {

						@Override
						public void keyReleased(KeyEvent e) {
							if (!txtprojectName.getText().isEmpty() && !txtFilename.getText().isEmpty() && !(comboFileType.getSelectionIndex()==-1)) {
								setPageComplete(true);
							} else {
								setPageComplete(false);
							}
						}

						@Override
						public void keyPressed(KeyEvent e) {
							// TODO Auto-generated method stub
						}
					});
				}
				else
				{
					setPageComplete(true);
					txtFilename.setVisible(false);
					lblFileName.setVisible(false);
					comboFileType.setVisible(false);
					lblFileType.setVisible(false);
				}

			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		setControl(container);
		new Label(container, SWT.NONE);

		lblFilePath = new Label(container, SWT.NONE);
		lblFilePath.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFilePath.setText("File Path");

		txtPath = new Text(container, SWT.BORDER);
		txtPath.setEditable(false);
		txtPath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		button = new Button(container, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DirectoryDialog dialog = new DirectoryDialog(Display.getDefault().getActiveShell());
				dialog.open();
				txtPath.setText(dialog.getFilterPath());
			}
		});
		button.setText(".......");
	}

	public Combo getComboFileType() {
		return comboFileType;
	}

	public String getProjectName() {
		return txtprojectName.getText();
	}

	public String getPath() {
		return txtPath.getText().toString();
	}

	public String getFileName() {
		return txtFilename.getText();
	}

}
