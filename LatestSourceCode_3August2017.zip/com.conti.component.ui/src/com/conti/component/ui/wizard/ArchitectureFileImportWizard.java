package com.conti.component.ui.wizard;

import java.io.IOException;
import java.util.Collections;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.IImportWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.PlatformUI;

import com.conti.component.ui.parsers.ReadExcel;
import com.conti.component.ui.view.ProjectView;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Root;
import autosar40.genericstructure.generaltemplateclasses.elementcollection.Collection;

public class ArchitectureFileImportWizard extends Wizard implements IImportWizard {

	private ArchitectureFileImportWizardPage architectureFileImportWizardPage;

	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {

	}

	@Override
	public boolean performFinish() {
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();

		IProject project = null;
		IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkbenchPart activePart = workbench.getActiveWorkbenchWindow().getActivePage().getActivePart();
		ISelection selection = null;
		IStructuredSelection iStructuredSelection = null;
		Object firstElement = null;
		if (activePart.getTitle().equals("Project") || activePart.getTitle().equals("Project Explorer")) {
			IWorkbenchPartSite site = activePart.getSite();
			if (site.getPart() != null && site.getPart() instanceof ProjectView) {

				ProjectView projView = ((ProjectView) site.getPart());
				selection = projView.getSelection();
				iStructuredSelection = (IStructuredSelection) selection;
				firstElement = iStructuredSelection.getFirstElement();
                if(firstElement instanceof IProject) {
                	project =((IProject)firstElement);
                }
			}

		}
		IFile file = project.getFile(architectureFileImportWizardPage.getFileName());
		if (!file.exists()) {
			try {
				file.create(null, IResource.NONE, null);
			} catch (CoreException e) {
				e.printStackTrace();
			}
		}

		String txtFilePath = architectureFileImportWizardPage.getTxtFilePath();
		ResourceSet rset = new ResourceSetImpl();
		rset.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
		rset.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool",
				new XMIResourceFactoryImpl());
		Resource resource = rset.getResource(URI.createFileURI(txtFilePath),true); //URI.createFileURI(txtFilePath)
		EObject eObject = resource.getContents().get(0);
		
		Root createRoot = ArchitecturetoolFactory.eINSTANCE.createRoot();
		if(eObject instanceof Root) {
			Root newRoot = EcoreUtil.copy((Root)eObject);
			resource.getContents().add(newRoot);
		}
		else if(eObject instanceof NoNameElement) {
			NoNameElement noNameElement = EcoreUtil.copy((NoNameElement)eObject);
			createRoot.getNonameelement().add(noNameElement);
			resource.getContents().add(createRoot);
		}
		
		
//		ResourceSet rset1 = new ResourceSetImpl();
//		rset1.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
//		rset1.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool",
//				new XMIResourceFactoryImpl());
		Resource resource1 = rset.createResource(URI.createURI(file.getFullPath().toString()));
		resource1.getContents().addAll(resource.getContents());
		try {
			resource1.save(Collections.EMPTY_MAP);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			project.refreshLocal(1, null);
		} catch (CoreException e) {
			e.printStackTrace();
		}

		return true;
	}
	
	@Override
	public void addPages() {
		architectureFileImportWizardPage = new ArchitectureFileImportWizardPage("page1");
		addPage(architectureFileImportWizardPage);
		super.addPages();
	}

}
