package com.conti.component.ui.wizard;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.internal.ide.dialogs.IDEResourceInfoUtils;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Root;

public class ArchitectureToolWizard extends Wizard implements INewWizard {

	private ArchitectureToolWizardPage toolWizardPage;

	public ArchitectureToolWizard() {
		setWindowTitle("New Wizard");
	}

	@Override
	public void addPages() {
		toolWizardPage = new ArchitectureToolWizardPage("page 1");
		addPage(toolWizardPage);
	}

	@Override
	public boolean performFinish() {
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
 String fileType = toolWizardPage.getComboFileType().getText();
		IProject project = root.getProject(toolWizardPage.getProjectName());
		@SuppressWarnings("restriction")
		String resolvedLocationText = IDEResourceInfoUtils.getResolvedLocationText(root);
		File newProjectFolder = null;
		IProjectDescription desc = null;
		if (toolWizardPage.getPath().trim().length() <= 0) {
			newProjectFolder = new File(resolvedLocationText + "/" + project.getName());
			newProjectFolder.mkdir();

			IWorkspace w = ResourcesPlugin.getWorkspace();
			desc = w.newProjectDescription(project.getName());
			org.eclipse.core.runtime.Path path = new org.eclipse.core.runtime.Path(
					resolvedLocationText + "/" + project.getName());
			desc.setLocation(path);
		} else {
//			newProjectFolder = new File(toolWizardPage.getPath() + "/" + project.getName());
//			newProjectFolder.mkdir();

			IWorkspace w = ResourcesPlugin.getWorkspace();
			desc = w.newProjectDescription(project.getName());
			org.eclipse.core.runtime.Path path = new org.eclipse.core.runtime.Path(
					toolWizardPage.getPath() ); //+ "/" + project.getName()
			desc.setLocation(path);
		}

		try {
			if (!project.exists())
				project.create(desc, null);
			project.open(new NullProgressMonitor());
			project.refreshLocal(IResource.DEPTH_INFINITE, new NullProgressMonitor());
		} catch (CoreException e) {
			e.printStackTrace();
		}
		if(fileType.endsWith("Component Architecture File"))
		{
			if (toolWizardPage.getFileName() != null && !toolWizardPage.getFileName().isEmpty()) {
				IFile file = project.getFile(toolWizardPage.getFileName() + ".architecturetool");
				if (!file.exists()) {
					try {
						file.create(null, IResource.NONE, null);
					} catch (CoreException e) {
						e.printStackTrace();
					}
				}
				ResourceSet resourceSet = new ResourceSetImpl();
				resourceSet.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
				resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool",
						new XMIResourceFactoryImpl());
				Resource resource = resourceSet.createResource(URI.createFileURI(file.getLocation().toOSString()));
				Root createRoot = ArchitecturetoolFactory.eINSTANCE.createRoot();
				NoNameElement createNoNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
				createRoot.getNonameelement().add(createNoNameElement);
				
				resource.getContents().add(createRoot);
				try {
					resource.save(Collections.EMPTY_MAP);
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		}
		if(fileType.equals("Project Architecture  File"))
		{
			if (toolWizardPage.getFileName() != null && !toolWizardPage.getFileName().isEmpty()) {
				IFile file = project.getFile(toolWizardPage.getFileName() + ".rp");
				if (!file.exists()) {
					try {
						file.create(null, IResource.NONE, null);
					} catch (CoreException e) {
						e.printStackTrace();
					}
				}
				ResourceSet resourceSet = new ResourceSetImpl();
				resourceSet.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
				resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("rp",
						new XMIResourceFactoryImpl());
				Resource resource = resourceSet.createResource(URI.createFileURI(file.getLocation().toOSString()));
				Root createRoot = ArchitecturetoolFactory.eINSTANCE.createRoot();
				NoNameElement createNoNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
				createRoot.getNonameelement().add(createNoNameElement);
				
				resource.getContents().add(createRoot);
				try {
					resource.save(Collections.EMPTY_MAP);
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		}
		
		
		return true;
	}

	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {

	}

}
