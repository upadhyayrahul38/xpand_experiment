package com.conti.component.ui.wizard;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.IImportWizard;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.PlatformUI;

import com.conti.component.ui.parsers.ReadExcel;
import com.conti.component.ui.view.ProjectView;



public class ExcelImportWizard extends Wizard implements IImportWizard {

	private ExcelImportWizardPage excelImportWizardPage;

	public ExcelImportWizard() {
	}

	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {
	}

	@Override
	public void addPages() {
		excelImportWizardPage = new ExcelImportWizardPage("page1");
		addPage(excelImportWizardPage);
		super.addPages();
	}

	@Override
	public boolean performFinish() {

		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();

		IProject project = null;
		IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkbenchPart activePart = workbench.getActiveWorkbenchWindow().getActivePage().getActivePart();
		ISelection selection = null;
		IStructuredSelection iStructuredSelection = null;
		Object firstElement = null;
		if (activePart.getTitle().equals("Project") || activePart.getTitle().equals("Project Explorer")) {
			IWorkbenchPartSite site = activePart.getSite();
			if (site.getPart() != null && site.getPart() instanceof ProjectView) {

				ProjectView projView = ((ProjectView) site.getPart());
				selection = projView.getSelection();
				iStructuredSelection = (IStructuredSelection) selection;
				firstElement = iStructuredSelection.getFirstElement();
                if(firstElement instanceof IProject) {
                	project = ((IProject)firstElement);
                }
			}

		}

		String txtFilePath = excelImportWizardPage.getTxtFilePath();

		ReadExcel excel = new ReadExcel();
		excel.importExcel(txtFilePath, project.getLocation() + "/" + excelImportWizardPage.getFileName());
		try {
			project.refreshLocal(1, null);
		} catch (CoreException e) {
			e.printStackTrace();
		}

		return true;
	}

}
