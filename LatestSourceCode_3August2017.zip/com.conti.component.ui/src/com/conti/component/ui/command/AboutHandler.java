package com.conti.component.ui.command;

import java.util.Dictionary;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IProduct;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

public class AboutHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {

		String version = getPlatformVersion();

		MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Architecture Tool",
				"Current version no:-" + version);

		return null;
	}

	public static String getPlatformVersion() {
		String version = null;

		try {
			Dictionary dictionary = org.eclipse.ui.internal.WorkbenchPlugin.getDefault().getBundle().getHeaders();
			version = (String) dictionary.get("Bundle-Version"); //$NON-NLS-1$
		} catch (NoClassDefFoundError e) {
			version = getProductVersion();
		}

		return version;
	}

	public static String getProductVersion() {
		String version = null;

		try {
			// this approach fails in "Rational Application Developer 6.0.1"
			IProduct product = Platform.getProduct();
			String aboutText = product.getProperty("aboutText"); //$NON-NLS-1$

			String pattern = "Version: (.*)\n"; //$NON-NLS-1$
			Pattern p = Pattern.compile(pattern);
			Matcher m = p.matcher(aboutText);
			boolean found = m.find();

			if (found) {
				version = m.group(1);
			}
		} catch (Exception e) {

		}

		return version;
	}

}
