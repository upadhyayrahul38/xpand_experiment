"""
stk_algo_if_wrapper
===================

**Important notice :**

To use this script an additional python package is needed, that is not part of
the Python(x,y) distribution.
<outputfolder> Folder has to be created

    **usage in command line:**
    python stk_algo_if_wrapper.py <algo_interface.xls> <outputfilename>

    python stk_algo_if_wrapper.py algo_interfaces_V1.13.xls AUTOSAR_AlgoTypes.ecuextract

    $Revision: 1.90 $

"""

# #####################################################
from xlrd import open_workbook,XL_CELL_TEXT,XL_CELL_NUMBER
import xlrd
import re
import sys
import string
import codecs
from operator import itemgetter

# Global variable indicating if output packages shall be sorted by short name
sort_subpackages = False

# Function to convert between AUTOSAR version 3.0 and version 4.0 XML tag names
def MapVersion3NameToV4(ver3name):
    conversionmap = { "RECORD-TYPE" : "IMPLEMENTATION-DATA-TYPE", "RECORD-ELEMENT" : "IMPLEMENTATION-DATA-TYPE-ELEMENT", "ARRAY-TYPE" : "IMPLEMENTATION-DATA-TYPE", "REAL-TYPE" : "IMPLEMENTATION-DATA-TYPE", "INTEGER-TYPE" : "IMPLEMENTATION-DATA-TYPE" }
    if ver3name in conversionmap:
        retval = conversionmap[ver3name]
    else:
        retval = ver3name
    return retval

# #############################################################################
# #############################################################################
# XML output class
# #############################################################################
# #############################################################################

# Class for exporting AUTOSAR EcuExtract XML files
class AUTOSAR_EcuExtract(object):
    # C onstructor to open an ECUExtract file for writing, writing header and root-level <AUTOSAR> tag
    def __init__(self, filename, version, subversion, tresos, force_imm_suffix):
        self.version = version
        self.subversion = subversion
        self.tresos = tresos
        self.force_imm_suffix = force_imm_suffix
        # Open an output file and write header information
        self.opentags = []
        self.tagmatch_regexp = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_\-]*$')
        self.wsmatch_regexp = re.compile(r'[ \t]+')
        try:
            if sys.version_info <= (2,6):
                self.file = codecs.open(filename, "wt", "utf-8")
            else:
                self.file = codecs.open(filename, "w", "utf-8")
            self.writeOneLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
            if self.version == 4:
                if self.tresos == True:
                  self.writeOneLine("<AUTOSAR xmlns=\"http://autosar.org/schema/r4.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://autosar.org/schema/r4.0 autosar_4-0-2.xsd\">")
                else:
                  self.writeOneLine("<AUTOSAR xmlns=\"http://autosar.org/schema/r4.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://autosar.org/schema/r4.0 autosar_4-0-1.xsd\">")

                self.opentags.append("AUTOSAR")
                self.writeOneLine("<AR-PACKAGES>")
                self.opentags.append("AR-PACKAGES")
            else:
                if self.subversion == 0 :
                    self.writeOneLine("<AUTOSAR xmlns=\"http://autosar.org/3.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://autosar.org/3.0.0 autosar.xsd\">")
                else:
                    self.writeOneLine("<AUTOSAR xmlns=\"http://autosar.org/3.2.1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://autosar.org/3.2.1 autosar.xsd\">")
                self.opentags.append("AUTOSAR")
                self.writeOneLine("<TOP-LEVEL-PACKAGES>")
                self.opentags.append("TOP-LEVEL-PACKAGES")
        except:
            print "Error opening or writing file " + filename
            self.file = None
    # Destructor - writes closing </AUTOSAR> tag and closes file
    def __del__(self):
        if self.file != None and not self.file.closed:
            numopentags = len(self.opentags)
            for i in range(numopentags):
                self.closeComplexTag()
            self.file.close()
    # Private method to write a line of XML
    def writeOneLine(self, linestr):
        if self.file != None and not self.file.closed:
            if (len(self.opentags) > 0):
                indentstr = "\t" * len(self.opentags)
                self.file.writelines([ indentstr, linestr, "\n" ])
            else:
                self.file.writelines([ linestr, "\n" ])
    # Private method to perform XML-like base encoding of strings
    def basicEncodeXml(self, str):
        shortstr = unicode(str).strip()
        shortstr = shortstr.replace('&', '&amp;')
        shortstr = shortstr.replace('>', '&gt;')
        shortstr = shortstr.replace('<', '&lt;')
        shortstr = shortstr.replace('\"', '&quot;')
        shortstr = shortstr.replace('\'', '&apos;')
        #shortstr = shortstr.replace('\n', '<BR/>')
        return shortstr
    # Private method to convert a tagname/attributename into a valid XML tag name
    def verifyTag(self, tagname):
        shorttag = self.basicEncodeXml(tagname)
        idlike = self.wsmatch_regexp.sub('_', shorttag)
        if self.tagmatch_regexp.match(idlike):
            return unicode(idlike)
        else:
            print "Invalid tag name '%s' specified - can not convert to XML!" % tagname
            return unicode(tagname)
    # Private method to convert an attribute value into a valid XML attribute value
    def verifyAttribute(self, attrib):
        shortatt = self.basicEncodeXml(attrib)
        return shortatt
    # Private method to verify raw data into valid XML
    def verifyRawData(self, rawdata):
        return self.basicEncodeXml(rawdata)
    # Internally used (private) method to create a tag string
    def createTagHeader(self, tagname, attributes):
        str = "<%s" % self.verifyTag(tagname)
        if attributes != None and len(attributes) > 0:
            for attribname in attributes.keys():
                str = str + " %s=\'%s\'" % (self.verifyTag(attribname), self.verifyAttribute(attributes[attribname]))
        return str
    # Internally used (private) method to recursively create complex tags for one-liners
    def createComplexTagStrRecursively(self, tagname, attributes, subtags, rawdata):
        str = self.createTagHeader(tagname, attributes)
        str = str + ">"
        if subtags != None:
            for subtag in subtags.keys():
                childtag = subtags[subtag]
                if "Attribs" in childtag:
                    childattribs = childtag["Attribs"]
                else:
                    childattribs = None
                if "Children" in childtag:
                    grandchildren = childtag["Children"]
                else:
                    grandchildren = None
                if "RawData" in childtag:
                    childrawdata = childtag["RawData"]
                else:
                    childrawdata = None
                str = str + self.createComplexTagStrRecursively(subtag, childattribs, grandchildren, childrawdata)
        if rawdata != None:
            str = str + self.verifyRawData(rawdata)
        str = str + "</%s>" % self.verifyTag(tagname)
        return str
    # Method to write a simple tag (without children)
    def writeSimpleTag(self, tagname, attributes = None):
            str = self.createTagHeader(tagname, attributes)
            str = str + "/>"
            self.writeOneLine(str)
    # Method to write a one line complex tag
    def writeComplexTag(self, tagname, attributes = None, subtags = None, rawdata = None):
        self.writeOneLine(self.createComplexTagStrRecursively(tagname, attributes, subtags, rawdata))
    # Method to start a complex tag (with children) Note: for each complex tag created, the closeComplexTag method needs to be called
    def startComplexTag(self, tagname, attributes = None):
        str = self.createTagHeader(tagname, attributes)
        str = str + ">"
        self.writeOneLine(str)
        self.opentags.append(tagname)
    # Method to write raw data
    def writeRawData(self, rawdata):
        self.writeOneLine(self.verifyRawData(rawdata))
    # Method to close a complex tag
    def closeComplexTag(self):
        if self.file != None and not self.file.closed:
            lasttag = self.opentags.pop()
            str = "</%s>" % self.verifyTag(lasttag)
            self.writeOneLine(str)

# #############################################################################
# #############################################################################
# AUTOSAR Classes
# #############################################################################
# #############################################################################

class AUTOSAR_CommonBase(object):
    def __init__(self, type_str, package, short_name, description, category = None):
        self.package = package
        self.type_str = type_str
        self.short_name = short_name
        self.description = description
        self.category    = category
        if package != None:
            package.addElement(self)
    # Method to get name reference to use
    def getRefName(self):
        if self.package != None:
            packagename = self.package.getRefName()
            if packagename != None and len(packagename) > 0:
                # Concatanate parent package's name(s) with out name
                return packagename + "/" + self.short_name
            else:
                # We have a parent package set, but it does not seem to have a valid name, just
                # return our own name
                return self.short_name
        else:
            # We have no parent package set, thus this is the root package
            return "/" + self.short_name
    # Method overridden by each derived class to dump the given AUTOSAR object to an ECU-Extract file
    def dumpAsXML(self, ecuextract):
        return False
    # Protected method to write most common raw header of complex AUTOSAR tags
    def writeCommonXMLHeader(self, ecuextract):
        if ecuextract.version == 4:
            # Map autosar version 3 names to their version 4 eqvivalents
            ecuextract.startComplexTag(MapVersion3NameToV4(self.type_str), None)
        else:
            # Use the type string directly
            ecuextract.startComplexTag(self.type_str, None)
        ecuextract.writeComplexTag("SHORT-NAME", None, None, self.short_name)
        # Only write category info if data present and being dumped to autosar 4.0
        if ecuextract.version == 4 and self.category is not None:
            ecuextract.writeComplexTag("CATEGORY", None, None, self.category )
        if self.description != None and len(self.description) > 0:
            ecuextract.writeComplexTag("DESC", None, { "L-2" : { "Attribs" : { "L" : "EN" }, "RawData" : self.description } }, None)

class AUTOSAR_ComplexBase(AUTOSAR_CommonBase):
    def __init__(self, type_str, package, name, description, category = None):
        AUTOSAR_CommonBase.__init__(self, type_str, package, name, description, category)
        self.elements = []
        self.namedict = {}
        self.elements_by_type = {}
    def addElement(self, element):
        if element != None and element.short_name != None and len(element.short_name) > 0:
            # Seems to be a valid element
            if not element.short_name in self.namedict:
                # No name clash, nothing in this package yet that would collide with the new element
                self.elements.append(element)
                self.namedict[element.short_name] = element
                if not element.type_str in self.elements_by_type:
                    self.elements_by_type[element.type_str] = []
                self.elements_by_type[element.type_str].append(element)
                return True
            else:
                # Name clash: we already have something with the same name as the new element
                return False
        else:
            # Element passed is invalid, since it does not have a correctly defined name
            return False
    def dumpAsXML(self, ecuextract):
        AUTOSAR_CommonBase.writeCommonXMLHeader(self, ecuextract)
        # Go through different types of objects in the order that
        # they were added in
        if len(self.elements_by_type.keys()) > 1 or ((not 'AR-PACKAGE' in self.elements_by_type) and (len(self.elements_by_type.keys()) > 0)):
            if (ecuextract.version == 4) and self.type_str == 'RECORD-TYPE':
                ecuextract.startComplexTag('SUB-ELEMENTS')
            else:
                ecuextract.startComplexTag('ELEMENTS')

            for elemtype in self.elements_by_type:
                if elemtype != 'AR-PACKAGE':
                    for elem in self.elements_by_type[elemtype]:
                        elem.dumpAsXML(ecuextract)
            ecuextract.closeComplexTag()    # Close 'ELEMENTS' / 'SUB-ELEMENTS'
        if 'AR-PACKAGE' in self.elements_by_type:
            if ecuextract.version == 4:
                ecuextract.startComplexTag("AR-PACKAGES")
            else:
                ecuextract.startComplexTag("SUB-PACKAGES")
            # At default initialize our output package list to our normal list
            packages_sorted = self.elements_by_type['AR-PACKAGE'];
            # If internal state indicates to sort by name, then do so now
            if sort_subpackages:
                packages_sorted = sorted(packages_sorted, key=lambda package : package.short_name)
            # Then output packages one by one
            for elem in packages_sorted:
                elem.dumpAsXML(ecuextract)
            ecuextract.closeComplexTag()    # Close 'AR-PACKAGES'/'SUB-PACKAGES'
        ecuextract.closeComplexTag()
    def getElement(self, element_name):
        if element_name in self.namedict:
            return self.namedict[element_name]
        else:
            return None

class AUTOSAR_RefingObjectBase(AUTOSAR_CommonBase):
    def __init__(self, type_str, package, name, description, typeobj, category = None, const_ref = False):
        AUTOSAR_CommonBase.__init__(self, type_str, package, name, description, category)
        self.refed_type = typeobj
        self.const_ref = const_ref
    def writeTypeRef(self, ecuextract):
        if self.refed_type != None:
            if ecuextract.version == 4:
                # Write AUTOSAR Version 4 reference
                if self.refed_type.type_str == "RECORD-TYPE" or self.refed_type.type_str == "INTEGER-TYPE" or self.refed_type.type_str == "REAL-TYPE":
                    reftype = "IMPLEMENTATION-DATA-TYPE"
                    source_type_ref = "IMPLEMENTATION-DATA-TYPE-REF"
                    def_category = "TYPE_REFERENCE"
                elif self.refed_type.type_str == "ARRAY-TYPE":
                    reftype = "IMPLEMENTATION-DATA-TYPE"
                    source_type_ref = "IMPLEMENTATION-DATA-TYPE-REF"
                    def_category = "TYPE_REFERENCE"
                elif ecuextract.tresos == True and self.refed_type.type_str == "BOOLEAN":
                    reftype = "IMPLEMENTATION-DATA-TYPE"
                    source_type_ref = "IMPLEMENTATION-DATA-TYPE-REF"
                    def_category = "TYPE_REFERENCE"
                else:
                    reftype = "SW-BASE-TYPE"
                    source_type_ref = "BASE-TYPE-REF"
                    def_category = "VALUE"
                # Write default category if our base category was not set in the common constructor
                # Note: pointer types have a default category and do not required re-writing here
                if self.category == None and def_category != None:
                    ecuextract.writeComplexTag("CATEGORY", None, None, def_category)
                ecuextract.startComplexTag("SW-DATA-DEF-PROPS")
                ecuextract.startComplexTag("SW-DATA-DEF-PROPS-VARIANTS")
                ecuextract.startComplexTag("SW-DATA-DEF-PROPS-CONDITIONAL")
                # Workaround: currently enums only seem to be generated by Cessar 4.0.3.3 when the compumethod is specified
                # not only at the type, but also at the reference level. @todo: Remove this once this confirmed bug is fixed in CESSAR/RTE-GEN

                refed_type_name = self.refed_type.getRefName()
                if ecuextract.tresos == True:
                    refed_type_name = re.sub("AUTOSAR/BaseTypes", "AUTOSAR_Platform/BaseTypes", refed_type_name)
                    if source_type_ref == "IMPLEMENTATION-DATA-TYPE-REF":
                        refed_type_name = re.sub("AUTOSAR_Platform/BaseTypes", "AUTOSAR_Platform/ImplementationDataTypes", refed_type_name)

                if (self.refed_type.type_str == "INTEGER-TYPE") and (self.refed_type.compu_method != None) and self.category == None and False:
                    ecuextract.writeComplexTag("COMPU-METHOD-REF", None, None, refed_type_name)
                # Write reference to destination type
                ecuextract.writeComplexTag(source_type_ref, { "DEST" : reftype }, None, refed_type_name)
                # If reference is contant then write implementation info
                if self.const_ref:
                    ecuextract.writeComplexTag("SW-IMPL-POLICY", None, None, "CONST")
                ecuextract.closeComplexTag()
                ecuextract.closeComplexTag()
                ecuextract.closeComplexTag()
            else:
                # Write AUTOSAR version 3 reference
                if self.refed_type.type_str == "RECORD-TYPE":
                    reftype = "RECORD"
                elif self.refed_type.type_str == "REAL-TYPE":
                    reftype = "REAL"
                elif self.refed_type.type_str == "INTEGER-TYPE":
                    if self.refed_type.compu_method != None:
                        reftype = "ENUM"
                    elif self.refed_type.lower_limit == None or self.refed_type.lower_limit != 0 or self.refed_type.upper_limit == None or self.refed_type.upper_limit <> 1:
                        reftype = "INTEGER"
                    else:
                        reftype = "BOOLEAN"
                elif self.refed_type.type_str == "ARRAY-TYPE":
                    reftype = "REFERENCE"
                else:
                    reftype = "REFERENCE"

                refed_type_name = self.refed_type.getRefName()

                if self.subversion == 2:
                    refed_type_name = re.sub("AUTOSAR/BaseTypes", "AUTOSAR/ImplTypes", refed_type_name)

                ecuextract.writeComplexTag("TYPE-TREF", { "DEST" : reftype }, None, refed_type_name)

    def dumpAsXML(self, ecuextract):
        self.writeCommonXMLHeader(ecuextract)
        self.writeTypeRef(ecuextract)
        ecuextract.closeComplexTag()

class AUTOSAR_Package(AUTOSAR_ComplexBase):
    def __init__(self, package, name, description):
        AUTOSAR_ComplexBase.__init__(self, "AR-PACKAGE", package, name, description)

class AUTOSAR_Unit(AUTOSAR_CommonBase):
    def __init__(self, package, name, description, display_str):
        AUTOSAR_CommonBase.__init__(self, "UNIT", package, name, description)
        self.display_str = display_str
    def dumpAsXML(self, ecuextract):
        AUTOSAR_CommonBase.writeCommonXMLHeader(self, ecuextract)
        if self.display_str != None and len(self.display_str) > 0:
            ecuextract.writeComplexTag("DISPLAY-NAME", None, None, self.display_str)
        ecuextract.closeComplexTag()

class AUTOSAR_Record(AUTOSAR_ComplexBase):
    def __init__(self, package, name, description):
        AUTOSAR_ComplexBase.__init__(self, "RECORD-TYPE", package, name, description, "STRUCTURE")

class AUTOSAR_CompuMethod(AUTOSAR_CommonBase):
    def __init__(self, package, name, description, long_name, enumvals, sortbyname = False):
        AUTOSAR_CommonBase.__init__(self, "COMPU-METHOD", package, name, description)
        self.long_name = long_name
        self.compu_scales = enumvals
        self.sort_by_name = sortbyname
    def dumpAsXML(self, ecuextract):
        AUTOSAR_CommonBase.writeCommonXMLHeader(self, ecuextract)
        # Check if textual enumerator conversion
        if self.compu_scales != None and len(self.compu_scales) > 0:
            if ecuextract.tresos == True:
              ecuextract.writeComplexTag("CATEGORY", None, None, 'TEXTTABLE')
            else:
              ecuextract.writeComplexTag("CATEGORY", None, None, 'TEXTABLE')
            ecuextract.startComplexTag("COMPU-INTERNAL-TO-PHYS")
            ecuextract.startComplexTag("COMPU-SCALES")
            suffix = ""
            if ecuextract.force_imm_suffix:
            	# Determine which suffix to use
            	enumvals = sorted(self.compu_scales.values())
            	if len(enumvals) > 0:
                    if enumvals[0] >= 0:
                            if enumvals[-1] <= 0xFFFFFFFF:
                                    suffix = "U"
                            else:
                                    suffix = "ULL"
                    else:
                            if enumvals[-1] <= 0x7FFFFFFF:
                                    suffix = ""
                            else:
                                    suffix = "LL"
            if (self.sort_by_name != True):
                valuesorted = sorted(self.compu_scales.items(), key=itemgetter(1))
            else:
                valuesorted = sorted(self.compu_scales.items(), key=itemgetter(0))
            for (enumerator, enumval) in valuesorted:
                outputval = str(enumval) + suffix
                ecuextract.startComplexTag("COMPU-SCALE")
                ecuextract.writeComplexTag("LOWER-LIMIT", None, None, outputval)
                ecuextract.writeComplexTag("UPPER-LIMIT", None, None, outputval)
                ecuextract.startComplexTag("COMPU-CONST")
                ecuextract.writeComplexTag("VT", None, None, enumerator)
                ecuextract.closeComplexTag()
                ecuextract.closeComplexTag()
            ecuextract.closeComplexTag()
            ecuextract.closeComplexTag()
        ecuextract.closeComplexTag()

class AUTOSAR_RealType(AUTOSAR_CommonBase):
    def __init__(self, package, name, desc = None, refType = None):
        AUTOSAR_CommonBase.__init__(self, "REAL-TYPE", package, name, desc)
        self.lower_limit = None
        self.upper_limit = None
        self.refType = refType
    def dumpAsXML(self, ecuextract):
        if ecuextract.version == 4:
            # AUTOSAR version 4 path
            AUTOSAR_CommonBase.writeCommonXMLHeader(self, ecuextract)
            ecuextract.writeComplexTag("CATEGORY", None, None, "VALUE" )
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS")
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS-VARIANTS")
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS-CONDITIONAL")
            if self.refType != None:
                base_type_ref_str = self.refType.getRefName()
                if ecuextract.tresos == True:
                    base_type_ref_str = re.sub("AUTOSAR/BaseTypes", "AUTOSAR_Platform/BaseTypes", base_type_ref_str)
            else:
                base_type_ref_str = 'unknown'
            ecuextract.writeComplexTag("BASE-TYPE-REF", {'DEST':'SW-BASE-TYPE'}, None, base_type_ref_str)
            ecuextract.closeComplexTag()
            ecuextract.closeComplexTag()
            ecuextract.closeComplexTag()
            ecuextract.closeComplexTag()
        else:
            # AUTOSAR version 3 path
            AUTOSAR_CommonBase.writeCommonXMLHeader(self, ecuextract)
            if self.lower_limit != None:
                ecuextract.writeComplexTag("LOWER-LIMIT", None, None, self.lower_limit)
            if self.upper_limit != None:
                ecuextract.writeComplexTag("UPPER-LIMIT", None, None, self.upper_limit)
            ecuextract.closeComplexTag()

class AUTOSAR_SWComponent(AUTOSAR_CommonBase):
    def __init__(self, package, name, desc, declared_enums):
        AUTOSAR_CommonBase.__init__(self, "ENUM_TYPE", package, name, desc)
        self.declared_enums = declared_enums
        self.name = name
    def dumpAsXML(self, ecuextract):
        ecuextract.startComplexTag("APPLICATION-SW-COMPONENT-TYPE")
        ecuextract.writeComplexTag("SHORT-NAME", None, None, self.name)

        ecuextract.startComplexTag("INTERNAL-BEHAVIORS")
        ecuextract.startComplexTag("SWC-INTERNAL-BEHAVIOR")
        ecuextract.writeComplexTag("SHORT-NAME", None, None, "SwcInternalBehaviorExt")
        ecuextract.startComplexTag("INCLUDED-DATA-TYPE-SETS")
        ecuextract.startComplexTag("INCLUDED-DATA-TYPE-SET")
        ecuextract.startComplexTag("DATA-TYPE-REFS")

        for declared_enum in self.declared_enums:
            ecuextract.writeComplexTag("DATA-TYPE-REF", { "DEST" : "IMPLEMENTATION-DATA-TYPE" }, None, declared_enum)

        # Close DATA-TYPE-REFS tag
        ecuextract.closeComplexTag()
        # Close INCLUDED-DATA-TYPE-SET tag
        ecuextract.closeComplexTag()
        # Close INCLUDED-DATA-TYPE-SETS tag
        ecuextract.closeComplexTag()
        # Close SWC-INTERNAL-BEHAVIOR tag
        ecuextract.closeComplexTag()
        # Close INTERNAL-BEHAVIORS tag
        ecuextract.closeComplexTag()
        # Close APPLICATION-SW-COMPONENT-TYPE tag
        ecuextract.closeComplexTag()


class AUTOSAR_IntegerType(AUTOSAR_CommonBase):
    def __init__(self, package, name, desc, compu_method = None, refType = None):
        AUTOSAR_CommonBase.__init__(self, "INTEGER-TYPE", package, name, desc)
        self.lower_limit = None
        self.upper_limit = None
        self.compu_method = compu_method
        self.refType = refType
    def dumpAsXML(self, ecuextract):
        AUTOSAR_CommonBase.writeCommonXMLHeader(self, ecuextract)
        compu_method_name = None
        # For AUTOSAR version 4 create necessary overhead tags
        if ecuextract.version == 4:
            ecuextract.writeComplexTag("CATEGORY", None, None, "VALUE" )
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS")
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS-VARIANTS")
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS-CONDITIONAL")
            if self.refType != None:
                base_type_ref_str = self.refType.getRefName()
                if ecuextract.tresos == True:
                    base_type_ref_str = re.sub("AUTOSAR/BaseTypes", "AUTOSAR_Platform/BaseTypes", base_type_ref_str)

            else:
                base_type_ref_str = 'unknown'
            ecuextract.writeComplexTag("BASE-TYPE-REF", {'DEST':'SW-BASE-TYPE'}, None, base_type_ref_str)
        if ecuextract.version == 3 and ecuextract.subversion == 2:
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS")
            if self.refType != None:
                base_type_ref_str = self.refType.getRefName()
            else:
                base_type_ref_str = "unknown"
            if self.compu_method == None:
                ecuextract.writeComplexTag("BASE-TYPE-REF", {'DEST':'SW-BASE-TYPE'}, None, base_type_ref_str)
        if self.compu_method != None:
            # There is an enumeration map attached that we need to dump
            ecuextract.writeComplexTag("COMPU-METHOD-REF", { 'DEST' : 'COMPU-METHOD' }, None, self.compu_method.getRefName())
        # Close overhead tags for AUTOSAR version 4
        if ecuextract.version == 4:
            ecuextract.closeComplexTag()
            ecuextract.closeComplexTag()
            ecuextract.closeComplexTag()
        # Close overhead tag for AUTOSAR 3.2
        if ecuextract.version == 3 and ecuextract.subversion == 2:
            ecuextract.closeComplexTag()
        # For version 3 write upper/lower limit
        if ecuextract.version == 3:
            if self.lower_limit != None:
                ecuextract.writeComplexTag("LOWER-LIMIT", { 'INTERVAL-TYPE' : 'CLOSED' }, None, self.lower_limit)
            if self.upper_limit != None:
                ecuextract.writeComplexTag("UPPER-LIMIT", { 'INTERVAL-TYPE' : 'CLOSED' }, None, self.upper_limit)
        ecuextract.closeComplexTag()

class AUTOSAR_RecordElement(AUTOSAR_RefingObjectBase):
    def __init__(self, package, name, description, typeobj):
        AUTOSAR_RefingObjectBase.__init__(self, "RECORD-ELEMENT", package, name, description, typeobj)

class AUTOSAR_ArrayType(AUTOSAR_RefingObjectBase):
    def __init__(self, package, name, description, typeobj, arraylen, elem_name):
        AUTOSAR_RefingObjectBase.__init__(self, "ARRAY-TYPE", package, name, description, typeobj)
        self.array_len = arraylen
        self.element_short_name = elem_name
    def dumpAsXML(self, ecuextract):
        AUTOSAR_RefingObjectBase.writeCommonXMLHeader(self, ecuextract)
        if ecuextract.version == 4:
            # Version 4 path
            ecuextract.writeComplexTag("CATEGORY", None, None, "ARRAY")
            ecuextract.startComplexTag("SUB-ELEMENTS", None)
            ecuextract.startComplexTag("IMPLEMENTATION-DATA-TYPE-ELEMENT", None)
            # Work-around for Cessar 4.0.3.3-x86 issues: most likely the regular expression used to validate
            # short names is simply wrong, since it does not allow two underscores behind each other
            # @todo: The above
            ecuextract.writeComplexTag("SHORT-NAME", None, None, self.element_short_name)
            #ecuextract.writeComplexTag("CATEGORY", None, None, "TYPE_REFERENCE")
            ecuextract.writeComplexTag("ARRAY-SIZE-SEMANTICS", None, None, "FIXED-SIZE")
            AUTOSAR_RefingObjectBase.writeTypeRef(self, ecuextract)
            # If an array length is set, then store that information
            if (self.array_len != None):
                ecuextract.writeComplexTag("ARRAY-SIZE", None, None, self.array_len)
            else:
                print "Warning: the array %s does not have it's number of elements set!" % self.short_name
            # Close the IMPLEMENTATION-DATA-TYPE-ELEMENT ja tag
            ecuextract.closeComplexTag()
            # Close the SUB-ELEMENTS tag
            ecuextract.closeComplexTag()
            # Close the CATEGORY tag
            ecuextract.closeComplexTag()
        else:
            # AUTOSAR version 3 path
            ecuextract.startComplexTag("ELEMENT", None)
            ecuextract.writeComplexTag("SHORT-NAME", None, None, self.element_short_name)
            AUTOSAR_RefingObjectBase.writeTypeRef(self, ecuextract)
            # If an array length is set, then store that information
            if (self.array_len != None):
                ecuextract.writeComplexTag("MAX-NUMBER-OF-ELEMENTS", None, None, self.array_len)
            else:
                print "Warning: the array %s does not have it's number of elements set!" % self.short_name
            # Close the ELEMENT tag
            ecuextract.closeComplexTag()
            # Close the ARRAY-TYPE tag
            ecuextract.closeComplexTag()

class AUTOSAR_PointerBase(AUTOSAR_RefingObjectBase):
    def __init__(self, package, name, description, typeobj, type_str, ptr_const, pointee_const):
        AUTOSAR_RefingObjectBase.__init__(self, type_str, package, name, description, typeobj, "DATA_REFERENCE", pointee_const)
        self.ptr_const = ptr_const
    def dumpAsXML(self, ecuextract):
        if (ecuextract.version >= 4):
            # Version 4 path
            AUTOSAR_RefingObjectBase.writeCommonXMLHeader(self, ecuextract)
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS")
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS-VARIANTS")
            ecuextract.startComplexTag("SW-DATA-DEF-PROPS-CONDITIONAL")
            if self.ptr_const:
                ecuextract.writeComplexTag("SW-IMPL-POLICY", None, None, "CONST")
            ecuextract.startComplexTag("SW-POINTER-TARGET-PROPS")
            if self.refed_type != None:
                if self.refed_type.type_str == "RECORD-TYPE" or self.refed_type.type_str == "INTEGER-TYPE" or self.refed_type.type_str == "REAL-TYPE" or self.refed_type.type_str == "ARRAY-TYPE":
                    target_category = "TYPE_REFERENCE"
                else:
                    target_category = "VALUE"
                ecuextract.writeComplexTag("TARGET-CATEGORY", None, None, target_category)
            AUTOSAR_RefingObjectBase.writeTypeRef(self, ecuextract)
            ecuextract.closeComplexTag()        # Close SW-POINTER-TARGET-PROPS
            ecuextract.closeComplexTag()        # Close SW-DATA-DEF-PROPS-CONDITIONAL
            ecuextract.closeComplexTag()        # Close SW-DATA-DEF-PROPS-VARIANTS
            ecuextract.closeComplexTag()        # Close SW-DATA-DEF-PROPS
            ecuextract.closeComplexTag()        # Close common XML header
        else:
            print "Error: pointer types can not be output in AUTOSAR 3 mode! Ignoring %s!" % self.short_name

class AUTOSAR_PointerType(AUTOSAR_PointerBase):
    def __init__(self, package, name, description, typeobj, ptr_const, pointee_const):
        AUTOSAR_PointerBase.__init__(self, package, name, description, typeobj, "RECORD-TYPE", ptr_const, pointee_const)

class AUTOSAR_PointerField(AUTOSAR_PointerBase):
    def __init__(self, package, name, description, typeobj, ptr_const, pointee_const):
        AUTOSAR_PointerBase.__init__(self, package, name, description, typeobj, "RECORD-ELEMENT", ptr_const, pointee_const)

# #############################################################################
# #############################################################################
# XLS to AUTOSAR conversion class (main)
# #############################################################################
# #############################################################################

class Excel2AUTOSAR(object):
    # Embedded XLS name forward reference object used to store forward references
    # to objects
    class XlsPendingNameRef(object):
        def __init__(self):
            self.type_str = 'not-defined-reference'
            self.autosar_objs = []  # List of AUTOSAR_RefingObjectBase which reference this symbol
            self.array_sizes = []   # List of AUTOSAR_ArrayType which reference this symbol as arraysize
            self.atomic_objs = {}   # Dictionary of atomic names with their containers referencing this symbol
            self.aliases = []
        # Method to add an AUTOSAR refing object to a forward reference
        def addRefingAutosarObj(self, autosar_obj):
            if autosar_obj != None:
                self.autosar_objs.append(autosar_obj)
        # Method to add an AUTOSAR array object referencing array size as
        # forward reference
        def addRefingArraySizeObj(self, autosar_array):
            if autosar_array != None:
                self.array_sizes.append(autosar_array)
        # Method to add an atomic referencing object. Atomic referencing objects
        # are enumerators or direct type references (fields, types) which could
        # not be resolved at declaration time
        def addRefingAtomic(self, atomic_obj_name, container):
            if atomic_obj_name != None and len(atomic_obj_name) > 0:
                self.atomic_objs[atomic_obj_name] = container
        # Method to resolve a given
        def resolveRefs(self, real_obj):
            for autosar_obj in self.autosar_objs:
                autosar_obj.refed_type = real_obj
            self.autosar_objs = []
            # Go through array size references
            if len(self.array_sizes) > 0:
                for array_obj in self.array_sizes:
                    if type(real_obj)==type(int()) and real_obj > 1:
                        array_obj.array_len = real_obj
                    else:
                        print "ERROR: AUTOSAR Array object '%s' references a non-integer array size!" % array_obj.short_name
            self.array_sizes = []
            # Go through direct references
            for atomic_obj_name in self.atomic_objs:
                container = self.atomic_objs[atomic_obj_name]
                if container != None:
                    if container.type_str == 'AR-PACKAGE':
                        # The referencing object is on package level
                        continue
                    elif container.type_str == 'COMPU_METHOD':
                        # The referencing object is an enumerator
                        continue
                    else:
                        # The referencing object is just a child element
                        continue
            self.atomic_objs = []
        # Method to link another forward references together
        def linkOtherRef(self, other, othername):
            self.aliases.append(othername)
        # Method to get aliases
        def getAliases(self):
            return self.aliases
        # Reference name getting (defined for the case when unresolved
        # references exist)
        def getRefName(self):
            return self.type_str

    # Embedded class for representing references outside of the normal AUTOSAR
    # classes
    class ExternalReference(AUTOSAR_CommonBase):
        def __init__(self, typestr, extref, shortname):
            AUTOSAR_CommonBase.__init__(self, typestr, None, shortname, None)
            if re.search(r'/$', extref):
                self.refstr = extref + shortname
            else:
                self.refstr = extref + '/' + shortname
        def getRefName(self):
            return self.refstr

    # The constructor of the Excel2AUTOSAR class
    def __init__(self, projectname, generate_doxy_meas_data = True, packages_for_sheets = True, allow_sym_minmax = False, type_prefix = None, type_suffix = None, max_name_length = 32, enum_prefix = None , gen_swc_data = False, use_meas_vaddr = False, prefer_signed_enums = False, enable_units = False, unique_negation = False):
        # File location information
        self.xls_name = xlsname
        self.xls_row  = 0
        self.xls_sheet = None

        # Set maximum name length
        self.max_name_length = max_name_length

        # Set project identification
        self.projectname = projectname.upper()

        # Create a dictionary of accepeted project names for faster processing
        self.projectnames = {}
        # Accept if no project name at all provided or a simple X or 'ALL'
        self.projectnames[""] = 1;
        self.projectnames["X"] = 1;
        self.projectnames["ALL"] = 1;

        # Split the project name list into single project names
        projects = self.projectname.split(',')
        # Accept the projects names directly
        for project in projects:
            self.projectnames[project] = 1;

        #initialize Provider and Receiver Information Dicts
        self.receiver = {}
        self.provider = {}
        self.provider_receiver_signals = {}

        # Now generate XXX names
        for project in projects:
            projmatch = re.match(r'^([A-Z]+)([0-9][0-9A-Z]+)$', project)
            if projmatch != None:
                # Now the first matching group is technology name (for example:
                # CSF, ARS, VPU etc.). The second match group is the exact ID
                # like 301, 315
                base_proj_name = projmatch.group(1)
                ext_proj_name = projmatch.group(2)
                # Based on this create alternative representations
                cur_base_proj_name = base_proj_name
                for i in range(0, len(ext_proj_name)):
                    cur_proj_name = cur_base_proj_name + "X"*(len(ext_proj_name) - i)
                    self.projectnames[cur_proj_name] = 1;

                    # allow also baseproject tags with length of old project nomenclature
                    project_string_length_old = 6
                    if (len(cur_base_proj_name)<project_string_length_old):
                        self.projectnames[cur_proj_name[0:project_string_length_old]] = 1;

                    cur_base_proj_name += ext_proj_name[i]
            else:
                self.Warning("Unknown project name %s, not generating wild-card patterns, only accepting direct matches!" % project)

        # Set flag if doxygen MTS descriptions shall be generated
        self.generate_doxygen_measdata = generate_doxy_meas_data

        # Set flag indicating if each sheet shall have it's own package generated
        self.packages_for_sheets = packages_for_sheets

        # Set flag indicating if minimum/maximum descriptions shall be generated
        self.generate_doxygen_min_max = True

        # Set flag indicating if symbolic minimum/maximum generation shall be allowed
        self.allow_symbolic_min_max = allow_sym_minmax

        # Set flag indicating if all struct/enums shall be declared over their
        # undecorated names besides being declared by the reference column
        # names. This may seem desireable sometimes, but poses some serious
        # issues. The most pressing of these is that two different structs can
        # not have a field with the same name.
        self.declare_struct_by_undecorated_name = False
        self.declare_enum_by_undecorated_name   = False

        # Set flag indicating if values declarations shall be generated (necessary
        # workaround since defines are currenly generated by RTE gen instead of
        # real enumerations - leading to the loss of grouping information)
        self.generate_doxygen_value_tags = True

        # Set flag indicating if defines shall be generated for static constants
        # (symbolic constants)
        self.generate_constant_defines  = True

        # Set flag indicating if symbolic min/max names shall be generated or only
        # decodeable numeric constants
        self.generate_symbolic_minmax  = True

        # Set flag indicating if special enumerations for meas addresses/interface
        # versions shall be sorted alphabetically instead of by value
        self.sort_special_enums_by_name = True

        # String containing enforced type prefix (if any). If no type prefix shall
        # be enforced/prepended, then set this to None. Otherwise the string set
        # here will be prepended to type-names auto-generated
        self.type_prefix = type_prefix

        # String containing enforced type suffix (if any). If no type suffix shall
        # be enforced/append, then set this to None. Otherwise the string set here
        # will be appended to type-names auto-generated
        self.type_suffix = type_suffix

        # String containing enforced enum prefix (if any). If no enum prefix shall
        # be enforced/append, then set this to None. Otherwise the string set here
        # will be appended to enum-names auto-generated
        self.enum_prefix = enum_prefix

        # Regexp for matching identifiers (cached for speed)
        self.ident_regexp = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')
        self.whitespace_regexp = re.compile(r'[ \t]+')
        self.intnum_regexp = re.compile(r'^([+\-]?[0-9]+)(\.[0]*)?$')
        self.realnum_regexp = re.compile(r'^([+\-]?[0-9]+)(\.[0-9]*)?$')

        # Map of virtual address names to their respective values
        self.virtual_addr_names = {}

        # Create a dictionary for names as used in the XLS cells
        self.xls_name_dict = {}

        # Create a dictionary for forward references not defined yet
        self.xls_forward_refs = {}

        # Crate a dictionary for symbolic constants (note: only used for generating
        # defines when needed, for real internal loookup the single xls_name_dict
        # dictionary is used)
        self.symbolic_constant_dict = {}

        # Create a dictionary for version numbers of structs
        self.VersionNumbers = {}

        # Special name to sheetname and row number dictionaries
        self.xls_orig_dec_loc = {}

        # Global (all declared symbols) look-up table
        self.xls_global_name_dict = {}

        # Store swc data generation flag
        self.gen_swc_data = gen_swc_data

        # Use the virtual addresses in case of the defines
        self.use_meas_vaddr = use_meas_vaddr

        # Global enum container
        self.declared_enums = []

        # Set setting if signed/unsigned enums prefered
        self.prefer_signed_enums = prefer_signed_enums

        # Setting if unit string comment output enabled
        self.enable_units_comment = enable_units

        #Setting if negation should negate only one project or the complete list
        self.unique_prj_negation = unique_negation

    def MessageOut(self, prefix, message):
        if prefix is None:
            prefix = "INFO"
        if self.xls_name is not None:
            if self.xls_sheet is not None:
                print "%s: File '%s' sheet '%s' row %u: %s" % (prefix, self.xls_name, self.xls_sheet.name, self.xls_row+1, message)
            else:
                print "%s: File '%s': %s" % (prefix, self.xls_name, message)
        else:
            print "%s: %s" % (prefix, message)

    def Error(self, message):
        self.MessageOut("ERROR", message)

    def Warning(self, message):
        self.MessageOut("WARNING", message)

    def InfoOut(self, message):
        self.MessageOut("INFO", message)

    # Method to parse an XLS file
    def ParseXlsFile(self, xlsname, dataFlowFileName, ap):
        # Save xls name for message output
        self.xls_name = xlsname
        self.xls_row  = 0
        self.xls_sheet = None

        # Open XLS via the XLRD open_workbook method
        self.xls_book = xlrd.open_workbook(xlsname,formatting_info=True)

        # Load the names of the sheets
        self.sheet_names = self.xls_book.sheet_names()

        # Create a dictionary of sheet-names indicating which need to be processed
        # The keys are the names of the sheets, and the values are non-zero if the
        # sheet needs to be processed
        self.gen_sheets = { 'Units' : 1, 'Static Variables' : 1, 'Base types' : 1 }

        # Put the Data-Flow filename into a class variable
        # to be able to access it in the FinalizeParsedInfo() function
        self.dataFlowFileName = dataFlowFileName;

        # Check if generator sheet exists, and process it
        if 'Generator' in self.sheet_names:
            # Sheet has generator
            gensheet = self.xls_book.sheet_by_name('Generator')
            if gensheet != None:
                # Set sheet we are processing for error/warning output
                self.xls_sheet = gensheet
                # Load the column headers
                colCapGen = self.loadSheetColumnHeaders(gensheet)
                # Try getting columns importatn for us
                gen_xml_col = self.getColumnIndexFromCaptions(colCapGen, [ 'Generate XML' ])
                gen_sheet_col = self.getColumnIndexFromCaptions(colCapGen, ['Sheet Name'])
                gen_provider_col = self.getColumnIndexFromCaptions(colCapGen, [ 'Provider' ])
                # Check for new entries in the provider/receiver dict, and add them
                self.ParseProviderList(colCapGen, gen_provider_col)
                # Now check if we have a column 'Generate XML'
                if gen_xml_col != None and gen_sheet_col != None:
                    # Go through rows and select which sheets need to be generated
                    for row in range(1, gensheet.nrows):
                        self.xls_row = row
                        cell_val_str = gensheet.cell(row, gen_xml_col).value
                        gen_sheet_name = gensheet.cell(row, gen_sheet_col).value
                        if gen_sheet_name in self.sheet_names:
                            if cell_val_str != "" and self.checkProjectMatch(cell_val_str):
                                self.gen_sheets[gen_sheet_name] = 1
                                # Generate information for Data-Flow file:
                                self.GenerateDataFlow(gensheet, gen_sheet_name, gen_provider_col, row, colCapGen)
                            else:
                                #print "Sheet '%s' does not need generation" % (gen_sheet_name)
                                pass
                        else:
                            if gen_sheet_name != "" and cell_val_str != "":
                                self.Warning("Reference to sheet '%s' that does not exist!" % (gen_sheet_name))
                else:
                    # There is no 'Generate XML' column
                    self.Warning("Sheet does not have a 'Generate XML' or 'Sheet Name' column! Generating all sheets!")
                    # Set all sheets to be generated
                    for sheetname in self.sheet_names:
                        self.gen_sheets[sheetname] = 1
                # Reset sheet
                self.xls_sheet = None
            else:
                self.Warning("Internal error: even though 'Generator' sheet exists, getting it by name failed! Generating all sheets!")
                # Set all sheets to be generated
                for sheetname in self.sheet_names:
                    self.gen_sheets[sheetname] = 1
        else:
            self.Warning("No Generator sheet for controlling which types are generated! Generating all sheets")
            # Set all sheets to be generated
            for sheetname in self.sheet_names:
                self.gen_sheets[sheetname] = 1

        # After generation information has been loaded, go through real data sheets
        if 'Static Variables' in self.sheet_names:
            self.processSymbolicConstSheet(ap, self.xls_book.sheet_by_name('Static Variables'))
        if 'External types' in self.sheet_names:
            self.processExternalTypesSheet(self.xls_book.sheet_by_name('External types'))
        if 'Units' in self.sheet_names:
            unit_package = AUTOSAR_Package(ap, "Units", None)
            self.processUnitsSheet(unit_package, self.xls_book.sheet_by_name('Units'))
        if 'Base types' in self.sheet_names:
            subpack = ap.getElement("SwBaseTypes")
            if subpack is not None:
                self.Warning("Multiple sheets with the name '%s' being merged into the same AUTOSAR package!" % "SwBaseTypes")
            else:
                subpack = AUTOSAR_Package(ap, "SwBaseTypes", None)
            self.processTypesSheet(subpack, self.xls_book.sheet_by_name('Base types'))
        if 'Meas' in self.sheet_names:
            self.processMeasInfoSheet(ap, self.xls_book.sheet_by_name('Meas'))
        # If packages for sheets is not enabled, then create one 'DataTypes' packages for rest
        if not self.packages_for_sheets:
            subpack = AUTOSAR_Package(ap, 'DataTypes', None)
        # Now process all remaining sheets
        for sheetname in self.gen_sheets:
            # Check if generation required flag is set
            if self.gen_sheets[sheetname] > 0 and sheetname in self.sheet_names:
                # Sheet should be generated
                if self.packages_for_sheets:
                    subpack = ap.getElement(sheetname)
                    if subpack <> None:
                        self.Warning("Multiple sheets with the name '%s' being merged into the same AUTOSAR package!" % sheetname)
                    else:
                        subpack = AUTOSAR_Package(ap, sheetname, None)
                self.processTypesSheet(subpack, self.xls_book.sheet_by_name(sheetname))

    # Method to generate list of available providers/receivers
    def ParseProviderList(self, HeaderLineDict, ProviderColumn):
      # Check for new entries in the provider/receiver dict, and add them
      for key in sorted(HeaderLineDict, key=HeaderLineDict.get):
        if (ProviderColumn < HeaderLineDict[key]):
          if (' ' in key):
            break;
          provider_name = key.upper();
          if (provider_name not in self.provider):
            self.provider[provider_name] = len(self.provider)
          if (provider_name not in self.receiver):
            self.receiver[provider_name] = len(self.receiver)

    # Method to generate the data flow
    def GenerateDataFlow(self, gensheet, gen_sheet_name, provider_column, row, colCapGen):
      if (len(self.dataFlowFileName) > 0):
        # Create array for DataFlow-File
        provider_name = gensheet.cell(row, provider_column).value.upper()
        # Check if there is a provider specified which is not specified in the the header line
        if (   (provider_name not in self.provider)
             & (' '           not in provider_name)
             & (len(provider_name) > 0            ) ):
          # This is a candidate, so add it to the provider and receiver dicts
          if (provider_name not in self.provider):
            self.provider[provider_name] = len(self.provider)
          if (provider_name not in self.receiver):
            self.receiver[provider_name] = len(self.receiver)

        # Check if its still not in the provider list
        if (provider_name in self.provider):
          # Loop over receiver columns and search for "x"
          for receiver_column in colCapGen.values():
            if (receiver_column > provider_column):
              receiver_value = gensheet.cell(row, receiver_column).value.lower()
              receiver_name = gensheet.cell(0, receiver_column).value.upper()
              if (receiver_value == "x"):
                pro_rec_key = provider_name+"->"+receiver_name;
                # Check if this is an already known pro->rec connection or if we have
                # to add a new key to the dict
                if (pro_rec_key in self.provider_receiver_signals):
                  self.provider_receiver_signals[pro_rec_key] += ", "+gen_sheet_name;
                else:
                  self.provider_receiver_signals[pro_rec_key] = gen_sheet_name;

    # Method to write the data flow file
    def WriteDataFlowFile(self):
      if (len(self.dataFlowFileName) > 0):
        try:
          dataFlowFile = open(self.dataFlowFileName,'w');
          if (dataFlowFile != -1):
            dataFlowFile.write("Provider->Receiver: \tSignals\n");
            dataFlowFile.write("--------------------------------------------------------------------\n");
            for key in sorted(self.provider_receiver_signals):
              dataFlowFile.write(key+": \t"+self.provider_receiver_signals[key]+"\n");
            dataFlowFile.close();
        except:
          self.Error("Can not write DataFlow File: %s"%dataFlowFile)

    # Method to reset parser when direct de-referencing between differnt XLS files is disabled
    def ResetParser(self):
        self.xls_name_dict = {}

    # Method to finalize autosar package parsed
    def FinalizeParsedInfo(self, ap):
        # Verify that all name references could be resolved
        self.checkMissingRefs()
        # Write special data with virtual address aliases
        if len(self.virtual_addr_names) > 0:
            if self.packages_for_sheets:
                subpack = AUTOSAR_Package(ap, 'MTS_VirtAddrs', None)
            ac = AUTOSAR_CompuMethod(subpack, self.generateUniqueValidName('MTS_VirtAddrsCompuMethod'), 'MTS virtual addresses', None, self.virtual_addr_names, self.sort_special_enums_by_name)
            # @todo: Add hard-wire reference to uint32 type for autosar 4!
            base_type = AUTOSAR_IntegerType(subpack, 'MTS_VirtAddrs', 'MTS virtual addresses', ac, self.getObjectGlobalWithoutRef('uint32'))

            self.declared_enums.append(base_type.getRefName())
            # hard-code limits to full 32-bit unsigned address space, as otherwise RTE generator
            # simply does not generate the type (without limits no enums output)
            base_type.lower_limit = 0
            base_type.upper_limit = 4294967295
        # Now if required to generate defines for constants
        if (len(self.symbolic_constant_dict) > 0) and self.generate_constant_defines:
            ac = AUTOSAR_CompuMethod(ap, self.generateUniqueValidName('SymbolicConstsCompuMethod'), 'Symbolic constants', None, self.symbolic_constant_dict, self.sort_special_enums_by_name)
            base_type = AUTOSAR_IntegerType(ap, 'SymbolicConstants', 'Symbolic constants', ac, self.getObjectGlobalWithoutRef('sint32'))

            self.declared_enums.append(base_type.getRefName())
            # hard-code limits to full 32-bit signed address space, as otherwise RTE generator
            # simply does not generate the type (without limits no enums output)
            base_type.lower_limit = -2147483648
            base_type.upper_limit = 2147483647
        # Now if version numbers specified, generate them
        if (len(self.VersionNumbers) > 0):
            ac = AUTOSAR_CompuMethod(ap, self.generateUniqueValidName('InterfaceVersions'), 'Interface version numbers', None, self.VersionNumbers, self.sort_special_enums_by_name)
            base_type = AUTOSAR_IntegerType(ap, 'InterfaceVersion', 'Interface version numbers', ac, self.getObjectGlobalWithoutRef('uint32'))

            self.declared_enums.append(base_type.getRefName())
            # hard-code limits to full 32-bit unsigned address space, as otherwise RTE generator
            # simply does not generate the type (without limits no enums output)
            base_type.lower_limit = 0
            base_type.upper_limit = 4294967295

        if (self.gen_swc_data):
            mypkg = AUTOSAR_Package(ap, "COMPONENTTYPES", None)
            AUTOSAR_SWComponent(mypkg, root_package_name, None, self.declared_enums)

        # Write Data-Flow File:
        self.WriteDataFlowFile();

    # Method to validate a name
    def validateName(self, inputname):
        inputshort = unicode(inputname).strip()
        if self.max_name_length != None and self.max_name_length > 0 and len(inputshort) > self.max_name_length:
            inputshort = inputshort[0:self.max_name_length]
            self.Warning("Truncating name '%s' to '%s' as it exceeds maximum length of %d!" % (inputname, inputshort, self.max_name_length))
        finalstr = self.whitespace_regexp.sub('_', inputshort)
        if self.ident_regexp.match(finalstr):
            return finalstr
        else:
            return None

    # Method to validate an input strings for being identifiers and
    # returning a corresponding identifier list
    def validateIdentList(self, inputstr):
        ident_match_list = []
        if inputstr != None and (len(inputstr) > 0) and inputstr != '-':
            inputstr_lines = inputstr.split(r',')#re.split(r'[,\n]+\W*', raw_vname_str)
            # Copy the valid identifiers to the ident_match_vname_list
            for cur_identname in inputstr_lines:
                cur_identname = cur_identname.strip()
                if len(cur_identname) > 0:
                    if self.ident_regexp.match(cur_identname):
                        ident_match_list.append(cur_identname)
                    else:
                        self.Error("Virtual instance name is not a valid identifier '%s'!" % (cur_identname))
        return ident_match_list

    # Method to determine if a given project string matches
    def checkProjectMatch(self, proj_str):
        if self.projectname != "":
            # The project name is set, we need to check for matches
            if proj_str != "":
                def_ret = False
                proj_array = proj_str.split(r',')
                for proj in proj_array:
                    # Basic expression support (currently only C-like ! (not) is supported)
                    MatchVal = True
                    notregexp = re.compile(r"[ \t]*\!(\w+)[ \t]*$")
                    matchexp = notregexp.match(proj)
                    if (matchexp):
                        MatchVal = False
                        proj = matchexp.group(1)
                        # Set default return value to 'true' since if none match,
                        # then due to negation that means we 'pass'
                        if self.unique_prj_negation == False:
                            def_ret = True
                    # Strip any whitespaces still pending and upper case it
                    proj_short = proj.strip()
                    proj_short_uc = proj_short.upper()
                    # If this project name is found in the acceptance dictionary, return true
                    if proj_short_uc in self.projectnames:
                        return MatchVal
                    elif proj_short in self.symbolic_constant_dict:
                        if (MatchVal):
                            return (self.symbolic_constant_dict[proj_short] != 0)
                        else:
                        	return (self.symbolic_constant_dict[proj_short] == 0)
                # Checked all projects in the array, acceptance match not found
                return def_ret
            else:
                # The passed project string is empty - accept this for all
                return True
        else:
            # No project string set, in this case we generate everything
            return True

    # Method to generate a unique and valid name
    def generateUniqueValidName(self, inputname):
        inputverified = self.validateName(inputname)
        inputshort = inputverified
        trynum = 0
        while ((inputshort in self.xls_name_dict) or (inputshort in self.xls_forward_refs) or (inputshort in self.xls_global_name_dict)) and (trynum < 50):
            if self.max_name_length != None and self.max_name_length > 0:
                inputshort = inputverified[0:(self.max_name_length - 2 - len(str(trynum)))] + '_' + str(trynum)
            else:
                inputshort = inputverified + '_' + str(trynum)
            trynum = trynum + 1
        return inputshort

    # Method to get an object referenced by the passed identifier.
    # If the object with the given name is not yet known it will create
    # a pending forward reference (placeholder) and return that
    def getObjectByRef(self, refname):
        if refname != None:
            if refname in self.xls_name_dict:
                # This symbol has already been defined by the XLS
                #print "DEBUG: Getting ref to '%s' OK, found declaration" % refname
                refedobj = self.xls_name_dict[refname]
            else:
                # Symbol has not defined yet, if not yet in forward reference map, add
                # it now
                #print "DEBUG: Getting ref to '%s' needs creation of forward ref" % refname
                if not refname in self.xls_forward_refs:
                    self.xls_forward_refs[refname] = self.XlsPendingNameRef()
                refedobj = self.xls_forward_refs[refname]
        else:
            refedobj = None
        return refedobj

    # Method to get an object without creating a forward reference
    def getObjectWithoutRef(self, refname):
        if refname != None:
            if refname in self.xls_name_dict:
                refedobj = self.xls_name_dict[refname]
            else:
                refedobj = None
        else:
            refedobj = None
        return refedobj

    # Method to get an object from global name dictionary without forward references
    def getObjectGlobalWithoutRef(self, refname):
        refedobj = None
        if refname != None:
            if refname in self.xls_global_name_dict:
                refedobj = self.xls_global_name_dict[refname]
        return refedobj

    # Method called to signal that a given object has been declared
    def declareObj(self, name, obj):
        # Generate current location string
        cur_loc_str = "File '%s' sheet '%s' row %d" % (self.xls_name, self.xls_sheet.name, self.xls_row)
        # First check if name has already been declared
        if name in self.xls_name_dict:
            if obj != self.xls_name_dict[name]:
                self.Error("Redeclaration of symbol '%s'!" % name)
                self.InfoOut("See previous declaration of '%s' : %s" % (name, self.xls_orig_dec_loc[name]))
            retval = False
        else:
            # Check if the name has already been referenced ahead
            if name in self.xls_forward_refs:
                # Yes, there are forward refs, update them now
                if type(obj) != type(self.XlsPendingNameRef()):
                    # Normal declaration, may be filled in now
                    self.xls_forward_refs[name].resolveRefs(obj)
                    # Also declare aliases as needed
                    aliases = self.xls_forward_refs[name].getAliases()
                    for alias in aliases:
                        if alias != None:
                            self.declareObj(alias, obj)
                    # Remove the complete forward declaration struct
                    del self.xls_forward_refs[name]
                else:
                    # Linked declaration
                    obj.linkOtherRef(self.xls_forward_refs[name], name)
                    self.Warning("Symbol '%s' declared as a link to another symbol! This is not representable by AUTOSAR: the intermediate type will not be generated!" % (name))
            if type(obj) != type(self.XlsPendingNameRef()):
                self.xls_name_dict[name] = obj
                self.xls_global_name_dict[name] = obj
            retval = True
            # Add to map of names and line number as well
            self.xls_orig_dec_loc[name] = cur_loc_str
        return retval

    def checkMissingRefs(self):
        for name in self.xls_forward_refs:
            self.Error("Reference to undeclared type '%s'!" % name)

    # Method to convert a numeric-like string to a number
    def decodeNumericString(self, numericstrcandidate):
        decnumregexp = re.compile(r'^[ \t]*[+\-]?[0-9]+([\.,][0-9]*)?[ \t]*$')
        hexnumregexp = re.compile(r'^[ \t]*0x[0-9A-F]+[ \t]*$')
        if decnumregexp.match(numericstrcandidate):
            if '.' in numericstrcandidate or ',' in numericstrcandidate:
                floatval = float(re.sub(r'[,]', '.', re.sub(r'[ \t]*', '', numericstrcandidate)))
                # Work-around for cases when excel returns a normal integer as a floating point
                # number. If the corresponding int matches the value, then treat as int
                if int(floatval) == floatval:
                    return int(floatval)
                return floatval
            else:
                return long(re.sub(r'[ \t]*', '', numericstrcandidate))
        elif hexnumregexp.match(numericstrcandidate):
            return int(re.sub(r'[ \t]*', '', numericstrcandidate), 16)
        else:
            try:
                # Try to split the string up into tokens, replace any known symbolic
                # constants and then try evaluating the expression
                token_list = re.split(r"(\W+)", numericstrcandidate)
                eval_str = ""
                for cur_token in token_list:
                    if self.ident_regexp.match(cur_token):
                        # Seems an identifier, replace with known value
                        if cur_token in self.symbolic_constant_dict:
                            eval_str += str(self.symbolic_constant_dict[cur_token])
                        elif cur_token.lower() == 'pi':
                            eval_str += "3.1415927"
                        else:
                            #print "This could be an issue " + cur_token
                            eval_str += cur_token
                    else:
                        # Non-identifier, take literally
                        eval_str += cur_token
                # After the above loop all symbolic constants were replaced
                # by their values, so we can try evaluating the string
                #print "Try to eval(%s)" % eval_str
                retval = eval(eval_str)
                if (type(retval) == type(int())):
                    return int(retval)
                elif (type(retval) == type(long())):
                    return long(retval)
                elif (type(retval) == type(float())):
                    if (floor(retval) == retval):
                        return int(retval)
                    return float(retval)
                else:
                    return None
            except:
                return None

    # Method to decode a value list which is used for range or enumerator
    # value specification
    def decodeValueList(self, str, type_str, sheetname, row):
        lines = unicode(str).splitlines()
        defaultnames = [ 'upper_limit', 'lower_limit' ]
        retval = {}
        identregexp = re.compile(r'^[ \t]*([a-zA-Z_][a-zA-Z0-9_]*)[ \t]*$')
        defaultval = 0
        for line in lines:
            line = line.strip()
            if len(line)>0 and line != '-' and line != '--':
                elements = line.split('=')
                enumerator_name = None
                if (type_str == 'enum') or (type_str == 'struct'):
                    # Enum types may have multiple lines with enumerators
                    if (len(elements) == 1):
                        if (identregexp.match(elements[0])):
                            # case without explicit value set
                            enumerator_name = elements[0].strip()
                        else:
                            self.Error("Enumerators shall have an identifier followed by an optional value assignment '%s' invalid!" % (elements[0]))
                    elif (len(elements) == 2) and (identregexp.match(elements[0])):
                        # Case with reference to some identifier
                        enumerator_name = elements[0]
                        if identregexp.match(elements[1]):
                            # Reference to some constant
                            if elements[1] in self.xls_name_dict:
                                testval = self.xls_name_dict[elements[1]]
                                if type(testval) != type(int()) and type(testval) != type(float()):
                                    self.Error("identifier reference '%s' to '%s' not an integer constant!" % (elements[1], str(type(elements[1]))))
                                    enumerator_name = None
                                else:
                                    defaultval = testval
                            else:
                                self.Error("Forward enumerator references '%s' to identifiers not yet implemented!" % (elements[1]))
                                enumerator_name = None
                        else:
                            testval = self.decodeNumericString(elements[1])
                            if (testval != None):
                                defaultval = testval
                            else:
                                self.Error("Specified enumerator line '%s' not supported - ignoring line!" % (line))
                    else:
                        self.Error("Specified enumerator line '%s' not supported - ignoring line!" % (line))
                else:
                    # Non-enums may only specify two lines : the first line is the
                    # lower limit, the second line is the upper limit
                    if len(defaultnames) > 0:
                        enumerator_name = defaultnames.pop()
                        if (identregexp.match(elements[0])):
                            curelemstr = elements[0].strip()
                            val_ref = self.getObjectWithoutRef(curelemstr)
                            if type(val_ref) == type(int()):
                                defaultval = val_ref
                            else:
                                #self.Error("Reference to '%s' prior to declaration or incompatible types!" % (elements[0]))
                                if self.generate_symbolic_minmax:
                                    retval[enumerator_name] = curelemstr
                                enumerator_name = None
                        else:
                            testval = self.decodeNumericString(elements[0])
                            if (testval != None):
                                defaultval = testval
                            else:
                                try:
                                    defaultval = eval(elements[0])
                                    flt_val = float(defaultval)
                                except:
                                    # Note: error message disabled due to rows like : -2 * PI, or 3.4 ^ 38 etc., which are
                                    # currently quite common in the Excel sheet
                                    #self.Error("Unsupported range line '%s'! Ignoring!" % (elements[0]))
                                    enumerator_name = None

                    else:
                        #self.Error("More than two lines for non-enumeration are not allowed! Please only specify lower and upper limit!")
                        return {}
                # If we have an enumerator name set, then we can add it
                if enumerator_name != None:
                    retval[enumerator_name] = defaultval
                    defaulval = defaultval + 1
        return retval

    # Method to decode a lower/upper limit into string form, resolving references as needed
    def DecodeValueForComment(self, value_str):
        retval = None
        if self.allow_symbolic_min_max or type(value_str) == type(float()) or type(value_str) == type(int()) or (type(value_str) == type(long())):
            retval = str(value_str)
        else:
            value_obj = self.getObjectWithoutRef(value_str)
            if (value_obj != None) and (type(value_obj) == type(float()) or type(value_obj) == type(int()) or type(value_obj) == type(long())):
                retval = str(value_obj)
            else:
                retval = None
        return retval

    # Method to load (and return) dictionary of column headers
    def loadSheetColumnHeaders(self, thesheet, caption_row = 0):
        # Load headers of columns
        colCapGen = {}
        for col in range(thesheet.ncols):
            cell_val_str = thesheet.cell(caption_row, col).value
            if len(cell_val_str) > 0:
                colCapGen[cell_val_str.lower()] = col
        return colCapGen

    # Method to process 'External types' sheet
    def processExternalTypesSheet(self, thesheet):
        self.xls_sheet = thesheet
        self.xls_row = 0
        colCaps = self.loadSheetColumnHeaders(thesheet)
        name_col = self.getColumnIndexFromCaptions(colCaps, [ 'Data Type Name', 'Name' ])
        if name_col == None:
            self.Error("No column 'Name' or 'Data Type Name' - ignoring sheet!")
            return
        ref_col = self.getColumnIndexFromCaptions(colCaps, [ 'Reference' ])
        if ref_col == None:
            self.Error("No column 'Reference' - ignoring sheet!")
            return
        type_col = self.getColumnIndexFromCaptions(colCaps, [ 'Type Class'])
        if type_col == None:
            self.Error("No column 'Type Class' - ignoring sheet!")
            return
        proj_col = self.getColumnIndexFromCaptions(colCaps, [ 'Project', 'Projects'])
        # Now go through all rows containing data
        for row in range(1, thesheet.nrows):
            # Set row number for messages
            self.xls_row = row
            # Get the values from the current row
            name_raw_str = thesheet.cell(row, name_col).value
            name_str = self.validateName(name_raw_str)
            type_str = thesheet.cell(row, type_col).value
            ref_str = thesheet.cell(row, ref_col).value

            if (proj_col == None) or self.checkProjectMatch(thesheet.cell(row, proj_col).value):
                if name_str != None and len(name_str) > 0:
                    if not name_str in self.xls_name_dict:
                        # Create a new external reference object for this
                        er = self.ExternalReference(type_str, ref_str, name_str)
                        # And add an XLS referencer object with this object
                        self.declareObj(name_str, er)
                    else:
                        # The type already exists - skip
                        pass
                else:
                    if len(name_raw_str) > 0:
                        self.Error("Type with invalid name! Ignoring row!")
        # Clear generation setting (as just done now)
        self.gen_sheets[thesheet.name] = 0
        self.xls_sheet = None

    # Method to process 'units' sheet
    def processUnitsSheet(self, ap, thesheet):
        self.xls_sheet = thesheet
        self.xls_row = 0
        # First load the names of the columns
        colCaps = self.loadSheetColumnHeaders(thesheet)
        sym_col = self.getColumnIndexFromCaptions(colCaps, [ 'Symbol' ])
        if sym_col != None:
            name_col = self.getColumnIndexFromCaptions(colCaps, ['Name'])
            if name_col != None:
                desc_col = self.getColumnIndexFromCaptions(colCaps, ['Description'])
                if desc_col != None:
                    proj_col = self.getColumnIndexFromCaptions(colCaps, ['Project', 'Projects'])
                    for row in range(1, thesheet.nrows):
                        self.xls_row = row
                        unit_raw_name = thesheet.cell(row, name_col).value
                        unit_name = self.validateName(unit_raw_name)
                        unit_symbol = thesheet.cell(row, sym_col).value
                        unit_desc = thesheet.cell(row, desc_col).value
                        if (proj_col == None) or self.checkProjectMatch(thesheet.cell(row, proj_col).value):
                            if unit_name != None and len(unit_name) > 0:
                                nu = AUTOSAR_Unit(ap, unit_name, unit_desc, unit_symbol)
                            else:
                                if len(unit_raw_name) > 0:
                                    self.Warning("Skipping line since no or invalid unit name provided!")
                else:
                    self.Error("Sheet does not contain a column 'Description'")
            else:
                self.Error("Sheet does not contain a column 'Name'")
        else:
            self.Error("Sheet does not contain a column 'Symbol'")
        # Clear generation setting (as just done now)
        self.gen_sheets[thesheet.name] = 0
        self.xls_sheet = None

    # Method to get column index based on list of possible captions
    def getColumnIndexFromCaptions(self, colCaps, altNames):
        for name in altNames:
            lc_name = name.lower()
            if lc_name in colCaps:
                return colCaps[lc_name]
        return None

    # Method to process base types sheet
    def processTypesSheet(self, ap, thesheet):
        self.xls_sheet = thesheet
        self.xls_row = 0
        # First load the names of the colums
        colCaps = self.loadSheetColumnHeaders(thesheet)
        name_col = self.getColumnIndexFromCaptions(colCaps, ['Name', 'Data Element'])
        if name_col == None:
            self.Error("Sheet does not have a column 'Name' or 'Data Element'! Ignoring sheet!")
            return
        desc_col = self.getColumnIndexFromCaptions(colCaps, ['Description'])
        if desc_col == None:
            self.Warning("Sheet does not have a column 'Description'! Not generating descriptions!")
        ref_col = self.getColumnIndexFromCaptions(colCaps, ['Reference', 'Typeref'])
        if ref_col == None:
            self.Error("Sheet does not have a column 'Reference'! Ignoring sheet!")
            return
        type_col = self.getColumnIndexFromCaptions(colCaps, ['Data Type', 'Type'])
        if type_col == None:
            self.Error("Sheet does not have a column 'Data Type' or 'Type'! Ignoring sheet!")
            return
        arr_size_col = self.getColumnIndexFromCaptions(colCaps, ['Array Size'])
        if arr_size_col == None:
            self.Warning("Sheet does not have an 'Array Size' column! Assuming non-array data!")
        resolution_col = self.getColumnIndexFromCaptions(colCaps, ['Resolution', 'Typ. Resolution'])
        if resolution_col == None:
            self.Warning("Sheet does not have a 'Resolution' or 'Typ. Resolution' column! Assuming default of 1 for all rows!")
        range_col = self.getColumnIndexFromCaptions(colCaps, ['Range', 'Typ. Range'])
        if range_col == None:
            self.Warning("Sheet does not have a 'Range' or 'Typ. Range' column! Assuming no range information!")
        array_name_hint_col = self.getColumnIndexFromCaptions(colCaps, ['Array Name', 'Array Type Name'])
        if array_name_hint_col == None:
            # Note: one could emit a warning/message here, but since this feature is only used by very few
            # sheets, currently just pass
            pass
        offset_col = self.getColumnIndexFromCaptions(colCaps, ['Typ. Offset' ])
        vname_col = self.getColumnIndexFromCaptions(colCaps, ['MTS Name', 'Virtual Name', 'Vname'])
        vaddr_col = self.getColumnIndexFromCaptions(colCaps, ['Virtual Address', 'Virt Addr', 'Vaddr'])
        cycleid_col = self.getColumnIndexFromCaptions(colCaps, ['Cycle ID', 'CycleID'])
        proj_col = self.getColumnIndexFromCaptions(colCaps, ['Project', 'Projects'])
        unit_col = self.getColumnIndexFromCaptions(colCaps, ['Physical Unit', 'Physical Units', 'Units', 'Unit'])
        # Now that we have indices of all relevant columns we can process the data
        # row by row
        last_level = 0          # The 'grouping' level of the last iteration
        last_obj = None         # The last object loaded from the previous row
        cur_container = ap      # The current container object (top of nested_objs stack)
        nested_objs = []        # The nested_objs stack
        cur_proj_accept = True  # The current project acceptance mode
        nested_proj_accept = [ True ] # The nested project acceptance stack
        for row in range(1, thesheet.nrows):
            self.xls_row = row
            # Get handy shorter references to the columns that are always present
            name_raw_str = unicode(thesheet.cell(row, name_col).value).strip()
            type_raw_str = self.validateName(thesheet.cell(row, type_col).value)
            # Verify that name non-empty
            if name_raw_str != None:
                # Carefully extract column information not always present
                if desc_col != None:
                    desc_raw_str = unicode(thesheet.cell(row, desc_col).value).strip()
                    # remove end-of-line to avoid pdo-tool errors
                    desc_raw_str = desc_raw_str.replace('\n',' ')
                else:
                    desc_raw_str = None
                if resolution_col != None:
                    resolution_raw_str = unicode(thesheet.cell(row, resolution_col).value).strip()
                    # remove end-of-line to avoid pdo-tool errors
                    resolution_raw_str = resolution_raw_str.replace('\n',' ')
                else:
                    resolution_raw_str = None
                if range_col != None:
                    range_raw_str_orig = unicode(thesheet.cell(row, range_col).value).strip()
                else:
                    range_raw_str_orig = None
                # remove end-of-line to avoid pdo-tool errors
                range_raw_str = range_raw_str_orig.replace('\n',' ')
                if arr_size_col != None:
                    arr_size_raw_str = unicode(thesheet.cell(row, arr_size_col).value).strip()
                else:
                    arr_size_raw_str = None
                # Get current level
                if row in thesheet.rowinfo_map:
                    cur_level = thesheet.rowinfo_map[row].outline_level
                else:
                    cur_level = last_level
                # Check if nesting level has changed
                while cur_level != last_level:
                    # Check if nesting level increased or decreased
                    if (cur_level > last_level):
                        # Nesting level increased, started definition of fields of a struct
                        if last_obj != None and last_obj.type_str == 'RECORD-TYPE':
                            #print "DEBUG: Sheet %s row %d, for %s grouping increase, creating new sub-elements for %s" % (thesheet.name, row+1, name_raw_str, last_obj.short_name)
                            nested_objs.append(cur_container)
                            nested_proj_accept.append(cur_proj_accept)
                            cur_container = last_obj
                        else:
                            # To keep stack in-tact push current container to the stack once more
                            nested_objs.append(cur_container)
                            nested_proj_accept.append(cur_proj_accept)
                            if cur_proj_accept == True:
                                self.Error("Grouping has increased, but no valid parent row (row above not a record!)")
                                if last_obj == None:
                                    self.InfoOut("ERROR was due to last obj being none")
                                else:
                                    self.InfoOut("ERROR was due to last obj being '%s'" % last_obj.type_str)
                        last_level = last_level + 1
                    else:
                        # Nesting level decreased, finished defining fields of a struct
                        if len(nested_objs) > 0:
                            #print "DEBUG: Sheet '%s' row %d grouping decrease, closing container %s" % (thesheet.name, row+1, cur_container.short_name)
                            cur_container = nested_objs.pop()
                            if len(nested_proj_accept) > 0:
                                nested_proj_accept.pop()
                            #print "DEBUG: Sheet '%s' row %d now using container %s" % (thesheet.name, row+1, cur_container.short_name)
                        else:
                            self.Error("Grouping has decreased, but internal container stack corrupt!")
                            cur_container = ap
                        last_level = last_level - 1
                # Set default value for current project accept
                if len(nested_proj_accept) > 0:
                    cur_proj_accept = nested_proj_accept[-1]
                else:
                    cur_proj_accept = True
                # Reset last object reference
                last_obj = None
                # Reset base type of row
                base_type = None
                # Reset lower and upper limit
                lower_limit = None
                upper_limit = None
                scale_factor = 1
                # Check if project configuration requires generation of row
                if proj_col == None or self.checkProjectMatch(thesheet.cell(row, proj_col).value):
                    name_valid_str = self.validateName(name_raw_str)
                    ref_raw_str = self.validateName(thesheet.cell(row, ref_col).value)
                    # Create a type hint string based on info so far
                    if ref_raw_str != None and len(ref_raw_str) > 0:
                        type_hint_str = ref_raw_str[0:self.max_name_length]
                    elif name_raw_str != None and len(name_raw_str) > 0:
                        # Check if required prefix present, and if not, prepend it
                        if self.type_prefix == None or re.match(self.type_prefix + r'.*$', name_raw_str ):
                            type_hint_str = name_raw_str
                        else:
                            type_hint_str = self.type_prefix + name_raw_str
                        # Check if required suffix present, and if not append it
                        if self.type_suffix == None or re.match(r'.*' + self.type_suffix + r'$', type_hint_str):
                            # Nothing to do
                            pass
                        else:
                            if self.max_name_length != None and self.max_name_length > 0:
                                type_hint_str = type_hint_str[0:self.max_name_length-len(self.type_suffix)] + self.type_suffix
                            else:
                                type_hint_str = type_hint_str + self.type_suffix
                    else:
                        type_hint_str = None
                    # Decide if lower-upper limit needs to be set
                    if range_raw_str != None and len(range_raw_str) > 0:
                        rangevals = self.decodeValueList(range_raw_str_orig, type_raw_str, thesheet.name, row)
                        if 'upper_limit' in rangevals:
                            upper_limit = rangevals['upper_limit']
                        if 'lower_limit' in rangevals:
                            lower_limit = rangevals['lower_limit']
                    # Create extra description string
                    extra_desc_str = ""
                    if self.generate_doxygen_min_max == True:
                        if lower_limit != None and (not "@min" in desc_raw_str):
                            lower_limit_str = self.DecodeValueForComment(lower_limit)
                            if (lower_limit_str != None):
                                extra_desc_str += " @min:" + lower_limit_str
                            else:
                                # For time being skip error message
                                #self.Warning("Specified symbolic minimum '%s' that can not be decoded - ignoring!" % (str(lower_limit)))
                                pass
                        if upper_limit != None and (not "@max" in desc_raw_str):
                            upper_limit_str = self.DecodeValueForComment(upper_limit)
                            if (upper_limit_str != None):
                                extra_desc_str += " @max:" + upper_limit_str
                            else:
                                # For time being skip error message
                                #self.Warning("Specified symbolic maximum '%s' that can not be decoded - ignoring!" % (str(upper_limit)))
                                pass
                        if resolution_raw_str != None and len(resolution_raw_str) > 0:
                            extra_desc_str += " @resolution:" + str(resolution_raw_str)
                        if offset_col != None:
                            offset_raw_str = thesheet.cell(row, offset_col).value
                            if (len(offset_raw_str) > 0):
                                extra_desc_str += " @offset:" + offset_raw_str
                    # Transcode resolution into a scaling factor
                    if (resolution_raw_str != None):
                        try:
                            scale_factor = eval(resolution_raw_str)
                        except:
                            scale_factor = 1
                    else:
                        scale_factor = 1
                    # Check if unit string output enabled
                    if self.enable_units_comment and unit_col != None:
                        unit_raw_str = unicode(thesheet.cell(row, unit_col).value).strip()
                        if len(unit_raw_str) > 0 and unit_raw_str != '-':
                            extra_desc_str += " @unit:" + unit_raw_str
                    # Generate MTS addresses if enabled to do so
                    if self.generate_doxygen_measdata == True:
                        num_vaddrs_read = 0
                        if vaddr_col != None:
                            raw_vaddr_str = unicode(thesheet.cell(row, vaddr_col).value)
                            if len(raw_vaddr_str) > 0 and raw_vaddr_str != '-':
                                vaddr_lines = raw_vaddr_str.split(r',') #re.split(r'[,\n]+\W*', raw_vaddr_str)
                                extra_desc_str += " @vaddr:"
                                vaddr_defs_str = ""
                                for cur_vaddr_line in vaddr_lines:
                                    if len(cur_vaddr_line) > 0:
                                        vaddr_elems = cur_vaddr_line.split('=')
                                        if len(vaddr_elems) == 1:
                                            vaddr_value_striped = vaddr_elems[0].strip()
                                            if self.use_meas_vaddr == True:
                                                if vaddr_value_striped not in self.virtual_addr_names:
                                                    self.Error("For meas address define '%s' is no address defined in the meas tab! Use default address 0xFFFFFFFF" % (vaddr_value_striped))
                                                    extra_desc_str += "0xFFFFFFFF"
                                                else:
                                                    extra_desc_str += "0x%08X" %self.virtual_addr_names[vaddr_value_striped]
                                                if len(vaddr_defs_str) > 0 and vaddr_defs_str[-1] != ',':
                                                    vaddr_defs_str += ','
                                                vaddr_defs_str += vaddr_value_striped
                                            else:
                                                extra_desc_str += vaddr_value_striped
                                            num_vaddrs_read = num_vaddrs_read + 1
                                        else:
                                            try:
                                                vaddr_value_striped = vaddr_elems[0].strip()
                                                self.virtual_addr_names[vaddr_value_striped] = int(vaddr_elems[1].strip(), 0)
                                                if self.use_meas_vaddr == True:
                                                    extra_desc_str += "0x%08X" %self.virtual_addr_names[vaddr_value_striped]
                                                else:
                                                    extra_desc_str += vaddr_value_striped
                                                if len(vaddr_defs_str) > 0 and vaddr_defs_str[-1] != ',':
                                                    vaddr_defs_str += ','
                                                vaddr_defs_str += vaddr_value_striped
                                                num_vaddrs_read = num_vaddrs_read + 1
                                            except:
                                                self.Error("Illegal virtual address '%s' specified!" % (cur_vaddr_line))
                                        if num_vaddrs_read < len(vaddr_lines):
                                            extra_desc_str += ', '
                                # Append PDO-unused tag @vaddr_defs with symbolic names of virtual addresses for easier
                                # look-up in source-code
                                if self.use_meas_vaddr and vaddr_defs_str != "":
                                    extra_desc_str += " @vaddr_defs: " + vaddr_defs_str
                        if cycleid_col != None:
                            raw_cycleid_str = unicode(thesheet.cell(row, cycleid_col).value)
                            if len(raw_cycleid_str) > 0 and raw_cycleid_str != '-':
                                ident_match_cycleid_list = self.validateIdentList(raw_cycleid_str)
                                if (len(ident_match_cycleid_list) > 0):
                                    extra_desc_str += " @cycleid:" + string.join(ident_match_cycleid_list, ",")
                        if vname_col != None:
                            raw_vname_str = unicode(thesheet.cell(row, vname_col).value)
                            if (len(raw_vname_str) > 0) and raw_vname_str != '-':
                                ident_match_vname_list = self.validateIdentList(raw_vname_str)
                                if len(ident_match_vname_list) != num_vaddrs_read and (len(ident_match_vname_list)!= 0 or num_vaddrs_read == 1):
                                    self.Error("More virtual addresses than virtual names specified!")
                                if (len(ident_match_vname_list)>0):
                                    extra_desc_str += " @vname:" + string.join(ident_match_vname_list, ",")
                    # Check if upper levels also pass
                    if cur_proj_accept:
                        # Based on the type information we need to decide how to handle data
                        if type_raw_str == 'enum':
                            # An enumeration. In this case the 'range_col' contains the enumerators
                            if range_raw_str != None:
                                # Use helper function for getting enumerators
                                # TODO: Transition to this later on
                                #enumvals = self.decodeValueList(range_raw_str_orig, type_raw_str, thesheet.name, row)
                                # We have the enumerators in the range column seperated by
                                # newlines: extract them from there
                                lines = unicode(range_raw_str_orig).splitlines()
                                cureval = 0
                                identregexp = re.compile(r'^[ \t]*([a-zA-Z_][a-zA-Z0-9_]*)[ \t]*$')
                                decimalregexp = re.compile(r'^[ \t]*[+\-]?[0-9]+[ \t]*$')
                                hexnumregexp = re.compile(r'^[ \t]*0x[0-9A-F]+[ \t]*$')

                                lower_limit = None
                                upper_limit = None
                                enum = {}
                                long_name = "enum {"
                                for line in lines:
                                    elements = line.split('=')
                                    enumerator_name = None
                                    if (len(elements) == 1) and (identregexp.match(elements[0])):
                                        # case without explicit value set
                                        enumerator_name = elements[0].strip()
                                    elif (len(elements) == 2) and (identregexp.match(elements[0])):
                                        # Case with reference to some identifier
                                        enumerator_name = elements[0].strip()
                                        if identregexp.match(elements[1]):
                                            # Reference to some constant
                                            enum_val_ref = self.getObjectByRef(elements[1].strip())
                                            if type(enum_val_ref) == type(int()):
                                                # Direct integer definition
                                                cureval = int(elements[1])
                                            elif type(enum_val_ref) == type(self.XlsPendingNameRef()):
                                                # Reference to an identifier not declared yet
                                                enum_val_ref.addRefingAtomic(enumerator_name, None)
                                            else:
                                                self.Error("Identifier reference '%s' to %s not an integer constant!" % (elements[1], str(type(elements[1]))))
                                                enumerator_name = None
                                        elif decimalregexp.match(elements[1]):
                                            cureval = int(elements[1])
                                        elif hexnumregexp.match(elements[1]):
                                            cureval = int(re.sub(r'[ \t]*', '', elements[1]), 16)
                                        else:
                                            self.Error("Specified enumerator line '%s' not supported - ignoring line!" % (line))
                                    else:
                                        self.Error("Specified enumerator line '%s' not supported - ignoring line!" % (line))
                                    # If we have an enumerator name set, then we can add it
                                    if enumerator_name != None:
                                        if not enumerator_name in self.xls_name_dict:
                                            # Enumerator name so far not declared - OK, add now
                                            self.declareObj(enumerator_name, cureval)
                                            enum[enumerator_name] = cureval
                                            long_name = long_name + unicode(enumerator_name) + "=" + unicode(cureval)
                                        else:
                                            # Enumerator name already used somewhere else
                                            prevdecl = self.xls_name_dict[enumerator_name]
                                            if type(prevdecl) == type(cureval) and prevdecl == cureval:
                                                # Identical declaration, should generate identical defines
                                                print "WARNING: File '%s' sheet '%s' row %d specifies enumerator '%s' for which a prior identical declaration exists!" % (self.xls_name, thesheet.name, row+1, enumerator_name)
                                                print "INFO: Previous declaration of '%s' : %s" % (enumerator_name, self.xls_orig_dec_loc[enumerator_name])
                                                enum[enumerator_name] = cureval
                                                long_name = long_name + unicode(enumerator_name) + "=" + unicode(cureval)
                                            else:
                                                self.Error("Specified enumerator '%s' which has a prior incompatible declaration! Ignoring enumertor!" % (enumerator_name))
                                        if upper_limit == None or cureval > upper_limit:
                                            upper_limit = cureval
                                        if lower_limit == None or cureval < lower_limit:
                                            lower_limit = cureval
                                        scale_factor = 1
                                        cureval = cureval + 1
                                # Finish long name string
                                long_name = long_name + "}"
                                # Check if @values already present in string, if yes, then ignore description str for 'desc_ext_raw_str'
                                if (desc_raw_str != None) and (not "@values" in desc_raw_str):
                                    desc_ext_raw_str = desc_raw_str
                                else:
                                    desc_ext_raw_str = ""
                                # Modify description string to contain min and max specification
                                if self.generate_doxygen_min_max == True:
                                    enum_extra_desc_str = " @min: " + str(lower_limit) + " @max:" + str(upper_limit)
                                    desc_ext_raw_str += enum_extra_desc_str
                                if (self.generate_doxygen_value_tags == True):
                                    if len(enum) > 0:
                                        enum_extra_desc_str = " @values: enum { "
                                        for enumerator in enum:
                                            enum_extra_desc_str += str(enumerator) + '=' + str(enum[enumerator]) + ','
                                        enum_extra_desc_str += '} '
                                        desc_ext_raw_str += enum_extra_desc_str
                                # Reset extra description string so that it isn't reused for field
                                extra_desc_str = None
                                # Now we have all the enumerator values
                                if self.enum_prefix == None:
                                    # Use default enum prefix e_
                                    ac = AUTOSAR_CompuMethod(ap, self.generateUniqueValidName("e_"+type_hint_str), desc_raw_str, long_name, enum)
                                else:
                                    ac = AUTOSAR_CompuMethod(ap, self.generateUniqueValidName(self.enum_prefix + type_hint_str), desc_raw_str, long_name, enum)
                                base_type = AUTOSAR_IntegerType(ap, type_hint_str, desc_ext_raw_str, ac, self.getBestBaseType(lower_limit, upper_limit))

                                self.declared_enums.append(base_type.getRefName())
                                self.declareObj(type_hint_str, base_type)
                                # If the normal name is not the same as type_hint_str, then declare the normal name as well
                                if (self.declare_enum_by_undecorated_name) and (type_hint_str != name_raw_str):
                                    self.declareObj(name_raw_str, base_type)
                                # If the raw type string had to be truncated, then declare that as well
                                if (ref_raw_str != None) and (len(ref_raw_str) > 0) and (ref_raw_str != type_hint_str):
                                    self.declareObj(ref_raw_str, base_type)
                                base_type.lower_limit = lower_limit
                                base_type.upper_limit = upper_limit
                            else:
                                # We are unable to decode the enumerator as range column was not found!
                                self.Error("Specifies an enumerator, but 'Range' column is not available! Skipping!")
                        elif type_raw_str == 'struct':
                            # Create a new record for the struct
                            if len(extra_desc_str) > 0:
                                if desc_raw_str != None:
                                    desc_raw_str += extra_desc_str
                                else:
                                    desc_raw_str = extra_desc_str
                            base_type = AUTOSAR_Record(ap, type_hint_str, desc_raw_str)
                            self.declareObj(type_hint_str, base_type)
                            # If the normal name is not the same as type_hint_str, then declare the normal name as well
                            if (self.declare_struct_by_undecorated_name) and (type_hint_str != name_raw_str):
                                self.declareObj(name_raw_str, base_type)
                            # If the raw type string had to be truncated, then declare that as well
                            if (ref_raw_str != None) and (len(ref_raw_str) > 0) and (ref_raw_str != type_hint_str):
                                self.declareObj(ref_raw_str, base_type)
                            # Special handling for structure level version numbers
                            if (range_raw_str != None) and (len(range_raw_str) > 0) and range_raw_str != '-' and range_raw_str != '--':
                                values = self.decodeValueList(range_raw_str, type_raw_str, thesheet.name, row)
                                for value_name in values:
                                    unique_value_name = self.generateUniqueValidName(value_name)
                                    self.VersionNumbers[unique_value_name] = values[value_name]
                            # TODO: continue from here
                        elif type_raw_str == 'ref':
                            # A reference to a type defined elsewhere
                            if ref_raw_str != None and re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', ref_raw_str):
                                base_type = self.getObjectByRef(ref_raw_str)
                            else:
                                self.Error("Type specified as 'ref', but no or invalid type name provided '%s'!" % (ref_raw_str))
                                base_type = None
                        elif type_raw_str == 'ptr' or type_raw_str == 'ptr2c':
                            # Pointer or pointer to constant
                            if ref_raw_str != None and re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', ref_raw_str):
                                base_type = self.getObjectByRef(ref_raw_str)
                            else:
                                self.Error("Use of 'pointer' type, but no or invalid type name provided '%s'!" % (ref_raw_str))
                                base_type = None
                        else:
                            # Simple type, in which case 'type_raw_str' is the type reference
                            base_type = self.getObjectByRef(type_raw_str)
                        # Store the base type in the last_obj variable (if struct fields are added)
                        last_obj = base_type
                    else:
                        # The current line indicates accept, but the parent lines indicate
                        # that it should not be accepted
                        if thesheet.cell(row, proj_col).value != "":
                            print "WARNING: Sheet '%s' row %d passes project acceptance filter, but higher level does not! Ignoring project acceptance!" % (thesheet.name, row+1)
                else:
                    # The project configuration indicates this row need not be generated
                    base_type = last_obj = None
                    cur_proj_accept = False
                # The processing of the row resulted in an element and we have a valid
                # container, then add it to it
                if base_type != None:
                    # Append extra description string if there is one
                    if extra_desc_str != None and len(extra_desc_str) > 0:
                        if desc_raw_str != None:
                            desc_raw_str += extra_desc_str
                        else:
                            desc_raw_str = extra_desc_str
                    # If an array length was specified, create an array type
                    if arr_size_raw_str != None and len(arr_size_raw_str) > 0:
                        # We have something in the array size column
                        # Set default array size (if later decoding fails)
                        arr_size = 1
                        # Check if simple integer enumerator specification
                        imatch = re.match('^([0-9]+)(\.[0]*)?$', arr_size_raw_str)
                        if imatch != None:
                            # Simple integer array size specification
                            arr_size = int(imatch.group(1))
                        elif re.match('^[a-zA-Z_][a-zA-Z0-9_]*$', arr_size_raw_str):
                            # Identifier like array size
                            arr_size_candidate = self.getObjectByRef(arr_size_raw_str)
                            if type(arr_size_candidate) != type(self.XlsPendingNameRef()):
                                if type(int()) == type(arr_size_candidate) or type(long()) == type(arr_size_candidate):
                                    arr_size = arr_size_candidate
                                else:
                                    self.Error("Array size specification '%s' references '%s' not an integer constant!" % (arr_size_raw_str, str(type(arr_size_candidate))))
                            else:
                                # This means we have an array size that is forward referencing an atomic to
                                # be declared later
                                arr_size = None
                        else:
                            self.Error("The specified array size '%s' is neither an identifier nor a valid integer! Ignoring array specification!" % (arr_size_raw_str))
                        # Now if the above decoding lead to an array size that is either positive or none,
                        # then create an array
                        if (arr_size == None) or (arr_size >= 1):
                            #print "Array-over-int: On sheet '%s' in row %d the specified array size '%d' an integer!" % (thesheet.name, row+1, arr_size)
                            if cur_level > 0:
                                # Check if we have an array name hinting column, and if yes, use that directly
                                if array_name_hint_col != None and len(thesheet.cell(row, array_name_hint_col).value) > 0:
                                    array_name_hint_str = thesheet.cell(row, array_name_hint_col).value
                                else:
                                    # We are not at top-level, thus we need to generate a name for the array
                                    # First add type prefix (if any)
                                    if self.type_prefix != None:
                                        if re.match("^" + self.type_prefix, name_raw_str):
                                            array_name_hint_str = name_raw_str
                                        else:
                                            array_name_hint_str = self.type_prefix + name_raw_str
                                    else:
                                        array_name_hint_str = name_raw_str
                                    # Next append array and the type suffix
                                    if self.type_suffix != None:
                                        if re.match(self.type_suffix + r'$', array_name_hint_str):
                                            array_name_hint_str = array_name_hint_str[:-len(self.type_suffix)] + "_array" + self.type_suffix
                                        else:
                                            array_name_hint_str = array_name_hint_str + "_array" + self.type_suffix
                                    else:
                                        array_name_hint_str = array_name_hint_str + "_array"
                                array_name = self.generateUniqueValidName(array_name_hint_str)
                            else:
                                # We are at top-level, thus the name of the array shall be the name field
                                if (type_raw_str != 'ref') and ref_raw_str != None and len(ref_raw_str) > 0:
                                    array_name = self.validateName(ref_raw_str)
                                else:
                                    array_name = name_valid_str
                            # Create a new array object, and replace base type with the array type
                            array_obj = AUTOSAR_ArrayType(ap, array_name, desc_raw_str, base_type, arr_size, array_name[0:24]+'_element')
                            # If array size was unknown on creation, add dependency
                            if (arr_size == None):
                                # Array size not yet known, add a reference
                                arr_size_candidate.addRefingArraySizeObj(array_obj)
                            # If the base type was a forward reference, then add as a dependency
                            if type(base_type) == type(self.XlsPendingNameRef()):
                                base_type.addRefingAutosarObj(array_obj)
                            self.declareObj(array_name, array_obj)
                            base_type = array_obj
                    else:
                        # Non-array object. If we are at root level (not within a struct) and this is a referencing entry,
                        # then this can not be represented by autosar (no features for typedef chaining)
                        if cur_level == 0 and type_raw_str == 'ref' :
                            self.Error("Top level non-array typedef reference. AUTOSAR XML has no support for typedef chaining! Ignoring entry!")
                    # Now base_type contains the type of the row, depending on whether we
                    # are at top-level or within a record we need to handle it differently, with
                    # special handling for pointer types
                    # First check for pointer types
                    if type_raw_str == 'ptr' or type_raw_str == 'ptr2c':
                        # Pointer types
                        if cur_level > 0:
                            cur_elem = AUTOSAR_PointerField(cur_container, name_valid_str, desc_raw_str, base_type, 0, (type_raw_str == 'ptr2c'))
                        else:
                            cur_elem = AUTOSAR_PointerType(cur_container, name_valid_str, desc_raw_str, base_type, 0, (type_raw_str == 'ptr2c'))
                    # Next check if it is within a record
                    elif cur_level > 0:
                        # We are within a record, thus this line of the excel sheet declares a field of
                        # a struct : in AUTOSAR speak a record element of a record
                        cur_elem = AUTOSAR_RecordElement(cur_container, name_valid_str, desc_raw_str, base_type)
                    elif type_raw_str != 'enum':
                        # We are at root level (not within a record) that means we are declaring an object
                        if base_type.type_str == 'REAL' or base_type.type_str == 'REAL-TYPE':
                            # Real type
                            cur_elem = AUTOSAR_RealType(ap, name_valid_str, desc_raw_str, base_type)
                            self.decodeLimits(cur_elem, lower_limit, upper_limit, scale_factor)
                        elif base_type.type_str == 'INTEGER' or base_type.type_str == 'INTEGER-TYPE':
                            # Integer type, only create if not already created by the same name
                            if (base_type.short_name != name_valid_str):
                                cur_elem = AUTOSAR_IntegerType(ap, name_valid_str, desc_raw_str, None, base_type)
                                self.decodeLimits(cur_elem, lower_limit, upper_limit, scale_factor)
                            else:
                                cur_elem = None
                        elif base_type.type_str == 'RECORD' or base_type.type_str == 'RECORD-TYPE':
                            # Record type - if the type_hint_str used to create the record type
                            # matches the raw name, then we have nothing more to do. Otherwise
                            # we need to declare name_raw_str also as an alias of the same type
                            # declared with 'type_hint_str'
                            if name_raw_str == type_hint_str:
                                cur_elem = None
                            else:
                                cur_elem = base_type
                        elif base_type.type_str == 'BOOLEAN':
                            # Boolean type
                            cur_elem = AUTOSAR_IntegerType(ap, name_valid_str, desc_raw_str, None, base_type)
                            cur_elem.lower_limit = 0
                            cur_elem.upper_limit = 1
                        elif base_type.type_str == 'ARRAY-TYPE':
                            # Array type
                            cur_elem = None
                        elif base_type.type_str == 'not-defined-reference':
                            # Undefined-forward-reference type
                            cur_elem = None
                            self.declareObj(name_raw_str, base_type)
                        else:
                            print "Unknown base type '%s' for field '%s'" % (base_type.type_str, name_raw_str)
                            cur_elem = None
                        if cur_elem != None:
                            self.declareObj(name_raw_str, cur_elem)
                    # Now if base type is a dummy forward reference and not equal to cur_elem, then
                    # we need to add 'cur_elem' to the list of objects waiting for the completion of
                    # the declaration of 'base_type'
                    if type(base_type)==type(self.XlsPendingNameRef()) and cur_elem != None and cur_elem != base_type:
                        #print "DEBUG: Sheet '%s' row %d adding AUTOSAR object '%s' as pending reference" % (thesheet.name, row+1, cur_elem.short_name)
                        base_type.addRefingAutosarObj(cur_elem)
        # Clear generation setting (as just done now)
        self.gen_sheets[thesheet.name] = 0
        self.xls_sheet = None
        self.xls_row = 0

    # Method to process symbolic constants sheet
    def processSymbolicConstSheet(self, ap, thesheet):
        self.xls_sheet = thesheet
        self.xls_row = 2
        # First load the names of the colums
        colCaps = self.loadSheetColumnHeaders(thesheet, 2)
        name_col = self.getColumnIndexFromCaptions(colCaps, ['Name'])
        val_col = self.getColumnIndexFromCaptions(colCaps, ['Value'])
        proj_col = self.getColumnIndexFromCaptions(colCaps, ['Project', 'Projects'])
        if name_col != None and val_col != None:
            # Both necessary keys present
            for row in range(3, thesheet.nrows):
                self.xls_row = row+1
                if proj_col == None or self.checkProjectMatch(thesheet.cell(row, proj_col).value):
                    symbol_raw_name = thesheet.cell(row, name_col).value
                    symbol_name = self.validateName(symbol_raw_name)
                    symbol_value = self.decodeNumericString(str(thesheet.cell(row, val_col).value))
                    if symbol_name != None and symbol_value != None:
                        # so far so good
                        if not symbol_name in self.symbolic_constant_dict:
                            self.xls_name_dict[symbol_name] = symbol_value
                            self.symbolic_constant_dict[symbol_name] = symbol_value
                        else:
                            old_sym_val = self.symbolic_constant_dict[symbol_name]
                            if old_sym_val != symbol_value:
                                self.Error("Redeclaration of symbolic constant '%s', previously declared different (%s != %s)" % (symbol_name, str(symbol_value), str(old_sym_val)))
                    else:
                        # This is not that good
                        if len(unicode(symbol_raw_name)) > 0:
                            self.Error("Does not contain a valid symbolic name-value pair!")
        else:
            self.Error("Does not contain column headers 'Name' and/or 'Value'!")
        # Clear generation setting (as just done now)
        self.gen_sheets[thesheet.name] = 0
        self.xls_sheet = None
        self.xls_row = 0

    # Method to process meas address information sheet
    def processMeasInfoSheet(self, ap, thesheet):
        self.xls_sheet = thesheet
        self.xls_row = 4
        colCaps = self.loadSheetColumnHeaders(thesheet, 4)
        start_addr_col = self.getColumnIndexFromCaptions(colCaps, ['Start'])
        sdl_name_col = self.getColumnIndexFromCaptions(colCaps, ['SDL Name'])
        macro_name_col = self.getColumnIndexFromCaptions(colCaps, ['Macro Name'])
        proj_col = self.getColumnIndexFromCaptions(colCaps, ['Project', 'Projects'])
        colCaps = self.loadSheetColumnHeaders(thesheet, 5)
        if (start_addr_col is None):
            start_addr_col = self.getColumnIndexFromCaptions(colCaps, ['Start'])
        if (sdl_name_col is None):
            sdl_name_col = self.getColumnIndexFromCaptions(colCaps, ['SDL Name'])
        if (macro_name_col is None):
            macro_name_col = self.getColumnIndexFromCaptions(colCaps, ['Macro Name'])
        if (proj_col is None):
            proj_col = self.getColumnIndexFromCaptions(colCaps, ['Project', 'Projects'])
        if start_addr_col != None and sdl_name_col != None and macro_name_col != None:
            # All necessary keys present
            for row in range(6, thesheet.nrows):
                self.xls_row = row+1
                start_addr_raw = unicode(thesheet.cell(row, start_addr_col).value)
                macro_name_raw = thesheet.cell(row, macro_name_col).value
                # check if project filtering allows row to be generated
                if (proj_col == None) or self.checkProjectMatch(thesheet.cell(row, proj_col).value):
                    if len(start_addr_raw) > 0 and len(macro_name_raw) > 0:
                        start_addr_num = int(eval(start_addr_raw))
                        macro_name_short = macro_name_raw.strip()
                        if not macro_name_short in self.virtual_addr_names:
                            self.virtual_addr_names[macro_name_short] = start_addr_num
                        else:
                            old_addr = self.virtual_addr_names[macro_name_short]
                            if old_addr != start_addr_num:
                                self.Error("Redeclares symbolic constant '%s', previously declared different (0x%x != 0x%x)" % (macro_name_raw, start_addr_num, old_addr))
                    else:
                        #self.Error("Passes project filtering but contains no valid macro name or start address!")
                        pass
        else:
            self.Error("Does not contain necessary column headers for a measurement information sheet!")
            if start_addr_col == None:
                self.Error("Missing address column")
            if sdl_name_col == None:
                self.Error("Missing SDL name column")
            if proj_col == None:
                self.Error("Missing project column")
        # Clear generation setting (as just done now)
        self.gen_sheets[thesheet.name] = 0
        self.xls_sheet = None
        self.xls_row = 0

    def getBestBaseType(self, lower_limit, upper_limit):
        rettype = None
        if lower_limit == None:
            lower_limit = 0
        if upper_limit == None:
            upper_limit = 4294967295
        # Changed with version 1.61 to prefer signed types up to 32 bits
        if self.prefer_signed_enums:
            # Prefer signed enums (i.e.: always check signed first for range match)
            if upper_limit <= 127 and lower_limit >= -128:
                rettype = self.getObjectWithoutRef('sint8')
            elif upper_limit <= 255 and lower_limit >= 0:
                rettype = self.getObjectWithoutRef('uint8')
            elif upper_limit <= 32767 and lower_limit >= -32768:
                rettype = self.getObjectWithoutRef('sint16')
            elif upper_limit <= 65535 and lower_limit >= 0:
                rettype = self.getObjectWithoutRef('uint16')
            elif upper_limit <= 2147483647 and lower_limit >= -2147483648:
                rettype = self.getObjectWithoutRef('sint32')
            elif upper_limit <= 4294967295 and lower_limit >= 0:
                rettype = self.getObjectWithoutRef('uint32')
            elif lower_limit >= 0:
                rettype = self.getObjectWithoutRef('uint64')
            else:
                rettype = self.getObjectWithoutRef('sint64')
        else:
            # Prefer unsigned enums (i.e.: always check unsigned first for range match)
            if lower_limit >= 0:
                # Unsigned branch
                if upper_limit <= 255:
                    rettype = self.getObjectWithoutRef('uint8')
                elif upper_limit <= 65535:
                    rettype = self.getObjectWithoutRef('uint16')
                elif upper_limit <= 4294967295:
                    rettype = self.getObjectWithoutRef('uint32')
                else:
                    rettype = self.getObjectWithoutRef('uint64')
            else:
                # Signed branch
                if upper_limit <= 127 and lower_limit >= -128:
                    rettype = self.getObjectWithoutRef('sint8')
                elif upper_limit <= 32767 and lower_limit >= -32768:
                    rettype = self.getObjectWithoutRef('sint16')
                elif upper_limit <= 2147483647 and lower_limit >= -2147483648:
                    rettype = self.getObjectWithoutRef('sint32')
                else:
                    rettype = self.getObjectWithoutRef('sint64')
        return rettype

    def decodeLimits(self, cur_elem, lower_limit, upper_limit, scale_factor):
        if lower_limit != None:
            if ((type(lower_limit) == type(float())) or type(lower_limit) == type(int()) or (type(lower_limit) == type(long()))):
                if scale_factor != None and (scale_factor > 1e-5 or scale_factor < -1e-5) and scale_factor != 1:
                    cur_elem.lower_limit = lower_limit / scale_factor
                else:
                    cur_elem.lower_limit = lower_limit
            else:
                self.Error("The specified minimum '%s' can not be interpreted!" % (lower_limit))
        if upper_limit != None:
            if ((type(upper_limit) == type(float())) or type(upper_limit) == type(int()) or (type(upper_limit) == type(long()))):
                if scale_factor != None and (scale_factor > 1e-5 or scale_factor < -1e-5) and scale_factor != 1:
                    cur_elem.upper_limit = upper_limit / scale_factor
                else:
                    cur_elem.upper_limit = upper_limit
            else:
                self.Error("The specified maximum '%s' can not be interpreted!" % (upper_limit))

######################################################
if __name__=='__main__':
    cur_arg = 1
    opt_values = [ "ARS301_algo_interface_types.xls", "./AUTOSAR_AlgoTypes.ecuextract" ]
    cur_opt_idx = 0
    project_name = "ARS301"
    gen_doxy_data = True
    gen_sub_packs = True
    allow_xref = False
    allow_sym_minmax = False
    # Define default type prefix/suffix setting as hard-coded in old (pre 1.52) script versions
    type_prefix = None
    type_suffix = "_t"
    max_name_length = None
    # Define default enum prefix setting as hard-coded in old (pre 1.54) script versions
    enum_prefix = "enum_"
    gen_swc_data_par =  False
    use_meas_vaddr_par = False
    root_package_name = "Algo"
    autosarver = 3
    autosarsubver = 0
    # true of created for tresos (otherwise created for CESSAR)
    tresos = False
    dataflowfile = "";
    prefer_signed_enum = False
    enable_units = False
    force_imm_suffix = False

    #force_unique_prj_negation:
    # - if False it works as before:
    #     project: ARS4xx
    #     line to parse: !SRR3T2,\nSRR3XX
    #     result: datatype/attribute gets added to the EcuExtract
    # - if True it works by ignoring only the negated project
    #     project: ARS4xx
    #     line to parse: !SRR3T2, \nSRR3XX
    #     result: datatype/attribute doesn't get added to the EcuExtract
    force_unique_prj_negation = False
    while (cur_arg < len(sys.argv)):
        if sys.argv[cur_arg][0] == '-':
            # It is an option
            if sys.argv[cur_arg] == "-p" or sys.argv[cur_arg] == "--project":
                cur_arg+=1
                project_name = sys.argv[cur_arg].upper()
            elif sys.argv[cur_arg] == "--rootpackage":
                cur_arg+=1
                root_package_name = sys.argv[cur_arg]
            elif sys.argv[cur_arg] == "--no-mtsgen":
                gen_doxy_data = False
            elif sys.argv[cur_arg] == "--no-subpackages":
                gen_sub_packs = False
            elif sys.argv[cur_arg] == "--dataflowfile":
                cur_arg+=1
                dataflowfile = sys.argv[cur_arg]
            elif sys.argv[cur_arg] == "--sort-subpkg":
                sort_subpackages = True
            elif sys.argv[cur_arg] == "--allow-xref":
                allow_xref = True
            elif sys.argv[cur_arg] == "--allow-symbolic-minmax":
                allow_sym_minmax = True
            elif sys.argv[cur_arg] == "--autosar4":
                autosarver = 4
            elif sys.argv[cur_arg] == "--autosar3_2":
                autosarsubver = 2
            elif sys.argv[cur_arg] == "--tresos":
                tresos = True
            elif sys.argv[cur_arg] == "--type-prefix":
                cur_arg+=1
                type_prefix = sys.argv[cur_arg]
                if (type_prefix.lower() == "none"):
                    type_prefix = None
            elif sys.argv[cur_arg] == "--type-suffix":
                cur_arg+=1
                type_suffix = sys.argv[cur_arg]
                if (type_suffix.lower() == "none"):
                    type_suffix = None
            elif sys.argv[cur_arg] == "--max-name-length":
                cur_arg+=1
                max_name_length = int(sys.argv[cur_arg])
            elif sys.argv[cur_arg] == "--enum-prefix":
                cur_arg+=1
                enum_prefix = sys.argv[cur_arg]
                if (enum_prefix.lower() == "none"):
                    enum_prefix = None
            elif sys.argv[cur_arg] == "--gen_swc":
                gen_swc_data_par = True
            elif sys.argv[cur_arg] == "--use-meas-vaddr":
                use_meas_vaddr_par = True
            elif sys.argv[cur_arg] == "--prefer-signed_enum":
                prefer_signed_enum = True
            elif sys.argv[cur_arg] == "--prefer-unsigned-enum":
                prefer_signed_enum = False
            elif sys.argv[cur_arg] == "--enable-units":
                enable_units = True
            elif sys.argv[cur_arg] == "--disable-units":
                enable_units = False
            elif sys.argv[cur_arg] == "--force-immediate-suffix":
                force_imm_suffix = True
            elif sys.argv[cur_arg] == "--unique-prj-negation":
                force_unique_prj_negation = True
            else:
                print "ERROR: Ignoring unknown option '%s'!" % sys.argv[cur_arg]
        else:
            # It is not an option
            if (len(opt_values) > cur_opt_idx):
                opt_values[cur_opt_idx] = sys.argv[cur_arg]
            else:
                opt_values.append(sys.argv[cur_arg])
            cur_opt_idx+=1
        cur_arg+=1

    xlsname = opt_values[0]
    xmlpath = opt_values[len(opt_values) - 1]

    if max_name_length == None or max_name_length <= 0:
        if project_name.find("SRR") > -1 or project_name.find("EVM") > -1 :
            max_name_length = 64
        else:
            max_name_length = 32

    algo_package = AUTOSAR_Package(None, root_package_name, None)
    xls_parser = Excel2AUTOSAR(project_name, gen_doxy_data, gen_sub_packs, allow_sym_minmax, type_prefix, type_suffix, max_name_length, enum_prefix, gen_swc_data_par, use_meas_vaddr_par, prefer_signed_enum, enable_units, force_unique_prj_negation)
    for xlsname in opt_values[:-1]:
        xlrdobj = xls_parser.ParseXlsFile(xlsname, dataflowfile, algo_package)
        if (not allow_xref):
            xls_parser.ResetParser()
    xls_parser.FinalizeParsedInfo(algo_package)
    ex = AUTOSAR_EcuExtract(xmlpath, autosarver, autosarsubver, tresos, force_imm_suffix)
    algo_package.dumpAsXML(ex)

    #                   Source     Speicherort  Autosar-Version
    # #####################################################


"""
CHANGE LOG:
-----------
$Log: stk_algo_if_wrapper.py  $
Revision 1.90 2016/03/29 17:17:38CEST Eisenacher, Michael (eisenacherm) 
tresos: bugfix for float32
Revision 1.89 2016/03/29 09:16:03CEST Eisenacher, Michael (eisenacherm)
tresos: bugfixes for booleans and base types
Revision 1.88 2016/03/24 11:14:27CET Eisenacher, Michael (eisenacherm)
additional changes for tresos
Revision 1.87 2016/03/23 08:59:14CET Eisenacher, Michael (eisenacherm)
first version of tresos version
Revision 1.86 2016/02/05 13:57:51CET Ichim, Marius (IchimM)
added new execution argument: --unique-prj-negation, which allows to negate only one project, not the complete project string.
E.g. without --unique-prj-negation,a datatype/attribute for "!SRR3T2,\nSRR3xx" will be selected for the ARS4xx project(the original behaviour of the script).
With the argument, for the ARS4xx project the datatype/attribute will not be selected.
Revision 1.85 2015/11/17 13:54:11CET Eisenacher, Michael (eisenacherm)
use root package name for component types to avoid generation conflicts
- Added comments -  eisenacherm [Nov 17, 2015 1:54:12 PM CET]
Change Package : 352553:2 http://mks-psad:7002/im/viewissue?selection=352553
Revision 1.84 2015/11/17 10:03:45CET Eisenacher, Michael (eisenacherm)
deactivated COMPU-METHOD-REF for enums
used gen_swc_data option instead
--- Added comments ---  eisenacherm [Nov 17, 2015 10:03:46 AM CET]
Change Package : 352553:2 http://mks-psad:7002/im/viewissue?selection=352553
Revision 1.83 2015/11/16 10:27:15CET Eisenacher, Michael (eisenacherm)
for ARS5/SRR5: activated COMPU-METHOD-REF for enums
--- Added comments ---  eisenacherm [Nov 16, 2015 10:27:15 AM CET]
Change Package : 352553:2 http://mks-psad:7002/im/viewissue?selection=352553
Revision 1.82 2015/04/20 12:40:33CEST Eisenacher, Michael (eisenacherm)
adapted to new project names e.g. ARS410VW16
--- Added comments ---  eisenacherm [Apr 20, 2015 12:40:34 PM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.81 2015/03/23 14:50:05CET Schlensag, Andreas (schlensaga)
use 64 signs names also for EVM projects
--- Added comments ---  schlensaga [Mar 23, 2015 2:50:06 PM CET]
Change Package : 294152:1 http://mks-psad:7002/im/viewissue?selection=294152
Revision 1.80 2014/11/27 16:33:01CET Ungvary, Gergely (ungvaryg)
Bugfix: project negation logic
If negation logic is used and no exact match is found by project filtering then passing a single not-test leads to
pass for a complete line
--- Added comments ---  ungvaryg [Nov 27, 2014 4:33:02 PM CET]
Change Package : 263272:4 http://mks-psad:7002/im/viewissue?selection=263272
Revision 1.79 2014/08/08 09:15:17CEST Eisenacher, Michael (eisenacherm)
removed end-of-lines to avoid pdo-tool errors
--- Added comments ---  eisenacherm [Aug 8, 2014 9:15:18 AM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.78 2014/06/18 08:31:54CEST Ungvary, Gergely (ungvaryg)
Move name and reference name validation code to be only performed if given line passes project filtering
(this prevents spurious name-length warning messages for structs/types not active for the given project)
--- Added comments ---  ungvaryg [Jun 18, 2014 8:31:54 AM CEST]
Change Package : 233688:3 http://mks-psad:7002/im/viewissue?selection=233688
Revision 1.77 2014/06/02 16:19:59CEST Eisenacher, Michael (eisenacherm)
autosar 3.2: distinguish between sw base types and base types
--- Added comments ---  eisenacherm [Jun 2, 2014 4:20:00 PM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.76 2014/06/02 08:53:13CEST Eisenacher, Michael (eisenacherm)
autosar 3.2: distinguish between BaseTypes and ImplTypes
--- Added comments ---  eisenacherm [Jun 2, 2014 8:53:14 AM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.75 2014/05/12 17:37:02CEST Eisenacher, Michael (eisenacherm)
bugfix for BASE-TYPE-REF
--- Added comments ---  eisenacherm [May 12, 2014 5:37:02 PM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.74 2014/05/08 15:32:25CEST Eisenacher, Michael (eisenacherm)
another bugfix for autosar 3.2 integer types
--- Added comments ---  eisenacherm [May 8, 2014 3:32:25 PM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.73 2014/05/07 17:46:12CEST Eisenacher, Michael (eisenacherm)
bugfix for autosar 3.2 integer types
--- Added comments ---  eisenacherm [May 7, 2014 5:46:12 PM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.72 2014/04/29 10:03:42CEST Eisenacher, Michael (eisenacherm)
added autosar 3.2 base types
--- Added comments ---  eisenacherm [Apr 29, 2014 10:03:43 AM CEST]
Change Package : 180551:1 http://mks-psad:7002/im/viewissue?selection=180551
Revision 1.71 2013/11/05 16:57:37CET Ungvary, Gergely (ungvaryg)
Bugfix of simple project filtering negation (previous version did not work properly)
--- Added comments ---  ungvaryg [Nov 5, 2013 4:57:38 PM CET]
Change Package : 203032:1 http://mks-psad:7002/im/viewissue?selection=203032
Revision 1.70 2013/11/05 10:10:58CET Ungvary, Gergely (ungvaryg)
Modify script to allow simple negation of project strings/switches in project column (to simplify for example
long controller dummy variable generation)
--- Added comments ---  ungvaryg [Nov 5, 2013 10:10:59 AM CET]
Change Package : 203032:1 http://mks-psad:7002/im/viewissue?selection=203032
Revision 1.69 2013/07/05 14:38:40CEST Ungvary, Gergely (ungvaryg)
Modify script for better error/warning message output (pass XLS messages through class methods for errors/warnings
where proper line number/file/sheet formating information is appended)
Note: just a quick hack for easier location of errors, but seems to work. Hope I haven't overlooked anything.
--- Added comments ---  ungvaryg [Jul 5, 2013 2:38:41 PM CEST]
Change Package : 179559:3 http://mks-psad:7002/im/viewissue?selection=179559
Revision 1.68 2013/04/08 15:36:59CEST Ungvary, Gergely (ungvaryg)
Add new option (work-around) --force-immediate-suffix to append C-suffixes to compu-method constants
depending on the range of the constants themselves. Note: this is a questionable work-around that seems to
work with current Cessar/RTE-Gen tooling, but is non-standard
--- Added comments ---  ungvaryg [Apr 8, 2013 3:37:00 PM CEST]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.67 2013/04/04 16:04:43CEST Ungvary, Gergely (ungvaryg)
Bugfix: erronous virtual addresses written for --use-meas-vaddr option, when address below 0x10000000 (bad hexadeimal formating string)
--- Added comments ---  ungvaryg [Apr 4, 2013 4:04:45 PM CEST]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.66 2013/02/27 15:44:48CET Exner, Christian (uidt8578)
- added ability to specify a comma separated list of projects to generate: --project A,B,C
--- Added comments ---  uidt8578 [Feb 27, 2013 3:44:48 PM CET]
Change Package : 162889:12 http://mks-psad:7002/im/viewissue?selection=162889
Revision 1.65 2013/02/18 11:19:32CET Ungvary, Gergely (ungvaryg)
Add new options "--enable-units" and "--disable-units" to enable generation of @unit comment tags in
output EcuExtract (default: disabled, same output as old versions)
--- Added comments ---  ungvaryg [Feb 18, 2013 11:19:37 AM CET]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.64 2013/02/08 13:22:08CET Ungvary, Gergely (ungvaryg)
Update: better decoding of numeric values (auto detect integer representation), allow expression support
for symbolic constants (using replacement of known symbols with their value)
Update: support for configuration switches in projects column (allow simple switching of multiple locations
via setting constant switch value
--- Added comments ---  ungvaryg [Feb 8, 2013 1:22:09 PM CET]
Change Package : 99436:3 http://mks-psad:7002/im/viewissue?selection=99436
Revision 1.63 2013/01/29 11:00:15CET Ungvary, Gergely (ungvaryg)
Add new options: --prefer-signed-enum and --prefer-unsigned-enum (default): with these you can control
wheather signed or unsigned types are prefered. For example an enum with values [0..2] can be
represented by a signed or unsigned 8 bit value. The actually binary representation is always the same,
but the generated defines will or will not have an unsigned suffix.
Modify the implementation of --use-meas-vaddr parameter to also generate the symbolic meas address
define names with a @vaddr_defs tag for documentation/readability purposes
--- Added comments ---  ungvaryg [Jan 29, 2013 11:00:15 AM CET]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.62 2013/01/17 18:21:10CET Spruck, Jochen (spruckj)
Add use-maeas-vadd parameter, if set the script resolves the vaddress and put it as hex to the comments
--- Added comments ---  spruckj [Jan 17, 2013 6:21:11 PM CET]
Change Package : 162889:25 http://mks-psad:7002/im/viewissue?selection=162889
Revision 1.61 2013/01/17 14:29:36CET Ungvary, Gergely (ungvaryg)
Modify generation script to only output floating-point format minimum/maximum values when necessary (otherwise format as int)
Modify AUTOSAR4 automatic type assignment for enums to prefer signed types (i.e.: corresponding signed
type range tested first for all types up to 32 bits, resulting in most small enums now being signed 8 bit values)
Minor simplification of upper/lower limit decoding logic: move into separate function
--- Added comments ---  ungvaryg [Jan 17, 2013 2:29:37 PM CET]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.60 2012/12/07 16:56:09CET Kanzler, Steven Gerd (uidk7715)
Improvements for Data-Flow Table generation:
It should be able to handle multiple Excel-Input files now. The output is still one file, although its not as pretty yet as before.
Important convention for naming the first line in the generator-sheet:
The script now parses the names of the receiver components, and it uses all columns which follow the column which contains "Provider".
And it does this until it finds a column which contains a " " (Space).
The script also checks if there is a provide component mentioned which is not in the list of receiver-components and use them too.
--- Added comments ---  uidk7715 [Dec 7, 2012 4:56:20 PM CET]
Change Package : 166298:1 http://mks-psad:7002/im/viewissue?selection=166298
Revision 1.55.1.1 2012/11/30 18:17:35CET Kanzler, Steven Gerd (uidk7715)
Improvements for Data-Flow Table generation:
It should be able to handle multiple Excel-Input files now. The output is still one file, although its not as pretty yet as before.
Important convention for naming the first line in the generator-sheet:
The script now parses the names of the receiver components, and it uses all columns which follow the column which contains "Provider".
And it does this until it finds a column which contains a " " (Space).
The script also checks if there is a provide component mentioned which is not in the list of receiver-components and use them too.

It has not been tested yet with real ARS400/SRR300 Excel-files, but with multiple hand built excel sheets.
Until it has been properly tested and reviewed, it is just a branch and not the head.
--- Added comments ---  uidk7715 [Nov 30, 2012 6:17:48 PM CET]
Revision 1.59 2012/12/07 13:27:26CET Ungvary, Gergely (ungvaryg)
Minor fix: remove Excel2Autosar classes dependency on global name 'swc_gen_data' being present (use instead
parameter passed to constructor)
--- Added comments ---  ungvaryg [Dec 7, 2012 1:27:37 PM CET]
Change Package : 106190:1 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.58 2012/12/06 15:43:49CET Spruck, Jochen (spruckj)
Add generation of ext software component to generate a file including all the enums definitions
option is --gen_swc
--- Added comments ---  spruckj [Dec 6, 2012 3:44:00 PM CET]
Change Package : 162889:2 http://mks-psad:7002/im/viewissue?selection=162889
Revision 1.57 2012/12/03 10:12:18CET Ungvary, Gergely (ungvaryg)
Bugfix: when raw reference string not specified for array then ref_raw_str set to 'none' leading to len() throwing exception
--- Added comments ---  ungvaryg [Dec 3, 2012 10:12:21 AM CET]
Change Package : 166298:1 http://mks-psad:7002/im/viewissue?selection=166298
Revision 1.56 2012/11/30 14:00:54CET Kanzler, Steven Gerd (uidk7715)
Added new command line option "--dataflowfile", which expects a filename after a space.
This enables the output of the data-flow diagram, which sw is requesting to understand the flow of the data signals.
Currently this does NOT work with multiple excel sheets each sheet will just overwrite the previous data flow file.
So for ARS4xx/SRR3xx architecture this code has to be reworked to work with multiple excel documents.

Backward compatibility is ensured.
(sorry for the 2-space-tabs...)
--- Added comments ---  uidk7715 [Nov 30, 2012 2:01:01 PM CET]
Change Package : 166298:1 http://mks-psad:7002/im/viewissue?selection=166298
Revision 1.55 2012/11/19 13:23:10CET Spruck, Jochen (spruckj)
Add new command-line option (no changes backwards compatible, thus when new option not specified,
script behaviour is exactly the same as of previous versions):
--enum-prefix prefix : useable to specify enum prefix. Where "--enum-prefix none" means standard prefix "e_" added
--- Added comments ---  spruckj [Nov 19, 2012 1:23:20 PM CET]
Change Package : 162889:2 http://mks-psad:7002/im/viewissue?selection=162889
Revision 1.54 2012/11/16 13:03:01CET Ungvary, Gergely (ungvaryg)
Add new command-line options (note changes backwards compatible, thus when new options not specified,
script behaviour is exactly the same as of previous versions):
--type-prefix prefix : useable to specify type prefix. Where "--type-prefix none" means no prefix added
--type-suffix suffix : useable to specify type suffix. Where "--type-suffix none" means no suffix added
--max-name-length n : Can be used to limit the generated short name length. Example: --max-name-length 32
--- Added comments ---  ungvaryg [Nov 16, 2012 1:03:09 PM CET]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.53 2012/11/16 11:00:19CET Spruck, Jochen (spruckj)
Updates:
- enums could also be defined as hex values
- static variables could also be float values
--- Added comments ---  spruckj [Nov 16, 2012 11:00:23 AM CET]
Change Package : 162889:2 http://mks-psad:7002/im/viewissue?selection=162889
Revision 1.52 2012/11/07 10:55:22CET Ungvary, Gergely (ungvaryg)
Add initial support for AUTOSAR 4 pointer types: introduce two new supported raw type strings: 'ptr' and 'ptr2c'
for pointer and pointer to contant respectively.
--- Added comments ---  ungvaryg [Nov 7, 2012 10:55:22 AM CET]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.51 2012/10/16 18:20:22CEST Ungvary, Gergely (ungvaryg)
Implement preliminary AUTOSAR 4 support (enabled via command-line switch --autosar4)
--- Added comments ---  ungvaryg [Oct 16, 2012 6:20:35 PM CEST]
Change Package : 106190:2 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.50 2012/04/16 10:05:32CEST Ungvary, Gergely (ungvaryg)
Revision 1.50.1.2 2012/11/30 12:46:27CET Kanzler, Steven Gerd (uidk7715)
Bugfix: FCT_Veh was not processed as provider or receive port in the DataFlow generation part.
--- Added comments ---  uidk7715 [Nov 30, 2012 12:46:27 PM CET]
Change Package : 166298:1 http://mks-psad:7002/im/viewissue?selection=166298
Revision 1.50.1.1 2012/11/29 17:15:37CET Kanzler, Steven Gerd (uidk7715)
Added new command line option "--dataflowfile", which expects a filename after a space.
This enables the output of the data-flow diagram, which sw is requesting to understand the flow of the data signals.
Backward compatibility is ensured.
(sorry for the 2-space-tabs...)
--- Added comments ---  uidk7715 [Nov 29, 2012 5:15:43 PM CET]
Change Package : 166298:1 http://mks-psad:7002/im/viewissue?selection=166298
Revision 1.50 2012/04/16 10:05:32CEST Ungvary, Gergely (ungvaryg)
Modify project acceptance regular expression pattern to accept letters followed by a number followed by other numbers and letters
Note: this change allows project names such as ARS3N0 (note: the generation between the front letters and
the rear ID still has to be a number)
--- Added comments ---  ungvaryg [Apr 16, 2012 10:05:32 AM CEST]
Change Package : 111477:1 http://mks-psad:7002/im/viewissue?selection=111477
Revision 1.49 2012/04/03 19:37:41CEST Ungvary, Gergely (ungvaryg)
Do not add symbolic min-max values unless command line option --allow-symbolic-minmax is specified
--- Added comments ---  ungvaryg [Apr 3, 2012 7:37:43 PM CEST]
Change Package : 106190:1 http://mks-psad:7002/im/viewissue?selection=106190
Revision 1.48 2012/03/19 17:26:08CET Kaelberer, Stephan (uidu2442)
Add support for multiple "Base types" sheets -> merge them into the same AUTOSAR package
& emit a warning about the "ambiguity"
--- Added comments ---  uidu2442 [Mar 19, 2012 5:26:09 PM CET]
Change Package : 96494:8 http://mks-psad:7002/im/viewissue?selection=96494
Revision 1.47 2012/03/16 16:10:37CET Ungvary, Gergely (ungvaryg)
Add error message for top-level non-array type references - these are not representable by AUTOSAR XML
--- Added comments ---  ungvaryg [Mar 16, 2012 4:10:37 PM CET]
Change Package : 93660:1 http://mks-psad:7002/im/viewissue?selection=93660
Revision 1.46 2012/03/15 12:52:51CET Ungvary, Gergely (ungvaryg)
Add support for multiple XLS sheets having sheets with the same name -> merge them into the same AUTOSAR
package & emit a warning about the "ambiguity"
--- Added comments ---  ungvaryg [Mar 15, 2012 12:52:51 PM CET]
Change Package : 93660:1 http://mks-psad:7002/im/viewissue?selection=93660
Revision 1.45 2012/02/27 10:46:23CET Ungvary, Gergely (ungvaryg)
Modify EcuExtract generation script for top-level array types, where ref column defines name: use that name
as type name of the array
--- Added comments ---  ungvaryg [Feb 27, 2012 10:46:23 AM CET]
Change Package : 93660:1 http://mks-psad:7002/im/viewissue?selection=93660
Revision 1.44 2012/01/17 18:20:41CET Ungvary, Gergely (ungvaryg)
Bugfix: prevent non-divisable min/max scaling operations
--- Added comments ---  ungvaryg [Jan 17, 2012 6:20:46 PM CET]
Change Package : 93660:1 http://mks-psad:7002/im/viewissue?selection=93660
Revision 1.43 2012/01/13 17:08:45CET Ungvary, Gergely (ungvaryg)
Improvement: modify external type declaration to check for actual defintion already found (prevent warning
messages when parsing multiple XLS files where one declares a type that the other references as external)
New feature: for better XML comparisson add new option "--sort-subpkg" that alphabetically sorts
sub-packages by their short-names
Improvement: better error messages with file names (though there still are old messages without filename in code)
--- Added comments ---  ungvaryg [Jan 13, 2012 5:08:47 PM CET]
Change Package : 93660:1 http://mks-psad:7002/im/viewissue?selection=93660
Revision 1.42 2012/01/13 15:20:11CET Ungvary, Gergely (ungvaryg)
Modify main evaluation logic: treat all but last non-option like names as input XLS names, and last name as
output XML file name (this way this change is backwards compatible) and parse XLS files into single AUTOSAR
package.
Add new option --allow_xref to allow cross references between XLS files without extern declarations (sloppy linkage)
Modify symbolic constant and measurement address evaluation code to check for redefinitions of the same
symbolic name
--- Added comments ---  ungvaryg [Jan 13, 2012 3:20:14 PM CET]
Change Package : 93660:1 http://mks-psad:7002/im/viewissue?selection=93660
Revision 1.41 2011/12/06 13:16:19CET Ungvary, Gergely (ungvaryg)
Add new class-internal option sort_special_enums_by_name to allow special enumerations for meas addresses,
interface versions and symbolic constants to be ordered by enumerator name instead of enumeration value
on output to EcuExtract (simplifies interface version comparisson with text compare tools, though uppon
updating script the order will change completely)
--- Added comments ---  ungvaryg [Dec 6, 2011 1:16:22 PM CET]
Change Package : 88909:2 http://mks-psad:7002/im/viewissue?selection=88909
Revision 1.40 2011/11/04 11:34:28CET Ungvary Gergely (ungvaryg) (ungvaryg)
Add support for specifying manual min/max using @min/@max tags in description column
Add switchable (generate_symbolic_minmax) support for generating symbolic @min/@max names
--- Added comments ---  ungvaryg [Nov 4, 2011 11:34:34 AM CET]
Change Package : 86065:1 http://mks-psad:7002/im/viewissue?selection=86065
Revision 1.39 2011/09/23 14:07:00CEST Kawamoto Masato (uidd4784) (uidd4784)
Condition for setting maximum name length depending on project changed from "SMR" to "SRR".
--- Added comments ---  uidd4784 [Sep 23, 2011 2:07:00 PM CEST]
Change Package : 78635:1 http://mks-psad:7002/im/viewissue?selection=78635
Revision 1.38 2011/06/29 09:27:38CEST Ungvary Gergely (ungvaryg) (ungvaryg)
Modify script to allow generation of 1 element long arrays (i.e.: treat '1' in the array size column as a valid array
length)
IMPORTANT NOTE: This change requires that for non-array rows no number be entered in the array size column
(ARS301/SMR2xx XLS adapted by Joachim Tandler to meet this requirement)
--- Added comments ---  ungvaryg [Jun 29, 2011 9:27:39 AM CEST]
Change Package : 46867:2 http://mks-psad:7002/im/viewissue?selection=46867
Revision 1.37 2011/05/30 18:30:25CEST Ungvary Gergely (ungvaryg) (ungvaryg)
Modify script to only use description string for enum type and compu_method declarations when it does not
contain a @values declaration. If it contains an @values declaration, then do not use the description, but
only output the generated min/max/values declarations for the integer type/compu_method
--- Added comments ---  ungvaryg [May 30, 2011 6:30:25 PM CEST]
Change Package : 68887:1 http://mks-psad:7002/im/viewissue?selection=68887
Revision 1.36 2011/04/12 15:18:02CEST Ungvary Gergely (ungvaryg) (ungvaryg)
Disable enum declarations by undecorated names : this is the better setting as it allows enums with the same
field-level name, but different type names to be correctly interpreted. It however may break XML generation,
when names were not assigned correctly in the first place (i.e.: there are references to field enums through
the field name, and not the complete correct name specified in the reference column). The breakage is still
the lesser of two evils, as fields with the same name (e.g.: State) occur often, while not specifying correct
type references is a user error that leads to ambiguities in the XLS file.
--- Added comments ---  ungvaryg [Apr 12, 2011 3:18:02 PM CEST]
Change Package : 46867:2 http://mks-psad:7002/im/viewissue?selection=46867
Revision 1.35 2010/07/01 12:17:44CEST gungvary
Add checks for virtual object names and cycle-ids to verify that they are identifier-like (allow catching common
errors early on)
Re-use regular expressions (only compile them once)
--- Added comments ---  gungvary [2010/07/01 10:17:45Z]
Change Package : 43282:2 http://LISS014:6001/im/viewissue?selection=43282
Revision 1.34 2010/07/01 10:51:24CEST gungvary
Add support for enforced prefixes & suffixes for type names via new type_prefix & type_suffix strings. When
these are set to non-None, then they are prepended / appended to type names generated from the Name columns
--- Added comments ---  gungvary [2010/07/01 08:51:24Z]
Change Package : 43282:2 http://LISS014:6001/im/viewissue?selection=43282
Revision 1.33 2010/06/09 09:34:58CEST gungvary
Modify script to ignore cycle-id string if it consists of a single dash
--- Added comments ---  gungvary [2010/06/09 07:34:59Z]
Change Package : 39685:3 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.32 2010/05/31 11:57:09CEST gungvary
Decode the data in the Typ. Offset column of sheets for scaled/offseted values (such as polylane for ARS315)
Merged from 1.29.1.3
--- Added comments ---  gungvary [2010/05/31 09:57:10Z]
Change Package : 39685:3 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.31 2010/05/21 12:59:02CEST Joachim Tandler (jtandler)
Merge with 1.29.1.2
--- Added comments ---  jtandler [2010/05/21 10:59:02Z]
Change Package : 44217:1 http://LISS014:6001/im/viewissue?selection=44217
Revision 1.29.1.2 2010/05/12 13:04:42CEST gungvary
Enable version number generation for structs where Typ. Range column contains IDENT = value like line
Add generic decoding of 0x prefixed hexadecimal strings to decodeNumericString method
--- Added comments ---  gungvary [2010/05/12 11:04:43Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.29.1.1 2010/05/07 17:44:03CEST gungvary
Bugfix: when multiple virtual addresses are provided with some of them without address specification form
(ident = address form), then old code mistakenly re-appended entire list to vaddr tag
--- Added comments ---  gungvary [2010/05/07 15:44:04Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.29 2010/04/30 10:44:56CEST gungvary
Bugfix: virtual name/address checks were reporting wrong row number (due to 0 based indexing)
Improvement: ignore MTS object names/virtual addresses if string is simple dash (-)
--- Added comments ---  gungvary [2010/04/30 08:44:56Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.28 2010/04/26 11:20:50CEST gungvary
Add capability to generate symbolic constants as a dedicated enumeration: workaround to allow generation of
defines for values on 'Static variables' sheet
--- Added comments ---  gungvary [2010/04/26 09:20:51Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.27 2010/04/23 16:08:47CEST gungvary
Modify calculation of minimum/maximum values: convert the physical range in the sheets to raw values for
the ecuextract file
--- Added comments ---  gungvary [2010/04/23 14:08:47Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.26 2010/04/22 19:49:36CEST gungvary
Improvement: generate max/min/resolution for all excel sheet rows
New feature: if sheet contains column 'Array Name' or 'Array Type Name' then use the value in that
column as array type name for arrays
--- Added comments ---  gungvary [2010/04/22 17:49:36Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.25 2010/04/22 19:16:54CEST gungvary
Extend script to generat min/max/resolution for fields directly referencing autosar types as well
--- Added comments ---  gungvary [2010/04/22 17:16:55Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.24 2010/04/22 19:07:35CEST gungvary
Add resolution decoding and write to doxygen comments
--- Added comments ---  gungvary [2010/04/22 17:07:35Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.23 2010/04/22 16:57:24CEST gungvary
Add preliminary support for 'Meas' sheet for extracting measurement addresses
--- Added comments ---  gungvary [2010/04/22 14:57:24Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.22 2010/04/14 10:41:33CEST gungvary
Modify script to use correct UTF-8 output encoding
Add two new boolean options to control is structs/enums are always declared by their simple (undecorated)
names as well as the reference strings. Set the default to declare enums by their simple names, but do not
declare structs by their simple names (reason: fields of the same name in different structs, eg: legacy)
Modify reference string use: do not force _t postfix decoration, but take string as-is
--- Added comments ---  gungvary [2010/04/14 08:41:33Z]
Change Package : 39685:2 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.21 2010/04/02 22:41:37CEST gungvary
Bugfix: Fix issues with top-level enumeration names being multply declared
Improvement: add information messages about conflicting declarations
--- Added comments ---  gungvary [2010/04/02 20:41:38Z]
Change Package : 39685:1 http://LISS014:6001/im/viewissue?selection=39685
Revision 1.20 2010/03/08 17:17:15CET gungvary
Split decoding paths for enumerations/non-enumerations for range columns: handle them differently. For
enumerations always expect an enumerator. For non-enumerations try evaluating the expression, and if
that fails, then silently ignore the error.
--- Added comments ---  gungvary [2010/03/08 16:17:15Z]
Change Package : 33458:1 http://LISS014:6001/im/viewissue?selection=33458
Revision 1.19 2010/03/02 17:29:02CET gungvary
Bugfix: Fix row 2 being ignored on Generator sheet
Bugfix: Remove fix generation sheets & add safety check to verify that sheet exists prior to processing
Improvement: better warning messages for missing sheet links
--- Added comments ---  gungvary [2010/03/02 16:29:02Z]
Change Package : 33458:1 http://LISS014:6001/im/viewissue?selection=33458
Revision 1.18 2010/02/19 11:16:11CET dkubera
footer for version history added
--- Added comments ---  dkubera [2010/02/19 10:16:11Z]
Change Package : 33974:2 http://LISS014:6001/im/viewissue?selection=33974
"""