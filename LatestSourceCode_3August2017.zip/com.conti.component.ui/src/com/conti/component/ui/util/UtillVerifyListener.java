package com.conti.component.ui.util;

import java.math.BigDecimal;

import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.widgets.Text;

public class UtillVerifyListener implements VerifyListener {

	@Override
	public void verifyText(VerifyEvent e) {

		// Get the source widget
		Text source = (Text) e.getSource();

		// Get the text
		final String oldS = source.getText();
		final String newS = oldS.substring(0, e.start) + e.text + oldS.substring(e.end);

		try {
			BigDecimal bd = new BigDecimal(newS);
			// value is decimal
			// Test value range
		} catch (final NumberFormatException numberFormatException) {
			// value is not decimal
			e.doit = false;
		}
	}

}
