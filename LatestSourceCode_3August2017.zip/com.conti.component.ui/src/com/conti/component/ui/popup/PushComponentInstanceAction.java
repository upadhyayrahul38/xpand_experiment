package com.conti.component.ui.popup;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;

import com.telelogic.rhapsody.core.IRPApplication;
import com.telelogic.rhapsody.core.IRPClass;
import com.telelogic.rhapsody.core.IRPComponent;
import com.telelogic.rhapsody.core.IRPInstance;
import com.telelogic.rhapsody.core.IRPModelElement;
import com.telelogic.rhapsody.core.IRPModule;
import com.telelogic.rhapsody.core.IRPOperation;
import com.telelogic.rhapsody.core.IRPPackage;
import com.telelogic.rhapsody.core.IRPPort;
import com.telelogic.rhapsody.core.IRPProject;
import com.telelogic.rhapsody.core.IRPTag;
import com.telelogic.rhapsody.core.RhapsodyAppServer;

import architecturetool.Component;
import architecturetool.Port;
import architecturetool.Runnable;
import architecturetool.SubComponent;

public class PushComponentInstanceAction extends Action implements ISelectionListener {

	private Component componentInstance;
	private ISelection iSelection;

	public PushComponentInstanceAction(ISelection iSelection) {
		this.iSelection = iSelection;
	    this.selectionChanged(null, this.iSelection);
	}

	@Override
	public void run() {
		try {
			addRowInComponentTable(componentInstance);
			MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Push to Rhapsody",
					"Component is pushed to rhapsody successfully");
		} catch (Exception e) {
			MessageDialog.openError(Display.getDefault().getActiveShell(), "Push to Rhapsody",
					"Component is not pushed to rhapsody succussfully.Please check the log file.");
		}

	}


	public static void addRowInComponentTable(Component componentInstance) {
		IRPApplication rpy = RhapsodyAppServer.getActiveRhapsodyApplication();
		IRPProject prj = rpy.activeProject();
		IRPModelElement pkgRoot = prj.findNestedElementRecursive("CompReq", "Package");

		
		// step 1 adding package
		IRPPackage packageElement = (IRPPackage) pkgRoot.addNewAggr("Package", componentInstance.getName());
		// adding stereo type for the package
		packageElement.addStereotype("Component", "Package");
		IRPPackage innerPackageElement = (IRPPackage) packageElement
				.addNestedPackage(componentInstance.getName() + "Req");

		// step 2 adding component
		EList<SubComponent> subcomponents = componentInstance.getSubcomponent();
		for (SubComponent subComponent : subcomponents) {
			IRPComponent componentElement = (IRPComponent) innerPackageElement.addNewAggr("Component",
					subComponent.getName());
			// adding stereo type for the component
			componentElement.addStereotype("Sub-Component", "Component");
		}

		// step 3 adding class
		IRPClass classElement = (IRPClass) innerPackageElement.addClass(componentInstance.getName());

		// step 4 adding port
		EList<Port> ports = componentInstance.getPorts().getPort();
		for (Port port : ports) {
			IRPPort portElement = (IRPPort) classElement.addNewAggr("Port", port.getName());
			// adding stereo type for the port
			portElement.addStereotype("ADLPort", "Port");
			// adding tag to port
			IRPTag tag = (IRPTag) portElement.addNewAggr("Tag", "Type");
			String tagValue = ports.get(0).getPortDirection().toString().substring(0, 3).toUpperCase();
			portElement.setTagValue(tag, tagValue);
		}

		// step 5 adding file(module)
		IRPModule addModule = innerPackageElement.addModule(componentInstance.getName() + "_ext");
		IRPInstance instance = (IRPInstance) addModule;

		IRPClass interfaceElement = (IRPClass) innerPackageElement.addNewAggr("Interface",
				componentInstance.getName() + "_Interface");
		// step 6 adding operation
		EList<Runnable> itsRunnable = componentInstance.getRunnables().getRunnable();
		for (Runnable runnable : itsRunnable) {
			instance.getOtherClass().addOperation(runnable.getName());

			IRPOperation operationElement = interfaceElement.addOperation(runnable.getName());
			operationElement.addStereotype("Runnable", "Operation");
		}

		// adding tag to top component
		IRPTag locationTag = (IRPTag) packageElement.addNewAggr("Tag", "Location");
		IRPTag mccTag = (IRPTag) packageElement.addNewAggr("Tag", "MCC");
		IRPTag mccHeadTag = (IRPTag) packageElement.addNewAggr("Tag", "MccHead");
		IRPTag sectionTag = (IRPTag) packageElement.addNewAggr("Tag", "Section");
		packageElement.setTagValue(locationTag, "TestLoc");
		packageElement.setTagValue(mccTag, "TestMcc");
		packageElement.setTagValue(mccHeadTag, "TestMccHead");
		packageElement.setTagValue(sectionTag, "TestSection");
	}

	

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			componentInstance = (Component) iStructuredSelection.getFirstElement();
		}
	}

}
