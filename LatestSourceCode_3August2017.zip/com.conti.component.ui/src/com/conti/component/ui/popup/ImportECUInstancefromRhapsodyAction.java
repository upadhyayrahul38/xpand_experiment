package com.conti.component.ui.popup;

import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;

import com.conti.component.ui.dialogs.ImportECUdialog;
import com.telelogic.rhapsody.core.IRPCollection;
import com.telelogic.rhapsody.core.IRPModelElement;
import com.telelogic.rhapsody.core.IRPStereotype;
import com.telelogic.rhapsody.core.RPDependency;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.CPU;
import architecturetool.ECU;
import architecturetool.FunctionalRequirement;
import architecturetool.Memory;
import architecturetool.NoNameElement;
import architecturetool.Node;

public class ImportECUInstancefromRhapsodyAction extends Action implements ISelectionListener {

	private NoNameElement noNameElement;
	private ISelection selection;

	public ImportECUInstancefromRhapsodyAction(ISelection selection) {
		this.selection = selection;
		this.selectionChanged(null, this.selection);
	}

	@Override
	public void run() {
		try {
			getECU();
		} catch (Exception e) {
			MessageDialog.openError(Display.getDefault().getActiveShell(), "Import Project from Rhapsody",
					"Project is not imported succussfully.Please check the log file.");
		}

	}

	public void getECU() {
		ImportECUdialog ecuInterfaceDailog = new ImportECUdialog(Display.getDefault().getActiveShell());
		if (IDialogConstants.OK_ID == ecuInterfaceDailog.open()) {

			IRPModelElement selectedProject = ecuInterfaceDailog.getSelectedProject();

			IRPCollection collectionOfCompInstances = selectedProject.getNestedElementsByMetaClass("Node", 1);
			int noOfNodes = collectionOfCompInstances.getCount();
			for (int i = 1; i < noOfNodes + 1; i++) {
				IRPModelElement componentInstance = (IRPModelElement) collectionOfCompInstances.getItem(i);
				IRPCollection stereotypes = componentInstance.getStereotypes();
				if (stereotypes.getCount() > 0) {
					if (((IRPStereotype) stereotypes.getItem(1)).getName().equals("ECU")) {
						/*
						 * Getting the children of NoNameElement and then
						 * comparing each of them with selected project's name.
						 */
						Iterator<ECU> noNameIterator = noNameElement.getEcus().iterator();
						while (noNameIterator.hasNext()) {
							ECU ecu_Obj = (ECU) noNameIterator.next();
							if (selectedProject.getName().equalsIgnoreCase(ecu_Obj.getName())) {
								MessageDialog.openError(Display.getDefault().getActiveShell(), "Error Message",
										"Project Exist");
								return;
							}
						}

						ECU createECU = ArchitecturetoolFactory.eINSTANCE.createECU();
						createECU.setName(componentInstance.getName());
						EList<ECU> ecus = noNameElement.getEcus();
						ecus.add(createECU);

						IRPCollection dependencies = componentInstance.getDependencies();
						if (dependencies.getCount() > 0) {
							for (int j = 1; j < dependencies.getCount() + 1; j++) {
								RPDependency item = (RPDependency) dependencies.getItem(j);
								// System.out.println(item.getName());
								IRPModelElement dependent = item.getDependsOn();
								IRPCollection childStereoType = dependent.getStereotypes();
								if (childStereoType.getCount() > 0) {
									if (((IRPStereotype) childStereoType.getItem(1)).getName().equals("Memory")) {
										Memory ecuMemory = getECUMemory(createECU, dependent);
										if (ecuMemory == null) {
											Memory creatememory = ArchitecturetoolFactory.eINSTANCE.createMemory();
											creatememory.setName(dependent.getName());
											createECU.getMemory().add(creatememory);
										}
									} else if (((IRPStereotype) childStereoType.getItem(1)).getName().equals("CPU")) {
										CPU createCPU = ArchitecturetoolFactory.eINSTANCE.createCPU();
										createCPU.setName(dependent.getName());
										createECU.getCpus().add(createCPU);

										IRPCollection cpuDepenencies = dependent.getDependencies();
										if (cpuDepenencies.getCount() > 0) {
											for (int k = 1; k < cpuDepenencies.getCount() + 1; k++) {
												RPDependency cpuItem = (RPDependency) cpuDepenencies.getItem(k);
												// System.out.println(item.getName());
												IRPModelElement cpudependent = cpuItem.getDependsOn();
												IRPCollection cpuStereoType = cpudependent.getStereotypes();
												if (cpuStereoType.getCount() > 0) {
													if (((IRPStereotype) cpuStereoType.getItem(1)).getName()
															.equals("Memory")) {
														Memory ecuMemory = getECUMemory(createECU, cpudependent);
														if (ecuMemory != null) {
															createCPU.getMemory().add(ecuMemory);
														} else {
															Memory creatememory = ArchitecturetoolFactory.eINSTANCE
																	.createMemory();
															creatememory.setName(cpudependent.getName());
															createECU.getMemory().add(creatememory);
															createCPU.getMemory()
																	.add(getECUMemory(createECU, cpudependent));
														}

													} else if (((IRPStereotype) cpuStereoType.getItem(1)).getName()
															.equals("ExecutionUnit")) {
														Node createNode = ArchitecturetoolFactory.eINSTANCE
																.createNode();
														createNode.setName(cpudependent.getName());
														createCPU.getNodes().add(createNode);
														IRPCollection nodeDepenencies = cpudependent.getDependencies();
														if (nodeDepenencies.getCount() > 0) {
															for (int k1 = 1; k1 < nodeDepenencies.getCount()
																	+ 1; k1++) {
																RPDependency nodeItem = (RPDependency) nodeDepenencies
																		.getItem(k1);
																// System.out.println(item.getName());
																IRPModelElement nodedependent = nodeItem.getDependsOn();
																IRPCollection nodeStereoType = nodedependent
																		.getStereotypes();
																if (nodeStereoType.getCount() > 0) {
																	if (((IRPStereotype) nodeStereoType.getItem(1))
																			.getName().equals("Memory")) {
																		Memory ecuMemory = getECUMemory(createECU,
																				nodedependent);
																		if (ecuMemory != null) {
																			createNode.getMemory().add(ecuMemory);
																		} else {
																			Memory creatememory = ArchitecturetoolFactory.eINSTANCE
																					.createMemory();
																			creatememory
																					.setName(nodedependent.getName());
																			createECU.getMemory().add(creatememory);
																			createNode.getMemory().add(getECUMemory(
																					createECU, nodedependent));
																		}

																	}
																}
															}
														}
													}

												}

											}
										}
									}
								} else if (((IRPStereotype) childStereoType.getItem(1)).getName().equals("Function")) {
									FunctionalRequirement createFunctionalRequirement = ArchitecturetoolFactory.eINSTANCE
											.createFunctionalRequirement();
									createFunctionalRequirement.setName(dependent.getName());
									createECU.getFunctionalrequirements().add(createFunctionalRequirement);
								}
							}
						}
						MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Import Project from Rhapsody",
								"Project is imported succussfully");
					} 


				}
			}
		}
	}

	public Memory getECUMemory(ECU createECU, IRPModelElement nodedependent) {
		EList<Memory> memories = createECU.getMemory();
		for (Memory memory : memories) {
			if (memory.getName().equalsIgnoreCase(nodedependent.getName())) {
				return memory;
			}
		}
		return null;
	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection sSelection = (IStructuredSelection) selection;
			noNameElement = (NoNameElement) sSelection.getFirstElement();
		}
	}

}
