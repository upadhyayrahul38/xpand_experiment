package com.conti.component.ui.popup;

import com.telelogic.rhapsody.core.IRPApplication;
import com.telelogic.rhapsody.core.RPObjectModelDiagram;
import com.telelogic.rhapsody.core.RhapsodyAppServer;

public class RhapsodyObjectModelDiagramTest {

	public static void main(String[] args) {
		IRPApplication app = RhapsodyAppServer.getActiveRhapsodyApplication();
		RPObjectModelDiagram el = (RPObjectModelDiagram)app.getSelectedElement();


	}

}
