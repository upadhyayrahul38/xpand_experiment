package com.conti.component.ui.popup;

import java.util.Map;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.xpand2.XpandExecutionContextImpl;
import org.eclipse.xpand2.XpandFacade;
import org.eclipse.xpand2.output.Outlet;
import org.eclipse.xpand2.output.OutputImpl;
import org.eclipse.xtend.typesystem.emf.EmfMetaModel;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.NoNameElement;
import architecturetool.impl.ComponentImpl;

public class GenerateSimconFile extends Action implements ISelectionListener {

	private Component componentInstance;
	private static EList<EObject> inObjects;
	private static EPackage pSM_Pkg;
	private boolean isGenerated = false;
	private String outputPath = null;
	private NoNameElement noNameElement;

	public GenerateSimconFile() {

	}

	public GenerateSimconFile(NoNameElement _noNameElement, String outputPath,Component componentInstance) {
		this.noNameElement = _noNameElement;
		this.outputPath = outputPath;
		this.componentInstance = componentInstance;
	}

	@Override
	public void run() {
		runMWEFile(componentInstance, this);

	}

	

	public void runMWEFile(EObject eobject, IAction action) {

		ArchitecturetoolPackage architectureToolPackage = ArchitecturetoolPackage.eINSTANCE;

		try {
			if (action != null && outputPath == null) {
				FileDialog filePath = new FileDialog(Display.getDefault().getActiveShell(), SWT.SAVE);
				filePath.setFileName("Simcon");
				String path = filePath.open();
				if (path != null) {
					URI outURI = URI.createURI("file:///" + path);
					OutputImpl out = new OutputImpl();
					Outlet outlet = new Outlet(outURI.toFileString());
					out.addOutlet(outlet);
					XpandExecutionContextImpl executionContext = new XpandExecutionContextImpl(out, null);

					// Configure the metamodels

					EmfMetaModel emfMetaModel = new EmfMetaModel();
					emfMetaModel.setMetaModelPackage(architectureToolPackage.getClass().getName());
					executionContext.registerMetaModel(emfMetaModel);
					XpandFacade xpandFacade = XpandFacade.create(executionContext);
					Object[] params = null;
					if (eobject != null) {
						xpandFacade.evaluate("template::SimCon::main", eobject.eContainer().eContainer(), params);
						MessageDialog.openInformation(Display.getDefault().getActiveShell(), "SIL Artifacts",
								"Files are generated succussfully in this path :" + path);
					}
				}
			} else if (action == null && outputPath != null) {
				URI outURI = URI.createURI("file:///" + outputPath);
				OutputImpl out = new OutputImpl();
				Outlet outlet = new Outlet(outURI.toFileString());
				out.addOutlet(outlet);
				XpandExecutionContextImpl executionContext = new XpandExecutionContextImpl(out, null);

				// Configure the metamodels

				EmfMetaModel emfMetaModel = new EmfMetaModel();
				emfMetaModel.setMetaModelPackage(architectureToolPackage.getClass().getName());
				executionContext.registerMetaModel(emfMetaModel);
				XpandFacade xpandFacade = XpandFacade.create(executionContext);
				Object[] params = null;
				if (noNameElement != null) {
					xpandFacade.evaluate("template::SimCon::main", noNameElement, params);
					isGenerated = true;
				}
			}
		} catch (Exception e) {
			isGenerated = false;
			if (action != null)
				MessageDialog.openError(Display.getDefault().getActiveShell(), "SIL Artifacts",
						"Files are not generated succussfully.Please check the log file.");
		}
	}

	public boolean isGenerated() {
		return isGenerated;
	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		// TODO Auto-generated method stub
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			if (iStructuredSelection != null && iStructuredSelection.getFirstElement() instanceof ComponentImpl) {
				componentInstance = (Component) iStructuredSelection.getFirstElement();
			}
		}

	}
}
