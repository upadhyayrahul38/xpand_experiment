package com.conti.component.ui.popup;

import java.io.IOException;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuCreator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.HelpListener;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;

import architecturetool.AbsoluteRefrence;
import architecturetool.Attribute;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.Generator;
import architecturetool.Literal;
import autosar40.autosartoplevelstructure.AUTOSAR;
import autosar40.commonstructure.basetypes.SwBaseType;
import autosar40.commonstructure.datadefproperties.SwDataDefProps;
import autosar40.commonstructure.datadefproperties.SwDataDefPropsConditional;
import autosar40.commonstructure.implementationdatatypes.ArraySizeSemanticsEnum;
import autosar40.commonstructure.implementationdatatypes.ImplementationDataType;
import autosar40.commonstructure.implementationdatatypes.ImplementationDataTypeElement;
import autosar40.genericstructure.generaltemplateclasses.arpackage.ARPackage;
import autosar40.genericstructure.generaltemplateclasses.arpackage.ArpackageFactory;
import autosar40.genericstructure.generaltemplateclasses.documentation.textmodel.languagedatamodel.LEnum;
import autosar40.genericstructure.generaltemplateclasses.documentation.textmodel.languagedatamodel.LOverviewParagraph;
import autosar40.genericstructure.generaltemplateclasses.documentation.textmodel.multilanguagedata.MultiLanguageOverviewParagraph;
import autosar40.genericstructure.varianthandling.attributevaluevariationpoints.LimitValueVariationPoint;
import autosar40.genericstructure.varianthandling.attributevaluevariationpoints.PositiveIntegerValueVariationPoint;
import autosar40.swcomponent.datatype.computationmethod.Compu;
import autosar40.swcomponent.datatype.computationmethod.CompuConst;
import autosar40.swcomponent.datatype.computationmethod.CompuConstTextContent;
import autosar40.swcomponent.datatype.computationmethod.CompuMethod;
import autosar40.swcomponent.datatype.computationmethod.CompuScale;
import autosar40.swcomponent.datatype.computationmethod.CompuScaleConstantContents;
import autosar40.swcomponent.datatype.computationmethod.CompuScales;
import autosar40.util.Autosar40Factory;
import autosar40.util.Autosar40Package;
import autosar40.util.Autosar40ResourceFactoryImpl;

public class GenerateARXMLAction extends Action implements ISelectionListener {

	private Component component;
	private String outputPath=null;
	boolean arxmlGenerated = false;
	
	public GenerateARXMLAction() {
		
	}

	public GenerateARXMLAction(Component _component, String _outputPath) {
		this.outputPath = _outputPath;
		this.component = _component;
	}

	@Override
	public void run() {
		/* 
		 * Creating AutoSar structure and arpackage as a child of it.
		 */
		
		AUTOSAR autosar = Autosar40Factory.eINSTANCE.createAUTOSAR();
		ARPackage arPackage = ArpackageFactory.eINSTANCE.createARPackage();
		arPackage.setShortName(component.getName());
		autosar.getArPackages().add(arPackage);

		EList<Generator> generators = component.getGenerator();
		for (Generator generator : generators) {
			ARPackage generatorARPackage = ArpackageFactory.eINSTANCE.createARPackage();
			generatorARPackage.setShortName(generator.getName());

			int packageAttribSize = 0;
			int enumSize = 0;
			if (generator.getAttribute() != null) {
				packageAttribSize = generator.getAttribute().size();
			}
			if (packageAttribSize > 0) {
				fillPackageAttributes(generator, generatorARPackage);
			}
			if (generator.getEnum() != null) {
				enumSize = generator.getEnum().size();
			}
			if (enumSize > 0) {
				fillEnum(generator, generatorARPackage);
			}
			EList<DataStructure> dataStructs = generator.getDatastructure();

			for (DataStructure struct : dataStructs) {
				
				ImplementationDataType implementationDataType = Autosar40Factory.eINSTANCE
						.createImplementationDataType();
				implementationDataType.setShortName(struct.getName());
				implementationDataType.setCategory("Structure");
				generatorARPackage.getElements().add(implementationDataType);

				if (!struct.getDescription().trim().isEmpty()) {
					MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraph = Autosar40Factory.eINSTANCE
							.createMultiLanguageOverviewParagraph();
					LOverviewParagraph lop = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
					lop.setL(LEnum.EN);
					lop.setMixedText(struct.getDescription());
					createMultiLanguageOverviewParagraph.getL2s().add(lop);
					implementationDataType.setDesc(createMultiLanguageOverviewParagraph);
				}
				int abRefSize = 0;
				int attribSize = 0;

				if (struct.getAbsolutereference() != null) {
					abRefSize = struct.getAbsolutereference().size();
				}
				if (struct.getAttributes() != null) {
					attribSize = struct.getAttributes().size();
				}

				if (attribSize > 0) {
					fillAttributes(struct, generatorARPackage, implementationDataType);
				}
				if (abRefSize > 0) {
					fillAbsoluteRef(struct, generatorARPackage, implementationDataType);
				}

			}
			arPackage.getArPackages().add(generatorARPackage);
		}
		genArxml(autosar,this);
	}
	//@Override
//	public void run(IAction action) {
//		/* 
//		 * Creating AutoSar structure and arpackage as a child of it.
//		 */
//		
//		AUTOSAR autosar = Autosar40Factory.eINSTANCE.createAUTOSAR();
//		ARPackage arPackage = ArpackageFactory.eINSTANCE.createARPackage();
//		arPackage.setShortName(component.getName());
//		autosar.getArPackages().add(arPackage);
//
//		EList<Generator> generators = component.getGenerator();
//		for (Generator generator : generators) {
//			ARPackage generatorARPackage = ArpackageFactory.eINSTANCE.createARPackage();
//			generatorARPackage.setShortName(generator.getName());
//
//			int packageAttribSize = 0;
//			int enumSize = 0;
//			if (generator.getAttribute() != null) {
//				packageAttribSize = generator.getAttribute().size();
//			}
//			if (packageAttribSize > 0) {
//				fillPackageAttributes(generator, generatorARPackage);
//			}
//			if (generator.getEnum() != null) {
//				enumSize = generator.getEnum().size();
//			}
//			if (enumSize > 0) {
//				fillEnum(generator, generatorARPackage);
//			}
//			EList<DataStructure> dataStructs = generator.getDatastructure();
//
//			for (DataStructure struct : dataStructs) {
//
//				ImplementationDataType implementationDataType = Autosar40Factory.eINSTANCE
//						.createImplementationDataType();
//				implementationDataType.setShortName(struct.getName());
//				implementationDataType.setCategory("Structure");
//				generatorARPackage.getElements().add(implementationDataType);
//
//				if (!struct.getDescription().trim().isEmpty()) {
//					MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraph = Autosar40Factory.eINSTANCE
//							.createMultiLanguageOverviewParagraph();
//					LOverviewParagraph lop = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
//					lop.setL(LEnum.EN);
//					lop.setMixedText(struct.getDescription());
//					createMultiLanguageOverviewParagraph.getL2s().add(lop);
//					implementationDataType.setDesc(createMultiLanguageOverviewParagraph);
//				}
//				int abRefSize = 0;
//				int attribSize = 0;
//
//				if (struct.getAbsolutereference() != null) {
//					abRefSize = struct.getAbsolutereference().size();
//				}
//				if (struct.getAttributes() != null) {
//					attribSize = struct.getAttributes().size();
//				}
//
//				if (attribSize > 0) {
//					fillAttributes(struct, generatorARPackage, implementationDataType);
//				}
//				if (abRefSize > 0) {
//					fillAbsoluteRef(struct, generatorARPackage, implementationDataType);
//				}
//
//			}
//			arPackage.getArPackages().add(generatorARPackage);
//		}
//		genArxml(autosar,action);
//
//	}

	private void fillPackageAttributes(Generator generator, ARPackage generatorARPackage) {
		// TODO Auto-generated method stub
		EList<Attribute> attributes = generator.getAttribute();
		for (Attribute attribute : attributes) {
			ImplementationDataType implementationDataType = Autosar40Factory.eINSTANCE.createImplementationDataType();
			implementationDataType.setShortName(attribute.getName());
			implementationDataType.setCategory("VALUE");
			generatorARPackage.getElements().add(implementationDataType);

			MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraph = Autosar40Factory.eINSTANCE
					.createMultiLanguageOverviewParagraph();
			LOverviewParagraph lop = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
			lop.setL(LEnum.EN);
			lop.setMixedText(attribute.getDescription());
			createMultiLanguageOverviewParagraph.getL2s().add(lop);
			implementationDataType.setDesc(createMultiLanguageOverviewParagraph);

			SwDataDefProps createSwDataDefProps = Autosar40Factory.eINSTANCE.createSwDataDefProps();
			SwDataDefPropsConditional createSwDataDefPropsConditional = Autosar40Factory.eINSTANCE
					.createSwDataDefPropsConditional();
			SwBaseType createSwBaseType = Autosar40Factory.eINSTANCE.createSwBaseType();
			createSwBaseType.setShortName("/AUTOSAR/BaseTypes/" + attribute.getDataType().getLiteral());
			createSwDataDefPropsConditional.setBaseType(createSwBaseType);

			if (attribute.getEnum() != null) {
				CompuMethod compuMethod = Autosar40Factory.eINSTANCE.createCompuMethod();
				compuMethod.setShortName(
						"/" +component.getName() + "/" + generator.getName() + "/" + attribute.getEnum().getName());
				createSwDataDefPropsConditional.setCompuMethod(compuMethod);
			}

			createSwDataDefProps.getSwDataDefPropsVariants().add(createSwDataDefPropsConditional);
			implementationDataType.setSwDataDefProps(createSwDataDefProps);
			generatorARPackage.getElements().add(implementationDataType);
		}
	}

	private void fillEnum(Generator generator, ARPackage generatorARPackage) {
		// TODO Auto-generated method stub
		EList<architecturetool.Enum> enumList = generator.getEnum();
		for (architecturetool.Enum enumElemnt : enumList) {
			CompuMethod compuMethodElement = Autosar40Factory.eINSTANCE.createCompuMethod();
			compuMethodElement.setShortName(enumElemnt.getName());
			compuMethodElement.setCategory("TEXTABLE");
			MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraph = Autosar40Factory.eINSTANCE
					.createMultiLanguageOverviewParagraph();
			LOverviewParagraph lop = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
			lop.setL(LEnum.EN);
			lop.setMixedText(enumElemnt.getDescription());
			createMultiLanguageOverviewParagraph.getL2s().add(lop);
			compuMethodElement.setDesc(createMultiLanguageOverviewParagraph);

			Compu compuElement = Autosar40Factory.eINSTANCE.createCompu();
			compuMethodElement.setCompuInternalToPhys(compuElement);
			CompuScales createCompuScales = Autosar40Factory.eINSTANCE.createCompuScales();
			compuElement.setCompuContent(createCompuScales);

			EList<Literal> literals = enumElemnt.getLiteral();
			for (Literal literal : literals) {

				CompuScale compuScaleElement = Autosar40Factory.eINSTANCE.createCompuScale();
				createCompuScales.getCompuScales().add(compuScaleElement);

				CompuScaleConstantContents createCompuScaleConstantContents = Autosar40Factory.eINSTANCE
						.createCompuScaleConstantContents();
				compuScaleElement.setCompuScaleContents(createCompuScaleConstantContents);

				CompuConst createCompuConst = Autosar40Factory.eINSTANCE.createCompuConst();
				createCompuScaleConstantContents.setCompuConst(createCompuConst);

				CompuConstTextContent createCompuConstTextContent = Autosar40Factory.eINSTANCE
						.createCompuConstTextContent();
				createCompuConst.setCompuConstContentType(createCompuConstTextContent);
				createCompuConstTextContent.setVt(literal.getName());

				LimitValueVariationPoint createLimitValueVariationPoint = Autosar40Factory.eINSTANCE
						.createLimitValueVariationPoint();
				compuScaleElement.setLowerLimit(createLimitValueVariationPoint);
				createLimitValueVariationPoint.setSd(Integer.toString(literal.getValue()));

				LimitValueVariationPoint createUpperLimitValueVariationPoint = Autosar40Factory.eINSTANCE
						.createLimitValueVariationPoint();
				compuScaleElement.setUpperLimit(createUpperLimitValueVariationPoint);
				createUpperLimitValueVariationPoint.setSd(Integer.toString(literal.getValue()));
			}

			generatorARPackage.getElements().add(compuMethodElement);

		}

	}

	public void fillAttributes(DataStructure dataStructure, ARPackage generatorARPackage,
			ImplementationDataType implementationDataType) {
		EList<Attribute> attributes = dataStructure.getAttributes();
		for (Attribute attribute : attributes) {

			ImplementationDataTypeElement implementationDataTypeElement = Autosar40Factory.eINSTANCE
					.createImplementationDataTypeElement();
			implementationDataTypeElement.setShortName(attribute.getName());
			implementationDataTypeElement.setCategory("VALUE");
			MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraph = Autosar40Factory.eINSTANCE
					.createMultiLanguageOverviewParagraph();
			LOverviewParagraph lop = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
			lop.setL(LEnum.EN);
			lop.setMixedText(attribute.getDescription());
			createMultiLanguageOverviewParagraph.getL2s().add(lop);
			implementationDataTypeElement.setDesc(createMultiLanguageOverviewParagraph);

			SwDataDefProps createSwDataDefProps = Autosar40Factory.eINSTANCE.createSwDataDefProps();
			implementationDataTypeElement.setSwDataDefProps(createSwDataDefProps);
			SwDataDefPropsConditional createSwDataDefPropsConditional = Autosar40Factory.eINSTANCE
					.createSwDataDefPropsConditional();
			SwBaseType createSwBaseType = Autosar40Factory.eINSTANCE.createSwBaseType();
			createSwBaseType.setShortName("/AUTOSAR/BaseTypes/" + attribute.getDataType().getLiteral());
			createSwDataDefPropsConditional.setBaseType(createSwBaseType);

			createSwDataDefProps.getSwDataDefPropsVariants().add(createSwDataDefPropsConditional);

			implementationDataType.getSubElements().add(implementationDataTypeElement);
			generatorARPackage.getElements().add(implementationDataType);
            /////////////
			if (attribute.getArraySize() > 0) {
				ImplementationDataType arrayImplementationDataType = Autosar40Factory.eINSTANCE
						.createImplementationDataType();
				arrayImplementationDataType.setShortName(attribute.getName() + "_array_t");
				arrayImplementationDataType.setCategory("ARRAY");
				generatorARPackage.getElements().add(arrayImplementationDataType);

				ImplementationDataTypeElement implementationDataTypeElementArray = Autosar40Factory.eINSTANCE
						.createImplementationDataTypeElement();
				implementationDataTypeElementArray.setShortName(attribute.getName() + "_array_t_element");
				implementationDataTypeElementArray.setCategory("VALUE");
				PositiveIntegerValueVariationPoint createPositiveIntegerValueVariationPoint = Autosar40Factory.eINSTANCE
						.createPositiveIntegerValueVariationPoint();
				createPositiveIntegerValueVariationPoint.setMixedText(Integer.toString(attribute.getArraySize()));
				implementationDataTypeElementArray.setArraySize(createPositiveIntegerValueVariationPoint);
				implementationDataTypeElementArray.setArraySizeSemantics(ArraySizeSemanticsEnum.FIXED_SIZE);

				MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraphArray = Autosar40Factory.eINSTANCE
						.createMultiLanguageOverviewParagraph();
				LOverviewParagraph lopArray = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
				lopArray.setL(LEnum.EN);
				lopArray.setMixedText(attribute.getDescription());
				createMultiLanguageOverviewParagraphArray.getL2s().add(lopArray);
				arrayImplementationDataType.setDesc(createMultiLanguageOverviewParagraphArray);

				SwDataDefProps createSwDataDefPropsArray = Autosar40Factory.eINSTANCE.createSwDataDefProps();
				implementationDataTypeElementArray.setSwDataDefProps(createSwDataDefPropsArray);
				SwDataDefPropsConditional createSwDataDefPropsConditionalArray = Autosar40Factory.eINSTANCE
						.createSwDataDefPropsConditional();

				SwBaseType createSwBaseTypeArray = Autosar40Factory.eINSTANCE.createSwBaseType();
				createSwBaseTypeArray.setShortName("/AUTOSAR/BaseTypes/" + attribute.getDataType().getLiteral());
				createSwDataDefPropsConditionalArray.setBaseType(createSwBaseTypeArray);

				createSwDataDefPropsArray.getSwDataDefPropsVariants().add(createSwDataDefPropsConditionalArray);

				arrayImplementationDataType.getSubElements().add(implementationDataTypeElementArray);
				generatorARPackage.getElements().add(arrayImplementationDataType);
			}
		}
	}

	public void fillAbsoluteRef(DataStructure dataStructure, ARPackage generatorARPackage,
			ImplementationDataType implementationDataType) {
		EList<AbsoluteRefrence> absoluterefrences = dataStructure.getAbsolutereference();
		for (AbsoluteRefrence absoluteRefrence : absoluterefrences) {

			ImplementationDataTypeElement implementationDataTypeElement = Autosar40Factory.eINSTANCE
					.createImplementationDataTypeElement();
			implementationDataTypeElement.setShortName(absoluteRefrence.getName());
			implementationDataTypeElement.setCategory("TYPE REFERENCE");
			MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraph = Autosar40Factory.eINSTANCE
					.createMultiLanguageOverviewParagraph();
			LOverviewParagraph lop = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
			lop.setL(LEnum.EN);
			lop.setMixedText(absoluteRefrence.getDescription());
			createMultiLanguageOverviewParagraph.getL2s().add(lop);
			implementationDataTypeElement.setDesc(createMultiLanguageOverviewParagraph);

			SwDataDefProps createSwDataDefProps = Autosar40Factory.eINSTANCE.createSwDataDefProps();
			SwDataDefPropsConditional createSwDataDefPropsConditional = Autosar40Factory.eINSTANCE
					.createSwDataDefPropsConditional();

			if (absoluteRefrence.getDatastructure() != null) {
				DataStructure dataStruct = absoluteRefrence.getDatastructure();
				Component component = (Component) dataStructure.eContainer().eContainer();

				ImplementationDataType implDataTypeRef = Autosar40Factory.eINSTANCE.createImplementationDataType();
				String parentname = "";
				if (dataStruct.eContainer() instanceof Generator) {
					parentname = ((Generator) dataStruct.eContainer()).getName();
				}
				if (!parentname.isEmpty()) {
					implDataTypeRef
							.setShortName("/" + component.getName() + "/" + parentname + "/" + dataStruct.getName());
				}
				createSwDataDefPropsConditional.setImplementationDataType(implDataTypeRef);
			}
            //Added for Attribute Check
			if (absoluteRefrence.getAttribute() != null) {
				Attribute attribute = absoluteRefrence.getAttribute();
				String parentname = "";
				Component component = null;
				if (attribute.eContainer() instanceof DataStructure) {
					component = (Component) attribute.eContainer().eContainer().eContainer();
				}
				if (attribute.eContainer() instanceof Generator) {
					component = (Component) attribute.eContainer().eContainer();
					parentname = ((Generator) attribute.eContainer()).getName();
				}

				ImplementationDataType implDataTypeRef = Autosar40Factory.eINSTANCE.createImplementationDataType();

				if (!parentname.isEmpty() && component != null) {
					implDataTypeRef
							.setShortName("/" + component.getName() + "/" + parentname + "/" + attribute.getName());
				}
				createSwDataDefPropsConditional.setImplementationDataType(implDataTypeRef);
			}

			createSwDataDefProps.getSwDataDefPropsVariants().add(createSwDataDefPropsConditional);
			implementationDataTypeElement.setSwDataDefProps(createSwDataDefProps);

			implementationDataType.getSubElements().add(implementationDataTypeElement);
			generatorARPackage.getElements().add(implementationDataType);
			
			if (absoluteRefrence.getArraySize() > 0) {
				ImplementationDataType arrayImplementationDataType = Autosar40Factory.eINSTANCE
						.createImplementationDataType();
				arrayImplementationDataType.setShortName(absoluteRefrence.getName() + "_array_t");
				arrayImplementationDataType.setCategory("ARRAY");
				generatorARPackage.getElements().add(arrayImplementationDataType);

				ImplementationDataTypeElement implementationDataTypeElementArray = Autosar40Factory.eINSTANCE
						.createImplementationDataTypeElement();
				implementationDataTypeElementArray.setShortName(absoluteRefrence.getName() + "_array_t_element");
				implementationDataTypeElementArray.setCategory("VALUE");
				PositiveIntegerValueVariationPoint createPositiveIntegerValueVariationPoint = Autosar40Factory.eINSTANCE
						.createPositiveIntegerValueVariationPoint();
				createPositiveIntegerValueVariationPoint
						.setMixedText(Integer.toString(absoluteRefrence.getArraySize()));
				implementationDataTypeElementArray.setArraySize(createPositiveIntegerValueVariationPoint);
				implementationDataTypeElementArray.setArraySizeSemantics(ArraySizeSemanticsEnum.FIXED_SIZE);

				MultiLanguageOverviewParagraph createMultiLanguageOverviewParagraphArray = Autosar40Factory.eINSTANCE
						.createMultiLanguageOverviewParagraph();
				LOverviewParagraph lopArray = Autosar40Factory.eINSTANCE.createLOverviewParagraph();
				lopArray.setL(LEnum.EN);
				lopArray.setMixedText(absoluteRefrence.getDescription());
				createMultiLanguageOverviewParagraphArray.getL2s().add(lopArray);
				arrayImplementationDataType.setDesc(createMultiLanguageOverviewParagraphArray);

				SwDataDefProps createSwDataDefPropsArray = Autosar40Factory.eINSTANCE.createSwDataDefProps();
				implementationDataTypeElementArray.setSwDataDefProps(createSwDataDefPropsArray);
				SwDataDefPropsConditional createSwDataDefPropsConditionalArray = Autosar40Factory.eINSTANCE
						.createSwDataDefPropsConditional();
				
				if (absoluteRefrence.getDatastructure() != null) {
					DataStructure dataStruct = absoluteRefrence.getDatastructure();
					Component component = (Component) dataStructure.eContainer().eContainer();

					ImplementationDataType implDataTypeRef = Autosar40Factory.eINSTANCE.createImplementationDataType();
					String parentname = "";
					if (dataStruct.eContainer() instanceof Generator) {
						parentname = ((Generator) dataStruct.eContainer()).getName();
					}
					if (!parentname.isEmpty()) {
						implDataTypeRef.setShortName(
								"/" + component.getName() + "/" + parentname + "/" + dataStruct.getName());
					}
					createSwDataDefPropsConditionalArray.setImplementationDataType(implDataTypeRef);
				}
                //Added for Attribute Check
				if (absoluteRefrence.getAttribute() != null) {
					Attribute attribute = absoluteRefrence.getAttribute();
					String parentname = "";
					Component component = null;
					if (attribute.eContainer() instanceof DataStructure) {
						component = (Component) attribute.eContainer().eContainer().eContainer();
					}
					if (attribute.eContainer() instanceof Generator) {
						component = (Component) attribute.eContainer().eContainer();
						parentname = ((Generator) attribute.eContainer()).getName();
					}

					ImplementationDataType implDataTypeRef = Autosar40Factory.eINSTANCE.createImplementationDataType();

					if (!parentname.isEmpty() && component != null) {
						implDataTypeRef
								.setShortName("/" + component.getName() + "/" + parentname + "/" + attribute.getName());
					}
					createSwDataDefPropsConditionalArray.setImplementationDataType(implDataTypeRef);
				}

				createSwDataDefPropsArray.getSwDataDefPropsVariants().add(createSwDataDefPropsConditionalArray);

				arrayImplementationDataType.getSubElements().add(implementationDataTypeElementArray);
				generatorARPackage.getElements().add(arrayImplementationDataType);

			}
		}
	}

	/*
	 * Generates Arxml at the specified location.
	 */
	public void genArxml(AUTOSAR autosar, IAction action) {
		ResourceSetImpl rset = new ResourceSetImpl();
		rset.getPackageRegistry().put(Autosar40Package.eNS_URI, Autosar40Package.eINSTANCE);
		rset.getResourceFactoryRegistry().getExtensionToFactoryMap().put("arxml", new Autosar40ResourceFactoryImpl());
		if (action != null && outputPath == null) {
			FileDialog filePath = new FileDialog(Display.getDefault().getActiveShell(), SWT.SAVE);
			filePath.setFileName(component.getName() + ".arxml");
			String path = filePath.open();
			try {
				if (path != null) {
					Resource resource = rset.createResource(URI.createFileURI(path));
					resource.getContents().add(autosar);
					resource.save(null);
					if (action != null)
						MessageDialog.openInformation(Display.getDefault().getActiveShell(), "ARXML Generation",
								"Files are generated succussfully in this path :" + path);
				}
			} catch (IOException e) {
				e.printStackTrace();
				if (action != null)
					MessageDialog.openError(Display.getDefault().getActiveShell(), "ARXML Generation",
							"Files are not generated succussfully.Please check the log file.");
			}
		}
		if (action == null && outputPath != null) {
			String finalPath = outputPath + "\\" + component.getName() + ".arxml";
			Resource resource = rset.createResource(URI.createFileURI(finalPath));
			resource.getContents().add(autosar);
			try {
				resource.save(null);
				arxmlGenerated = true;
			} catch (IOException e) {
				arxmlGenerated = false;
				e.printStackTrace();
			}
		}
	}

	public boolean isArxmlGenerated() {
		return arxmlGenerated;
	}

	/*
	 * Setting selection at component level. (non-Javadoc)
	 * 
	 * @see
	 * org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.
	 * IAction, org.eclipse.jface.viewers.ISelection)
	 */
//	@Override
//	public void selectionChanged(IAction action, ISelection selection) {
//		if (selection instanceof IStructuredSelection) {
//			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
//			component = (Component) iStructuredSelection.getFirstElement();
//
//		}
//	}

//	@Override
//	public void selectionChanged(SelectionChangedEvent event) {
//		if (event.getSelection() instanceof IStructuredSelection) {
//			IStructuredSelection iStructuredSelection = (IStructuredSelection) event.getSelection();
//			component = (Component) iStructuredSelection.getFirstElement();
//
//		}
//		
//	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
		IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
		component = (Component) iStructuredSelection.getFirstElement();

	}
		
	}

	

}
