package com.conti.component.ui.popup;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EModelElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature.Setting;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.EcoreUtil.UsageCrossReferencer;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.URIHandlerImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Port;
import architecturetool.Runnable;
import architecturetool.Runnables;
import autosar40.util.Autosar40Package;

public class ExportProject extends Action implements ISelectionListener {

	private NoNameElement noNameElement;
	private MCC mccElement;
	private ECU ecuElement;
	private Component componentElement;
	private ISelection iSelection;

	public ExportProject(ISelection iSelection) {
		this.iSelection = iSelection;
		this.selectionChanged(null, iSelection);
	}

	@Override
	public void run() {
		exportProject();

	}

	private void exportProject() {
		ResourceSetImpl rset = new ResourceSetImpl();
		rset.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
		rset.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool",
				new XMIResourceFactoryImpl());
		FileDialog filePath = new FileDialog(Display.getDefault().getActiveShell(), SWT.SAVE);
		String fileName = "";
		String path = "";
		XMIResource resource = null;
		if (noNameElement != null) {
			fileName = noNameElement.getName();
			filePath.setFileName(fileName + ".architecturetool");
			path = filePath.open();
			resource = (XMIResource)rset.createResource(URI.createFileURI(path));
			resource.getContents().add(noNameElement);
		} else if (mccElement != null) {
			MCC mcc = EcoreUtil.copy(mccElement);
			
			fileName = mccElement.getName();
			filePath.setFileName(fileName + ".architecturetool");
			path = filePath.open();
			resource = (XMIResource)rset.createResource(URI.createFileURI(path));
			resource.getContents().add(mcc);
		} else if (ecuElement != null) {
			
			ECU createECU = EcoreUtil.copy(ecuElement);
			
			fileName = ecuElement.getName();
			filePath.setFileName(fileName + ".architecturetool");
			path = filePath.open();
			resource = (XMIResource)rset.createResource(URI.createFileURI(path));
			resource.getContents().add(createECU);
		} else if (componentElement != null) {
			
			Component comp = EcoreUtil.copy(componentElement);
			EList<Port> port = componentElement.getPorts().getPort();
			fileName = componentElement.getName();
			filePath.setFileName(fileName + ".architecturetool");
			path = filePath.open();
			resource = (XMIResource) rset.createResource(URI.createFileURI(path));
			EList<Port> port2 = comp.getPorts().getPort();
			Runnables runnables = comp.getRunnables();
			for (Iterator iterator = port2.iterator(); iterator.hasNext();) {
				Port port3 = (Port) iterator.next();
				DataStructure type = port3.getType();
				if (type != null) {
					port3.setPortTypeCompoName(type.getName());
				}
			}
			comp.getRunnables().getRunnable().clear();
			comp.getRunnables().getRunnable().addAll(componentElement.getRunnables().getRunnable());
			if (runnables != null) {
				EList<Runnable> runnable = runnables.getRunnable();
				if (runnable != null) {
					for (Iterator<Runnable> iterator = runnable.iterator(); iterator.hasNext();) {
						Runnable runnable2 = (Runnable) iterator.next();
						EList<Port> ports = runnable2.getPorts();
						for (Iterator<Port> iterator2 = ports.iterator(); iterator2.hasNext();) {
							Port port3 = (Port) iterator2.next();
							if (port3.eContainer().eContainer() instanceof Component) {

								Component component = (Component) port3.eContainer().eContainer();
								boolean equals = EcoreUtil.equals(component, comp);
								if (!equals) {
									DataStructure type = port3.getType();
									if (type != null) {
										port3.setPortTypeCompoName(type.getName());
									}
								}
							}
						}
					}
				}
			}			
			
			resource.getContents().add(comp);
			//((MCC)componentElement.eContainer()).getComponents().add(componentElement);
		}
		
		XMLResource.URIHandler uriHandler = new URIHandlerImpl() {
			@Override
			public URI deresolve(URI uri) {
				// make sure references are stored without # URI prefix
				return URI.createURI(uri.fragment());
			}
		};
		resource.getDefaultSaveOptions().put(XMIResource.OPTION_URI_HANDLER, uriHandler);
		resource.getDefaultSaveOptions().put(XMIResource.OPTION_PROCESS_DANGLING_HREF, XMIResource.OPTION_PROCESS_DANGLING_HREF_DISCARD);
		

		try {
			resource.save(Collections.EMPTY_MAP);
			MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Export Project",
					"Files are generated succussfully in this path :" + path);
		} catch (IOException e) {
			e.printStackTrace();
			MessageDialog.openError(Display.getDefault().getActiveShell(), "Export Project",
					"Files are not generated succussfully.Please check the log file.");
		}

	}


	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			if (iStructuredSelection.getFirstElement() instanceof NoNameElement) {
				noNameElement = (NoNameElement) iStructuredSelection.getFirstElement();
			} else if (iStructuredSelection.getFirstElement() instanceof MCC) {
				mccElement = (MCC) iStructuredSelection.getFirstElement();
			} else if (iStructuredSelection.getFirstElement() instanceof ECU) {
				ecuElement = (ECU) iStructuredSelection.getFirstElement();
			} else if (iStructuredSelection.getFirstElement() instanceof Component) {
				componentElement = (Component) iStructuredSelection.getFirstElement();
			}
		}

	}

}
