package com.conti.component.ui.popup;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;

import com.telelogic.rhapsody.core.IRPApplication;
import com.telelogic.rhapsody.core.IRPClass;
import com.telelogic.rhapsody.core.IRPClassifier;
import com.telelogic.rhapsody.core.IRPCollection;
import com.telelogic.rhapsody.core.IRPModelElement;
import com.telelogic.rhapsody.core.IRPObjectModelDiagram;
import com.telelogic.rhapsody.core.IRPProject;
import com.telelogic.rhapsody.core.RPSysMLPort;
import com.telelogic.rhapsody.core.RhapsodyAppServer;

import architecturetool.Component;
import architecturetool.Port;
import architecturetool.PortListType;
import architecturetool.Runnable;

public class PushNewStructureToRhapsody extends Action implements ISelectionListener {
	private Component componentInstance;
	private ISelection iSelection;

	public PushNewStructureToRhapsody(ISelection iSelection) {
		this.iSelection = iSelection;
		this.selectionChanged(null, this.iSelection);
	}

	@Override
	public void run() {
		try {
			addRowInComponentTable(componentInstance);
			MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Push to Rhapsody",
					"Component is pushed to rhapsody successfully");
		} catch (Exception e) {
			MessageDialog.openError(Display.getDefault().getActiveShell(), "Push to Rhapsody",
					"Component is not pushed to rhapsody succussfully.Please check the log file.");
		}

	}


	public static void addRowInComponentTable(Component componentInstance) {
		IRPApplication rpy = RhapsodyAppServer.getActiveRhapsodyApplication();
		IRPProject prj = rpy.activeProject();
		IRPCollection packageElementsMetaClass = prj.getNestedElementsByMetaClass("Package", 0);
		int packageElementCount = packageElementsMetaClass.getCount();
		if (packageElementCount > 0) {
			for (int packageCount = 1; packageCount < packageElementCount + 1; packageCount++) {
				IRPModelElement modelElement = (IRPModelElement) packageElementsMetaClass.getItem(packageCount);
				if (modelElement.getName().equals("Components")) {

					IRPCollection compPackageElementsMetaClass = ((IRPModelElement) modelElement)
							.getNestedElementsByMetaClass("Class", 0);
					int compPackageElementCount = compPackageElementsMetaClass.getCount();
					if (compPackageElementCount > 0) {
						if (getExistingComponents(componentInstance.getName()).size() > 0) {
							List<IRPModelElement> existingComponents = getExistingComponents(
									componentInstance.getName());

							IRPCollection portPackageElementsMetaClass = ((IRPModelElement) existingComponents.get(0))
									.getNestedElementsByMetaClass("SysMLPort", 0);
							int portPackageElementCount = portPackageElementsMetaClass.getCount();
							if (portPackageElementCount > 0) {
								EList<Port> ports1 = componentInstance.getPorts().getPort();
								for (Port port : ports1) {
									List<IRPModelElement> existingPort = getExistingPort(port.getName(),
											existingComponents.get(0));
									if (existingPort.isEmpty()) {
										RPSysMLPort sysMLPort = (RPSysMLPort) existingComponents.get(0)
												.addNewAggr("SysMLPort", port.getName());
										IRPModelElement rteType = ((IRPModelElement) existingComponents.get(0))
												.addNewAggr("Type", port.getType().getName());
										sysMLPort.setType((IRPClassifier) rteType);
										// sysMLPort.setType((IRPClassifier)
										// existingComponents.get(0));
										if (port.getPortDirection().equals(PortListType.PROVIDER)) {
											sysMLPort.setPortDirection("Out");
										} else {
											sysMLPort.setPortDirection("In");
										}
									} else {
										RPSysMLPort sysMLPort = (RPSysMLPort) existingPort.get(0);
										sysMLPort.setType((IRPClassifier) existingComponents.get(0));
										if (port.getPortDirection().equals(PortListType.PROVIDER)) {
											sysMLPort.setPortDirection("Out");
										} else {
											sysMLPort.setPortDirection("In");
										}
									}

								}
							} else {
								EList<Port> ports = componentInstance.getPorts().getPort();
								for (Port port : ports) {
									RPSysMLPort sysMLPort = (RPSysMLPort) existingComponents.get(0)
											.addNewAggr("SysMLPort", port.getName());
									IRPModelElement rteType = ((IRPModelElement) existingComponents.get(0))
											.addNewAggr("Type", port.getType().getName());
									sysMLPort.setType((IRPClassifier) rteType);
									// sysMLPort.setType((IRPClassifier)
									// existingComponents.get(0));
									if (port.getType().equals(PortListType.PROVIDER)) {
										sysMLPort.setPortDirection("Out");
									} else {
										sysMLPort.setPortDirection("In");
									}
								}

							}

							IRPCollection runnablePackageElementsMetaClass = ((IRPModelElement) existingComponents
									.get(0)).getNestedElementsByMetaClass("Operation", 0);
							int runnablePackageElementCount = runnablePackageElementsMetaClass.getCount();

							if (runnablePackageElementCount > 0) {
								EList<Runnable> itsRunnable = componentInstance.getRunnables().getRunnable();
								for (Runnable runnable : itsRunnable) {
									List<IRPModelElement> existingRunnables = getExistingRunnables(runnable.getName(),
											existingComponents.get(0));
									if (existingRunnables.isEmpty()) {
										existingComponents.get(0).addNewAggr("AdlRunnable", runnable.getName());
										EList<Port> ports = runnable.getPorts();
										for (Port port : ports) {
											existingRunnables.get(0).addDependencyTo(
													getExistingPort(port.getName(), existingComponents.get(0)).get(0));
										}
									} else {
										EList<Port> ports = runnable.getPorts();
										for (Port port : ports) {
											if (!isPortExist(runnable, existingRunnables.get(0), port.getName())) {
												existingRunnables.get(0).addDependencyTo(
														getExistingPort(port.getName(), existingComponents.get(0))
																.get(0));
											}
										}
									}

								}

							} else {
								EList<Runnable> itsRunnable = componentInstance.getRunnables().getRunnable();
								for (Runnable runnable : itsRunnable) {
									existingComponents.get(0).addNewAggr("AdlRunnable", runnable.getName());
									List<IRPModelElement> existingRunnables = getExistingRunnables(runnable.getName(),
											existingComponents.get(0));
									EList<Port> ports = runnable.getPorts();
									for (Port port : ports) {
										existingRunnables.get(0).addDependencyTo(
												getExistingPort(port.getName(), existingComponents.get(0)).get(0));
									}
								}
							}

						} else {
							IRPClass classElement = (IRPClass) modelElement.addNewAggr("AdlComponent",
									componentInstance.getName());

							EList<Port> ports = componentInstance.getPorts().getPort();
							for (Port port : ports) {
								RPSysMLPort sysMLPort = (RPSysMLPort) classElement.addNewAggr("SysMLPort",
										port.getName());
								IRPModelElement rteType = classElement.addNewAggr("Type", port.getType().getName());
								sysMLPort.setType((IRPClassifier) rteType);
								if (port.getPortDirection().equals(PortListType.PROVIDER)) {
									sysMLPort.setPortDirection("Out");
								} else {
									sysMLPort.setPortDirection("In");
								}
							}

							EList<Runnable> itsRunnable = componentInstance.getRunnables().getRunnable();
							for (Runnable runnable : itsRunnable) {
								classElement.addNewAggr("AdlRunnable", runnable.getName());
								List<IRPModelElement> existingRunnables = getExistingRunnables(runnable.getName(),
										classElement);
								EList<Port> ports1 = runnable.getPorts();
								for (Port port : ports1) {
									existingRunnables.get(0)
											.addDependencyTo(getExistingPort(port.getName(), classElement).get(0));
								}

							}

							IRPObjectModelDiagram addNewAggr = (IRPObjectModelDiagram) classElement
									.addNewAggr("AdlComponentDiagram", componentInstance.getName());
							addNewAggr.addNewNodeForElement(classElement, 100, 100, 200, 300);
							classElement.setMainDiagram(addNewAggr);
						}

					}

				}
			}

		}

	}

	public static List<IRPModelElement> getExistingComponents(String componentName) {
		List<IRPModelElement> componentList = new ArrayList<IRPModelElement>();

		IRPApplication rpy = RhapsodyAppServer.getActiveRhapsodyApplication();
		IRPProject prj = rpy.activeProject();
		IRPCollection packageElementsMetaClass = prj.getNestedElementsByMetaClass("Package", 0);
		int packageElementCount = packageElementsMetaClass.getCount();
		if (packageElementCount > 0) {
			for (int packageCount = 1; packageCount < packageElementCount + 1; packageCount++) {
				IRPModelElement modelElement = (IRPModelElement) packageElementsMetaClass.getItem(packageCount);
				if (modelElement.getName().equals("Components")) {

					IRPCollection compPackageElementsMetaClass = ((IRPModelElement) modelElement)
							.getNestedElementsByMetaClass("Class", 0);
					int compPackageElementCount = compPackageElementsMetaClass.getCount();
					if (compPackageElementCount > 0) {
						for (int compPackageCount = 1; compPackageCount < compPackageElementCount
								+ 1; compPackageCount++) {
							IRPModelElement adlModelElement = (IRPModelElement) compPackageElementsMetaClass
									.getItem(compPackageCount);
							if (adlModelElement.getName().equalsIgnoreCase(componentName)) {
								componentList.add(adlModelElement);
							}
						}
					}

				}
			}
		}

		return componentList;
	}

	public static List<IRPModelElement> getExistingPort(String portName, IRPModelElement existingComponents) {
		List<IRPModelElement> portList = new ArrayList<IRPModelElement>();
		IRPCollection portPackageElementsMetaClass = ((IRPModelElement) existingComponents)
				.getNestedElementsByMetaClass("SysMLPort", 0);
		int portPackageElementCount = portPackageElementsMetaClass.getCount();
		if (portPackageElementCount > 0) {
			for (int portPackageCount = 1; portPackageCount < portPackageElementCount + 1; portPackageCount++) {
				IRPModelElement portModelElement = (IRPModelElement) portPackageElementsMetaClass
						.getItem(portPackageCount);
				if (portModelElement.getName().equalsIgnoreCase(portName)) {
					portList.add(portModelElement);
				}

			}
		}

		return portList;
	}

	public static List<IRPModelElement> getExistingRunnables(String portName, IRPModelElement existingComponents) {
		List<IRPModelElement> runnableList = new ArrayList<IRPModelElement>();
		IRPCollection runnablePackageElementsMetaClass = ((IRPModelElement) existingComponents)
				.getNestedElementsByMetaClass("Operation", 0);
		int runnablePackageElementCount = runnablePackageElementsMetaClass.getCount();

		if (runnablePackageElementCount > 0) {
			for (int runnablePackageCount = 1; runnablePackageCount < runnablePackageElementCount
					+ 1; runnablePackageCount++) {
				IRPModelElement runnableModelElement = (IRPModelElement) runnablePackageElementsMetaClass
						.getItem(runnablePackageCount);
				if (runnableModelElement.getName().equals(portName)) {
					runnableList.add(runnableModelElement);
				}

			}
		}

		return runnableList;
	}

	public static boolean isPortExist(Runnable runnable, IRPModelElement runnableModel, String portName) {
		Boolean isPort = false;
		IRPCollection dependencies = runnableModel.getDependencies();
		for (int i = 1; i < dependencies.getCount() + 1; i++) {
			IRPModelElement portElement = (IRPModelElement) dependencies.getItem(i);
			if (portName.equalsIgnoreCase(portElement.getName())) {
				isPort = true;
				break;
			} else {
				isPort = false;
			}
		}

		return isPort;

	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		// TODO Auto-generated method stub
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			componentInstance = (Component) iStructuredSelection.getFirstElement();
		}

	}

}
