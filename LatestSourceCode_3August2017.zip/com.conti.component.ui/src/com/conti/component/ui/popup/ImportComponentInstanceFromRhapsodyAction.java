package com.conti.component.ui.popup;

import java.util.ArrayList;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;

import com.conti.component.ui.dialogs.ImportComponentInterfaceDialog;
import com.telelogic.rhapsody.core.IRPModelElement;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ComponentInstance;
import architecturetool.FunctionalRequirement;

public class ImportComponentInstanceFromRhapsodyAction extends Action implements ISelectionListener {

	private FunctionalRequirement firstElement;
	private ISelection iSelection;

	public ImportComponentInstanceFromRhapsodyAction(ISelection iSelection) {
		this.iSelection = iSelection;
		this.selectionChanged(null, this.iSelection);
	}

	@Override
	public void run() {

		try {
			ImportComponentInterfaceDialog componentInterfaceDailog = new ImportComponentInterfaceDialog(
					Display.getDefault().getActiveShell());
			if (IDialogConstants.OK_ID == componentInterfaceDailog.open()) {
				ArrayList<IRPModelElement> componentInstanceList = componentInterfaceDailog.getComponentInstanceList();
				for (IRPModelElement irpModelElement : componentInstanceList) {
					ComponentInstance compInstance = ArchitecturetoolFactory.eINSTANCE.createComponentInstance();
					compInstance.setName(irpModelElement.getName());
					firstElement.getComponentinstance().add(compInstance);

				}
				if (!componentInstanceList.isEmpty()) {
					MessageDialog.openInformation(Display.getDefault().getActiveShell(),
							"Import Component Interface from Rhapsody",
							"Component Interface are imported succussfully");
				}
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			MessageDialog.openError(Display.getDefault().getActiveShell(), "Import Component Interface from Rhapsody",
					"Component Interface is not imported succussfully.Please check the log file.");
		}

		// TODO Auto-generated method stub

	}


	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection sSelection = (IStructuredSelection) selection;
			firstElement = (FunctionalRequirement) sSelection.getFirstElement();

		}
	}

}
