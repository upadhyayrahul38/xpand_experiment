package com.conti.component.ui.popup;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.mwe.core.WorkflowContextDefaultImpl;
import org.eclipse.emf.mwe.core.issues.Issues;
import org.eclipse.emf.mwe.core.issues.IssuesImpl;
import org.eclipse.emf.workspace.util.WorkspaceSynchronizer;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.ide.dialogs.IDEResourceInfoUtils;
import org.eclipse.xpand.support.cdt.CppBeautifier;
import org.eclipse.xpand2.XpandExecutionContextImpl;
import org.eclipse.xpand2.XpandFacade;
import org.eclipse.xpand2.XpandUtil;
import org.eclipse.xpand2.output.Outlet;
import org.eclipse.xpand2.output.OutputImpl;
import org.eclipse.xtend.middleend.xpand.XpandComponent;
import org.eclipse.xtend.typesystem.emf.EmfMetaModel;
import org.osgi.service.log.LogService;

import com.conti.component.ui.Activator;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.MCC;
import architecturetool.NoNameElement;
//import generator.RunXpandTemplate;
import architecturetool.impl.ComponentImpl;

public class GenerateRteHeaders extends Action implements ISelectionListener {

	private Component componentInstance;
	private static EList<EObject> inObjects;
	private static EPackage pSM_Pkg;
	private NoNameElement noNameElement;
	private String outputPath;
	public Boolean isRteGenerated;

	public Boolean isRteGenerated() {
		return isRteGenerated;
	}

	public void setIsRteGenerated(Boolean isRteGenerated) {
		this.isRteGenerated = isRteGenerated;
	}

	public GenerateRteHeaders() {
	}

	public GenerateRteHeaders(NoNameElement _noNameElement, String _outputPath, Component componentInstance) {
		this.noNameElement = _noNameElement;
		this.outputPath = _outputPath;
		this.componentInstance = componentInstance;
	}

	@Override
	public void run() {
		runMWEFile(componentInstance, this);

	}

	public void runMWEFile(Component eobject, IAction action) {

		ArchitecturetoolPackage architectureToolPackage = ArchitecturetoolPackage.eINSTANCE;

		try {
			if (action != null && outputPath == null) {
				StringBuilder compFileName = new StringBuilder();
				IDialogSettings dialogSettings = Activator.getDefault().getDialogSettings(); 
				String lastUsedPath = dialogSettings.get("lastfolderpath");
				if (lastUsedPath == null) {
					lastUsedPath = "c:\\";
				}
				DirectoryDialog dialog = new DirectoryDialog(Display.getDefault().getActiveShell());
				dialog.setFilterPath(lastUsedPath);
				String path = dialog.open();
				if (path == null) {
					return;
				}
				dialogSettings.put("lastfolderpath", path); 
				
				if (path != null) {
					URI outURI = URI.createURI("file:///" + path);

					OutputImpl out = new OutputImpl();
					Outlet outlet = new Outlet(outURI.toFileString());
					out.addOutlet(outlet);
					XpandExecutionContextImpl executionContext = new XpandExecutionContextImpl(out, null);

					// Configure the metamodels

					EmfMetaModel emfMetaModel = new EmfMetaModel();
					emfMetaModel.setMetaModelPackage(architectureToolPackage.getClass().getName());
					executionContext.registerMetaModel(emfMetaModel);
					XpandFacade xpandFacade = XpandFacade.create(executionContext);
					Object[] params = null;
					if (eobject != null) {
						xpandFacade.evaluate("template::Component::main", componentInstance, params); // noNameElement										
						MessageDialog.openInformation(Display.getDefault().getActiveShell(), "RTE Headers",
								"Files are generated succussfully in this path :" + path);
					}
				}
			} else {
				if (outputPath != null) {
					URI outURI = URI.createURI("file:///" + outputPath);

					OutputImpl out = new OutputImpl();
					Outlet outlet = new Outlet(outURI.toFileString());
					out.addOutlet(outlet);
					XpandExecutionContextImpl executionContext = new XpandExecutionContextImpl(out, null);

					// Configure the metamodels

					EmfMetaModel emfMetaModel = new EmfMetaModel();
					emfMetaModel.setMetaModelPackage(architectureToolPackage.getClass().getName());
					executionContext.registerMetaModel(emfMetaModel);
					XpandFacade xpandFacade = XpandFacade.create(executionContext);
					Object[] params = null;
					if (noNameElement != null) {
						xpandFacade.evaluate("template::Component::main", noNameElement, params);
						isRteGenerated = true;
						setIsRteGenerated(isRteGenerated);
					}

				}
			}
		} catch (Exception e) {
			isRteGenerated = false;
			setIsRteGenerated(isRteGenerated);
			MessageDialog.openError(Display.getDefault().getActiveShell(), "RTE Header File",
					"Files are not generated succussfully.Please check the log file.");

			IWorkspace workspace = WorkspaceSynchronizer.getFile(componentInstance.eResource()).getProject()
					.getWorkspace();
			IPath location = workspace.getRoot().getLocation();
			Status status = new Status(IStatus.ERROR, Activator.PLUGIN_ID, e.getLocalizedMessage(), e);
			Activator.getDefault().getLog().log(status);
		}

	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			if (iStructuredSelection != null && iStructuredSelection.getFirstElement() instanceof ComponentImpl) {
				componentInstance = (Component) iStructuredSelection.getFirstElement();
			}
		}

	}

}
	