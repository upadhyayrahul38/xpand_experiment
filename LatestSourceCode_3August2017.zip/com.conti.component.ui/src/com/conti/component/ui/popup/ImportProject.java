package com.conti.component.ui.popup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

import org.eclipse.emf.common.util.ECollections;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Port;
import architecturetool.Ports;
import architecturetool.Runnable;
import architecturetool.impl.DataStructureImpl;
import architecturetool.impl.PortImpl;
import architecturetool.impl.PortsImpl;

public class ImportProject extends Action implements ISelectionListener {

	private NoNameElement noNameElement;
	private MCC mccElement;
	private ECU ecuElement;
	private Component componentElement;
	private ISelection iSelection;

	public ImportProject(ISelection iSelection) {
		this.iSelection = iSelection;
		this.selectionChanged(null, iSelection);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		ImportProject();

	}

	private void ImportProject() {
		// TODO Auto-generated method stub
		FileDialog filePath = new FileDialog(Display.getDefault().getActiveShell(), SWT.OPEN);
		String path = filePath.open();

		
		ResourceSetImpl resourceSet = new ResourceSetImpl();
		resourceSet.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool",
				new XMIResourceFactoryImpl());
		//XMIResourceImpl resource = new XMIResourceImpl();
		File source = new File(path);
		try {
			Resource resource = resourceSet.getResource(URI.createFileURI(source.getPath()), true); //source.getLocation().toOSString()
			resource.load(new FileInputStream(source), new HashMap<Object, Object>());
			if (resource.getContents().get(0) instanceof NoNameElement) {
				NoNameElement noName = (NoNameElement) resource.getContents().get(0);
				noNameElement.setName(noName.getName());
				if (noName.getMcc() != null) {
					noNameElement.getMcc().addAll(noName.getMcc());
				}
			} else if (resource.getContents().get(0) instanceof MCC) {
				MCC mcc = (MCC) resource.getContents().get(0);
				mccElement.setName(mcc.getName());
				if (mcc.getComponents() != null) {
					mccElement.getComponents().addAll(mcc.getComponents());
				}
				if (mcc.getParameters() != null) {
					mccElement.getParameters().addAll(mcc.getParameters());
				}
			} else if (resource.getContents().get(0) instanceof ECU) {
				ECU ecu = (ECU) resource.getContents().get(0);
				ecuElement.setName(ecu.getName());
				if (ecu.getCpus() != null) {
					ecuElement.getCpus().addAll(ecu.getCpus());
				}
				if (ecu.getFunctionalrequirements() != null) {
					ecuElement.getFunctionalrequirements().addAll(ecu.getFunctionalrequirements());
				}
				if (ecu.getMemory() != null) {
					ecuElement.getMemory().addAll(ecu.getMemory());
				}
			} else if (resource.getContents().get(0) instanceof Component) {
				Component comp = (Component) resource.getContents().get(0);
				mccElement.getComponents().add(comp);
				ECollections.sort(mccElement.getComponents(), new Comparator<Component>() {
					@Override
					public int compare(Component o1, Component o2) {
						     if(o1.getName()!=null && o2.getName()!=null) {
						    	 return o1.getName().compareToIgnoreCase(o2.getName());
						     }
							return 0;
					}
				});
				if (mccElement != null) {
					EList<Port> port = comp.getPorts().getPort();
					for (Iterator<Port> iterator = port.iterator(); iterator.hasNext();) {
						Port port2 = (Port) iterator.next();
						boolean eIsProxy = port2.getType().eIsProxy();
						if (eIsProxy) {
								URI eProxyURI = ((InternalEObject) port2.getType()).eProxyURI();
								EObject eObject = mccElement.eResource().getEObject(eProxyURI.toString());
								if (eObject != null && eObject instanceof DataStructureImpl) {
									DataStructureImpl dataStruct = ((DataStructureImpl) eObject);
									port2.setType(dataStruct);
								}
						}

					}
					ArrayList<Port> portListHref = new ArrayList<Port>();
					EList<Runnable> runnable = comp.getRunnables().getRunnable();
					String uriFragment = mccElement.eResource().getURIFragment(mccElement);
					for (Iterator<Runnable> iterator = runnable.iterator(); iterator.hasNext();) {
						Runnable runnable2 = (Runnable) iterator.next();
						EList<Port> ports = runnable2.getPorts();
						for (Iterator<Port> iterator2 = ports.iterator(); iterator2.hasNext();) {
							Port port2 = (Port) iterator2.next();
							boolean eIsProxy = port2.eIsProxy();
							if (eIsProxy) {
								URI eProxyURI = ((InternalEObject) port2).eProxyURI();
								String eProxyStr = eProxyURI.toString();
								if (eProxyStr.startsWith("//@ports")) {
									String lastSegment = eProxyURI.lastSegment();
									String substring = lastSegment.substring("@port.".length(), lastSegment.length());
									Port port3 = comp.getPorts().getPort().get(Integer.parseInt(substring));
									if (port3 != null) {
										portListHref.add(port3);
									}
								} else if (eProxyStr.startsWith("//@nonameelement.")) {
									EObject eObject = mccElement.eResource().getEObject(eProxyURI.toString());
									if (eObject != null && eObject instanceof Port) {
										Port portFromUri = ((Port) eObject);
										portListHref.add(portFromUri);
									}
								}
							} else {
								portListHref.add(port2);
							}
						}
						runnable2.getPorts().clear();
						runnable2.getPorts().addAll(portListHref);
						portListHref.clear();
					}

					//mccElement.getComponents().add(comp);
					MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Import Project",
							"Files are imported succussfully from this path :" + path);
				}

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			MessageDialog.openError(Display.getDefault().getActiveShell(), "Import Project",
					"Files are not imported succussfully.Please check the log file.");
		}

	}


	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		// TODO Auto-generated method stub
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			if (iStructuredSelection.getFirstElement() instanceof NoNameElement) {
				noNameElement = (NoNameElement) iStructuredSelection.getFirstElement();
			} else if (iStructuredSelection.getFirstElement() instanceof MCC) {
				mccElement = (MCC) iStructuredSelection.getFirstElement();
			} else if (iStructuredSelection.getFirstElement() instanceof ECU) {
				ecuElement = (ECU) iStructuredSelection.getFirstElement();
			} else if (iStructuredSelection.getFirstElement() instanceof Component) {
				componentElement = (Component) iStructuredSelection.getFirstElement();
			}
		}

	}

}
