
package com.conti.component.ui.popup;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.dialogs.ListSelectionDialog;

import com.conti.component.ui.labelprovider.ListSelectionLabelProvider;
import com.telelogic.rhapsody.core.IRPApplication;
import com.telelogic.rhapsody.core.IRPCollection;
import com.telelogic.rhapsody.core.IRPComponent;
import com.telelogic.rhapsody.core.IRPModelElement;
import com.telelogic.rhapsody.core.IRPOperation;
import com.telelogic.rhapsody.core.IRPPort;
import com.telelogic.rhapsody.core.IRPProject;
import com.telelogic.rhapsody.core.IRPStereotype;
import com.telelogic.rhapsody.core.IRPTag;
import com.telelogic.rhapsody.core.IRPType;
import com.telelogic.rhapsody.core.RhapsodyAppServer;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.Generator;
import architecturetool.MCC;
import architecturetool.Port;
import architecturetool.PortListType;
import architecturetool.Ports;
import architecturetool.Runnable;
import architecturetool.Runnables;
import architecturetool.SubComponent;

public class ImportComprReqFromRhapsodyAction extends Action implements ISelectionListener {

	private static final String COMP_REQ = "CompReq";
	private static final String PACKAGE = "Package";
	private static final String SUBCOMPONENT = "SubComponent";
	private static final String SUB_COMPONENT = "Sub-Component";
	private static final String RUNNABLE = "Runnable";
	private static final String TYPE = "Type";
	private static final String ADL_PORT = "ADLPort";
	private static final String PORT = "Port";
	private static final String OPERATION = "Operation";
	private static final String COMPONENT = "Component";
	private static final String RTETYPE = "RteType";
	private MCC mcc;
	private ISelection iSelection;

	public ImportComprReqFromRhapsodyAction(ISelection iSelection) {
		this.iSelection = iSelection;
		this.selectionChanged(null, iSelection);
	}

	@Override
	public void run() {
		
			try {
				findElement();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				MessageDialog.openError(Display.getDefault().getActiveShell(), "Import Component from CompReq",
						"Component is not imported succussfully.Please check the log file.");
			}
	}



	private void findElement() {

		System.setProperty("java.library.path", "D:/Work/Workspaces/TrialSpace/com.conti.component.ui/dll");
		System.load("D:/Work/Workspaces/TrialSpace/com.conti.component.ui/dll/rhapsody.dll");

		IRPApplication app = RhapsodyAppServer.getActiveRhapsodyApplication();
		IRPProject prj = app.activeProject();
		IRPModelElement myEle = prj.findNestedElementRecursive(COMP_REQ, PACKAGE);
		myEle.highLightElement();
		IRPCollection packageElementsMetaClass = myEle.getNestedElementsByMetaClass(PACKAGE, 0);
		List<IRPModelElement> modelElementList = new ArrayList<IRPModelElement>();
		int packageElementCount = packageElementsMetaClass.getCount();
		if (packageElementCount > 0) {
			for (int packageCount = 1; packageCount < packageElementCount + 1; packageCount++) {
				IRPModelElement modelElement = (IRPModelElement) packageElementsMetaClass.getItem(packageCount);
				if (modelElement.getStereotypes().getCount() > 0) {
					IRPStereotype item = (IRPStereotype) modelElement.getStereotypes().getItem(1);
					if (item.getName().equals(COMPONENT)) {
						modelElementList.add(modelElement);
					}
				}
			}
		}

		// set a input for listSelectionDialog
		ListSelectionDialog componentsDialog = new ListSelectionDialog(Display.getDefault().getActiveShell(),
				modelElementList, new ArrayContentProvider(), new ListSelectionLabelProvider(),
				"Select the Components");
		componentsDialog.setTitle("MCC-Components");

		if (IDialogConstants.OK_ID == componentsDialog.open()) {
			Object[] selectedComponent = componentsDialog.getResult();
			for (Object element : selectedComponent) {

				if (element instanceof IRPModelElement) {
					IRPModelElement irpModelElement = (IRPModelElement) element;
					boolean needOverride = false;
					List<Component> existingComponents = getExistingComponents(irpModelElement.getName());
					if (!existingComponents.isEmpty()) {
						needOverride = MessageDialog.openConfirm(Display.getDefault().getActiveShell(), "Confirm",
								"Do you want to override the component?");
					}
					if (existingComponents.isEmpty() || needOverride) {
						if (irpModelElement.getStereotypes().getCount() > 0) {
							IRPStereotype stereoType = (IRPStereotype) irpModelElement.getStereotypes().getItem(1);

							if (stereoType.getName().equals(COMPONENT)) {
								if (!needOverride) {
									Component component = ArchitecturetoolFactory.eINSTANCE.createComponent();
									component.setName(irpModelElement.getName());
									mcc.getComponents().add(component);

									addComponentElements(irpModelElement, needOverride, component);
								} else {

									for (Component component : existingComponents) {
										if (component.getName().equalsIgnoreCase(irpModelElement.getName())) {
											addComponentElements(irpModelElement, needOverride, component);
										}

									}
								}

							}

						}
					}
				}
			}
			MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Import Components from ComReq",
					"Components are imported succussfully");
		}

	}

	public void addComponentElements(IRPModelElement irpModelElement, boolean needOverride, Component component) {

		// Get port from MCC Components(Rhapsody)
		getPorts(irpModelElement, component, needOverride);
		// Get runnable from MCC
		// Components(Rhapsody)
		if (!needOverride) {
			// Get subcomponent from MCC
			// Components(Rhapsody)
			getSubcomponents(irpModelElement, component, needOverride);

			getRunnables(irpModelElement, component, needOverride);

			getRTETypes(irpModelElement, component, needOverride);
		}
	}

	public List<Component> getExistingComponents(String componentName) {
		List<Component> componentList = new ArrayList<Component>();
		EList<Component> components = mcc.getComponents();
		for (Component component : components) {
			if (component.getName().equalsIgnoreCase(componentName)) {
				componentList.add(component);
			}
		}
		return componentList;
	}

	public void getRunnables(IRPModelElement irpModelElement, Component component, boolean needOverride) {
		IRPCollection operationMetaElement = irpModelElement.getNestedElementsByMetaClass(OPERATION, 1);

		int runnableElementCount = operationMetaElement.getCount();
		for (int runnableCount = 1; runnableCount < runnableElementCount + 1; runnableCount++) {
			IRPOperation operationElement = (IRPOperation) operationMetaElement.getItem(runnableCount);
			if (operationElement.getStereotypes() != null && operationElement.getStereotypes().getCount() > 0) {
				IRPStereotype stereoType = (IRPStereotype) operationElement.getStereotypes().getItem(1);
				String stereoTypeName = stereoType.getName();
				if (stereoTypeName.equals(RUNNABLE)) {
					// if (!needOverride) {
					Runnable runnable = ArchitecturetoolFactory.eINSTANCE.createRunnable();
					runnable.setName(operationElement.getName());
					Runnables runnables = ArchitecturetoolFactory.eINSTANCE.createRunnables();
					runnables.getRunnable().add(runnable);
					component.setRunnables(runnables);
					// }
				}
			}

		}

	}

	public void getRTETypes(IRPModelElement irpModelElement, Component component, boolean needOverride) {
		IRPCollection rteTypeMetaElement = irpModelElement.getNestedElementsByMetaClass(TYPE, 1);

		int rteTypeElementCount = rteTypeMetaElement.getCount();
		for (int rteTypeCount = 1; rteTypeCount < rteTypeElementCount + 1; rteTypeCount++) {
			IRPType rteTypeElement = (IRPType) rteTypeMetaElement.getItem(rteTypeCount);
			if (rteTypeElement.getStereotypes() != null && rteTypeElement.getStereotypes().getCount() > 0) {
				IRPStereotype stereoType = (IRPStereotype) rteTypeElement.getStereotypes().getItem(1);
				String stereoTypeName = stereoType.getName();
				if (stereoTypeName.equals(RTETYPE)) {
					// if (!needOverride) {
					Generator generator = ArchitecturetoolFactory.eINSTANCE.createGenerator();
					generator.setName(rteTypeElement.getName());
					DataStructure insideDataStruct = ArchitecturetoolFactory.eINSTANCE.createDataStructure();
					insideDataStruct.setName(rteTypeElement.getName());
					insideDataStruct.setDescription(rteTypeElement.getDescription());
					generator.getDatastructure().add(insideDataStruct);
					component.getGenerator().add(generator);
					// }
				}
			}

		}

	}

	public void getPorts(IRPModelElement irpModelElement, Component component, boolean needOverride) {

		IRPCollection portMetaElement = irpModelElement.getNestedElementsByMetaClass(PORT, 1);

		int portElementCount = portMetaElement.getCount();
		for (int portCount = 1; portCount < portElementCount + 1; portCount++) {
			IRPPort portElement = (IRPPort) portMetaElement.getItem(portCount);

			if (portElement.getStereotypes() != null && portElement.getStereotypes().getCount() > 0) {
				IRPStereotype stereoType = (IRPStereotype) portElement.getStereotypes().getItem(1);
				String stereoTypeName = stereoType.getName();

				if (stereoTypeName.equals(ADL_PORT)) {
					if (!needOverride) {
						addNewPort(component, portElement);
					} else {
						EList<Port> ports = component.getPorts().getPort();
						for (Port port : ports) {
							if (port.getName().equalsIgnoreCase(portElement.getName())) {
								IRPTag tag = portElement.getTag(TYPE);
								if (PortListType.REQUEST.getLiteral().toLowerCase()
										.contains(tag.getValue().toLowerCase())) {
									port.setPortDirection(PortListType.REQUEST);
								} else {
									port.setPortDirection(PortListType.PROVIDER);
								}
							}
						}
					}
				}
			}
		}

	}

	public void addNewPort(Component component, IRPPort portElement) {
		Port port = ArchitecturetoolFactory.eINSTANCE.createPort();
		IRPTag tag = portElement.getTag(TYPE);
		port.setName(portElement.getName());
		if (PortListType.REQUEST.getLiteral().toLowerCase().contains(tag.getValue().toLowerCase())) {
			port.setPortDirection(PortListType.REQUEST);
		} else {
			port.setPortDirection(PortListType.PROVIDER);
		}

		Ports ports = ArchitecturetoolFactory.eINSTANCE.createPorts();
		ports.getPort().add(port);
		component.setPorts(ports);
	}

	public void getSubcomponents(IRPModelElement irpModelElement, Component component, boolean needOverride) {

		IRPCollection componentMetaElement = irpModelElement.getNestedElementsByMetaClass(COMPONENT, 1);
		int componentMetaElementCount = componentMetaElement.getCount();
		for (int jcomponentCount = 1; jcomponentCount < componentMetaElementCount + 1; jcomponentCount++) {
			IRPComponent componentElement = (IRPComponent) componentMetaElement.getItem(jcomponentCount);

			if (componentElement.getStereotypes() != null && componentElement.getStereotypes().getCount() > 0) {
				IRPStereotype stereoType = (IRPStereotype) componentElement.getStereotypes().getItem(1);
				String stereoTypeName = stereoType.getName();
				if (stereoTypeName.equals(SUB_COMPONENT) || (stereoTypeName.equals(SUBCOMPONENT))) {
					// if (!needOverride) {
					SubComponent subcomponent = ArchitecturetoolFactory.eINSTANCE.createSubComponent();
					subcomponent.setName(componentElement.getName());
					component.getSubcomponent().add(subcomponent);
					// }
				}
			}
		}

	}


	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			Object firstElement = iStructuredSelection.getFirstElement();
			if (firstElement instanceof MCC) {
				mcc = (MCC) firstElement;
			}

		}
	}

}
