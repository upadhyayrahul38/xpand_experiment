package com.conti.component.ui.popup;

import org.eclipse.ant.core.AntCorePlugin;
import org.eclipse.ant.core.AntCorePreferences;
import org.eclipse.emf.common.util.URI;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.xpand.support.cdt.CppBeautifier;
import org.eclipse.xpand2.XpandExecutionContextImpl;
import org.eclipse.xpand2.XpandFacade;
import org.eclipse.xpand2.output.Outlet;
import org.eclipse.xpand2.output.OutputImpl;
import org.eclipse.xtend.typesystem.emf.EmfMetaModel;

import com.conti.component.ui.Activator;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;

public class GenerateHeaderfileAction extends Action implements ISelectionListener {

	private Component component;
	private String filePath;

	public GenerateHeaderfileAction() {

	}

	public GenerateHeaderfileAction(Component _component, String path) {
		this.component = _component;
		this.filePath = path;
	}

	public boolean runConsole() {
		ArchitecturetoolPackage architectureToolPackage = ArchitecturetoolPackage.eINSTANCE;
		DirectoryDialog dirPath = new DirectoryDialog(Display.getDefault().getActiveShell(), SWT.SAVE);

		// dirPath.setFileName(compFileName.toString());
		// filePath.setFileName("RTE Headers");
		String path = dirPath.open();
		if (path != null) {
			URI outURI = URI.createURI("file:///" + path);

			OutputImpl out = new OutputImpl();
			Outlet outlet = new Outlet(outURI.toFileString());
			out.addOutlet(outlet);
			XpandExecutionContextImpl executionContext = new XpandExecutionContextImpl(out, null);

			// Configure the metamodels

			EmfMetaModel emfMetaModel = new EmfMetaModel();
			emfMetaModel.setMetaModelPackage(architectureToolPackage.getClass().getName());
			executionContext.registerMetaModel(emfMetaModel);
			XpandFacade xpandFacade = XpandFacade.create(executionContext);
			Object[] params = null;
			if (component != null) {
				try {
					xpandFacade.evaluate("template::ExternalHeader::main", component.eContainer().eContainer(), params);
					return true;
				} catch (Exception e) {
					return false;

				}
			}
		}
		return false;
	}

	@Override
	public void run() {

		ArchitecturetoolPackage architectureToolPackage = ArchitecturetoolPackage.eINSTANCE;
		IDialogSettings dialogSettings = Activator.getDefault().getDialogSettings(); 
		String lastUsedPath = dialogSettings.get("lastfolderpath");
		if (lastUsedPath == null) {
			lastUsedPath = "c:\\";
		}
		DirectoryDialog dialog = new DirectoryDialog(Display.getDefault().getActiveShell());
		dialog.setFilterPath(lastUsedPath);
		String location = dialog.open();
		if (location == null) {
			return;
		}
		dialogSettings.put("lastfolderpath", location); 
		
		if (location != null) {
			URI outURI = URI.createURI("file:///" + location);

			OutputImpl out = new OutputImpl();
			Outlet outlet = new Outlet(outURI.toFileString());
		
			out.addOutlet(outlet);
			XpandExecutionContextImpl executionContext = new XpandExecutionContextImpl(out, null);

			// Configure the metamodels

			EmfMetaModel emfMetaModel = new EmfMetaModel();
			emfMetaModel.setMetaModelPackage(architectureToolPackage.getClass().getName());
			executionContext.registerMetaModel(emfMetaModel);
			XpandFacade xpandFacade = XpandFacade.create(executionContext);
			Object[] params = null;
			if (component != null) {
				xpandFacade.evaluate("template::ExternalHeader::main", component, params); // component.eContainer().eContainer()
				MessageDialog.openInformation(Display.getDefault().getActiveShell(), "RTE Headers",
						"Files are generated successfully in this path :" + location);
			}
		}
	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			component = (Component) iStructuredSelection.getFirstElement();

		}
	}

}
