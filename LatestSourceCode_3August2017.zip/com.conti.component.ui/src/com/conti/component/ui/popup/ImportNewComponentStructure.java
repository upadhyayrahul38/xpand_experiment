package com.conti.component.ui.popup;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.dialogs.ListSelectionDialog;

import com.conti.component.ui.labelprovider.ListSelectionLabelProvider;
import com.telelogic.rhapsody.core.IRPApplication;
import com.telelogic.rhapsody.core.IRPClassifier;
import com.telelogic.rhapsody.core.IRPCollection;
import com.telelogic.rhapsody.core.IRPModelElement;
import com.telelogic.rhapsody.core.IRPProject;
import com.telelogic.rhapsody.core.RPSysMLPort;
import com.telelogic.rhapsody.core.RhapsodyAppServer;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.Generator;
import architecturetool.MCC;
import architecturetool.Port;
import architecturetool.PortListType;
import architecturetool.Ports;
import architecturetool.Runnable;
import architecturetool.Runnables;

public class ImportNewComponentStructure extends Action implements ISelectionListener{
	private MCC mcc;
	private ISelection iSelection;

	public ImportNewComponentStructure(ISelection iSelection) {
		this.iSelection = iSelection;
		this.selectionChanged(null, this.iSelection);
	}

	@Override
	public void run() {
		try {
			findElement();
		} catch (Exception e) {
			MessageDialog.openError(Display.getDefault().getActiveShell(), "Import Components from Components",
					"Components are not imported succussfully.Please check the log file.");
		}
	}

	private void findElement() {
		System.setProperty("java.library.path", "D:/Work/Workspaces/TrialSpace/com.conti.component.ui/dll");
		System.load("D:/Work/Workspaces/TrialSpace/com.conti.component.ui/dll/rhapsody.dll");

		IRPApplication app = RhapsodyAppServer.getActiveRhapsodyApplication();
		IRPProject prj = app.activeProject();
		// IRPModelElement myEle = prj.findNestedElementRecursive("Components",
		// PACKAGE);
		// myEle.highLightElement();
		IRPCollection packageElementsMetaClass = prj.getNestedElementsByMetaClass("Package", 0);
		int packageElementCount = packageElementsMetaClass.getCount();
		List<IRPModelElement> modelElementList = new ArrayList<IRPModelElement>();
		if (packageElementCount > 0) {
			for (int packageCount = 1; packageCount < packageElementCount + 1; packageCount++) {
				IRPModelElement modelElement = (IRPModelElement) packageElementsMetaClass.getItem(packageCount);
				if (modelElement.getName().equals("Components")) {
					IRPCollection compPackageElementsMetaClass = ((IRPModelElement) modelElement)
							.getNestedElementsByMetaClass("Class", 0);
					int compPackageElementCount = compPackageElementsMetaClass.getCount();
					if (compPackageElementCount > 0) {
						for (int compPackageCount = 1; compPackageCount < compPackageElementCount
								+ 1; compPackageCount++) {
							IRPModelElement adlModelElement = (IRPModelElement) compPackageElementsMetaClass
									.getItem(compPackageCount);
							modelElementList.add(adlModelElement);
						}
					}

				}
			}
		}

		// set a input for listSelectionDialog
		ListSelectionDialog componentsDialog = new ListSelectionDialog(Display.getDefault().getActiveShell(),
				modelElementList, new ArrayContentProvider(), new ListSelectionLabelProvider(),
				"Select the Components");
		componentsDialog.setTitle("MCC-Components");

		if (IDialogConstants.OK_ID == componentsDialog.open()) {
			Object[] selectedComponent = componentsDialog.getResult();
			for (Object adlModelElement : selectedComponent) {
				if (adlModelElement instanceof IRPModelElement) {
					boolean needOverride = false;
					List<Component> existingComponents = getExistingComponents(
							((IRPModelElement) adlModelElement).getName());
					if (!existingComponents.isEmpty()) {
						needOverride = MessageDialog.openConfirm(Display.getDefault().getActiveShell(), "Confirm",
								"Do you want to override the component?");
					}
					if (existingComponents.isEmpty() || needOverride) {
						if (!needOverride) {
							Component component = ArchitecturetoolFactory.eINSTANCE.createComponent();
							component.setName(((IRPModelElement) adlModelElement).getName());
							mcc.getComponents().add(component);

							IRPCollection portPackageElementsMetaClass = ((IRPModelElement) adlModelElement)
									.getNestedElementsByMetaClass("SysMLPort", 0);
							int portPackageElementCount = portPackageElementsMetaClass.getCount();
							Ports ports = ArchitecturetoolFactory.eINSTANCE.createPorts();
							component.setPorts(ports);
							if (portPackageElementCount > 0) {
								for (int portPackageCount = 1; portPackageCount < portPackageElementCount
										+ 1; portPackageCount++) {
									IRPModelElement portModelElement = (IRPModelElement) portPackageElementsMetaClass
											.getItem(portPackageCount);
									RPSysMLPort sysMLPort = (RPSysMLPort) portModelElement;
									IRPClassifier type = sysMLPort.getType();
									String portDirection = sysMLPort.getPortDirection();
									String name = portModelElement.getName();
									Port port = ArchitecturetoolFactory.eINSTANCE.createPort();
									port.setName(name);
									Generator generator = ArchitecturetoolFactory.eINSTANCE.createGenerator();
									generator.setName(type.getName());
									DataStructure newDataStruct = ArchitecturetoolFactory.eINSTANCE
											.createDataStructure();
									newDataStruct.setName(type.getName());
									newDataStruct.setDescription(type.getDescription());
									generator.getDatastructure().add(newDataStruct);
									component.getGenerator().add(generator);
									port.setType(newDataStruct);
									if (portDirection.equalsIgnoreCase("Out")) {
										port.setPortDirection(PortListType.PROVIDER);
									} else {
										port.setPortDirection(PortListType.REQUEST);
									}
									ports.getPort().add(port);

								}
							}

							IRPCollection runnablePackageElementsMetaClass = ((IRPModelElement) adlModelElement)
									.getNestedElementsByMetaClass("Operation", 0);
							int runnablePackageElementCount = runnablePackageElementsMetaClass.getCount();
							Runnable createRunnable = ArchitecturetoolFactory.eINSTANCE.createRunnable();
							Runnables runnables = ArchitecturetoolFactory.eINSTANCE.createRunnables();
							component.setRunnables(runnables);
							if (runnablePackageElementCount > 0) {
								for (int runnablePackageCount = 1; runnablePackageCount < runnablePackageElementCount
										+ 1; runnablePackageCount++) {
									IRPModelElement runnableModelElement = (IRPModelElement) runnablePackageElementsMetaClass
											.getItem(runnablePackageCount);
									Runnable runnable = createRunnable;
									runnable.setName(runnableModelElement.getName());

									IRPCollection dependencies = runnableModelElement.getDependencies();
									if (dependencies.getCount() > 0) {
										for (int depPackageCount = 1; depPackageCount < dependencies.getCount()
												+ 1; depPackageCount++) {
											IRPModelElement depModelElement = (IRPModelElement) dependencies
													.getItem(depPackageCount);
											Port existingPort = getExistingPort(depModelElement.getName(), component);
											if (existingPort != null) {
												runnable.getPorts().add(existingPort);
											}

										}

									}
									runnables.getRunnable().add(runnable);

								}
							}
							MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Import Components from Components",
									"Components are imported succussfully");
						} else {
							for (Component component : existingComponents) {
								if (component.getName()
										.equalsIgnoreCase(((IRPModelElement) adlModelElement).getName())) {

									IRPCollection portPackageElementsMetaClass = ((IRPModelElement) adlModelElement)
											.getNestedElementsByMetaClass("SysMLPort", 0);
									int portPackageElementCount = portPackageElementsMetaClass.getCount();

									if (portPackageElementCount > 0) {
										for (int portPackageCount = 1; portPackageCount < portPackageElementCount
												+ 1; portPackageCount++) {
											IRPModelElement portModelElement = (IRPModelElement) portPackageElementsMetaClass
													.getItem(portPackageCount);
											RPSysMLPort sysMLPort = (RPSysMLPort) portModelElement;
											IRPClassifier type = sysMLPort.getType();
											String portDirection = sysMLPort.getPortDirection();
											String name = portModelElement.getName();
											EList<Port> ports1 = component.getPorts().getPort();
											for (Port port : ports1) {

												DataStructure existingDataStructure = getExistingDataStructure(
														component, type.getName());
												Generator existingGenerator = getExistingGenerator(component,
														type.getName());
												if (existingGenerator != null && existingComponents != null) {
													existingGenerator.getDatastructure().add(existingDataStructure);
													component.getGenerator().add(existingGenerator);
												} else {
													Generator generator = ArchitecturetoolFactory.eINSTANCE
															.createGenerator();
													generator.setName(type.getName());
													DataStructure newDataStruct = ArchitecturetoolFactory.eINSTANCE
															.createDataStructure();
													newDataStruct.setName(type.getName());
													generator.getDatastructure().add(newDataStruct);
													component.getGenerator().add(generator);
													existingDataStructure = newDataStruct;
												}
												port.setType(existingDataStructure);
												if (port.getName().equalsIgnoreCase(name)) {
													if (portDirection.equalsIgnoreCase("Out")) {
														port.setPortDirection(PortListType.PROVIDER);
													} else {
														port.setPortDirection(PortListType.REQUEST);
													}
												}
											}

										}
									}
									MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Import Components from Components",
											"Components are imported succussfully");

								}
							}
						}

					}

				}

			}

		}
	}

	private Generator getExistingGenerator(Component component, String name) {
		// TODO Auto-generated method stub
		EList<Generator> generators = component.getGenerator();
		for (Generator generator : generators) {
			EList<DataStructure> datastructures = generator.getDatastructure();
			for (DataStructure dataStructure : datastructures) {
				if (dataStructure.getName().equalsIgnoreCase(name)) {
					return generator;
				}
			}
		}
		return null;
	}

	private Runnable getExistingRunnable(Component component, String name) {
		// TODO Auto-generated method stub
		EList<Runnable> runnables = component.getRunnables().getRunnable();
		for (Runnable runnable : runnables) {
			if (runnable.getName().equalsIgnoreCase(name)) {
				return runnable;
			}
		}
		return null;

	}

	private DataStructure getExistingDataStructure(Component component, String name) {
		// TODO Auto-generated method stub
		EList<Generator> generators = component.getGenerator();
		for (Generator generator : generators) {
			EList<DataStructure> datastructures = generator.getDatastructure();
			for (DataStructure dataStructure : datastructures) {
				if (dataStructure.getName().equalsIgnoreCase(name)) {
					return dataStructure;
				}
			}
		}

		return null;
	}

	

	public List<Component> getExistingComponents(String componentName) {
		List<Component> componentList = new ArrayList<Component>();
		EList<Component> components = mcc.getComponents();
		for (Component component : components) {
			if (component.getName().equalsIgnoreCase(componentName)) {
				componentList.add(component);
			}
		}
		return componentList;
	}

	public Port getExistingPort(String portName, Component newComponent) {
		EList<Port> ports = newComponent.getPorts().getPort();
		for (Port port : ports) {
			if (port.getName().equalsIgnoreCase(portName)) {
				return port;
			}
		}
		return null;
	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
			Object firstElement = iStructuredSelection.getFirstElement();
			if (firstElement instanceof MCC) {
				mcc = (MCC) firstElement;
			}

		}

	}

	

}
