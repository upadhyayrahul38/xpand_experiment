package com.conti.component.ui.decorators;

import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IDecoration;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ILightweightLabelDecorator;
import org.eclipse.swt.widgets.Display;

import com.conti.component.ui.Activator;

import architecturetool.Component;
import architecturetool.Port;
import architecturetool.Ports;

public class ArchitectureToolLabelDecorator implements ILightweightLabelDecorator {

	@Override
	public void addListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isLabelProperty(Object element, String property) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void removeListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void decorate(Object element, IDecoration decoration) {
		if (element instanceof Component) {
			boolean flag = false;
			Component component = (Component) element;
			if (component.getPorts() != null) {
				EList<Port> port = component.getPorts().getPort();
				EList<Port> portCopy = component.getPorts().getPort();
				boolean isEqual = false;

				for (Iterator<Port> iterator = port.iterator(); iterator.hasNext();) {
					Port port2 = (Port) iterator.next();

					for (Iterator<Port> iterator2 = portCopy.iterator(); iterator2.hasNext();) {
						Port port3 = (Port) iterator2.next();
						if (port.indexOf(port3) == portCopy.indexOf(port2))
							continue;
						flag = EcoreUtil.equals(port2, port3);
						if (flag)
							break;
					}
					if (flag) {
						decoration.addOverlay(
								Activator.imageDescriptorFromPlugin(Activator.PLUGIN_ID, "icons/error_ovr.gif"),
								IDecoration.BOTTOM_RIGHT);

					}
				}

				decoration.addSuffix("[SubComponents :" + component.getSubcomponent().size() + "]  " + "[Generators :"
						+ component.getGenerator().size() + "]");
			}
		} else if (element instanceof Ports) {
			boolean flag = false;
			Ports ports = (Ports) element;
			if (ports.getPort() != null) {
				EList<Port> port = ports.getPort();
				EList<Port> portCopy = ports.getPort();

				for (Iterator<Port> iterator = port.iterator(); iterator.hasNext();) {
					Port port2 = (Port) iterator.next();

					for (Iterator<Port> iterator2 = portCopy.iterator(); iterator2.hasNext();) {
						Port port3 = (Port) iterator2.next();
						if (port.indexOf(port3) == portCopy.indexOf(port2))
							continue;
						flag = EcoreUtil.equals(port2, port3);
						if (flag)
							break;
					}
					if (flag) {
						decoration.addOverlay(
								Activator.imageDescriptorFromPlugin(Activator.PLUGIN_ID, "icons/error_ovr.gif"),
								IDecoration.BOTTOM_RIGHT);

					}
				}

				decoration.addSuffix("[Ports :" + ports.getPort().size() + "]");
			}
		}
	}

}
