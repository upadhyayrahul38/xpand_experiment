package com.conti.component.ui.editor.detailspage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Memory;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;

public class MemoryRegionDetailPage implements IDetailsPage ,VerifyListener,ModifyListener{

	private IManagedForm managedForm;
	private Text textStartAdd;
	private Text textEndAdd;
	private architecturetool.MemoryRegion memoryRegion;

	/**
	 * Create the details page.
	 */
	public MemoryRegionDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//	
		UtillVerifyListener listener=new UtillVerifyListener();
		Section sctnMemoryRegion = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		sctnMemoryRegion.setText("Memory Region");
		//
		Composite composite = toolkit.createComposite(sctnMemoryRegion, SWT.NONE);
		toolkit.paintBordersFor(composite);
		sctnMemoryRegion.setClient(composite);
		composite.setLayout(new GridLayout(2, false));
		
		Label lblStartAddress = new Label(composite, SWT.NONE);
		lblStartAddress.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblStartAddress, true, true);
		lblStartAddress.setText("Start Address");
		
		textStartAdd = new Text(composite, SWT.BORDER);
		
		textStartAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textStartAdd.setData(ArchitecturetoolPackage.Literals.MEMORY_REGION__START_ADDRESS);
		textStartAdd.addModifyListener(this);
		textStartAdd.addVerifyListener(listener);
		toolkit.adapt(textStartAdd, true, true);
		
		Label lblEndAddress = new Label(composite, SWT.NONE);
		lblEndAddress.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblEndAddress, true, true);
		lblEndAddress.setText("End Address");
		
		textEndAdd = new Text(composite, SWT.BORDER);
		textEndAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textEndAdd.setData(ArchitecturetoolPackage.Literals.MEMORY_REGION__END_ADDRESS);
		textEndAdd.addModifyListener(this);
		textEndAdd.addModifyListener(new ModifyListener() {
			
			@Override
			public void modifyText(ModifyEvent e) {
				Memory memory = (Memory) memoryRegion.eContainer();
				int memorySize = memory.getSize();
				int startSize = Integer.valueOf(textStartAdd.getText());
				int endSize = Integer.valueOf(textEndAdd.getText());
				if(endSize-startSize>0 || endSize-startSize==0){
					if(memorySize<(endSize-startSize))
					{
						managedForm.getForm().setMessage("Diffrence of End Address and Start Address should be less then Memory size", IMessageProvider.ERROR);	

					}
					else
						managedForm.getForm().setMessage(null, 0);
					}
					
			}
		});
		textEndAdd.addVerifyListener(listener);
		toolkit.adapt(textEndAdd, true, true);
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		textStartAdd.setText(String.valueOf(memoryRegion.getStartAddress()));
		textEndAdd.setText(String.valueOf(memoryRegion.getEndAddress()));
		}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1)
		{
			memoryRegion = (architecturetool.MemoryRegion) structuredSelection.getFirstElement();
		}
		else
			memoryRegion=null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (data instanceof EAttribute) {
				EAttribute attribute = (EAttribute) data;
				if(attribute.getEAttributeType().getName().equals("EString"))
					memoryRegion.eSet(data, ((Text)source).getText());
				if(attribute.getEAttributeType().getName().equals("EInt"))
					memoryRegion.eSet(data, Integer.parseInt(((Text) source).getText()));
			}
		}
		
	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
