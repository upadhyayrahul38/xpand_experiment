package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Enum;
import architecturetool.Generator;
import architecturetool.Literal;

public class EnumDetailPage implements IDetailsPage, ModifyListener {
	private class TableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Literal) {
				Literal literal = (Literal) element;
				switch (columnIndex) {
				case 0:
					return literal.getName();
					
				}
			}
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtDesc;
	private Table table;
	private Enum enu;
	private TableViewer tableViewer;

	/**
	 * Create the details page.
	 */
	public EnumDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Enum");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));

		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");

		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.ENUM__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);

		Label lblDescription = new Label(composite, SWT.NONE);
		lblDescription.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblDescription, true, true);
		lblDescription.setText("Description");

		txtDesc = new Text(composite, SWT.BORDER);
		txtDesc.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtDesc.setData(ArchitecturetoolPackage.Literals.ENUM__DESCRIPTION);
		txtDesc.addModifyListener(this);
		toolkit.adapt(txtDesc, true, true);
		new Label(composite, SWT.NONE);
		new Label(composite, SWT.NONE);

		tableViewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(table);
		toolkit.paintBordersFor(table);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tblclmnLiterals = new TableColumn(table, SWT.NONE);
		tblclmnLiterals.setWidth(507);
		tblclmnLiterals.setText("Literals");
		
		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1));
		toolkit.adapt(composite_1);
		toolkit.paintBordersFor(composite_1);
		composite_1.setLayout(new GridLayout(1, false));
				
						Button btnNewButton = new Button(composite_1, SWT.NONE);
						btnNewButton.addSelectionListener(new SelectionAdapter() {
							@Override
							public void widgetSelected(SelectionEvent e) {
								ElementListSelectionDialog dialog = new ElementListSelectionDialog(
										Display.getDefault().getActiveShell(), new LabelProvider() {
											@Override
											public String getText(Object element) {
												if (element instanceof Literal) {
													Literal literal = (Literal) element;
													return literal.getName();

												}
												return super.getText(element);
											}
										});
								Generator generator = (Generator) enu.eContainer();
								ArrayList<Literal> arrayList=new ArrayList<Literal>();
								EList<Enum> enum1 = generator.getEnum();
								for (Enum enum2 : enum1) {
									EList<Literal> literal = enum2.getLiteral();
									arrayList.addAll(literal);
								}
								
								dialog.setElements(arrayList.toArray());
								dialog.open();
								Literal firstResult = (Literal) dialog.getFirstResult();
								if(firstResult!=null)
								enu.getLiteral().add(firstResult);
								tableViewer.refresh();
							}
						});
						toolkit.adapt(btnNewButton, true, true);
						btnNewButton.setText(".....");
						
						Button button = new Button(composite_1, SWT.NONE);
						button.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_ETOOL_DELETE));
						button.addSelectionListener(new SelectionAdapter() {
							@Override
							public void widgetSelected(SelectionEvent e) {
								IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
								if(!selection.isEmpty())
								{
									Iterator iterator = selection.iterator();
									while (iterator.hasNext()) {
										Object object = (Object) iterator.next();
										enu.getLiteral().remove(object);
										
									}
								}
								tableViewer.refresh();
							}
						});
						toolkit.adapt(button, true, true);
		
		tableViewer.setLabelProvider(new TableLabelProvider());
		tableViewer.setContentProvider(new ArrayContentProvider());
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if (enu.getName() != null) {
			txtName.setText(enu.getName());
		}
		if (enu.getDescription() != null) {
			txtDesc.setText(enu.getDescription());
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			enu = (Enum) structuredSelection.getFirstElement();
		} else
			enu = null;
		tableViewer.setInput(enu.getLiteral());
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature eStructuralFeature = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
			enu.eSet(eStructuralFeature, ((Text) source).getText());
			}

		}

	}

}
