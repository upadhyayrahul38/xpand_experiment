package com.conti.component.ui.editor;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.dnd.DragSourceEvent;
import org.eclipse.swt.dnd.DragSourceListener;
import org.eclipse.swt.dnd.TextTransfer;

import architecturetool.DataStructure;

public class TreeDragSourceListener implements DragSourceListener {

	private TreeViewer treeViewer;

	public TreeDragSourceListener(TreeViewer treeViewer) {
		this.treeViewer = treeViewer;
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public void dragStart(DragSourceEvent event) {
		 System.out.println("Start Drag");
		
	}
	@Override
	public void dragSetData(DragSourceEvent event) {
		  IStructuredSelection selection = treeViewer.getStructuredSelection();
		  EObject firstElement = (EObject) selection.getFirstElement();

	        if (TextTransfer.getInstance().isSupportedType(event.dataType)) {
	            event.data = firstElement.toString();
	        }
		
	}
	@Override
	public void dragFinished(DragSourceEvent event) {
		 System.out.println("Finshed Drag");
	}

	

}
