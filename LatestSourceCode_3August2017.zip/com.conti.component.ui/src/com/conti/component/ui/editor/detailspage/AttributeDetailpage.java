package com.conti.component.ui.editor.detailspage;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.AttributeTypeEnum;
import architecturetool.DataStructure;
import architecturetool.DatatypeEnum;
import architecturetool.Enum;
import architecturetool.Generator;
import architecturetool.PhysicalUnitEnum;
import architecturetool.impl.DataStructureImpl;
import architecturetool.impl.GeneratorImpl;

public class AttributeDetailpage implements IDetailsPage, ModifyListener,VerifyListener {

	private IManagedForm managedForm;
	private Text txtDescription;
	private Text txtTypeAccuracy;
	private Text txtArraySize;
	private Combo cmbPhysicalUnit;
	private Text txtAccuracy;
	private Text txtInterfaceVersion;
	private Combo cmbAttributeType;
	private Label lblDataType;
	private Combo cmbDataType;
	private Label lblEnum;
	private Text txtEnum;
	private Button btnenum;
	private Attribute attribute;
	private Label lblName;
	private Text textName;
	private Label lblInterfaceVersion;

	/**
	 * Create the details page.
	 */
	public AttributeDetailpage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		UtillVerifyListener verifyListener = new UtillVerifyListener();
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Attribute");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));
		
		lblName = new Label(composite, SWT.NONE);
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");
		
		textName = new Text(composite, SWT.BORDER);
		textName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textName.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__NAME);
		textName.addModifyListener(this);
		toolkit.adapt(textName, true, true);
		new Label(composite, SWT.NONE);
		Label lblDescriotion = new Label(composite, SWT.NONE);
		toolkit.adapt(lblDescriotion, true, true);
		lblDescriotion.setText("Description");

		txtDescription = new Text(composite, SWT.BORDER);
		txtDescription.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtDescription.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__DESCRIPTION);
		txtDescription.addModifyListener(this);
		toolkit.adapt(txtDescription, true, true);
		new Label(composite, SWT.NONE);

		Label lblTypeAccuracy = new Label(composite, SWT.NONE);
		toolkit.adapt(lblTypeAccuracy, true, true);
		lblTypeAccuracy.setText("Type Accuracy");

		txtTypeAccuracy = new Text(composite, SWT.BORDER);
		txtTypeAccuracy.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtTypeAccuracy.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__TYPE_ACCURACY);
		txtTypeAccuracy.addModifyListener(this);
		txtTypeAccuracy.addVerifyListener(verifyListener);
		toolkit.adapt(txtTypeAccuracy, true, true);
		new Label(composite, SWT.NONE);

		Label lblAttributeType = new Label(composite, SWT.NONE);
		toolkit.adapt(lblAttributeType, true, true);
		lblAttributeType.setText("Attribute Type");

		cmbAttributeType = new Combo(composite, SWT.READ_ONLY);

		cmbAttributeType.setItems(
				new String[] { AttributeTypeEnum.BASIC_TYPE.toString(), AttributeTypeEnum.ENUM_TYPE.toString() });
		cmbAttributeType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		cmbAttributeType.setData(ArchitecturetoolPackage.Literals.ATTRIBUTE__ATTRIBUTE_TYPE);
		cmbAttributeType.addModifyListener(this);
		toolkit.adapt(cmbAttributeType);
		toolkit.paintBordersFor(cmbAttributeType);
		
		new Label(composite, SWT.NONE);

		lblDataType = new Label(composite, SWT.NONE);
		toolkit.adapt(lblDataType, true, true);
		lblDataType.setText("Data Type");

		cmbDataType = new Combo(composite, SWT.READ_ONLY);
		cmbDataType.setItems(new String[] { DatatypeEnum.BOOLEAN.toString(), DatatypeEnum.SINT8.toString(),
				DatatypeEnum.UNIT8.toString(), DatatypeEnum.SINT16.toString(), DatatypeEnum.UNIT16.toString(),
				DatatypeEnum.SINT32.toString(), DatatypeEnum.UNIT32.toString(), DatatypeEnum.FLOAT32.toString() });

		cmbDataType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		cmbDataType.setData(ArchitecturetoolPackage.Literals.ATTRIBUTE__DATA_TYPE);
		cmbDataType.addModifyListener(this);
		toolkit.adapt(cmbDataType);
		toolkit.paintBordersFor(cmbDataType);
		cmbAttributeType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (cmbAttributeType.getText().equals(AttributeTypeEnum.BASIC_TYPE.getName())) {

					lblDataType.setVisible(true);
					cmbDataType.setVisible(true);
					
					txtInterfaceVersion.setVisible(false);
					lblInterfaceVersion.setVisible(false);
					lblEnum.setVisible(false);
					txtEnum.setVisible(false);
					btnenum.setVisible(false);
				} else if (cmbAttributeType.getText().equals(AttributeTypeEnum.ENUM_TYPE.getName())) {
					lblDataType.setVisible(false);
					cmbDataType.setVisible(false);

					lblEnum.setVisible(true);
					txtEnum.setVisible(true);
					btnenum.setVisible(true);
					txtInterfaceVersion.setVisible(true);
					lblInterfaceVersion.setVisible(true);
				}
			}
		});
		new Label(composite, SWT.NONE);

		lblEnum = new Label(composite, SWT.NONE);
		toolkit.adapt(lblEnum, true, true);
		lblEnum.setText("Enum");

		txtEnum = new Text(composite, SWT.BORDER);
		txtEnum.setEnabled(false);
		txtEnum.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(txtEnum, true, true);

		btnenum = new Button(composite, SWT.NONE);
		btnenum.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog= new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					
					@Override
					public String getText(Object element) {
						if (element instanceof Enum) {
							Enum enum1 = (Enum) element;
							return enum1.getName();
							
						}
						return super.getText(element);
					}
					
				});
				if(attribute.eContainer() instanceof GeneratorImpl){
					Generator generator = (Generator) attribute.eContainer();
					EList<Enum> enum1 = generator.getEnum();
					dialog.setElements(enum1.toArray());
					dialog.open();
					Enum firstResult = (Enum) dialog.getFirstResult();
					txtEnum.setText(firstResult.getName());
					attribute.setEnum(firstResult);
				}
				else if(attribute.eContainer() instanceof DataStructureImpl)	{
					Generator generator = (Generator) attribute.eContainer().eContainer();
					EList<Enum> enum1 = generator.getEnum();
					dialog.setElements(enum1.toArray());
					dialog.open();
					Enum firstResult = (Enum) dialog.getFirstResult();
					txtEnum.setText(firstResult.getName());
					attribute.setEnum(firstResult);
				}
				
			}
		});
		toolkit.adapt(btnenum, true, true);
		btnenum.setText("......");

		
		
		Label lblArraySize = new Label(composite, SWT.NONE);
		toolkit.adapt(lblArraySize, true, true);
		lblArraySize.setText("Array Size");

		txtArraySize = new Text(composite, SWT.BORDER);
		txtArraySize.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtArraySize.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__ARRAY_SIZE);
		txtArraySize.addModifyListener(this);
		txtArraySize.addVerifyListener(verifyListener);
		toolkit.adapt(txtArraySize, true, true);
		new Label(composite, SWT.NONE);

		Label lblPhysicalUnit = new Label(composite, SWT.NONE);
		toolkit.adapt(lblPhysicalUnit, true, true);
		lblPhysicalUnit.setText("Physical Unit");

		cmbPhysicalUnit = new Combo(composite, SWT.READ_ONLY);
		cmbPhysicalUnit.setItems(new String[] { PhysicalUnitEnum.NOUNIT.toString(), PhysicalUnitEnum.METER.toString(),
				PhysicalUnitEnum.SQUAREMETER.toString(), PhysicalUnitEnum.SECOND.toString(),
				PhysicalUnitEnum.METERPERSECOND.toString(), PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED.toString(),
				PhysicalUnitEnum.METERPERSECONDSQUARED.toString(), PhysicalUnitEnum.METERPERSECONDCUBED.toString(),
				PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED.toString(), PhysicalUnitEnum.RADIAN.toString(),
				PhysicalUnitEnum.RADIANPERSECOND.toString(), PhysicalUnitEnum.RADIANPERSECONDSQUARED.toString(),
				PhysicalUnitEnum.NEWTON.toString(), PhysicalUnitEnum.DEGREECENTIGRADE.toString(),
				PhysicalUnitEnum.NEWTONMETER.toString(), PhysicalUnitEnum.NEWTONPERRAD.toString(),
				PhysicalUnitEnum.KILOGRAM.toString(), PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER.toString(),
				PhysicalUnitEnum.DECIBEL.toString(), PhysicalUnitEnum.CURVATURE.toString(),
				PhysicalUnitEnum.CURVATURERATE.toString(), PhysicalUnitEnum.KILOMETER.toString(),
				PhysicalUnitEnum.KILOMETERPERHOUR.toString(), PhysicalUnitEnum.DEGREE.toString(),
				PhysicalUnitEnum.PERCENT.toString(), PhysicalUnitEnum.MILLISECOND.toString(),
				PhysicalUnitEnum.DECIBELPERSQUAREMETER.toString(), PhysicalUnitEnum.DEGREEPERSECOND.toString(),
				PhysicalUnitEnum.PERCENTPERSECOND.toString(), PhysicalUnitEnum.PIXEL.toString(),
				PhysicalUnitEnum.MICROSECOND.toString(), PhysicalUnitEnum.BYTE.toString(),
				PhysicalUnitEnum.BIT.toString() });
		cmbPhysicalUnit.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		cmbPhysicalUnit.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT);
		cmbPhysicalUnit.addModifyListener(this);
		toolkit.adapt(cmbPhysicalUnit, true, true);
		new Label(composite, SWT.NONE);

		Label lblAccuracy = new Label(composite, SWT.NONE);
		toolkit.adapt(lblAccuracy, true, true);
		lblAccuracy.setText("Accuracy");

		txtAccuracy = new Text(composite, SWT.BORDER);
		txtAccuracy.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtAccuracy.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__ACCURACY);
		txtAccuracy.addModifyListener(this);
		txtAccuracy.addModifyListener(this);
		txtAccuracy.addVerifyListener(verifyListener);
		toolkit.adapt(txtAccuracy, true, true);
		new Label(composite, SWT.NONE);

		lblInterfaceVersion = new Label(composite, SWT.NONE);
		toolkit.adapt(lblInterfaceVersion, true, true);
		lblInterfaceVersion.setText("Interface Version");

		txtInterfaceVersion = new Text(composite, SWT.BORDER);
		txtInterfaceVersion.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtInterfaceVersion.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__INTERFACE_VERSION);
		txtInterfaceVersion.addModifyListener(this);
		txtInterfaceVersion.addVerifyListener(verifyListener);
		toolkit.adapt(txtInterfaceVersion, true, true);
		new Label(composite, SWT.NONE);
		
		lblDataType.setVisible(false);
		cmbDataType.setVisible(false);
		lblEnum.setVisible(false);
		txtEnum.setVisible(false);
		btnenum.setVisible(false);
		txtInterfaceVersion.setVisible(false);
		lblInterfaceVersion.setVisible(false);

	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {

		if (attribute.getName() != null) {
			textName.setText(attribute.getName());
		}
		else {
			textName.setText("");
		}
		
		if (attribute.getEnum() != null) {
			txtEnum.setText(attribute.getEnum().getName());
		}
		else {
			txtEnum.setText("");
		}
		
		if (attribute.getDescription() != null) {
			txtDescription.setText(attribute.getDescription());
		} else {
			txtDescription.setText("");
		}
	
		if (attribute.getAttributeType().equals(AttributeTypeEnum.BASIC_TYPE)) {
			cmbAttributeType.select(0);
			lblDataType.setVisible(true);
			cmbDataType.setVisible(true);
			txtInterfaceVersion.setVisible(false);
			lblInterfaceVersion.setVisible(false);
			lblEnum.setVisible(false);
			txtEnum.setVisible(false);
			btnenum.setVisible(false);
		}else if (attribute.getAttributeType().equals(AttributeTypeEnum.ENUM_TYPE)) {
			cmbAttributeType.select(1);
			lblDataType.setVisible(false);
			cmbDataType.setVisible(false);
			
			txtInterfaceVersion.setVisible(true);
			lblInterfaceVersion.setVisible(true);
			lblEnum.setVisible(true);
			txtEnum.setVisible(true);
			btnenum.setVisible(true);
		}
		if (attribute.getDataType().equals(DatatypeEnum.BOOLEAN)) {
			cmbDataType.select(0);
		} else if (attribute.getDataType().equals(DatatypeEnum.SINT8)) {
			cmbDataType.select(1);
		} else if (attribute.getDataType().equals(DatatypeEnum.UNIT8)) {
			cmbDataType.select(2);
		} else if (attribute.getDataType().equals(DatatypeEnum.SINT16)) {
			cmbDataType.select(3);
		} else if (attribute.getDataType().equals(DatatypeEnum.UNIT16)) {
			cmbDataType.select(4);
		} else if (attribute.getDataType().equals(DatatypeEnum.SINT32)) {
			cmbDataType.select(5);
		} else if (attribute.getDataType().equals(DatatypeEnum.UNIT32)) {
			cmbDataType.select(6);
		} else if (attribute.getDataType().equals(DatatypeEnum.FLOAT32)) {
			cmbDataType.select(7);
		}
		txtAccuracy.setText(String.valueOf(attribute.getAccuracy()));
		txtArraySize.setText(String.valueOf(attribute.getArraySize()));
		if (attribute.getDescription() != null) {
			txtDescription.setText(attribute.getDescription());
		}
		txtTypeAccuracy.setText(String.valueOf(attribute.getTypeAccuracy()));
		txtInterfaceVersion.setText(String.valueOf(attribute.getInterfaceVersion()));

		if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.NOUNIT)) {
			cmbPhysicalUnit.select(0);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.METER)) {
			cmbPhysicalUnit.select(1);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.SQUAREMETER)) {
			cmbPhysicalUnit.select(2);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.SECOND)) {
			cmbPhysicalUnit.select(3);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECOND)) {
			cmbPhysicalUnit.select(4);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(5);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(6);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDCUBED)) {
			cmbPhysicalUnit.select(7);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED)) {
			cmbPhysicalUnit.select(8);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.RADIAN)) {
			cmbPhysicalUnit.select(9);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANPERSECOND)) {
			cmbPhysicalUnit.select(10);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(11);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTON)) {
			cmbPhysicalUnit.select(12);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREECENTIGRADE)) {
			cmbPhysicalUnit.select(13);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTONMETER)) {
			cmbPhysicalUnit.select(14);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTONPERRAD)) {
			cmbPhysicalUnit.select(15);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.KILOGRAM)) {
			cmbPhysicalUnit.select(16);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER)) {
			cmbPhysicalUnit.select(17);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.DECIBEL)) {
			cmbPhysicalUnit.select(18);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.CURVATURE)) {
			cmbPhysicalUnit.select(19);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.CURVATURERATE)) {
			cmbPhysicalUnit.select(20);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.KILOMETER)) {
			cmbPhysicalUnit.select(21);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.KILOMETERPERHOUR)) {
			cmbPhysicalUnit.select(22);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREE)) {
			cmbPhysicalUnit.select(23);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.PERCENT)) {
			cmbPhysicalUnit.select(24);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.MILLISECOND)) {
			cmbPhysicalUnit.select(25);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.DECIBELPERSQUAREMETER)) {
			cmbPhysicalUnit.select(26);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREEPERSECOND)) {
			cmbPhysicalUnit.select(27);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.PERCENTPERSECOND)) {
			cmbPhysicalUnit.select(28);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.PIXEL)) {
			cmbPhysicalUnit.select(29);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.MICROSECOND)) {
			cmbPhysicalUnit.select(30);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.BYTE)) {
			cmbPhysicalUnit.select(31);
		} else if (attribute.getPhysicalUnit().equals(PhysicalUnitEnum.BIT)) {
			cmbPhysicalUnit.select(32);
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1)
			attribute = (Attribute) structuredSelection.getFirstElement();
		else
			attribute = null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					attribute.eSet(data, ((Text) source).getText());
				else if (eAttributeType.getName().equals("EInt")&&!(((Text) source).getText().isEmpty()))
					attribute.eSet(data, Integer.parseInt(((Text) source).getText().trim()));
				else if (eAttributeType.getName().equals("EFloat"))
					attribute.eSet(data, Float.parseFloat(((Text) source).getText()));
			}
			

		} else if (source instanceof Combo) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (data instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("PhysicalUnitEnum"))
					attribute.eSet(data, PhysicalUnitEnum.get(((Combo) source).getText()));
				else if (eAttributeType.getName().equals("AttributeTypeEnum"))
						attribute.eSet(data, AttributeTypeEnum.get(((Combo) source).getText()));
				else if (eAttributeType.getName().equals("DatatypeEnum"))
					attribute.eSet(data, DatatypeEnum.get(((Combo) source).getText()));


			}
		}

	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
