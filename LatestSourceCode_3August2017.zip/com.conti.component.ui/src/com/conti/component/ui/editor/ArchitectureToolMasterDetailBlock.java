package com.conti.component.ui.editor;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;

import org.eclipse.emf.common.command.BasicCommandStack;
import org.eclipse.emf.common.util.ECollections;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.edit.command.CopyCommand;
import org.eclipse.emf.edit.command.RemoveCommand;
import org.eclipse.emf.edit.domain.AdapterFactoryEditingDomain;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.ui.action.CreateChildAction;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryContentProvider;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IContributionManager;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.viewers.DecoratingLabelProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DragSource;
import org.eclipse.swt.dnd.DragSourceEvent;
import org.eclipse.swt.dnd.DragSourceListener;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.TreeAdapter;
import org.eclipse.swt.events.TreeEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.CoolBar;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.forms.DetailsPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.MasterDetailsBlock;
import org.eclipse.ui.forms.SectionPart;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.editor.detailspage.AbsoluteRefrenceDetailPage;
import com.conti.component.ui.editor.detailspage.AttributeDetailpage;
import com.conti.component.ui.editor.detailspage.BuildUnitDetailPage;
import com.conti.component.ui.editor.detailspage.CPUDetailPage;
import com.conti.component.ui.editor.detailspage.ComponentDetailsPage;
import com.conti.component.ui.editor.detailspage.ComponentInstanceDetailPage;
import com.conti.component.ui.editor.detailspage.DataStructureDetailPage;
import com.conti.component.ui.editor.detailspage.ECUDetailPage;
import com.conti.component.ui.editor.detailspage.EnumDetailPage;
import com.conti.component.ui.editor.detailspage.FlowDetailPage;
import com.conti.component.ui.editor.detailspage.FunctionalReqirementDetailPage;
import com.conti.component.ui.editor.detailspage.ISRDetailPage;
import com.conti.component.ui.editor.detailspage.LiteralDetailPage;
import com.conti.component.ui.editor.detailspage.MCCDetailPage;
import com.conti.component.ui.editor.detailspage.MemoryBudgetDetailPage;
import com.conti.component.ui.editor.detailspage.MemoryDetailPage;
import com.conti.component.ui.editor.detailspage.MemoryRegionDetailPage;
import com.conti.component.ui.editor.detailspage.NodeDetailPage;
import com.conti.component.ui.editor.detailspage.OSApplicationDetailPage;
import com.conti.component.ui.editor.detailspage.ParameterDetailPage;
import com.conti.component.ui.editor.detailspage.PortDetailPage;
import com.conti.component.ui.editor.detailspage.ProcmemDetailPage;
import com.conti.component.ui.editor.detailspage.ResourceBudgetDetailpage;
import com.conti.component.ui.editor.detailspage.RunTimeBudgetdetailPage;
import com.conti.component.ui.editor.detailspage.RunnableDetailPage;
import com.conti.component.ui.editor.detailspage.SubComponentDetailPage;
import com.conti.component.ui.editor.detailspage.TaskDetailPage;
import com.conti.component.ui.popup.ExportProject;
import com.conti.component.ui.popup.GenerateARXMLAction;
import com.conti.component.ui.popup.GenerateHeaderfileAction;
import com.conti.component.ui.popup.GenerateRteHeaders;
import com.conti.component.ui.popup.GenerateSILArtifactsPar;
import com.conti.component.ui.popup.GenerateSimconFile;
import com.conti.component.ui.popup.GenerateWrapperFileAction;
import com.conti.component.ui.popup.ImportComponentInstanceFromRhapsodyAction;
import com.conti.component.ui.popup.ImportComprReqFromRhapsodyAction;
import com.conti.component.ui.popup.ImportECUInstancefromRhapsodyAction;
import com.conti.component.ui.popup.ImportNewComponentStructure;
import com.conti.component.ui.popup.ImportProject;
import com.conti.component.ui.popup.PushComponentInstanceAction;
import com.conti.component.ui.popup.PushNewStructureToRhapsody;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.BuildUnit;
import architecturetool.CPU;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.ECU;
import architecturetool.Enum;
import architecturetool.Flow;
import architecturetool.Flows;
import architecturetool.FunctionalRequirement;
import architecturetool.Generator;
import architecturetool.ISR;
import architecturetool.Literal;
import architecturetool.MCC;
import architecturetool.Memory;
import architecturetool.NoNameElement;
import architecturetool.Node;
import architecturetool.OSApplication;
import architecturetool.Parameter;
import architecturetool.Port;
import architecturetool.Ports;
import architecturetool.ProcMem;
import architecturetool.Root;
import architecturetool.Runnables;
import architecturetool.SubComponent;
import architecturetool.Task;
import architecturetool.impl.AbsoluteRefrenceImpl;
import architecturetool.impl.AttributeImpl;
import architecturetool.impl.BuildUnitImpl;
import architecturetool.impl.CPUImpl;
import architecturetool.impl.ComponentImpl;
import architecturetool.impl.ComponentInstanceImpl;
import architecturetool.impl.DataStructureImpl;
import architecturetool.impl.ECUImpl;
import architecturetool.impl.EnumImpl;
import architecturetool.impl.FlowImpl;
import architecturetool.impl.FunctionalRequirementImpl;
import architecturetool.impl.GeneratorImpl;
import architecturetool.impl.ISRImpl;
import architecturetool.impl.LiteralImpl;
import architecturetool.impl.MCCImpl;
import architecturetool.impl.MemoryBudgetImpl;
import architecturetool.impl.MemoryImpl;
import architecturetool.impl.MemoryRegionImpl;
import architecturetool.impl.NodeImpl;
import architecturetool.impl.OSApplicationImpl;
import architecturetool.impl.ParameterImpl;
import architecturetool.impl.PortImpl;
import architecturetool.impl.ProcMemImpl;
import architecturetool.impl.ResourceBudgetImpl;
import architecturetool.impl.RootImpl;
import architecturetool.impl.RunnableImpl;
import architecturetool.impl.RuntimeBudgetImpl;
import architecturetool.impl.SubComponentImpl;
import architecturetool.impl.TaskImpl;
import architecturetool.provider.ArchitecturetoolItemProviderAdapterFactory;

public class ArchitectureToolMasterDetailBlock extends MasterDetailsBlock {

	private FormToolkit toolkit;
	private TreeViewer treeViewer;
	private ComposedAdapterFactory factories;
	private AdapterFactoryEditingDomain editingDomain;
	private Action deleteAction;
	private Action undoaction;
	private EObject eObject;
	private FormEditor formEditor;
	private Action copyAction;
	private Action pasteAction;
	private Object copyElement;
	private Action importComponentAction;
	private Action importCompReqAction;
	private Action exportElementAction;
	private Action importElementAction;
	private Action importECUFromRhapsodyAction;
	private Action importComponentInstanceRhapsodyAction;
	private Action pushComponentToComponentAction;
	private Action pushCompToCompReqAction;
	private Action generateSILParAction;
	private Action generateSILSimconAction;
	private Action generateRTEAction;
	private Action generateECUExtractAction;
	private Action generateHeaderAction;
	private Action generateWrapperAction;

	/**
	 * Create the master details block.
	 * 
	 * @param eObject
	 * @param formEditor
	 */
	public ArchitectureToolMasterDetailBlock(EObject eObject, FormEditor formEditor) {
		this.eObject = eObject;
		this.seteObject(eObject);
		this.formEditor = formEditor;
		factories = new ComposedAdapterFactory();
		factories.addAdapterFactory(new ArchitecturetoolItemProviderAdapterFactory());

		BasicCommandStack commandStack = new BasicCommandStack();
		editingDomain = new AdapterFactoryEditingDomain(factories, commandStack);
	}

	/**
	 * Create contents of the master details block.
	 * 
	 * @param managedForm
	 * @param parent
	 */
	@Override
	protected void createMasterPart(IManagedForm managedForm, Composite parent) {
		toolkit = managedForm.getToolkit();
		//
		Section sctnArchitectureConfiguration = toolkit.createSection(parent, Section.EXPANDED | Section.TITLE_BAR);
		sctnArchitectureConfiguration.setText("Architecture Configuration");
		//
		Composite composite = toolkit.createComposite(sctnArchitectureConfiguration, SWT.NONE);
		toolkit.paintBordersFor(composite);
		sctnArchitectureConfiguration.setClient(composite);
		composite.setLayout(new GridLayout(1, false));

		final SectionPart spart = new SectionPart(sctnArchitectureConfiguration);
		managedForm.addPart(spart);

		treeViewer = new TreeViewer(composite, SWT.BORDER);
		Tree tree = treeViewer.getTree();
		treeViewer.setSorter(new ViewerSorter() {
			@Override
			public int compare(Viewer viewer, Object e1, Object e2) {
				// TODO Auto-generated method stub
				
				if (e1 instanceof Component && e2 instanceof Component) {
					Component s2 = (Component) e1;
					Component s1 = (Component) e2;
				if (s1.getName()!=null && s2.getName()!=null) {
					return s2.getName().compareToIgnoreCase(s1.getName());
				}
				
				}
				return 0;
			}

		});

		

		DecoratingLabelProvider dlp = new DecoratingLabelProvider(new AdapterFactoryLabelProvider(factories),
				PlatformUI.getWorkbench().getDecoratorManager());

		treeViewer.setContentProvider(new AdapterFactoryContentProvider(factories));
		treeViewer.setLabelProvider(dlp);

		NoNameElement createNoNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
		createNoNameElement.setName("x");
		MCC createMCC = ArchitecturetoolFactory.eINSTANCE.createMCC();
		createNoNameElement.getMcc().add(createMCC);

		int operations = DND.DROP_COPY | DND.DROP_MOVE;
		Transfer[] transferTypes = new Transfer[] { TextTransfer.getInstance() };
		treeViewer.addDragSupport(operations, transferTypes, new TreeDragSourceListener(treeViewer));
		treeViewer.addDropSupport(operations, transferTypes, new TreeDropListener(treeViewer));
		// treeViewer.setInput(createNoNameElement);

		EObject geteObject = geteObject();
		if (geteObject == null) {
			treeViewer.setInput(createNoNameElement);
		} else {

			NoNameElement cNoNameElement = null;
			if (geteObject instanceof MCC) {
				MCC mcc = ((MCC) geteObject);
				cNoNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
				cNoNameElement.setName("WQ");
				cNoNameElement.getMcc().add(mcc);

				treeViewer.setInput(cNoNameElement);
			} else if (geteObject instanceof ECU) {
				ECU ecu = ((ECU) geteObject);
				cNoNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
				cNoNameElement.setName("WQ");
				cNoNameElement.getEcus().add(ecu);
				treeViewer.setInput(cNoNameElement);
			} else {
				treeViewer.setInput(geteObject);
			}
		}

		GridData gd_tree = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd_tree.widthHint = 292;
		tree.setLayoutData(gd_tree);
		toolkit.paintBordersFor(tree);

		treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				managedForm.fireSelectionChanged(spart, event.getSelection());

			}
		});

		createActions();
		hookContextMenu();
		formEditor.getSite().setSelectionProvider(treeViewer);

	}

	private void createActions() {
		deleteAction = new Action("Delete") {
			@Override
			public void run() {
				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();
				RemoveCommand removeCommand = null;
				if (firstElement instanceof Component) {
					Component component = ((Component) firstElement);
					MCC mcc = (MCC) component.eContainer();
					removeCommand = new RemoveCommand(editingDomain, mcc,
							ArchitecturetoolPackage.Literals.MCC__COMPONENTS, component);
					//editingDomain.getCommandStack().execute(removeCommand);
					EcoreUtil.delete(component,true);
				}

				if (firstElement instanceof ISR) {
					ISR isr = ((ISR) firstElement);
					EcoreUtil.delete(isr, true);
				}

				if (firstElement instanceof OSApplication) {
					OSApplication osApplication = ((OSApplication) firstElement);
					EcoreUtil.delete(osApplication, true);
				}

				if (firstElement instanceof BuildUnit) {
					BuildUnit buildUnit = ((BuildUnit) firstElement);
					EcoreUtil.delete(buildUnit, true);
				}

				if (firstElement instanceof Task) {
					Task task = ((Task) firstElement);
					EcoreUtil.delete(task, true);
				}

				if (firstElement instanceof Node) {
					Node node = ((Node) firstElement);
					EcoreUtil.delete(node, true);
				}

				if (firstElement instanceof Memory) {
					Memory memory = ((Memory) firstElement);
					EcoreUtil.delete(memory, true);
				}

				if (firstElement instanceof FunctionalRequirement) {
					FunctionalRequirement funcRequirement = ((FunctionalRequirement) firstElement);
					EcoreUtil.delete(funcRequirement, true);
				}

				if (firstElement instanceof CPU) {
					CPU cpu = ((CPU) firstElement);
					EcoreUtil.delete(cpu, true);
				}

				if (firstElement instanceof ECU) {
					ECU ecu = ((ECU) firstElement);
					EcoreUtil.delete(ecu, true);
				}

				if (firstElement instanceof SubComponent) {
					SubComponent subcomponent = ((SubComponent) firstElement);
					EcoreUtil.delete(subcomponent, true);
				}

				if (firstElement instanceof Runnables) {
					Runnables runnables = ((Runnables) firstElement);
					EcoreUtil.delete(runnables, true);
				}

				if (firstElement instanceof Runnable) {
					architecturetool.Runnable runnable = ((architecturetool.Runnable) firstElement);
					EcoreUtil.delete(runnable, true);
				}

				if (firstElement instanceof Parameter) {
					Parameter parameter = ((Parameter) firstElement);
					// MCC mcc = (MCC) parameter.eContainer();
					// removeCommand = new RemoveCommand(editingDomain, mcc,
					// ArchitecturetoolPackage.Literals.MCC__PARAMETERS,
					// parameter);
					// editingDomain.getCommandStack().execute(removeCommand);
					EcoreUtil.delete(parameter, true);
				}

				if (firstElement instanceof architecturetool.Runnable) {
					architecturetool.Runnable runnable = ((architecturetool.Runnable) firstElement);
					// Runnables runnables = (Runnables) runnable.eContainer();
					// removeCommand = new RemoveCommand(editingDomain,
					// runnables,
					// ArchitecturetoolPackage.Literals.RUNNABLES__RUNNABLE,
					// runnable);
					// editingDomain.getCommandStack().execute(removeCommand);
					EcoreUtil.delete(runnable, true);
				}

				if (firstElement instanceof Generator) {
					Generator generator = ((Generator) firstElement);
					EcoreUtil.delete(generator, true);
				}

				if (firstElement instanceof DataStructure) {
					DataStructure dataStructure = ((DataStructure) firstElement);
					EcoreUtil.delete(dataStructure, true);
				}

				if (firstElement instanceof Attribute) {
					Attribute attribute = ((Attribute) firstElement);
					EcoreUtil.delete(attribute, true);
				}

				if (firstElement instanceof AbsoluteRefrence) {
					AbsoluteRefrence absRef = ((AbsoluteRefrence) firstElement);
					EcoreUtil.delete(absRef, true);
				}

				if (firstElement instanceof MCC) {
					MCC mcc = ((MCC) firstElement);
					// NoNameElement noNameElement = (NoNameElement)
					// mcc.eContainer();
					// removeCommand = new RemoveCommand(editingDomain,
					// noNameElement,
					// ArchitecturetoolPackage.Literals.NO_NAME_ELEMENT__MCC,
					// mcc);
					// editingDomain.getCommandStack().execute(removeCommand);
					EcoreUtil.delete(mcc, true);
				}

				if (firstElement instanceof Ports) {
					Ports ports = ((Ports) firstElement);
					EcoreUtil.delete(ports, true);
				}

				if (firstElement instanceof Flow) {
					Flow flow = ((Flow) firstElement);
					EcoreUtil.delete(flow, true);
				}

				if (firstElement instanceof Port) {
					Port port = (Port) firstElement;
					Ports ports = (Ports) port.eContainer();
					removeCommand = new RemoveCommand(editingDomain, ports,
							ArchitecturetoolPackage.Literals.PORTS__PORT, port);
					// editingDomain.getCommandStack().execute(removeCommand);
					EcoreUtil.delete(port, true);
				}
				if (firstElement instanceof ECU) {
					ECU ecu = ((ECU) firstElement);
					EcoreUtil.delete(ecu, true);
				}
				if (firstElement instanceof Enum) {
					Enum eNum = ((Enum) firstElement);
					EcoreUtil.delete(eNum, true);
				}

				if (firstElement instanceof ProcMem) {
					ProcMem procMem = ((ProcMem) firstElement);
					EcoreUtil.delete(procMem, true);
				}
				super.run();
			}
		};
		copyAction = new Action("Copy") {

			@Override
			public void run() {
				copyElement = treeViewer.getStructuredSelection().getFirstElement();
				CopyCommand coppyCommand = null;
				if (copyElement instanceof EObject) {
					EObject eObject = ((EObject) copyElement);
					EcoreUtil.copy(eObject);
				}
			}

		};
		pasteAction = new Action("Paste") {
			@Override
			public void run() {
				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();

				if (firstElement instanceof DataStructure) {
					DataStructure dataStructure = ((DataStructure) firstElement);
					if (copyElement instanceof Attribute) {
						dataStructure.getAttributes().add((Attribute) copyElement);
					} else if (copyElement instanceof AbsoluteRefrence) {
						dataStructure.getAbsolutereference().add((AbsoluteRefrence) copyElement);
					} else if (copyElement instanceof DataStructure) {
						dataStructure.getStructs().add((DataStructure) copyElement);
					}

				} else if (firstElement instanceof MCC) {
					MCC mcc = ((MCC) firstElement);
					if (copyElement instanceof Parameter) {
						mcc.getParameters().add((Parameter) copyElement);
					} else if (copyElement instanceof Component) {
						mcc.getComponents().add((Component) copyElement);
					}
				} else if (firstElement instanceof Component) {
					Component component = (Component) firstElement;
					if (copyElement instanceof Generator) {
						component.getGenerator().add((Generator) copyElement);
					} else if (copyElement instanceof SubComponent) {
						component.getSubcomponent().add((SubComponent) copyElement);
					}
				} else if (firstElement instanceof Ports) {
					Ports ports = (Ports) firstElement;
					ports.getPort().add((Port) copyElement);
				} else if (firstElement instanceof Runnables) {
					Runnables runnables = (Runnables) firstElement;
					runnables.getRunnable().add((architecturetool.Runnable) copyElement);
				} else if (firstElement instanceof Flows) {
					Flows flows = (Flows) firstElement;
					flows.getFlow().add((Flow) copyElement);
				} else if (firstElement instanceof Enum) {
					Enum enum1 = (Enum) firstElement;
					enum1.getLiteral().add((Literal) copyElement);
				}
			}

		};
		undoaction = new Action("Undo") {
			@Override
			public void run() {
				editingDomain.getCommandStack().undo();
			}

		};

		importComponentAction = new Action("Import Components from Rhapsody") {
			@Override
			public void run() {
				ImportNewComponentStructure componentStructure = new ImportNewComponentStructure(
						treeViewer.getSelection());
				componentStructure.run();
			}

		};
		importCompReqAction = new Action("Import CompReq from Rhapsody") {
			@Override
			public void run() {
				ImportComprReqFromRhapsodyAction comprReqFromRhapsodyAction = new ImportComprReqFromRhapsodyAction(
						treeViewer.getSelection());
				comprReqFromRhapsodyAction.run();
			}

		};
		importElementAction = new Action("Import Element") {
			@Override
			public void run() {
				ImportProject importProject = new ImportProject(treeViewer.getSelection());
				importProject.run();
			}

		};
		exportElementAction = new Action("Export Element") {
			@Override
			public void run() {
				ExportProject exportProject = new ExportProject(treeViewer.getSelection());
				exportProject.run();
			}

		};
		importECUFromRhapsodyAction = new Action("Import Project from Rhapsody") {
			@Override
			public void run() {
				ImportECUInstancefromRhapsodyAction importECUInstancefromRhapsodyAction = new ImportECUInstancefromRhapsodyAction(
						treeViewer.getSelection());
				importECUInstancefromRhapsodyAction.run();
			}

		};
		importComponentInstanceRhapsodyAction = new Action("Import Component Instance from Rhapsody") {
			@Override
			public void run() {
				ImportComponentInstanceFromRhapsodyAction componentInstanceFromRhapsodyAction = new ImportComponentInstanceFromRhapsodyAction(
						treeViewer.getSelection());
				componentInstanceFromRhapsodyAction.run();
			}

		};
		pushCompToCompReqAction = new Action("Push Component to CompReq(Rhapsody)") {
			@Override
			public void run() {
				PushComponentInstanceAction componentInstanceAction = new PushComponentInstanceAction(
						treeViewer.getSelection());
				componentInstanceAction.run();
			}

		};
		pushComponentToComponentAction = new Action("Push Component to Components(Rhapsody)") {
			@Override
			public void run() {
				PushNewStructureToRhapsody pushNewStructureToRhapsody = new PushNewStructureToRhapsody(
						treeViewer.getSelection());
				pushNewStructureToRhapsody.run();
			}

		};
		generateSILParAction = new Action("Generate SIL Artifacts(Par)") {
			@Override
			public void run() {
				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();

				if (firstElement instanceof Component) {
					NoNameElement eContainer = (NoNameElement) ((Component) firstElement).eContainer().eContainer();
					GenerateSILArtifactsPar generateSILArtifactsPar = new GenerateSILArtifactsPar(eContainer, null,
							((Component) firstElement));
					generateSILArtifactsPar.run();
				}
			}

		};
		generateSILSimconAction = new Action("Generate SIL Artifacts(Simcon)") {
			@Override
			public void run() {
				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();
				if (firstElement instanceof Component) {
					NoNameElement eContainer = (NoNameElement) ((Component) firstElement).eContainer().eContainer();
					GenerateSimconFile generateSimconFile = new GenerateSimconFile(eContainer, null,
							((Component) firstElement));
					generateSimconFile.run();
				}
			}

		};
		generateRTEAction = new Action("Generate RTE Headers") {
			@Override
			public void run() {
				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();
				if (firstElement instanceof Component) {
					NoNameElement eContainer = (NoNameElement) ((Component) firstElement).eContainer().eContainer();
					GenerateRteHeaders generateRteHeaders = new GenerateRteHeaders(eContainer, null,
							((Component) firstElement));
					generateRteHeaders.run();
				}
			}

		};
		generateECUExtractAction = new Action("Generate ECUEXTRACT") {
			@Override
			public void run() {
				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();
				if (firstElement instanceof Component) {
					GenerateARXMLAction generateARXMLAction = new GenerateARXMLAction(((Component) firstElement), null);
					generateARXMLAction.run();
				}
			}

		};
		generateHeaderAction = new Action("Generate Header File") {
			@Override
			public void run() {

				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();
				if (firstElement instanceof Component) {
					GenerateHeaderfileAction generateHeaderfileAction = new GenerateHeaderfileAction(
							((Component) firstElement), null);
					generateHeaderfileAction.run();
				}
			}

		};
		generateWrapperAction = new Action("Generate Wrapper File") {
			@Override
			public void run() {

				Object firstElement = treeViewer.getStructuredSelection().getFirstElement();
				if (firstElement instanceof Component) {
					GenerateWrapperFileAction generateHeaderfileAction = new GenerateWrapperFileAction(
							((Component) firstElement), null);
					generateHeaderfileAction.run();
				}
			}

		};
	}

	private void hookContextMenu() {
		MenuManager contextMenu = new MenuManager();
		contextMenu.setRemoveAllWhenShown(true);
		contextMenu.removeAll();
		contextMenu.addMenuListener(new IMenuListener() {

			@Override
			public void menuAboutToShow(IMenuManager manager) {

				MenuManager newChildMenu = new MenuManager("New Child");
				manager.add(newChildMenu);
				MenuManager importExportMenu = new MenuManager("Architecture Tool");

				IStructuredSelection sSelection = (IStructuredSelection) treeViewer.getSelection();
				Object selectedObject = sSelection.getFirstElement();

				Collection<?> newChildDescriptors = editingDomain.getNewChildDescriptors(selectedObject, null);

				for (Object object : newChildDescriptors) {
					newChildMenu.add(new CreateChildAction(editingDomain, sSelection, object));
				}
				if (selectedObject instanceof MCC) {
					importExportMenu.add(importComponentAction);
					importExportMenu.add(importCompReqAction);
					importExportMenu.add(importElementAction);
					importExportMenu.add(exportElementAction);
				} else if (selectedObject instanceof NoNameElement) {
					importExportMenu.add(importElementAction);
					importExportMenu.add(exportElementAction);
					importExportMenu.add(importECUFromRhapsodyAction);
				} else if (selectedObject instanceof FunctionalRequirement) {
					importExportMenu.add(importComponentInstanceRhapsodyAction);
				} else if (selectedObject instanceof Component) {
					importExportMenu.add(importElementAction);
					importExportMenu.add(exportElementAction);
					importExportMenu.add(pushCompToCompReqAction);
					importExportMenu.add(pushComponentToComponentAction);
					importExportMenu.add(generateSILParAction);
					importExportMenu.add(generateSILSimconAction);
					importExportMenu.add(generateRTEAction);
					importExportMenu.add(generateECUExtractAction);
					if (((Component) selectedObject).getRunnables() != null
							&& !((Component) selectedObject).getRunnables().getRunnable().isEmpty()) {
						generateHeaderAction.setEnabled(true);
						generateWrapperAction.setEnabled(true);
						importExportMenu.add(generateHeaderAction);
						importExportMenu.add(generateWrapperAction);
					} else {
						generateHeaderAction.setEnabled(false);
						generateWrapperAction.setEnabled(false);
						importExportMenu.add(generateHeaderAction);
						importExportMenu.add(generateWrapperAction);
					}
				} else if (selectedObject instanceof ECU) {
					importExportMenu.add(importElementAction);
					importExportMenu.add(exportElementAction);

				}
				manager.add(importExportMenu);
				manager.add(deleteAction);
				manager.add(undoaction);
				manager.add(copyAction);
				manager.add(pasteAction);

			}
		});

		Menu menu = contextMenu.createContextMenu(treeViewer.getTree());
		treeViewer.getTree().setMenu(menu);

		// Brings Actions from plugin.xml
		// formEditor.getSite().registerContextMenu(contextMenu, treeViewer);

	}

	/**
	 * Register the pages.
	 * 
	 * @param part
	 */
	@Override
	protected void registerPages(DetailsPart part) {
		part.registerPage(ComponentImpl.class, new ComponentDetailsPage(this));
		part.registerPage(PortImpl.class, new PortDetailPage(this));
		part.registerPage(MCCImpl.class, new MCCDetailPage());
		part.registerPage(RunnableImpl.class, new RunnableDetailPage(this));
		part.registerPage(DataStructureImpl.class, new DataStructureDetailPage(this));
		part.registerPage(AttributeImpl.class, new AttributeDetailpage());
		part.registerPage(EnumImpl.class, new EnumDetailPage());
		part.registerPage(LiteralImpl.class, new LiteralDetailPage());
		part.registerPage(FlowImpl.class, new FlowDetailPage());
		part.registerPage(SubComponentImpl.class, new SubComponentDetailPage());
		part.registerPage(AbsoluteRefrenceImpl.class, new AbsoluteRefrenceDetailPage());
		part.registerPage(ParameterImpl.class, new ParameterDetailPage());

		part.registerPage(ECUImpl.class, new ECUDetailPage());
		part.registerPage(CPUImpl.class, new CPUDetailPage());
		part.registerPage(MemoryImpl.class, new MemoryDetailPage());
		part.registerPage(FunctionalRequirementImpl.class, new FunctionalReqirementDetailPage());
		part.registerPage(NodeImpl.class, new NodeDetailPage());
		part.registerPage(TaskImpl.class, new TaskDetailPage());
		part.registerPage(BuildUnitImpl.class, new BuildUnitDetailPage());
		part.registerPage(OSApplicationImpl.class, new OSApplicationDetailPage());
		part.registerPage(ISRImpl.class, new ISRDetailPage());
		part.registerPage(ComponentInstanceImpl.class, new ComponentInstanceDetailPage());
		part.registerPage(ResourceBudgetImpl.class, new ResourceBudgetDetailpage());
		part.registerPage(RuntimeBudgetImpl.class, new RunTimeBudgetdetailPage());
		part.registerPage(MemoryBudgetImpl.class, new MemoryBudgetDetailPage());
		part.registerPage(MemoryRegionImpl.class, new MemoryRegionDetailPage());
		part.registerPage(ProcMemImpl.class, new ProcmemDetailPage());
		sashForm.setWeights(new int[] { 1, 3 });

	}

	/**
	 * Create the toolbar actions.
	 * 
	 * @param managedForm
	 */
	@Override
	protected void createToolBarActions(IManagedForm managedForm) {
		// Create the toolbar actions
	}

	public void select(ISelection firstElement) {
		Object selectedObject = ((IStructuredSelection) firstElement).getFirstElement();
		if (selectedObject instanceof Attribute) {
			Attribute new_name = (Attribute) selectedObject;
			if (new_name.getEnum() != null) {
				treeViewer.setSelection(new StructuredSelection(new_name.getEnum()));
			} else {
				treeViewer.setSelection(firstElement);
			}
		}
		if (selectedObject instanceof DataStructure) {
			DataStructure ds_name = (DataStructure) selectedObject;
			if (ds_name != null) {
				treeViewer.setSelection(firstElement);
			}
		}
		if (selectedObject instanceof AbsoluteRefrence) {
			AbsoluteRefrence absRef_name = (AbsoluteRefrence) selectedObject;
			if (absRef_name != null) {
				treeViewer.setSelection(firstElement);
			}
		}
		if (selectedObject instanceof Port) {
			Port port_name = (Port) selectedObject;
			if (port_name != null) {
				treeViewer.setSelection(firstElement);
			}
		}

	}

	public EObject geteObject() {
		return eObject;
	}

	public void seteObject(EObject eObject) {
		this.eObject = eObject;
	}

}
