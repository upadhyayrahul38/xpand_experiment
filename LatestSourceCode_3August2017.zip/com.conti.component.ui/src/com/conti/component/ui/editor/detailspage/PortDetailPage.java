package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ResourceBundle.Control;
import java.util.Set;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.workspace.util.WorkspaceSynchronizer;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.editor.ArchitectureToolMasterDetailBlock;
import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.AttributeTypeEnum;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.DatatypeEnum;
import architecturetool.Generator;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Parameter;
import architecturetool.Port;
import architecturetool.PortListType;
import architecturetool.Ports;
import architecturetool.impl.DataStructureImpl;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.databinding.swt.WidgetProperties;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.fieldassist.ControlDecoration;
import org.eclipse.jface.fieldassist.FieldDecoration;
import org.eclipse.jface.fieldassist.FieldDecorationRegistry;
import org.eclipse.core.databinding.beans.PojoProperties;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;

public class PortDetailPage implements IDetailsPage, ModifyListener,VerifyListener {
	private DataBindingContext m_bindingContext;

	private IManagedForm managedForm;
	private Text textxtname;
	private Port port;
	private Combo cmbPortDirection;
	private Text txtType;
	private Text txtParameter;
	private Text txtPort;
	private Text txtvirtualAdd;
	private Text txtPortSize;
	private Button btnCheckexternal;

	private ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock;

	/**
	 * Create the details page.
	 * @param architectureToolMasterDetailBlock 
	 * 
	 * @param port2
	 */
	public PortDetailPage(ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock) {
		this.architectureToolMasterDetailBlock = architectureToolMasterDetailBlock;
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		UtillVerifyListener verifyListener = new UtillVerifyListener();
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Empty Section");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(4, false));

		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");

		textxtname = new Text(composite, SWT.BORDER);
		textxtname.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		textxtname.setData(ArchitecturetoolPackage.Literals.PORT__NAME);
		textxtname.addModifyListener(this);
		toolkit.adapt(textxtname, true, true);
		txtDecorator = new ControlDecoration(textxtname, SWT.TOP|SWT.RIGHT);
		FieldDecoration fieldDecoration = FieldDecorationRegistry.getDefault().getFieldDecoration(FieldDecorationRegistry .DEC_ERROR);
		Image img = fieldDecoration.getImage();
		txtDecorator.setImage(img);
		txtDecorator.setDescriptionText("Port name can not be empty.");
		// hiding it initially
		txtDecorator.hide();
		

		Label lblPortDirection = new Label(composite, SWT.NONE);
		lblPortDirection.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblPortDirection, true, true);
		lblPortDirection.setText("Port Direction");

		cmbPortDirection = new Combo(composite, SWT.READ_ONLY);
		cmbPortDirection.setItems(new String[] { PortListType.PROVIDER.toString(), PortListType.REQUEST.toString() });
		cmbPortDirection.setData(ArchitecturetoolPackage.Literals.PORT__PORT_DIRECTION);
		cmbPortDirection.addModifyListener(this);
		cmbPortDirection.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		toolkit.adapt(cmbPortDirection);
		toolkit.paintBordersFor(cmbPortDirection);

		Label lblType = new Label(composite, SWT.NONE);
		lblType.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblType, true, true);
		lblType.setText("Type");

		txtType = new Text(composite, SWT.BORDER);
		//txtType.setEnabled(false);
		txtType.setLayoutData(new GridData(SWT.FILL, SWT.LEFT, true, false, 2, 1)); //SWT.FILL SWT.CENTER
		toolkit.adapt(txtType, true, true);
	    MouseListener onMouseClickText = new MouseListener() {
			
			@Override
			public void mouseUp(MouseEvent e) {
				
			}
			
			@Override
			public void mouseDown(MouseEvent e) {
				
			}
			
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				
				String txtData = txtType.getText();
				DataStructure type = port.getType();
				if((txtData!=null && type!=null && txtData.equals(type.getName()))) {
					architectureToolMasterDetailBlock.select(new StructuredSelection(type));
				}
				System.err.println("Source is as follows:: " + txtData);
			}
		};
		txtType.addMouseListener(onMouseClickText);
		

		Button btnType = new Button(composite, SWT.NONE);
		btnType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog elementListSelectionDialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof DataStructure) {
									DataStructure dataStructure = (DataStructure) element;
									EObject eContainer = dataStructure.eContainer();
									Component component  = null;
									Component component1 = null;
									if(eContainer instanceof Generator) {
										EObject eContainer2 = ((Generator)eContainer).eContainer();
										if(eContainer2 instanceof Component) {
										 component = ((Component)eContainer2);
										}
									}
									if(!(eContainer instanceof Generator)) {
										while(!(((DataStructure)eContainer) instanceof Generator)) {
											eContainer = ((DataStructure)eContainer).eContainer();
											if(eContainer instanceof Generator) {
												break;
											}
											else {
												continue; 
											}
											
										}
										EObject eContainer2 = ((Generator)eContainer).eContainer();
										if(eContainer2 instanceof Component) {
										 component = ((Component)eContainer2);
										}
										
									}
									return dataStructure.getName()+" ("+component.getName()+")";
								}
								return super.getText(element);
							}
						});
				if (cmbPortDirection.getText().equals(PortListType.PROVIDER.getName())) {
					ArrayList<DataStructure> dsList = new ArrayList<DataStructure>();
					Component component = (Component) port.eContainer().eContainer();
					if (component.eContainer().eContainer() instanceof NoNameElement) {
						NoNameElement noNameElement = ((NoNameElement) component.eContainer().eContainer());
						EList<MCC> mcc = noNameElement.getMcc();
						for (Iterator iterator = mcc.iterator(); iterator.hasNext();) {
							MCC mccElement = (MCC) iterator.next();
							EList<Component> components = mccElement.getComponents();
							for (Iterator iterator2 = components.iterator(); iterator2.hasNext();) {
								Component componentElement = (Component) iterator2.next();
								boolean showAllTypes = port.getShowAllTypes();
								if (!showAllTypes && (EcoreUtil.equals(component, componentElement))) {
									EList<Generator> generator = componentElement.getGenerator();
									for (Iterator iterator3 = generator.iterator(); iterator3.hasNext();) {
										Generator generatorElement = (Generator) iterator3.next();
										TreeIterator<Object> dataStructAllContents = EcoreUtil
												.getAllContents(generatorElement.getDatastructure());
										while (dataStructAllContents.hasNext()) {
											Object object = (Object) dataStructAllContents.next();
											if (object instanceof DataStructure) {
												dsList.add(((DataStructure) object));
											}
										}
									}
								}
								if(showAllTypes) {
									EList<Generator> generator = componentElement.getGenerator();
									for (Iterator iterator3 = generator.iterator(); iterator3.hasNext();) {
										Generator generatorElement = (Generator) iterator3.next();
										TreeIterator<Object> dataStructAllContents = EcoreUtil
												.getAllContents(generatorElement.getDatastructure());
										while (dataStructAllContents.hasNext()) {
											Object object = (Object) dataStructAllContents.next();
											if (object instanceof DataStructure) {
												dsList.add(((DataStructure) object));
											}
										}
									}
								}
							}
						}
					}
					elementListSelectionDialog.setElements(dsList.toArray());
					elementListSelectionDialog.open();
					DataStructure dataStructure = (DataStructure) elementListSelectionDialog.getFirstResult();
					if (dataStructure != null) {
						if (dataStructure.getName() != null)
							txtType.setText(dataStructure.getName());
					}
					port.setType(dataStructure);
				}
				if (cmbPortDirection.getText().equals(PortListType.REQUEST.getName())) {
					ArrayList<DataStructure> dsList = new ArrayList<DataStructure>();
					Component component = (Component) port.eContainer().eContainer();
					if (component.eContainer().eContainer() instanceof NoNameElement) {
						NoNameElement noNameElement = ((NoNameElement) component.eContainer().eContainer());
						EList<MCC> mcc = noNameElement.getMcc();
						for (Iterator iterator = mcc.iterator(); iterator.hasNext();) {
							MCC mccElement = (MCC) iterator.next();
							EList<Component> components = mccElement.getComponents();
							for (Iterator iterator2 = components.iterator(); iterator2.hasNext();) {
								Component componentElement = (Component) iterator2.next();
								boolean showAllTypes = port.getShowAllTypes();
								if (!showAllTypes && !(EcoreUtil.equals(component, componentElement))) {
									EList<Generator> generator = componentElement.getGenerator();
									for (Iterator iterator3 = generator.iterator(); iterator3.hasNext();) {
										Generator generatorElement = (Generator) iterator3.next();
										TreeIterator<Object> dataStructAllContents = EcoreUtil
												.getAllContents(generatorElement.getDatastructure());
										while (dataStructAllContents.hasNext()) {
											Object object = (Object) dataStructAllContents.next();
											if (object instanceof DataStructure) {
												dsList.add(((DataStructure) object));
											}
										}
									}
								}
								if (showAllTypes) {
									EList<Generator> generator = componentElement.getGenerator();
									for (Iterator<Generator> iterator3 = generator.iterator(); iterator3.hasNext();) {
										Generator generatorElement = (Generator) iterator3.next();
										TreeIterator<Object> dataStructAllContents = EcoreUtil
												.getAllContents(generatorElement.getDatastructure());
										while (dataStructAllContents.hasNext()) {
											Object object = (Object) dataStructAllContents.next();
											if (object instanceof DataStructure) {
												dsList.add(((DataStructure) object));
											}
										}
									}
								}

							}
						}
					}
					elementListSelectionDialog.setElements(dsList.toArray());
					elementListSelectionDialog.open();
					DataStructure dataStructure = (DataStructure) elementListSelectionDialog.getFirstResult();
					if (dataStructure != null) {
						if (dataStructure.getName() != null)
							txtType.setText(dataStructure.getName());
					}
					port.setType(dataStructure);
				}
			}
		});
		toolkit.adapt(btnType, true, true);
		btnType.setText("......");
		
		Label lblParameter = new Label(composite, SWT.NONE);
		lblParameter.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblParameter, true, true);
		lblParameter.setText("Parameter");
		
		
		txtParameter = new Text(composite, SWT.BORDER);
		txtParameter.setEnabled(false);
		txtParameter.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(txtParameter, true, true);
		
		Button button = new Button(composite, SWT.NONE);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				port.setParameter(null);
				txtParameter.setText("");
			}
		});
		button.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_ETOOL_DELETE));
		toolkit.adapt(button, true, true);
		
		Button btnParameter = new Button(composite, SWT.NONE);
		toolkit.adapt(btnParameter, true, true); 
		btnParameter.setText("......");
		ArrayList<Parameter> parameterList = new ArrayList<Parameter>();
		btnParameter.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				ElementListSelectionDialog elementListSelectionDialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Parameter) {
									Parameter parameter = (Parameter) element;
									if (parameter.eContainer() instanceof Component) {
										return parameter.getName() + " ("
												+ ((Component) parameter.eContainer()).getName() +" :Component"+ ")";
									} else if (parameter.eContainer() instanceof MCC) {
										return parameter.getName() + " (" + ((MCC) parameter.eContainer()).getName()
												+" :MCC"+ ")";
									}
								}
								return super.getText(element);
							}

						});
				MCC mcc = (MCC) port.eContainer().eContainer().eContainer();
				EList<Parameter> parameters = mcc.getParameters();
				Component component = (Component) port.eContainer().eContainer();
				EList<Parameter> parameters2 = component.getParameters();
				parameterList.clear();
				parameterList.addAll(parameters);
				parameterList.addAll(parameters2);
				elementListSelectionDialog.setElements(parameterList.toArray());

				elementListSelectionDialog.open();
				Parameter selectedParameter = (Parameter) elementListSelectionDialog.getFirstResult();
				if (selectedParameter != null) {
					if (selectedParameter.getName() != null)
						txtParameter.setText(selectedParameter.getName());
				}
				port.setParameter(selectedParameter);
				
			}
		});
		
		
		lblVirtualAddressBlock = new Label(composite, SWT.NONE);
		lblVirtualAddressBlock.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblVirtualAddressBlock, true, true);
		lblVirtualAddressBlock.setText("Virtual Address Block");
		
		txtvirtualAdd = new Text(composite, SWT.BORDER);
		txtvirtualAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		txtvirtualAdd.setData(ArchitecturetoolPackage.Literals.PORT__VIRTUAL_ADDRESS_BLOCK);
		txtvirtualAdd.addModifyListener(this);
		toolkit.adapt(txtvirtualAdd, true, true);
		
		cmbPortDirection.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
            	if(cmbPortDirection.getText().equals(PortListType.REQUEST.getName())) {
            		lblVirtualAddressBlock.setVisible(false);
            		txtvirtualAdd.setVisible(false);
            	}
            	else if(cmbPortDirection.getText().equals(PortListType.PROVIDER.getName())) {
            		lblVirtualAddressBlock.setVisible(true);
            		txtvirtualAdd.setVisible(true);
            	}
            }
		});
		
		
		Label lblPortSizeBlock = new Label(composite, SWT.NONE);
		lblPortSizeBlock.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblPortSizeBlock, true, true);
		lblPortSizeBlock.setText("Port Size(Bytes)");
		
		txtPortSize = new Text(composite, SWT.BORDER);
		txtPortSize.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		txtPortSize.setEditable(false);
		txtPortSize.setEnabled(false);
		toolkit.adapt(txtPortSize, true, true);
		
		btnCheckexternal = new Button(composite, SWT.CHECK);
		
		toolkit.adapt(btnCheckexternal, true, true);
		btnCheckexternal.setText("Show All Types");
		new Label(composite, SWT.NONE);
		new Label(composite, SWT.NONE);
		new Label(composite, SWT.NONE);
		btnCheckexternal.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				Widget source = e.widget;
				if (source instanceof Button) {
					Button sourceBtn = ((Button) source);
					boolean selection = sourceBtn.getSelection();
					if (selection) {
						port.setShowAllTypes(true);
					} else {
						port.setShowAllTypes(false);
					}
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});

	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	Set<DataStructure> dsList = new HashSet<DataStructure>();
	Set<Attribute> attrList = new HashSet<Attribute>();

	private ControlDecoration txtDecorator;

	private Label lblVirtualAddressBlock;
	
	private void update() {

		if (port != null) {
			boolean showAllTypes = port.getShowAllTypes();
			if(showAllTypes) {
				btnCheckexternal.setSelection(true);
				port.setShowAllTypes(true);
			}
			else {
				btnCheckexternal.setSelection(false);
				port.setShowAllTypes(false);
			}
//			if(btnCheckexternal.getSelection()) {
//				port.setShowAllTypes(true);
//			}
//			else {
//				port.setShowAllTypes(false);
//			}
			
			if (port.getName() != null) {
				if(port.getName().trim().isEmpty()) {
					Resource eResource = port.eResource();
					IResource file = WorkspaceSynchronizer.getFile(eResource);
					try {
						IMarker createMarker = file.createMarker(IMarker.PROBLEM);
						createMarker.setAttribute(IMarker.MESSAGE, ((Component) port.eContainer().eContainer()).getName()
								+ " contains port which has no name");
						createMarker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
					} catch (CoreException e) {
						e.printStackTrace();
					}
				}
				textxtname.setText(port.getName());
			}
			else
			{  
				port.setName(""); 
				textxtname.setText("");
			}
			if (port.getVirtualAddressBlock() != null) {
				txtvirtualAdd.setText(port.getVirtualAddressBlock());
			}
			else
			{
				txtvirtualAdd.setText("");
			}
			if (port.getParameter() != null && port.getParameter().getName() != null) {
				txtParameter.setText(port.getParameter().getName());
			} else {

				txtParameter.setText("");
			}
			if (port.getType() != null) {
				if (port.getType().getName() != null) {
					port.setPortTypeCompoName(port.getType().getName());
					txtType.setText(port.getType().getName());
				}
			} else {
				txtType.setText("");
			}

			if (port.getPortDirection().equals(PortListType.PROVIDER)) {
				cmbPortDirection.select(0);
			} else {
				cmbPortDirection.select(1);
			}
			
			int size = 0;
			if (port.getType() != null) {
				DataStructure dataStructure = port.getType();
				ArrayList<Attribute> attributeList = new ArrayList<Attribute>();
				ArrayList<DataStructure> dataStructureList = new ArrayList<DataStructure>();
				attributeList.addAll(dataStructure.getAttributes());
				dataStructureList.addAll(dataStructure.getStructs());
				dsList.clear();
				attrList.clear();
				Set<DataStructure> collectDataStructures = collectDataStructures(dataStructure);
				ArrayList<DataStructure> dsListt = new ArrayList<DataStructure>();
				dsListt.addAll(collectDataStructures);
				Set<Attribute> collectAttributes = collectAttributes(dsListt);
				dsListt.clear();
				for (Iterator<Attribute> iterator = collectAttributes.iterator(); iterator.hasNext();) {
					Attribute attribute = (Attribute) iterator.next();
					AttributeTypeEnum attributeType = attribute.getAttributeType();
					AttributeTypeEnum attributeTypeValue = attributeType.get(attributeType.getValue());
					if (attributeTypeValue.getName()
							.equals(attributeType.get(attributeType.BASIC_TYPE_VALUE).getName())) {
						DatatypeEnum dataType = attribute.getDataType();
						DatatypeEnum datatypeEnum = dataType.get(dataType.getValue());
						int arrSize = attribute.getArraySize();
						if (datatypeEnum.getName().equals(datatypeEnum.get(datatypeEnum.UNIT32_VALUE).getName())) {
							size = size + (arrSize * 4);
							
						} else if (datatypeEnum.getName()
								.equals(datatypeEnum.get(datatypeEnum.SINT32_VALUE).getName())) {
							size = size + (arrSize * 4);
						} else if (datatypeEnum.getName()
								.equals(datatypeEnum.get(datatypeEnum.FLOAT32_VALUE).getName())) {
							size = size + (arrSize * 4);
						} else if (datatypeEnum.getName()
								.equals(datatypeEnum.get(datatypeEnum.UNIT16_VALUE).getName())) {
							size = size + (arrSize * 2);
						} else if (datatypeEnum.getName()
								.equals(datatypeEnum.get(datatypeEnum.SINT16_VALUE).getName())) {
							size = size + (arrSize * 2);
						} else if (datatypeEnum.getName()
								.equals(datatypeEnum.get(datatypeEnum.SINT8_VALUE).getName())) {
							size = size + (arrSize * 1);
						} else if (datatypeEnum.getName()
								.equals(datatypeEnum.get(datatypeEnum.BOOLEAN_VALUE).getName())) {
							size = size + (arrSize * 1);
						} else if (datatypeEnum.getName()
								.equals(datatypeEnum.get(datatypeEnum.UNIT8_VALUE).getName())) {
							size = size + (arrSize * 1);
						}

					}
				}
				txtPortSize.setText(Integer.toString(size));
			}
			
			if(cmbPortDirection.getText().equals(PortListType.REQUEST.getName())) {
        		lblVirtualAddressBlock.setVisible(false);
        		txtvirtualAdd.setVisible(false);
        	}
        	else if(cmbPortDirection.getText().equals(PortListType.PROVIDER.getName())) {
        		lblVirtualAddressBlock.setVisible(true);
        		txtvirtualAdd.setVisible(true);
        	}
		}
	}

	public Set<DataStructure> collectDataStructures(DataStructure ds) {
		dsList.add(ds);
		EList<DataStructure> structs = ds.getStructs();
		for (Iterator<DataStructure> iterator = structs.iterator(); iterator.hasNext();) {
			DataStructure dataStructure = (DataStructure) iterator.next();
			if (dataStructure.getStructs().isEmpty()) {
				dsList.add(dataStructure);
			} else {
				collectDataStructures(dataStructure);
			}
		}
		return dsList;
	}
	
	public Set<Attribute> collectAttributes(ArrayList<DataStructure> dsList) {
		for (Iterator<DataStructure> iterator = dsList.iterator(); iterator.hasNext();) {
			DataStructure dataStructure = (DataStructure) iterator.next();
			EList<Attribute> attributes = dataStructure.getAttributes();
			if (!attributes.isEmpty()) {
				for (Iterator<Attribute> attribIterator = attributes.iterator(); attribIterator.hasNext();) {
					Attribute attribute = ((Attribute) attribIterator.next());
					attrList.add(attribute);
				}
			}
		}
		return attrList;
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			
				port = (Port) structuredSelection.getFirstElement();
			
		} else
			port = null;

		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (port != null) {
				String string = ((Text) source).getText().trim();
		        if(string.isEmpty()) {
		        	txtDecorator.show();
		        } else {
		        	txtDecorator.hide();
		        }
				if (data instanceof EAttribute) {
					EAttribute attribute = (EAttribute) data;
					EDataType eAttributeType = attribute.getEAttributeType();
					if (eAttributeType.getName().equals("EString"))
						port.eSet(data, ((Text) source).getText());
					else if (eAttributeType.getName().equals("EInt"))
						port.eSet(data, Integer.parseInt(((Text) source).getText()));
				}
			}
		} else if (source instanceof Combo) {
			int selectionIndex = ((Combo)source).getSelectionIndex();
			String selItem = ((Combo)source).getItem(selectionIndex);
			EStructuralFeature structuralFeature = (EStructuralFeature) source.getData();
			if (structuralFeature instanceof EAttribute) { // EEnum
				if (port != null) {
					port.eSet(structuralFeature, PortListType.get(selItem));
				}
			}
		}
	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
