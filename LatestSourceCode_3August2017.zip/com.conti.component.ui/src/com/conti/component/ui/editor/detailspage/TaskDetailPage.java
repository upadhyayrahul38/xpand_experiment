package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.CPU;
import architecturetool.Component;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.Memory;
import architecturetool.MemoryPartition;
import architecturetool.NoNameElement;
import architecturetool.Node;
import architecturetool.OSApplication;
import architecturetool.Runnable;
import architecturetool.Runnables;
import architecturetool.Task;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

public class TaskDetailPage implements IDetailsPage, ModifyListener,VerifyListener {
	private class ShutdownTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}
		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Runnable) {
				Runnable runnable = (Runnable) element;
				switch (columnIndex) {
				case 0:
					return runnable.getName();
				}
			}
			return element.toString();
		}
	}
	private class RunnableTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}
		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Runnable) {
				Runnable runnable = (Runnable) element;
				switch (columnIndex) {
				case 0:
					return runnable.getName();
				}
			}
			return element.toString();
		}
	}
	private class StartupTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}
		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Runnable) {
				Runnable runnable = (Runnable) element;
				switch (columnIndex) {
				case 0:
					return runnable.getName();
				}
			}
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtRuntime;
	private Text txtRamSectionUsed;
	private Text txtStack;
	private Text txtMemoryPartition;
	private Table startupTable;
	private Table runnableTable;
	private Table shutdownTable;
	private TableViewer startupTableViewer;
	private TableViewer runnableTableViewer;
	private TableViewer shutdownTableViewer;
	private Task task;

	/**
	 * Create the details page.
	 */
	public TaskDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		UtillVerifyListener verifyListener = new UtillVerifyListener();
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Task");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));

		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");

		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.TASK__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);

		Label lblRuntime = new Label(composite, SWT.NONE);
		lblRuntime.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblRuntime, true, true);
		lblRuntime.setText("Runtime");

		txtRuntime = new Text(composite, SWT.BORDER);
		txtRuntime.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRuntime.setData(ArchitecturetoolPackage.Literals.TASK__RUNTIME);
		txtRuntime.addModifyListener(this);
		txtRuntime.addVerifyListener(verifyListener);
		toolkit.adapt(txtRuntime, true, true);
		new Label(composite, SWT.NONE);

		Label lblRamSectionUsed = new Label(composite, SWT.NONE);
		lblRamSectionUsed.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblRamSectionUsed, true, true);
		lblRamSectionUsed.setText("Ram Section Used");

		txtRamSectionUsed = new Text(composite, SWT.BORDER);
		txtRamSectionUsed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRamSectionUsed.setData(ArchitecturetoolPackage.Literals.TASK__RAM_SECTION_USED);
		txtRamSectionUsed.addModifyListener(this);
		toolkit.adapt(txtRamSectionUsed, true, true);
		new Label(composite, SWT.NONE);

		Label lblStack = new Label(composite, SWT.NONE);
		lblStack.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblStack, true, true);
		lblStack.setText("Stack");

		txtStack = new Text(composite, SWT.BORDER);
		txtStack.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtStack.setData(ArchitecturetoolPackage.Literals.TASK__STACK);
		txtStack.addModifyListener(this);
		txtStack.addVerifyListener(verifyListener);
		toolkit.adapt(txtStack, true, true);
		new Label(composite, SWT.NONE);

		Label lblMemoryPartit = new Label(composite, SWT.NONE);
		lblMemoryPartit.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblMemoryPartit, true, true);
		lblMemoryPartit.setText("Memory Partition");

		txtMemoryPartition = new Text(composite, SWT.BORDER);
		txtMemoryPartition.setEnabled(false);
		txtMemoryPartition.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtMemoryPartition.setData(ArchitecturetoolPackage.Literals.TASK__MEMORYREGION);//TASK__MEMORYPARTITION
		txtMemoryPartition.addModifyListener(this);
		toolkit.adapt(txtMemoryPartition, true, true);

		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof MemoryPartition) {
									MemoryPartition memoryPartition = (MemoryPartition) element;
									return memoryPartition.toString();

								}
								return super.getText(element);
							}
						});
				ECU ecu = (ECU) task.eContainer().eContainer().eContainer();
				ArrayList<MemoryPartition> arrayList = new ArrayList<MemoryPartition>();
				EList<CPU> cpus = ecu.getCpus();
				for (Iterator iterator = cpus.iterator(); iterator.hasNext();) {
					CPU cpu = (CPU) iterator.next();
					EList<Node> nodes = cpu.getNodes();
					for (Iterator iterator2 = nodes.iterator(); iterator2.hasNext();) {
						Node node = (Node) iterator2.next();
						EList<OSApplication> osapplications = node.getOsapplications();
						if (osapplications != null) {
							for (Iterator iteratorOsApp = osapplications.iterator(); iteratorOsApp.hasNext();) {
								OSApplication osApplication = (OSApplication) iteratorOsApp.next();
								MemoryPartition memorypartition = osApplication.getMemorypartition();
								if (!arrayList.contains(memorypartition)) {
									arrayList.add(memorypartition);
								}
							}
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				MemoryPartition firstResult = (MemoryPartition) dialog.getFirstResult();
				txtMemoryPartition.setText(firstResult.toString());

			}
		});
		toolkit.adapt(button, true, true);
		button.setText(".....");

		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setLayout(new GridLayout(6, false));
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 3, 1));
		toolkit.adapt(composite_1);
		toolkit.paintBordersFor(composite_1);

		startupTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		startupTable = startupTableViewer.getTable();
		startupTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(startupTable);
		toolkit.paintBordersFor(startupTable);
		startupTable.setHeaderVisible(true);
		startupTable.setLinesVisible(true);

		TableColumn tblclmnShutdownStartup = new TableColumn(startupTable, SWT.NONE);
		tblclmnShutdownStartup.setWidth(150);
		tblclmnShutdownStartup.setText("Startup Runnables");
	

		Button button_1 = new Button(composite_1, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Runnable) {
									Runnable runnable = (Runnable) element;
								return	runnable.getName();
								}
								return super.getText(element);
							}
						});
				NoNameElement noNameElement = (NoNameElement) task.eContainer().eContainer().eContainer().eContainer();
				ArrayList<Runnable> arrayList = new ArrayList<Runnable>();
				EList<MCC> mcc = noNameElement.getMcc();
				for (MCC mcc2 : mcc) {
					EList<Component> components = mcc2.getComponents();
					for (Component component : components) {
						Runnables runnables = component.getRunnables();
						if(runnables!=null)
						{
							arrayList.addAll(runnables.getRunnable());
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Runnable firstResult = (Runnable) dialog.getFirstResult();
				task.getStartupRunnables().add(firstResult);
				startupTableViewer.refresh();
			}
		});
		button_1.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(button_1, true, true);
		button_1.setText(".....");

		runnableTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		runnableTable = runnableTableViewer.getTable();
		runnableTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(runnableTable);
		toolkit.paintBordersFor(runnableTable);
		runnableTable.setHeaderVisible(true);
		runnableTable.setLinesVisible(true);

		TableColumn tblclmnRunnables = new TableColumn(runnableTable, SWT.NONE);
		tblclmnRunnables.setWidth(171);
		tblclmnRunnables.setText("Runnables");
	

		Button button_2 = new Button(composite_1, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Runnable) {
									Runnable runnable = (Runnable) element;
								return	runnable.getName();
								}
								return super.getText(element);
							}
						});
				NoNameElement noNameElement = (NoNameElement) task.eContainer().eContainer().eContainer().eContainer();
				ArrayList<Runnable> arrayList = new ArrayList<Runnable>();
				EList<MCC> mcc = noNameElement.getMcc();
				for (MCC mcc2 : mcc) {
					EList<Component> components = mcc2.getComponents();
					for (Component component : components) {
						Runnables runnables = component.getRunnables();
						if(runnables!=null)
						{
							arrayList.addAll(runnables.getRunnable());
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Runnable firstResult = (Runnable) dialog.getFirstResult();
				task.getRunnables().add(firstResult);
				runnableTableViewer.refresh();
			
			}
		});
		button_2.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(button_2, true, true);
		button_2.setText(".....");

		shutdownTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		shutdownTable = shutdownTableViewer.getTable();
		shutdownTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(shutdownTable);
		toolkit.paintBordersFor(shutdownTable);
		shutdownTable.setHeaderVisible(true);
		shutdownTable.setLinesVisible(true);

		TableColumn tblclmnShutdownRunnables = new TableColumn(shutdownTable, SWT.NONE);
		tblclmnShutdownRunnables.setWidth(162);
		tblclmnShutdownRunnables.setText("Shutdown Runnables");
		

		Button button_3 = new Button(composite_1, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {


				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Runnable) {
									Runnable runnable = (Runnable) element;
								return	runnable.getName();
								}
								return super.getText(element);
							}
						});
				NoNameElement noNameElement = (NoNameElement) task.eContainer().eContainer().eContainer().eContainer();
				ArrayList<Runnable> arrayList = new ArrayList<Runnable>();
				EList<MCC> mcc = noNameElement.getMcc();
				for (MCC mcc2 : mcc) {
					EList<Component> components = mcc2.getComponents();
					for (Component component : components) {
						Runnables runnables = component.getRunnables();
						if(runnables!=null)
						{
							arrayList.addAll(runnables.getRunnable());
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Runnable firstResult = (Runnable) dialog.getFirstResult();
				task.getShutdownRunnables().add(firstResult);
				shutdownTableViewer.refresh();
			
			
			}
		});
		button_3.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(button_3, true, true);
		button_3.setText(".....");
		
		
		startupTableViewer.setContentProvider(new ArrayContentProvider());
		runnableTableViewer.setContentProvider(new ArrayContentProvider());
		shutdownTableViewer.setContentProvider(new ArrayContentProvider());
		
		shutdownTableViewer.setLabelProvider(new ShutdownTableLabelProvider());
		runnableTableViewer.setLabelProvider(new RunnableTableLabelProvider());
		startupTableViewer.setLabelProvider(new StartupTableLabelProvider());
		
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {

		if (task.getName() != null) {
			txtName.setText(task.getName());
		}
		if (task.getRamSectionUsed() != null) {
			txtRamSectionUsed.setText(task.getRamSectionUsed());
		}
//		if (task.getMemorypartition() != null) {
//			txtMemoryPartition.setText(task.getMemorypartition().toString());
//		}
		if (task.getMemoryregion() !=null) {
			txtMemoryPartition.setText(task.getMemoryregion().toString());
		}

		txtStack.setText(String.valueOf(task.getStack()));
		txtRuntime.setText(String.valueOf(task.getRuntime()));

	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			task = (Task) structuredSelection.getFirstElement();
		} else
			task = null;
		startupTableViewer.setInput(task.getStartupRunnables());
		runnableTableViewer.setInput(task.getRunnables());
		shutdownTableViewer.setInput(task.getShutdownRunnables());
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {

			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					task.eSet(data, ((Text) source).getText());
				else if (eAttributeType.getName().equals("EInt"))
					task.eSet(data, Integer.parseInt(((Text) source).getText()));
				else if (eAttributeType.getName().equals("StackInt"))
					task.eSet(data, Integer.parseInt(((Text) source).getText()));
			}

		}

	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
