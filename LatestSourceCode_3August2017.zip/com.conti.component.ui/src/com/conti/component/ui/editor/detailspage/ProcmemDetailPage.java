package com.conti.component.ui.editor.detailspage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.EAttributeImpl;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.PortListType;
import architecturetool.ProcMem;
import architecturetool.ProcMem_AccessSpeed;
import architecturetool.ProcMem_Cycle;
import architecturetool.ProcMem_Safety;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;

public class ProcmemDetailPage implements IDetailsPage, ModifyListener {

	private IManagedForm managedForm;
	private Text textBudget;
	private ProcMem procMem;
	private Combo comboSafetylavel;
	private Combo comboAccessSpeed;
	private Combo comboScope;

	/**
	 * Create the details page.
	 */
	public ProcmemDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section sctnProcMemQm = toolkit.createSection(parent,
				ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		sctnProcMemQm.setText("Proc Mem QM");
		//
		Composite composite = toolkit.createComposite(sctnProcMemQm, SWT.NONE);
		toolkit.paintBordersFor(composite);
		sctnProcMemQm.setClient(composite);
		composite.setLayout(new GridLayout(2, false));

		Label lblSafetyLevel = new Label(composite, SWT.NONE);
		toolkit.adapt(lblSafetyLevel, true, true);
		lblSafetyLevel.setText("Safety Level");

		comboSafetylavel = new Combo(composite, SWT.READ_ONLY);
		comboSafetylavel.setItems(new String[] { ProcMem_Safety.ASILA.toString(), ProcMem_Safety.ASILB.toString(),
				ProcMem_Safety.ASILC.toString(), ProcMem_Safety.ASILD.toString(), ProcMem_Safety.QM.toString() });
		comboSafetylavel.setData(ArchitecturetoolPackage.Literals.PROC_MEM__SAFETY_ENUM);
		comboSafetylavel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		comboSafetylavel.addModifyListener(this);
		toolkit.adapt(comboSafetylavel);
		toolkit.paintBordersFor(comboSafetylavel);

		Label lblAccessSpeed = new Label(composite, SWT.NONE);
		lblAccessSpeed.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblAccessSpeed, true, true);
		lblAccessSpeed.setText("Access Speed");

		comboAccessSpeed = new Combo(composite, SWT.READ_ONLY);
		comboAccessSpeed
				.setItems(new String[] { ProcMem_AccessSpeed.FAST.toString(), ProcMem_AccessSpeed.SLOW.toString() });
		comboAccessSpeed.setData(ArchitecturetoolPackage.Literals.PROC_MEM__ACCESS_SPEED_ENUM);
		comboAccessSpeed.addModifyListener(this);
		comboAccessSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(comboAccessSpeed);
		toolkit.paintBordersFor(comboAccessSpeed);

		Label lblScope = new Label(composite, SWT.NONE);
		toolkit.adapt(lblScope, true, true);
		lblScope.setText("Scope");

		comboScope = new Combo(composite, SWT.READ_ONLY);
		comboScope.setItems(
				new String[] { ProcMem_Cycle.INTRA_CYCLE.toString(), ProcMem_Cycle.INTRA_CYCLE_MEAS.toString(),
						ProcMem_Cycle.INTER_CYCLE.toString(), ProcMem_Cycle.INTER_CYCLE_MEAS.toString() });
		comboScope.setData(ArchitecturetoolPackage.Literals.PROC_MEM__CYCLE_ENUM);
		comboScope.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		comboScope.addModifyListener(this);
		toolkit.adapt(comboScope);
		toolkit.paintBordersFor(comboScope);

		Label lblBudget = new Label(composite, SWT.NONE);
		toolkit.adapt(lblBudget, true, true);
		lblBudget.setText("Budget ");

		textBudget = new Text(composite, SWT.BORDER);
		textBudget.setData(ArchitecturetoolPackage.Literals.PROC_MEM__BUDGET);
		textBudget.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textBudget.addModifyListener(this);
		toolkit.adapt(textBudget, true, true);
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if(procMem.getBudget()!=null)
		{
			textBudget.setText(procMem.getBudget());
		}else
			textBudget.setText("");
		
		
		if(procMem.getAccessSpeedEnum().equals(ProcMem_AccessSpeed.FAST))
		{
			comboAccessSpeed.select(0);
		}
		else
		{
			comboAccessSpeed.select(1);
		}
		
		if (procMem.getCycleEnum().equals(ProcMem_Cycle.INTRA_CYCLE)) {
			comboScope.select(0);
		}else if (procMem.getCycleEnum().equals(ProcMem_Cycle.INTRA_CYCLE_MEAS)) {
			comboScope.select(1);
		}else if (procMem.getCycleEnum().equals(ProcMem_Cycle.INTER_CYCLE)) {
			comboScope.select(2);
		}else if (procMem.getCycleEnum().equals(ProcMem_Cycle.INTER_CYCLE_MEAS)) {
			comboScope.select(3);
		}
		
		if(procMem.getSafetyEnum().equals(ProcMem_Safety.ASILA))
		{
			comboSafetylavel.select(0);
		}else if(procMem.getSafetyEnum().equals(ProcMem_Safety.ASILB))
		{
			comboSafetylavel.select(1);
		}else if(procMem.getSafetyEnum().equals(ProcMem_Safety.ASILC))
		{
			comboSafetylavel.select(2);
		}else if(procMem.getSafetyEnum().equals(ProcMem_Safety.ASILD))
		{
			comboSafetylavel.select(3);
		}
		else if(procMem.getSafetyEnum().equals(ProcMem_Safety.QM))
		{
			comboSafetylavel.select(4);
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1)
		procMem = (ProcMem) structuredSelection.getFirstElement();
		else
			procMem=null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature structuralFeature = (EStructuralFeature) source.getData();
			if (procMem != null) {
		        
				procMem.eSet(structuralFeature, ((Text) source).getText());
			}
		} else if (source instanceof Combo) {
			int selectionIndex = ((Combo)source).getSelectionIndex();
			String selItem = ((Combo)source).getItem(selectionIndex);
			EStructuralFeature structuralFeature = (EStructuralFeature) source.getData();
			if (structuralFeature instanceof EAttribute) { // EEnum
				EAttributeImpl object=(EAttributeImpl) structuralFeature;
				if (object.getNameGen().equals("CycleEnum")) {
					procMem.eSet(structuralFeature, ProcMem_Cycle.get(selItem));
				}else if (object.getNameGen().equals("SafetyEnum")) {
					procMem.eSet(structuralFeature, ProcMem_Safety.get(selItem));
				}else if (object.getNameGen().equals("AccessSpeedEnum")) {
					procMem.eSet(structuralFeature, ProcMem_AccessSpeed.get(selItem));
				}
			}
		}
	}

}
