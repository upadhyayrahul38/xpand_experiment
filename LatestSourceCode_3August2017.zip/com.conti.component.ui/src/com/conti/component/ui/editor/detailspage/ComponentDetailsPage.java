package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import org.eclipse.emf.common.util.ECollections;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.edit.domain.AdapterFactoryEditingDomain;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.editor.ArchitectureToolMasterDetailBlock;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.Port;
import architecturetool.Ports;

public class ComponentDetailsPage implements IDetailsPage, ModifyListener {
	protected final class PortViewerSorter extends ViewerSorter {
		@Override
		public int compare(Viewer viewer, Object e1, Object e2) {
			Port s1 = (Port) e1;
			Port s2 = (Port) e2;

			if (sortDirection == SWT.DOWN) {
				if (s1.getName() != null && s2.getName() != null) {
					return s1.getName().compareToIgnoreCase(s2.getName());
				}

			} else {
				if (s1.getName() != null && s2.getName() != null) {
					return s2.getName().compareToIgnoreCase(s1.getName());
				}
			}

			return 0;

		}

		int sortDirection;

		public void setSortDirection(int sortDirection) {
			this.sortDirection = sortDirection;
		}
	}

	private class TableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			String portItem = "";
			if (element instanceof Port) {
				Port port = (Port) element;
				switch (columnIndex) {
				case 0:
					portItem = port.getName();
					break;
				case 1:
					portItem = port.getPortDirection().toString();
					break;
				case 2:
					if (port.getType() != null)
						portItem = port.getType().getName();
				default:
					break;
				}
			}
			return portItem;
		}
	}

	private IManagedForm managedForm;
	private Component component;
	private Text txtName;
	private Table table;
	private ComposedAdapterFactory factories;
	private AdapterFactoryEditingDomain editingDomain;
	private TableViewer tableViewer;
	private Button btnCheckexternal;
	private ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock;

	/**
	 * Create the details page.
	 * 
	 * @param architectureToolMasterDetailBlock
	 * 
	 * @param component
	 */
	public ComponentDetailsPage(ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock) {
		this.architectureToolMasterDetailBlock = architectureToolMasterDetailBlock;
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Component");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(2, false));

		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblNewLabel, true, true);
		lblNewLabel.setText("Name");

		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.COMPONENT__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);

		btnCheckexternal = new Button(composite, SWT.CHECK);

		toolkit.adapt(btnCheckexternal, true, true);
		btnCheckexternal.setText("External Static Mem Used");
		new Label(composite, SWT.NONE);
		btnCheckexternal.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				Widget source = e.widget;
				if (source instanceof Button) {
					Button sourceBtn = ((Button) source);
					boolean selection = sourceBtn.getSelection();
					if (selection) {
						component.setExternalStaticMemUsed(true);
					} else {
						component.setExternalStaticMemUsed(false);
					}
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		tableViewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(table);
		toolkit.paintBordersFor(table);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tblclmnNmae = new TableColumn(table, SWT.NONE);
		tblclmnNmae.setWidth(256);
		tblclmnNmae.setText("Port Name");

		TableColumn tblclmnPortDirection = new TableColumn(table, SWT.NONE);
		tblclmnPortDirection.setWidth(287);
		tblclmnPortDirection.setText("Port Direction");

		TableColumn tblclmnPortType = new TableColumn(table, SWT.NONE);
		tblclmnPortType.setWidth(287);
		tblclmnPortType.setText("Port Type");

		tableViewer.setContentProvider(new ArrayContentProvider());
		tableViewer.setLabelProvider(new TableLabelProvider());

		PortViewerSorter sorter = new PortViewerSorter();
		tableViewer.setSorter(sorter);

		table.setSortColumn(tblclmnNmae);
			table.setSortDirection(SWT.UP);
		tblclmnNmae.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				int sortDirection = table.getSortDirection();
				if (sortDirection == SWT.UP) {
					sorter.setSortDirection(SWT.DOWN);
					table.setSortDirection(SWT.DOWN);
				} else {
					sorter.setSortDirection(SWT.UP);
					table.setSortDirection(SWT.UP);
				}
				tableViewer.refresh();
			}
		});
		tableViewer.addDoubleClickListener(new IDoubleClickListener() {

			@Override
			public void doubleClick(DoubleClickEvent event) {
				architectureToolMasterDetailBlock.select(event.getSelection());

			}
		});

		toolkit.decorateFormHeading(managedForm.getForm().getForm());

	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if (component != null && (component.getName() != null && !component.getName().trim().isEmpty()))
			txtName.setText(component.getName());
		else {
			component.setName("");
			txtName.setText("");
		}

		if (component.getExternalStaticMemUsed()) {
			btnCheckexternal.setSelection(true);
			component.setExternalStaticMemUsed(true);
		} else {
			btnCheckexternal.setSelection(false);
			component.setExternalStaticMemUsed(false);
		}

	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			component = (Component) structuredSelection.getFirstElement();
			if (component.getPorts() != null) { // createPorts!=null &&
				component.setPorts(component.getPorts()); // createPorts
				EList<Port> portList = component.getPorts().getPort();
				EList<Port> port = portList;
				EList<Port> portCopy = portList;

				for (Iterator iterator = port.iterator(); iterator.hasNext();) {
					Port port2 = (Port) iterator.next();
					boolean flag = false;
					for (Iterator iterator2 = portCopy.iterator(); iterator2.hasNext();) {
						Port port3 = (Port) iterator2.next();
						if (port.indexOf(port3) == portCopy.indexOf(port2))
							continue;
						flag = EcoreUtil.equals(port2, port3);
						if (flag)
							break;
					}
					if (flag) {

						managedForm.getForm().setMessage("Duplicate Port Not Allow  \t( Port :" + port2.getName()
								+ "\tComponent:  " + component.getName() + ")", IMessageProvider.ERROR);
						break;
					} else {
						managedForm.getForm().setMessage(null, 0);
					}
				}
				tableViewer.setInput(portList); // .getPort()

			}
		} else
			component = null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			component.eSet(data, ((Text) source).getText());

		}

	}
}
