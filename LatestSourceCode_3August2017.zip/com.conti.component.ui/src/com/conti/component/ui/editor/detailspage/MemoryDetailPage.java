package com.conti.component.ui.editor.detailspage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.ECU;
import architecturetool.Memory;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.TableColumn;

public class MemoryDetailPage implements IDetailsPage ,ModifyListener,VerifyListener{

	private IManagedForm managedForm;
	private Text txtNmae;
	private Memory memory;
	private Text textSize;
	private Table table;

	/**
	 * Create the details page.
	 */
	public MemoryDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		UtillVerifyListener listener=new UtillVerifyListener();
		//		
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Memory");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(2, false));
		
		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");
		
		txtNmae = new Text(composite, SWT.BORDER);
		txtNmae.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtNmae.setData(ArchitecturetoolPackage.Literals.MEMORY__NAME);
		txtNmae.addModifyListener(this);
		toolkit.adapt(txtNmae, true, true);
		
		Label lblSize = new Label(composite, SWT.NONE);
		lblSize.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblSize, true, true);
		lblSize.setText("Size");
		
		textSize = new Text(composite, SWT.BORDER);
		textSize.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textSize.setData(ArchitecturetoolPackage.Literals.MEMORY__SIZE);
		textSize.addModifyListener(this);
		textSize.addVerifyListener(listener);
		toolkit.adapt(textSize, true, true);
		
		table = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		toolkit.adapt(table);
		toolkit.paintBordersFor(table);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnName = new TableColumn(table, SWT.NONE);
		tblclmnName.setWidth(175);
		tblclmnName.setText("Name");
		
		TableColumn tblclmnStartAddress = new TableColumn(table, SWT.NONE);
		tblclmnStartAddress.setWidth(193);
		tblclmnStartAddress.setText("Start Address");
		
		TableColumn tblclmnEndAddress = new TableColumn(table, SWT.NONE);
		tblclmnEndAddress.setWidth(201);
		tblclmnEndAddress.setText("End Address");
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if(memory.getName()!=null)
		{
			txtNmae.setText(memory.getName());
		}
		textSize.setText(String.valueOf(memory.getSize()));
		
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1)
		{
			memory = (Memory) structuredSelection.getFirstElement();
		}
		else
			memory=null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (data instanceof EAttribute) {
				EAttribute attribute = (EAttribute) data;
				if(attribute.getEAttributeType().getName().equals("EString"))
					memory.eSet(data, ((Text)source).getText());
				if(attribute.getEAttributeType().getName().equals("EInt"))
					memory.eSet(data, Integer.parseInt(((Text) source).getText()));
			}
		}
		
	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
