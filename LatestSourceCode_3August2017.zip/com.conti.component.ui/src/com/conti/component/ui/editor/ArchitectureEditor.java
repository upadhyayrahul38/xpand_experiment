package com.conti.component.ui.editor;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.UnaryOperator;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.ECollections;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EContentAdapter;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.workspace.util.WorkspaceSynchronizer;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IPropertyListener;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.internal.ide.IDEWorkbenchPlugin;

import com.conti.component.ui.Activator;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Port;
import architecturetool.Ports;
import architecturetool.Root;

public class ArchitectureEditor extends FormEditor implements IPropertyListener {

	private EObject eObject;
	protected boolean dirty;
	private Resource eResource;

	public ArchitectureEditor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void addPages() {
		try {
			addPage(new ArchitectureFormPage(this, "page1", "Architecture Tool", eObject));
		} catch (PartInitException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	@Override
	public void doSave(IProgressMonitor monitor) {
		//try {
			if (eResource != null) {
				NoNameElement noNameElement = null;
				Root root = null;
				if (eObject instanceof MCC) {
					root = ArchitecturetoolFactory.eINSTANCE.createRoot();
					noNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
					noNameElement.getMcc().add(((MCC) eObject));
					ECU ecu = ArchitecturetoolFactory.eINSTANCE.createECU();
					noNameElement.getEcus().add(ecu);
					root.getNonameelement().add(noNameElement);
				} else if (eObject instanceof ECU) {
					root = ArchitecturetoolFactory.eINSTANCE.createRoot();
					noNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
					noNameElement.getEcus().add(((ECU) eObject));
					MCC mcc = ArchitecturetoolFactory.eINSTANCE.createMCC();
					noNameElement.getMcc().add(mcc);
					root.getNonameelement().add(noNameElement);
				}
				else if(eObject instanceof NoNameElement) {
					noNameElement = ((NoNameElement)eObject);
					root = ArchitecturetoolFactory.eINSTANCE.createRoot();
					root.getNonameelement().add(noNameElement);
				}
				if(root==null) // noNameElement
				eResource.getContents().add(eObject);
				else
				eResource.getContents().add(root); // noNameElement
				
				eResource.eAdapters().add(new EContentAdapter() {
					@Override
					public void notifyChanged(Notification notification) {
						dirty = true;
						editorDirtyStateChanged();
						super.notifyChanged(notification);
					}
				});
				
			try {
				eResource.save(Collections.EMPTY_MAP);
			} catch (Exception e1) {
				Activator.getDefault().getLog()
						.log(new Status(IStatus.ERROR, Activator.PLUGIN_ID, "Unable to Save. Access Denied.", e1));
			}
			IFile architectureFile = WorkspaceSynchronizer.getFile(eResource);
			IProject archFileProj = architectureFile.getProject();
			try {
				archFileProj.refreshLocal(IResource.DEPTH_INFINITE, new NullProgressMonitor());
			} catch (CoreException e) {
				e.printStackTrace();
			}
		}
		dirty = false;
		editorDirtyStateChanged();
	}

	@Override
	public void doSaveAs() {

	}
	private static final int DEFAULT_BUFFER_SIZE = 16*1024;
    protected void writeFile(IFile file, IPath destinationPath)
			throws IOException, CoreException {
		OutputStream output = null;
		InputStream contentStream = null;

		try {
			contentStream = new BufferedInputStream(file.getContents(false));
			output = new BufferedOutputStream(new FileOutputStream(destinationPath.toOSString()));
			// for large files, need to make sure the chunk size can be handled
			// by the VM
			int available = contentStream.available();
			available = available <= 0 ? DEFAULT_BUFFER_SIZE : available;
			int chunkSize = Math.min(DEFAULT_BUFFER_SIZE, available);
			byte[] readBuffer = new byte[chunkSize];
			int n = contentStream.read(readBuffer);

			while (n > 0) {
				// only write the number of bytes read
				output.write(readBuffer, 0, n);
				n = contentStream.read(readBuffer);
			}
		} finally {
			if (contentStream != null) {
				// wrap in a try-catch to ensure attempt to close output stream
				try {
					contentStream.close();
				} catch (IOException e) {
					IDEWorkbenchPlugin.log("Error closing input stream for file: " + file.getLocation(), e); //$NON-NLS-1$
				}
			}
			if (output != null) {
				// propogate this error to the user
				output.close();
			}
		}
	}

	
	@Override
	public void init(IEditorSite site, IEditorInput input) throws PartInitException {
		super.init(site, input);
		IFileEditorInput fileinput = (IFileEditorInput) input;
		IFile file = fileinput.getFile();
		try {
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool",
					new XMIResourceFactoryImpl());
			Resource resource = resourceSet.getResource(URI.createFileURI(file.getLocation().toOSString()), true);
			eObject = resource.getContents().get(0);
			eResource = eObject.eResource();
			if (eObject instanceof MCC || eObject instanceof ECU || eObject instanceof NoNameElement) {
				this.doSave(new NullProgressMonitor());
				resource = resourceSet.getResource(URI.createFileURI(file.getLocation().toOSString()), true);
				eObject = resource.getContents().get(0);
				eResource = eObject.eResource();
			}
			if (eObject instanceof Root) {
				Root root = ((Root) eObject);
				EList<NoNameElement> nonameelement = root.getNonameelement();
				List<Component> eCompoList = new ArrayList<Component>();
				for (Iterator<NoNameElement> iterator = nonameelement.iterator(); iterator.hasNext();) {
					NoNameElement noNameElement2 = (NoNameElement) iterator.next();
					EList<MCC> mcc = noNameElement2.getMcc();
					for (Iterator<MCC> iterator2 = mcc.iterator(); iterator2.hasNext();) {
						MCC mcc2 = (MCC) iterator2.next();
						EList<? extends Component> components = mcc2.getComponents();
							ECollections.sort(components, new Comparator<Component>() {
								@Override
								public int compare(Component o1, Component o2) {
									     if(o1.getName()!=null && o2.getName()!=null) {
									    	 return o1.getName().compareToIgnoreCase(o2.getName());
									     }
										return 0;
								}
							});
						for (@SuppressWarnings("unchecked")
						Iterator<Component> iterator3 =  (Iterator<Component>) components.iterator(); iterator3.hasNext();) {
							Component component = (Component) iterator3.next();
							Ports ports = component.getPorts();
							if(ports!=null) {
								EList<Port> port = ports.getPort();
								for (Iterator<Port> iterator4 = port.iterator(); iterator4.hasNext();) {
									Port port2 = (Port) iterator4.next();
									if (port2!=null && port2.getType() != null) {
										if(port2.getType().getName()!=null)
										port2.setPortTypeCompoName(port2.getType().getName());
									}
								}
							}
						}
					}
				}
				this.doSave(new NullProgressMonitor());
			}
			EcoreUtil.resolveAll(resourceSet);
			eObject.eAdapters().add(new EContentAdapter() {
				@Override
				public void notifyChanged(Notification notification) {
					dirty = true;
					editorDirtyStateChanged();
					super.notifyChanged(notification);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			eObject = null;
		}

	}

	@Override
	public boolean isDirty() {
		return dirty;
	}

	@Override
	public boolean isSaveAsAllowed() {
		return false;
	}

	@Override
	public void propertyChanged(Object source, int propId) {

	}

}
