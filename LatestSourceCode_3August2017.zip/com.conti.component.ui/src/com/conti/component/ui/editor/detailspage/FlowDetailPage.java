package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.Flow;
import architecturetool.MCC;
import architecturetool.Port;
import architecturetool.PortListType;
import architecturetool.Ports;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;

public class FlowDetailPage implements IDetailsPage, ModifyListener,VerifyListener {

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtValue;
	private Text txtReqPort;
	private Text txtProPort;
	private Flow flow;

	/**
	 * Create the details page.
	 */
	public FlowDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		UtillVerifyListener verifyListener = new UtillVerifyListener();
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Flow");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));

		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");

		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.FLOW__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);

		Label lblValue = new Label(composite, SWT.NONE);
		lblValue.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblValue, true, true);
		lblValue.setText("SelectionOffset");

		txtValue = new Text(composite, SWT.BORDER);
		txtValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtValue.setData(ArchitecturetoolPackage.Literals.FLOW__VALUE);
		txtValue.addModifyListener(this);
		txtValue.addVerifyListener(verifyListener);
		toolkit.adapt(txtValue, true, true);
		new Label(composite, SWT.NONE);

		Label lblRequestPort = new Label(composite, SWT.NONE);
		lblRequestPort.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblRequestPort, true, true);
		lblRequestPort.setText("Request Port");

		txtReqPort = new Text(composite, SWT.BORDER);
		txtReqPort.setEnabled(false);
		txtReqPort.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtReqPort.setData(ArchitecturetoolPackage.Literals.FLOW__REQUEST_PORT);
		txtReqPort.addModifyListener(this);
		toolkit.adapt(txtReqPort, true, true);

		Button btnReqPort = new Button(composite, SWT.NONE);
		btnReqPort.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Port) {
									Port port = (Port) element;
									EObject parent = port.eContainer().eContainer();
									if (parent instanceof Component) {
										Component comp = ((Component) parent);
										PortListType portDirection = port.getPortDirection();
										return port.getName()+" ("+comp.getName()+", "+portDirection+")";
									}

								}
								return super.getText(element);
							}
						});
				MCC mcc = (MCC) flow.eContainer().eContainer().eContainer();
				ArrayList<Port> arrayList = new ArrayList<Port>();
				EList<Component> components = mcc.getComponents();
				for (Component component : components) {
					Ports ports = component.getPorts();
					if(ports.getPort()!=null){
					EList<Port> port = ports.getPort();
					for (Port port2 : port) {
						if (port2.getPortDirection().equals(PortListType.REQUEST))
							arrayList.add(port2);
					}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Port firstResult = (Port) dialog.getFirstResult();
				if (firstResult != null) {
					txtReqPort.setText(firstResult.getName());
					flow.setRequestPort(firstResult);
				}
			}
		});
		toolkit.adapt(btnReqPort, true, true);
		btnReqPort.setText("......");

		Label lblProviderPort = new Label(composite, SWT.NONE);
		lblProviderPort.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblProviderPort, true, true);
		lblProviderPort.setText("Provider Port");

		txtProPort = new Text(composite, SWT.BORDER);
		txtProPort.setEnabled(false);
		txtProPort.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtProPort.addModifyListener(this);
		toolkit.adapt(txtProPort, true, true);

		Button btnProPort = new Button(composite, SWT.NONE);
		btnProPort.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Port) {
									Port port = (Port) element;
									EObject parent = port.eContainer().eContainer();
									if (parent instanceof Component) {
										Component comp = ((Component) parent);
										PortListType portDirection = port.getPortDirection();
										return port.getName()+" ("+comp.getName()+", "+portDirection+")";
									}

								}
								return super.getText(element);
							}
						});
				MCC mcc = (MCC) flow.eContainer().eContainer().eContainer();
				ArrayList<Port> arrayList = new ArrayList<Port>();
				EList<Component> components = mcc.getComponents();
				for (Component component : components) {
					Ports ports = component.getPorts();
					EList<Port> port = ports.getPort();
					for (Port port2 : port) {
						if (port2.getPortDirection().equals(PortListType.PROVIDER))
							arrayList.add(port2);
					}

				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Port firstResult = (Port) dialog.getFirstResult();
				if (firstResult != null) {
					txtProPort.setText(firstResult.getName());
					flow.setProviderPort(firstResult);
				}

			}
		});
		toolkit.adapt(btnProPort, true, true);
		btnProPort.setText("......");
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if (flow.getName() != null)
			txtName.setText(flow.getName());
		else
			txtName.setText("");

		txtValue.setText(String.valueOf(flow.getValue()));
		if (flow.getRequestPort() != null && flow.getRequestPort().getName() != null) {
			txtReqPort.setText(flow.getRequestPort().getName());
		} else
			txtReqPort.setText("");
		if (flow.getProviderPort() != null && flow.getProviderPort().getName() != null)
			txtProPort.setText(flow.getProviderPort().getName());
		else
			txtProPort.setText("");
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1)
			flow = (Flow) structuredSelection.getFirstElement();
		else
			flow = null;

		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (data instanceof EAttribute) {
				EAttribute attribute = (EAttribute) data;
				EDataType eAttributeType = attribute.getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					flow.eSet(data, ((Text) source).getText());
				else if (eAttributeType.getName().equals("EInt"))
					flow.eSet(data, Integer.parseInt(((Text) source).getText()));

			}
		}

	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
