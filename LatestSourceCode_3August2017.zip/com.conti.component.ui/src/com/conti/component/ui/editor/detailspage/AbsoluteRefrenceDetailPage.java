package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.AttributeTypeEnum;
import architecturetool.DataStructure;
import architecturetool.DatatypeEnum;
import architecturetool.Generator;
import architecturetool.PhysicalUnitEnum;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;

public class AbsoluteRefrenceDetailPage implements IDetailsPage,ModifyListener,VerifyListener {

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtDesc;
	private Text txtTypeAccuracy;
	private Text txtArraySize;
	private Text txtAccuracy;
	private Text txtInterfaceVersion;
	private Text txtDatastructure;
	private Text txtAttribute;
	private Combo cmbPhysicalUnit;
	private AbsoluteRefrence absoluteRefrence;

	/**
	 * Create the details page.
	 */
	public AbsoluteRefrenceDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * @param parent
	 */
	public void createContents(Composite parent) {
		UtillVerifyListener verifyListener = new UtillVerifyListener();
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//		
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Absolute Refrence");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));
		
		Label label = new Label(composite, SWT.NONE);
		label.setText("Name");
		label.setBounds(0, 0, 32, 15);
		toolkit.adapt(label, true, true);
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setBounds(0, 0, 450, 21);
		txtName.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);
		
		Label label_1 = new Label(composite, SWT.NONE);
		label_1.setText("Description");
		label_1.setBounds(0, 0, 60, 15);
		toolkit.adapt(label_1, true, true);
		
		txtDesc = new Text(composite, SWT.BORDER);
		txtDesc.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtDesc.setBounds(0, 0, 450, 21);
		txtDesc.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__DESCRIPTION);
		txtDesc.addModifyListener(this);
		toolkit.adapt(txtDesc, true, true);
		new Label(composite, SWT.NONE);
		
		Label label_2 = new Label(composite, SWT.NONE);
		label_2.setText("Type Accuracy");
		label_2.setBounds(0, 0, 78, 15);
		toolkit.adapt(label_2, true, true);
		
		txtTypeAccuracy = new Text(composite, SWT.BORDER);
		txtTypeAccuracy.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtTypeAccuracy.setBounds(0, 0, 450, 21);
		txtTypeAccuracy.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__TYPE_ACCURACY);
		txtTypeAccuracy.addModifyListener(this);
		txtTypeAccuracy.addVerifyListener(verifyListener);
		toolkit.adapt(txtTypeAccuracy, true, true);
		new Label(composite, SWT.NONE);
		
		Label label_3 = new Label(composite, SWT.NONE);
		label_3.setText("Array Size");
		label_3.setBounds(0, 0, 51, 15);
		toolkit.adapt(label_3, true, true);
		
		txtArraySize = new Text(composite, SWT.BORDER);
		txtArraySize.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		txtArraySize.setBounds(0, 0, 450, 21);
		txtArraySize.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__ARRAY_SIZE);
		txtArraySize.addModifyListener(this);
		txtArraySize.addVerifyListener(verifyListener);
		toolkit.adapt(txtArraySize, true, true);
		new Label(composite, SWT.NONE);
		
		Label label_4 = new Label(composite, SWT.NONE);
		label_4.setText("Physical Unit");
		label_4.setBounds(0, 0, 68, 15);
		toolkit.adapt(label_4, true, true);
		
		cmbPhysicalUnit = new Combo(composite, SWT.READ_ONLY);
		cmbPhysicalUnit.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		cmbPhysicalUnit.setItems(new String[] { PhysicalUnitEnum.NOUNIT.toString(), PhysicalUnitEnum.METER.toString(),
				PhysicalUnitEnum.SQUAREMETER.toString(), PhysicalUnitEnum.SECOND.toString(),
				PhysicalUnitEnum.METERPERSECOND.toString(), PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED.toString(),
				PhysicalUnitEnum.METERPERSECONDSQUARED.toString(), PhysicalUnitEnum.METERPERSECONDCUBED.toString(),
				PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED.toString(), PhysicalUnitEnum.RADIAN.toString(),
				PhysicalUnitEnum.RADIANPERSECOND.toString(), PhysicalUnitEnum.RADIANPERSECONDSQUARED.toString(),
				PhysicalUnitEnum.NEWTON.toString(), PhysicalUnitEnum.DEGREECENTIGRADE.toString(),
				PhysicalUnitEnum.NEWTONMETER.toString(), PhysicalUnitEnum.NEWTONPERRAD.toString(),
				PhysicalUnitEnum.KILOGRAM.toString(), PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER.toString(),
				PhysicalUnitEnum.DECIBEL.toString(), PhysicalUnitEnum.CURVATURE.toString(),
				PhysicalUnitEnum.CURVATURERATE.toString(), PhysicalUnitEnum.KILOMETER.toString(),
				PhysicalUnitEnum.KILOMETERPERHOUR.toString(), PhysicalUnitEnum.DEGREE.toString(),
				PhysicalUnitEnum.PERCENT.toString(), PhysicalUnitEnum.MILLISECOND.toString(),
				PhysicalUnitEnum.DECIBELPERSQUAREMETER.toString(), PhysicalUnitEnum.DEGREEPERSECOND.toString(),
				PhysicalUnitEnum.PERCENTPERSECOND.toString(), PhysicalUnitEnum.PIXEL.toString(),
				PhysicalUnitEnum.MICROSECOND.toString(), PhysicalUnitEnum.BYTE.toString(),
				PhysicalUnitEnum.BIT.toString() });
		cmbPhysicalUnit.setBounds(0, 0, 450, 23);
		cmbPhysicalUnit.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT);
		cmbPhysicalUnit.addModifyListener(this);
		toolkit.adapt(cmbPhysicalUnit);
		toolkit.paintBordersFor(cmbPhysicalUnit);
		new Label(composite, SWT.NONE);
		
		Label label_5 = new Label(composite, SWT.NONE);
		label_5.setText("Accuracy");
		label_5.setBounds(0, 0, 49, 15);
		toolkit.adapt(label_5, true, true);
		
		txtAccuracy = new Text(composite, SWT.BORDER);
		txtAccuracy.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		txtAccuracy.setBounds(0, 0, 450, 21);
		txtAccuracy.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__ACCURACY);
		txtAccuracy.addModifyListener(this);
		txtAccuracy.addVerifyListener(verifyListener);
		toolkit.adapt(txtAccuracy, true, true);
		new Label(composite, SWT.NONE);
		
		Label label_6 = new Label(composite, SWT.NONE);
		label_6.setText("Interface Version");
		label_6.setBounds(0, 0, 88, 15);
		toolkit.adapt(label_6, true, true);
		
		txtInterfaceVersion = new Text(composite, SWT.BORDER);
		txtInterfaceVersion.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtInterfaceVersion.setBounds(0, 0, 450, 21);
		txtInterfaceVersion.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__INTERFACE_VERSION);
		txtInterfaceVersion.addModifyListener(this);
		txtInterfaceVersion.addVerifyListener(verifyListener);
		toolkit.adapt(txtInterfaceVersion, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblDataStructure = new Label(composite, SWT.NONE);
		toolkit.adapt(lblDataStructure, true, true);
		lblDataStructure.setText("Datastructure");
		
		txtDatastructure = new Text(composite, SWT.BORDER);
		txtDatastructure.setEnabled(false);
		txtDatastructure.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtDatastructure.setData(ArchitecturetoolPackage.Literals.ABSOLUTE_REFRENCE__DATASTRUCTURE);
		txtDatastructure.addModifyListener(this);
		toolkit.adapt(txtDatastructure, true, true);
		
		Button btnDatastructure = new Button(composite, SWT.NONE);
		btnDatastructure.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog=new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					@Override
					public String getText(Object element) {
						if (element instanceof DataStructure) {
							DataStructure dataStructure = (DataStructure) element;
							return dataStructure.getName();
							
						}
						return super.getText(element);
					}
					
				})	;	
				Generator	generator = (Generator) absoluteRefrence.eContainer().eContainer();
				EList<DataStructure> datastructure = generator.getDatastructure();
				dialog.setElements(datastructure.toArray());
				dialog.open();
				DataStructure firstResult = (DataStructure) dialog.getFirstResult();
				if (firstResult != null)
					txtDatastructure.setText(firstResult.getName());

			}
		});
		toolkit.adapt(btnDatastructure, true, true);
		btnDatastructure.setText("......");
		
		Label lblAttribute = new Label(composite, SWT.NONE);
		toolkit.adapt(lblAttribute, true, true);
		lblAttribute.setText("Attribute");
		
		txtAttribute = new Text(composite, SWT.BORDER);
		txtAttribute.setEnabled(false);
		txtAttribute.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtAttribute.setData(ArchitecturetoolPackage.Literals.ABSOLUTE_REFRENCE__ATTRIBUTE);
		txtAttribute.addModifyListener(this);
		toolkit.adapt(txtAttribute, true, true);
		
		Button btnAttribute = new Button(composite, SWT.NONE);
		btnAttribute.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog=new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					@Override
					public String getText(Object element) {
						if (element instanceof Attribute) {
							Attribute attribute = (Attribute) element;
							return attribute.getName();
							
						}
						return super.getText(element);
					}
					
				})	;	
				Generator	generator = (Generator) absoluteRefrence.eContainer().eContainer();
				
				ArrayList<Attribute> arrayList = new ArrayList<Attribute>();
				EList<DataStructure> datastructure = generator.getDatastructure();
				for (DataStructure dataStructure2 : datastructure) {
					arrayList.addAll(dataStructure2.getAttributes());
				}
				EList<Attribute> attribute = generator.getAttribute();
				arrayList.addAll(attribute);
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Attribute firstResult = (Attribute) dialog.getFirstResult();
				if (firstResult != null)
					txtAttribute.setText(firstResult.getName());
						
			}
		});
		toolkit.adapt(btnAttribute, true, true);
		btnAttribute.setText("......");
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if (absoluteRefrence.getName() != null) {
			txtName.setText(absoluteRefrence.getName());
		}
		else {
			txtName.setText("");
		}
		txtAccuracy.setText(String.valueOf(absoluteRefrence.getAccuracy()));
		txtArraySize.setText(String.valueOf(absoluteRefrence.getArraySize()));
		if (absoluteRefrence.getDescription() != null) {
			txtDesc.setText(absoluteRefrence.getDescription());
		}
		else {
			txtDesc.setText("");
		}
		txtTypeAccuracy.setText(String.valueOf(absoluteRefrence.getTypeAccuracy()));
		txtInterfaceVersion.setText(String.valueOf(absoluteRefrence.getInterfaceVersion()));

		if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.NOUNIT)) {
			cmbPhysicalUnit.select(0);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.METER)) {
			cmbPhysicalUnit.select(1);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.SQUAREMETER)) {
			cmbPhysicalUnit.select(2);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.SECOND)) {
			cmbPhysicalUnit.select(3);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECOND)) {
			cmbPhysicalUnit.select(4);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(5);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(6);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDCUBED)) {
			cmbPhysicalUnit.select(7);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED)) {
			cmbPhysicalUnit.select(8);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.RADIAN)) {
			cmbPhysicalUnit.select(9);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANPERSECOND)) {
			cmbPhysicalUnit.select(10);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(11);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTON)) {
			cmbPhysicalUnit.select(12);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREECENTIGRADE)) {
			cmbPhysicalUnit.select(13);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTONMETER)) {
			cmbPhysicalUnit.select(14);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTONPERRAD)) {
			cmbPhysicalUnit.select(15);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.KILOGRAM)) {
			cmbPhysicalUnit.select(16);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER)) {
			cmbPhysicalUnit.select(17);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.DECIBEL)) {
			cmbPhysicalUnit.select(18);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.CURVATURE)) {
			cmbPhysicalUnit.select(19);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.CURVATURERATE)) {
			cmbPhysicalUnit.select(20);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.KILOMETER)) {
			cmbPhysicalUnit.select(21);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.KILOMETERPERHOUR)) {
			cmbPhysicalUnit.select(22);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREE)) {
			cmbPhysicalUnit.select(23);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.PERCENT)) {
			cmbPhysicalUnit.select(24);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.MILLISECOND)) {
			cmbPhysicalUnit.select(25);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.DECIBELPERSQUAREMETER)) {
			cmbPhysicalUnit.select(26);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREEPERSECOND)) {
			cmbPhysicalUnit.select(27);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.PERCENTPERSECOND)) {
			cmbPhysicalUnit.select(28);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.PIXEL)) {
			cmbPhysicalUnit.select(29);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.MICROSECOND)) {
			cmbPhysicalUnit.select(30);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.BYTE)) {
			cmbPhysicalUnit.select(31);
		} else if (absoluteRefrence.getPhysicalUnit().equals(PhysicalUnitEnum.BIT)) {
			cmbPhysicalUnit.select(32);
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1) {
			absoluteRefrence = (AbsoluteRefrence) structuredSelection.getFirstElement();
		}
		else
			absoluteRefrence=null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					absoluteRefrence.eSet(data, ((Text) source).getText());
				else if (eAttributeType.getName().equals("EInt"))
					absoluteRefrence.eSet(data, Integer.parseInt(((Text) source).getText()));
				else if (eAttributeType.getName().equals("EFloat"))
					absoluteRefrence.eSet(data, Float.parseFloat(((Text) source).getText()));
			}
			

		} else if (source instanceof Combo) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (data instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("PhysicalUnitEnum"))
					absoluteRefrence.eSet(data, PhysicalUnitEnum.get(((Combo) source).getText()));
				


			}
		}

	}

	@Override
	public void verifyText(VerifyEvent e) {
		
	}

}
