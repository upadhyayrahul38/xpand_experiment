package com.conti.component.ui.editor;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.plugin.AbstractUIPlugin;

import architecturetool.NoNameElement;

public class CustomAdapterFactoryLabelProvider extends AdapterFactoryLabelProvider {

	public CustomAdapterFactoryLabelProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}
	
	
	@Override
	public Image getImage(Object object) {
		if (object instanceof NoNameElement) {
			ImageDescriptor imageDescriptorFromPlugin = AbstractUIPlugin
					.imageDescriptorFromPlugin("com.conti.component.ui", "icons/green_light.gif");
			Image createImage = imageDescriptorFromPlugin.createImage();
			return createImage;
		}
		return super.getImage(object);
	}

}
