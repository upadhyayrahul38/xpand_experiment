package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.ComponentInstance;
import architecturetool.ECU;
import architecturetool.FunctionalRequirement;
import architecturetool.Memory;
import architecturetool.Node;

public class NodeDetailPage implements IDetailsPage ,ModifyListener{

	private class MemoryTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}
		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Memory) {
				Memory memory = (Memory) element;
				switch (columnIndex) {
				case 0:
					return memory.getName();
				}
			}
			return element.toString();
		}
	}
	private class ComponentInstanceTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}
		public String getColumnText(Object element, int columnIndex) {
			
			if (element instanceof ComponentInstance) {
				ComponentInstance componentInstance = (ComponentInstance) element;
				switch (columnIndex) {
				case 0:
					return componentInstance.getName();
				}
			}
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtName;
	private Table componentinstanceTable;
	private Table memoryTable;
	private TableViewer componentInstanceTableViewer;
	private TableViewer memoryTableViewer;
	private Node node;

	/**
	 * Create the details page.
	 */
	public NodeDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//		
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Node");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(2, false));
		
		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.CPU__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);
		
		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setLayout(new GridLayout(4, false));
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));
		toolkit.adapt(composite_1);
		toolkit.paintBordersFor(composite_1);
		
		componentInstanceTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		componentinstanceTable = componentInstanceTableViewer.getTable();
		componentinstanceTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(componentinstanceTable);
		toolkit.paintBordersFor(componentinstanceTable);
		componentinstanceTable.setHeaderVisible(true);
		componentinstanceTable.setLinesVisible(true);
		
		TableColumn tblclmnNodes = new TableColumn(componentinstanceTable, SWT.NONE);
		tblclmnNodes.setWidth(262);
		tblclmnNodes.setText("Component Instance");
		
		
		Button btnNodes = new Button(composite_1, SWT.NONE);
		btnNodes.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) { 
				ElementListSelectionDialog dialog=new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					@Override
					public String getText(Object element) {
						if (element instanceof ComponentInstance) {
							ComponentInstance componentInstance = (ComponentInstance) element;
							return componentInstance.getName();
						}
						return super.getText(element);
					}
				});
				 ECU ecu = (ECU) node.eContainer().eContainer();
				 ArrayList<ComponentInstance> arrayList = new ArrayList<ComponentInstance>();
				 EList<FunctionalRequirement> functionalrequirements = ecu.getFunctionalrequirements();
				 for (FunctionalRequirement functionalRequirement : functionalrequirements) {
					arrayList.addAll(functionalRequirement.getComponentinstance());
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				ComponentInstance firstResult = (ComponentInstance) dialog.getFirstResult();
				node.getComponentinstance().add(firstResult);
				componentInstanceTableViewer.refresh();
			}
		});
		btnNodes.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(btnNodes, true, true);
		btnNodes.setText(".....");
		
		memoryTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		memoryTable = memoryTableViewer.getTable();
		memoryTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(memoryTable);
		toolkit.paintBordersFor(memoryTable);
		memoryTable.setHeaderVisible(true);
		memoryTable.setLinesVisible(true);
		
		TableColumn tblclmnMemory = new TableColumn(memoryTable, SWT.NONE);
		tblclmnMemory.setWidth(253);
		tblclmnMemory.setText("Memory");
		
		
		Button btnMemory = new Button(composite_1, SWT.NONE);
		btnMemory.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) { 
				ElementListSelectionDialog dialog=new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					@Override
					public String getText(Object element) {
						if (element instanceof Memory) {
							Memory memory = (Memory) element;
							return memory.getName();
						}
						return super.getText(element);
					}
				});
				 ECU ecu = (ECU) node.eContainer().eContainer();
				 EList<Memory> memory = ecu.getMemory();
				dialog.setElements(memory.toArray());
				dialog.open();
				Memory firstResult = (Memory) dialog.getFirstResult();
				node.getMemory().add(firstResult);
				memoryTableViewer.refresh();
			}
		});
		btnMemory.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(btnMemory, true, true);
		btnMemory.setText(".....");
		new Label(composite, SWT.NONE);
		
		componentInstanceTableViewer.setContentProvider(new ArrayContentProvider());
		componentInstanceTableViewer.setLabelProvider(new ComponentInstanceTableLabelProvider());
		memoryTableViewer.setContentProvider(new ArrayContentProvider());
		memoryTableViewer.setLabelProvider(new MemoryTableLabelProvider());
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if(node.getName()!=null)
			txtName.setText(node.getName());
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1) {
			node = (Node) structuredSelection.getFirstElement();
		}
		else 
			node=null;
		memoryTableViewer.setInput(node.getMemory());
		componentInstanceTableViewer.setInput(node.getComponentinstance());
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (data instanceof EAttribute) {
				EAttribute attribute = (EAttribute) data;
				if(attribute.getEAttributeType().getName().equals("EString"))
					node.eSet(data, ((Text)source).getText());
			}
		}
		
	}

}
