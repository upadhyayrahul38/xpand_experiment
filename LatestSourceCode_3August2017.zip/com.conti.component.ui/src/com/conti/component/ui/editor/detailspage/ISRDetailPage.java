package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.ISR;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Runnable;
import architecturetool.Runnables;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Button;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class ISRDetailPage implements IDetailsPage ,ModifyListener{
	private class TableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}
		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Runnable) {
				Runnable runnable = (Runnable) element;
				switch (columnIndex) {
				case 0:
					return runnable.getName();
				}
				
			}
			
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtName;
	private Table isrTable;
	private TableViewer isrTableViewer;
	private ISR isr;

	/**
	 * Create the details page.
	 */
	public ISRDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//		
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("ISR");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));
		
		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.ISR__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);
		
		isrTableViewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION);
		isrTable = isrTableViewer.getTable();
		isrTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		toolkit.adapt(isrTable);
		toolkit.paintBordersFor(isrTable);
		isrTable.setHeaderVisible(true);
		isrTable.setLinesVisible(true);
		
		TableColumn tblclmnRunnables = new TableColumn(isrTable, SWT.NONE);
		tblclmnRunnables.setWidth(575);
		tblclmnRunnables.setText("Runnables");
		
		isrTableViewer.setLabelProvider(new TableLabelProvider());
		isrTableViewer.setContentProvider(new ArrayContentProvider());
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Runnable) {
									Runnable runnable = (Runnable) element;
								return	runnable.getName();
								}
								return super.getText(element);
							}
						});
				NoNameElement noNameElement = (NoNameElement) isr.eContainer().eContainer().eContainer().eContainer();
				ArrayList<Runnable> arrayList = new ArrayList<Runnable>();
				EList<MCC> mcc = noNameElement.getMcc();
				for (MCC mcc2 : mcc) {
					EList<Component> components = mcc2.getComponents();
					for (Component component : components) {
						Runnables runnables = component.getRunnables();
						if(runnables!=null)
						{
							arrayList.addAll(runnables.getRunnable());
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Runnable firstResult = (Runnable) dialog.getFirstResult();
				isr.getRunnables().add(firstResult);
				isrTableViewer.refresh();
			}
		});
		button.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(button, true, true);
		button.setText(".....");
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if(isr.getName()!=null)
			txtName.setText(isr.getName());
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1) {
			isr = (ISR) structuredSelection.getFirstElement();
		}
		else isr=null;
		isrTableViewer.setInput(isr.getRunnables());
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EAttribute attribute = (EAttribute) data;
				if (attribute.getEAttributeType().getName().equals("EString"));
				isr.eSet(data, ((Text) source).getText());

			}
		}

	}

}
