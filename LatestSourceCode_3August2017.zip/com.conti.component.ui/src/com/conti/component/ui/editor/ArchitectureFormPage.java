package com.conti.component.ui.editor;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.editor.FormPage;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;

public class ArchitectureFormPage extends FormPage {

	private EObject eObject;
	private FormEditor formEditor;

	/**
	 * Create the form page.
	 * @param id
	 * @param title
	 */
	public ArchitectureFormPage(String id, String title) {
		super(id, title);
	}

	/**
	 * Create the form page.
	 * @param editor
	 * @param id
	 * @param title
	 * @param eObject 
	 * @wbp.parser.constructor
	 * @wbp.eval.method.parameter id "Some id"
	 * @wbp.eval.method.parameter title "Some title"
	 */
	public ArchitectureFormPage(FormEditor editor, String id, String title, EObject eObject) {
		super(editor, id, title);
		this.formEditor = editor;
		this.eObject = eObject;
	}

	/**
	 * Create contents of the form.
	 * @param managedForm
	 */
	@Override
	protected void createFormContent(IManagedForm managedForm) {
		FormToolkit toolkit = managedForm.getToolkit();
		ScrolledForm form = managedForm.getForm();
		String name = formEditor.getEditorInput().getName();
		String fileName = name.substring(0,name.indexOf("."));
		form.setText(fileName+" Configuration");// "Empty FormPage" 
		Composite body = form.getBody();
		toolkit.decorateFormHeading(form.getForm());
		toolkit.paintBordersFor(body);
		
		ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock = new ArchitectureToolMasterDetailBlock(eObject, getEditor());
		architectureToolMasterDetailBlock.createContent(managedForm);
	}
	
	@Override
	public void doSave(IProgressMonitor monitor) {
		super.doSave(monitor);
	}
}
