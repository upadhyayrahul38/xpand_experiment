package com.conti.component.ui.editor.detailspage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.DatatypeEnum;
import architecturetool.Enum;
import architecturetool.Parameter;
import architecturetool.ParameterConditionEnum;
import architecturetool.PhysicalUnitEnum;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;

public class ParameterDetailPage implements IDetailsPage, ModifyListener {

	private IManagedForm managedForm;
	private Text  txtname;
	private Parameter parameter;
	private Text txtParameterValue;
	private Combo cmbParamConditions;

	/**
	 * Create the details page.
	 */
	public ParameterDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section sctnParameter = toolkit.createSection(parent,
				ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		sctnParameter.setText("Parameter");
		//
		Composite composite = toolkit.createComposite(sctnParameter, SWT.NONE);
		toolkit.paintBordersFor(composite);
		sctnParameter.setClient(composite);
		composite.setLayout(new GridLayout(2, false));

		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");

		 txtname = new Text(composite, SWT.BORDER);
		 txtname.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		 txtname.setData(ArchitecturetoolPackage.Literals.PARAMETER__NAME);
		 txtname.addModifyListener(this);
		toolkit.adapt( txtname, true, true);
		
		Label lblParamConditions = new Label(composite, SWT.NONE);
		toolkit.adapt(lblParamConditions, true, true);
		lblParamConditions.setText("Parameter Conditions:");

		cmbParamConditions = new Combo(composite, SWT.READ_ONLY);
		cmbParamConditions.setItems(new String[] { ParameterConditionEnum.GREATER_THAN.toString(),
				ParameterConditionEnum.DOUBLE_EQUAL.toString(), ParameterConditionEnum.GREATER_THAN_EQUAL.toString(),
				ParameterConditionEnum.LESS_THAN_EQUAL.toString(), ParameterConditionEnum.LESSER_THAN.toString(),
				ParameterConditionEnum.NOT_EQUAL.toString() });
        cmbParamConditions.select(1);
		cmbParamConditions.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		cmbParamConditions.setData(ArchitecturetoolPackage.Literals.PARAMETER__PARAMETER_CONDITION);
		cmbParamConditions.addModifyListener(this);
		toolkit.adapt(cmbParamConditions,true,true);
		toolkit.paintBordersFor(cmbParamConditions);
		
		lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Value");

		txtParameterValue = new Text(composite, SWT.BORDER);
		txtParameterValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtParameterValue.setData(ArchitecturetoolPackage.Literals.PARAMETER__VALUE);
		txtParameterValue.addModifyListener(this);
		toolkit.adapt(txtParameterValue, true, true);

	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if (parameter != null) {
			if (parameter.getName() != null && !parameter.getName().trim().isEmpty()) {
				txtname.setText(parameter.getName());
                if(parameter.getValue() == null) {
                	parameter.setValue("".trim());
                	txtParameterValue.setText(parameter.getValue());
                } else {
                	txtParameterValue.setText(parameter.getValue());                	
                }
				cmbParamConditions.select(parameter.getParameterCondition().getValue());
			} else {
				parameter.setName("");
				txtname.setText("");
				if(parameter.getValue() == null) {
                	parameter.setValue("".trim());
                	txtParameterValue.setText(parameter.getValue());
                } else {
                	txtParameterValue.setText(parameter.getValue());                	
                }
				cmbParamConditions.select(0);
			}
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			parameter = (Parameter) structuredSelection.getFirstElement();

		} else
			parameter = null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute && data.getName().equals("name")) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					parameter.eSet(data, ((Text) source).getText());
			}
			if(source.getData() instanceof EAttribute && data.getName().equals("Value")) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString")) {
					parameter.eSet(data, ((Text) source).getText());
				}
			}
			

		}
		if(source instanceof Combo) {
			int selectionIndex = ((Combo)source).getSelectionIndex();
			String selItem = ((Combo)source).getItem(selectionIndex);
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (data instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if(eAttributeType.getName().equals("ParameterConditionEnum")) {
					parameter.eSet(data, ParameterConditionEnum.get(selItem));
					parameter.setParameterCondition(ParameterConditionEnum.get(((Combo) source).getText()));
				}
			}
		}
	}

}
