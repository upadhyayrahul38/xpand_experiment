package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.BuildUnit;
import architecturetool.CPU;
import architecturetool.Component;
import architecturetool.ComponentInstance;
import architecturetool.ECU;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Node;
import architecturetool.Runnable;
import architecturetool.Runnables;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;

public class ComponentInstanceDetailPage implements IDetailsPage,ModifyListener,VerifyListener {
	private class BuildUnitTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}
		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof BuildUnit) {
				BuildUnit buildUnit = (BuildUnit) element;
				switch (columnIndex) {
				case 0:
					return buildUnit.getName();
				}
			}
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtRam;
	private Text txtRamSection;
	private Text txtRom;
	private Text txtNMV;
	private Text txtMeas;
	private Text txtType;
	private Text txtOwner;
	private Text tXTComponent;
	private Table buildUnitTable;
	private TableViewer buildUnitTableViewer;
	private ComponentInstance componentInstance;

	/**
	 * Create the details page.
	 */
	public ComponentInstanceDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * @param parent
	 */
	public void createContents(Composite parent) {
		
		UtillVerifyListener verifyListener = new UtillVerifyListener();
		
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//		
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Component Instance");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));
		
		Label lblName = new Label(composite, SWT.NONE);
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__NAME);
		txtName.addModifyListener(this);
		
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblRam = new Label(composite, SWT.NONE);
		toolkit.adapt(lblRam, true, true);
		lblRam.setText("Ram");
		
		txtRam = new Text(composite, SWT.BORDER);
		txtRam.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRam.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__RAM);
		txtRam.addModifyListener(this);
		txtRam.addVerifyListener(verifyListener);
		toolkit.adapt(txtRam, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblRamSection = new Label(composite, SWT.NONE);
		toolkit.adapt(lblRamSection, true, true);
		lblRamSection.setText("Ram Section");
		
		txtRamSection = new Text(composite, SWT.BORDER);
		txtRamSection.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRamSection.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__RAM_SECTION);
		txtRamSection.addModifyListener(this);
		toolkit.adapt(txtRamSection, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblRom = new Label(composite, SWT.NONE);
		toolkit.adapt(lblRom, true, true);
		lblRom.setText("Rom");
		
		txtRom = new Text(composite, SWT.BORDER);
		txtRom.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRom.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__ROM);
		txtRom.addModifyListener(this);
		txtRom.addVerifyListener(verifyListener);
		toolkit.adapt(txtRom, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblNmv = new Label(composite, SWT.NONE);
		toolkit.adapt(lblNmv, true, true);
		lblNmv.setText("NMV");
		
		txtNMV = new Text(composite, SWT.BORDER);
		txtNMV.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtNMV.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__NMV);
		txtNMV.addModifyListener(this);
		txtNMV.addVerifyListener(verifyListener);
		toolkit.adapt(txtNMV, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblMeans = new Label(composite, SWT.NONE);
		toolkit.adapt(lblMeans, true, true);
		lblMeans.setText("Meas");
		
		txtMeas = new Text(composite, SWT.BORDER);
		txtMeas.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtMeas.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__MEAS);
		txtMeas.addModifyListener(this);
		txtMeas.addVerifyListener(verifyListener);
		toolkit.adapt(txtMeas, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblType = new Label(composite, SWT.NONE);
		toolkit.adapt(lblType, true, true);
		lblType.setText("Type");
		
		txtType = new Text(composite, SWT.BORDER);
		txtType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtType.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__TYPE);
		txtType.addModifyListener(this);
		toolkit.adapt(txtType, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblOwner = new Label(composite, SWT.NONE);
		toolkit.adapt(lblOwner, true, true);
		lblOwner.setText("Owner");
		
		txtOwner = new Text(composite, SWT.BORDER);
		txtOwner.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtOwner.setData(ArchitecturetoolPackage.Literals.COMPONENT_INSTANCE__OWNER);
		txtOwner.addModifyListener(this);
		toolkit.adapt(txtOwner, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblComponent = new Label(composite, SWT.NONE);
		lblComponent.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblComponent, true, true);
		lblComponent.setText("Component");
		
		tXTComponent = new Text(composite, SWT.BORDER);
		tXTComponent.setEnabled(false);
		tXTComponent.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(tXTComponent, true, true);
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Component) {
									Component runnable = (Component) element;
								return	runnable.getName();
								}
								return super.getText(element);
							}
						});
				NoNameElement noNameElement = (NoNameElement) componentInstance.eContainer().eContainer().eContainer();
				ArrayList<Component> arrayList = new ArrayList<Component>();
				EList<MCC> mcc = noNameElement.getMcc();
				for (MCC mcc2 : mcc) {
					arrayList.addAll(mcc2.getComponents());
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Component firstResult = (Component) dialog.getFirstResult();
				tXTComponent.setText(firstResult.getName());
				componentInstance.setComponent(firstResult);
				
			}
		});
		toolkit.adapt(button, true, true);
		button.setText(".....");
		
		buildUnitTableViewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION);
		buildUnitTable = buildUnitTableViewer.getTable();
		buildUnitTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		toolkit.adapt(buildUnitTable);
		toolkit.paintBordersFor(buildUnitTable);
		buildUnitTable.setHeaderVisible(true);
		buildUnitTable.setLinesVisible(true);
		
		
		
		TableColumn tblclmnBuildunits = new TableColumn(buildUnitTable, SWT.NONE);
		tblclmnBuildunits.setWidth(539);
		tblclmnBuildunits.setText("BuildUnits");
		buildUnitTableViewer.setLabelProvider(new BuildUnitTableLabelProvider());
		buildUnitTableViewer.setContentProvider(new ArrayContentProvider());
		
		Button button_1 = new Button(composite, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog=new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					@Override
					public String getText(Object element) {
						if (element instanceof BuildUnit) {
							BuildUnit buildUnit = (BuildUnit) element;
							
							return buildUnit.getName();
						}
						return super.getText(element);
					}
				});
				ECU ecu =(ECU) componentInstance.eContainer().eContainer();
				ArrayList< BuildUnit> arrayList=new ArrayList<BuildUnit>();
				EList<CPU> cpus = ecu.getCpus();
				for (CPU cpu : cpus) {
					EList<Node> nodes = cpu.getNodes();
					for (Node node : nodes) {
						arrayList.addAll(node.getBuildunits());
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				BuildUnit firstResult = (BuildUnit) dialog.getFirstResult();
				componentInstance.getBuildunits().add(firstResult);
				buildUnitTableViewer.refresh();
			}
		});
		button_1.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(button_1, true, true);
		button_1.setText(".....");
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if(componentInstance.getName()!=null)
		{
			txtName.setText(componentInstance.getName());
		}
		if(componentInstance.getOwner()!=null)
		{
			txtOwner.setText(componentInstance.getOwner());
		}
		if(componentInstance.getRamSection()!=null)
		{
			txtRamSection.setText(componentInstance.getRamSection());
		}
		if(componentInstance.getType()!=null)
		{
			txtType.setText(componentInstance.getType());
		}
		if(componentInstance.getComponent()!=null && componentInstance.getComponent().getName()!=null)
		{
			tXTComponent.setText(componentInstance.getComponent().getName());
		}
		txtMeas.setText(String.valueOf(componentInstance.getMeas()));
		txtNMV.setText(String.valueOf(componentInstance.getNmv()));
		txtRam.setText(String.valueOf(componentInstance.getRam()));
		txtRom.setText(String.valueOf(componentInstance.getRom()));
		
		
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1) {
			componentInstance = (ComponentInstance) structuredSelection.getFirstElement();
		}
		else
		componentInstance=null;
		buildUnitTableViewer.setInput(componentInstance.getBuildunits());
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {

		Widget source = e.widget;
		if (source instanceof Text) {

			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					componentInstance.eSet(data, ((Text) source).getText());
				else if (eAttributeType.getName().equals("EInt"))
 					componentInstance.eSet(data, Integer.parseInt(((Text) source).getText()));
				else if (eAttributeType.getName().equals("EDouble"))
 					componentInstance.eSet(data, Double.parseDouble(((Text) source).getText()));
			}

		}

	
	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
