package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.BuildUnit;
import architecturetool.ECU;
import architecturetool.Memory;
import architecturetool.MemoryPartition;
import architecturetool.Node;
import architecturetool.OSApplication;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class BuildUnitDetailPage implements IDetailsPage,ModifyListener {

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtMemoryPartition;
	private BuildUnit buildtUnit;

	/**
	 * Create the details page.
	 */
	public BuildUnitDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//		
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("BuildUnit");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));
		
		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.BUILD_UNIT__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);
		
		Label lblMemoryPartition = new Label(composite, SWT.NONE);
		lblMemoryPartition.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblMemoryPartition, true, true);
		lblMemoryPartition.setText("Memory Partition");
		
		txtMemoryPartition = new Text(composite, SWT.BORDER);
		txtMemoryPartition.setEnabled(false);
		txtMemoryPartition.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtMemoryPartition.setData(ArchitecturetoolPackage.Literals.BUILD_UNIT__MEMORYPARTITION);
		txtMemoryPartition.addModifyListener(this);
		toolkit.adapt(txtMemoryPartition, true, true);
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog= new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					@Override
					public String getText(Object element) {
						if (element instanceof MemoryPartition) {
							MemoryPartition memoryPartition = (MemoryPartition) element;
							return memoryPartition.getClass().getName();
							
						}
						return super.getText(element);
					}
				});
				ECU ecu = (ECU) buildtUnit.eContainer().eContainer().eContainer();
				ArrayList<MemoryPartition> arrayList = new ArrayList<MemoryPartition>();
				Node node = (Node) buildtUnit.eContainer();
				EList<OSApplication> osapplications = node.getOsapplications();
				if (osapplications != null) {
					for (Iterator iterator = osapplications.iterator(); iterator.hasNext();) {
						OSApplication osApplication = (OSApplication) iterator.next();
						MemoryPartition memorypartition = osApplication.getMemorypartition();
                        if(!arrayList.contains(memorypartition)) {
                            arrayList.add(memorypartition);                        	
                        }
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				MemoryPartition firstResult = (MemoryPartition) dialog.getFirstResult();
				txtMemoryPartition.setText(firstResult.toString());
			}
		});
		toolkit.adapt(button, true, true);
		button.setText(".....");
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if(buildtUnit.getName()!=null)
		{
			txtName.setText(buildtUnit.getName());
		}
		if(buildtUnit.getMemorypartition()!=null)
		{
			txtMemoryPartition.setText(buildtUnit.getMemorypartition().toString());
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if(structuredSelection.size()==1) {
			buildtUnit = (BuildUnit) structuredSelection.getFirstElement();
		}
		else
			buildtUnit=null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EAttribute attribute = (EAttribute) data;
				if(attribute.getEAttributeType().getName().equals("EString"));
				buildtUnit.eSet(data, ((Text)source).getText());
				
			}
		}
		
	}

}
