package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.CPU;
import architecturetool.ECU;
import architecturetool.ISR;
import architecturetool.Memory;
import architecturetool.MemoryPartition;
import architecturetool.NoNameElement;
import architecturetool.Node;
import architecturetool.OSApplication;
import architecturetool.Task;

public class OSApplicationDetailPage implements IDetailsPage, ModifyListener {
	private class ISRTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof ISR) {
				ISR isr = (ISR) element;
				switch (columnIndex) {
				case 0:
					return isr.getName();
				}
			}
			return element.toString();
		}
	}

	private class TaskTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Task) {
				Task task = (Task) element;
				switch (columnIndex) {
				case 0:
					return task.getName();
				}
			}
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtMemoryPartition;
	private Table taskTable;
	private Table isrTable;
	private TableViewer taskTableViewer;
	private TableViewer isrTableViewer;
	private OSApplication osApplication;

	/**
	 * Create the details page.
	 */
	public OSApplicationDetailPage() {
		// Create the details page
	}

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("OSApplication");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));

		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");

		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.OS_APPLICATION__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);

		Label lblMemoryPartition = new Label(composite, SWT.NONE);
		lblMemoryPartition.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblMemoryPartition, true, true);
		lblMemoryPartition.setText("Memory Partition");

		txtMemoryPartition = new Text(composite, SWT.BORDER);
		txtMemoryPartition.setEnabled(false);
		txtMemoryPartition.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtMemoryPartition.addModifyListener(this);
		toolkit.adapt(txtMemoryPartition, true, true);

		Button btnMemoryPartition = new Button(composite, SWT.NONE);
		btnMemoryPartition.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof MemoryPartition) {
									MemoryPartition memoryPartition = (MemoryPartition) element;
									return memoryPartition.toString();

								}
								return super.getText(element);
							}
						});
				ECU ecu = (ECU) osApplication.eContainer().eContainer().eContainer();
				ArrayList<MemoryPartition> arrayList = new ArrayList<MemoryPartition>();
				EList<Memory> memory = ecu.getMemory();
				EList<CPU> cpus = ecu.getCpus();
				for (Iterator iterator = cpus.iterator(); iterator.hasNext();) {
					CPU cpu = (CPU) iterator.next();
					EList<Node> nodes = cpu.getNodes();
					for (Iterator iterator2 = nodes.iterator(); iterator2.hasNext();) {
						Node node = (Node) iterator2.next();
						EList<OSApplication> osapplications = node.getOsapplications();
						if (osapplications != null) {
							for (Iterator iteratorOsApp = osapplications.iterator(); iteratorOsApp.hasNext();) {
								OSApplication osApplication = (OSApplication) iteratorOsApp.next();
								MemoryPartition memorypartition = osApplication.getMemorypartition();
								if (!arrayList.contains(memorypartition)) {
									arrayList.add(memorypartition);
								}
							}
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				MemoryPartition firstResult = (MemoryPartition) dialog.getFirstResult();
				txtMemoryPartition.setText(firstResult.toString());

			}
		});
		toolkit.adapt(btnMemoryPartition, true, true);
		btnMemoryPartition.setText(".....");

		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setLayout(new GridLayout(4, false));
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 3, 1));
		toolkit.adapt(composite_1);
		toolkit.paintBordersFor(composite_1);

		taskTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		taskTable = taskTableViewer.getTable();
		taskTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(taskTable);
		toolkit.paintBordersFor(taskTable);
		taskTable.setHeaderVisible(true);
		taskTable.setLinesVisible(true);

		TableColumn tblclmnTasks = new TableColumn(taskTable, SWT.NONE);
		tblclmnTasks.setWidth(255);
		tblclmnTasks.setText("Tasks");

		Button btnTask = new Button(composite_1, SWT.NONE);
		btnTask.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof Task) {
									Task task = (Task) element;
									return task.getName();
								}
								return super.getText(element);
							}
						});
				NoNameElement noNameElement = (NoNameElement) osApplication.eContainer().eContainer().eContainer()
						.eContainer();
				ArrayList<Task> arrayList = new ArrayList<Task>();
				EList<ECU> ecus = noNameElement.getEcus();
				for (ECU ecu2 : ecus) {
					EList<CPU> cpus = ecu2.getCpus();
					for (CPU cpu : cpus) {
						EList<Node> nodes = cpu.getNodes();
						for (Node node : nodes) {
							arrayList.addAll(node.getTask());
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				Task firstResult = (Task) dialog.getFirstResult();
				osApplication.getTasks().add(firstResult);
				taskTableViewer.refresh();

			}
		});
		btnTask.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(btnTask, true, true);
		btnTask.setText(".....");

		isrTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		isrTable = isrTableViewer.getTable();
		isrTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(isrTable);
		toolkit.paintBordersFor(isrTable);
		isrTable.setHeaderVisible(true);
		isrTable.setLinesVisible(true);

		TableColumn tblclmnIsr = new TableColumn(isrTable, SWT.NONE);
		tblclmnIsr.setWidth(255);
		tblclmnIsr.setText("ISR");

		Button btnIsr = new Button(composite_1, SWT.NONE);
		btnIsr.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof ISR) {
									ISR task = (ISR) element;
									return task.getName();
								}
								return super.getText(element);
							}
						});
				NoNameElement noNameElement = (NoNameElement) osApplication.eContainer().eContainer().eContainer()
						.eContainer();
				ArrayList<ISR> arrayList = new ArrayList<ISR>();
				EList<ECU> ecus = noNameElement.getEcus();
				for (ECU ecu2 : ecus) {
					EList<CPU> cpus = ecu2.getCpus();
					for (CPU cpu : cpus) {
						EList<Node> nodes = cpu.getNodes();
						for (Node node : nodes) {
							arrayList.addAll(node.getIsr());
						}
					}
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				ISR firstResult = (ISR) dialog.getFirstResult();
				osApplication.getIsr().add(firstResult);
				isrTableViewer.refresh();

			}
		});
		btnIsr.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		toolkit.adapt(btnIsr, true, true);
		btnIsr.setText(".....");

		taskTableViewer.setLabelProvider(new TaskTableLabelProvider());
		taskTableViewer.setContentProvider(new ArrayContentProvider());

		isrTableViewer.setLabelProvider(new ISRTableLabelProvider());
		isrTableViewer.setContentProvider(new ArrayContentProvider());
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if (osApplication.getName() != null)
			txtName.setText(osApplication.getName());
		if (osApplication.getMemorypartition() != null)
			txtMemoryPartition.setText(osApplication.getMemorypartition().toString());

	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			osApplication = (OSApplication) structuredSelection.getFirstElement();
		} else
			osApplication = null;
		taskTableViewer.setInput(osApplication.getTasks());
		isrTableViewer.setInput(osApplication.getIsr());
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EAttribute attribute = (EAttribute) data;
				if (attribute.getEAttributeType().getName().equals("EString"));
				osApplication.eSet(data, ((Text) source).getText());

			}
		}

	}

}
