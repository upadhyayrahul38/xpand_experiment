package com.conti.component.ui.editor;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerDropAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.TransferData;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.Enum;
import architecturetool.Flow;
import architecturetool.Flows;
import architecturetool.Generator;
import architecturetool.Literal;
import architecturetool.MCC;
import architecturetool.Parameter;
import architecturetool.Port;
import architecturetool.Ports;
import architecturetool.Runnables;
import architecturetool.SubComponent;
import architecturetool.impl.AbsoluteRefrenceImpl;
import architecturetool.impl.AttributeImpl;
import architecturetool.impl.ComponentImpl;
import architecturetool.impl.DataStructureImpl;
import architecturetool.impl.EnumImpl;
import architecturetool.impl.FlowImpl;
import architecturetool.impl.FlowsImpl;
import architecturetool.impl.GeneratorImpl;
import architecturetool.impl.LiteralImpl;
import architecturetool.impl.MCCImpl;
import architecturetool.impl.ParameterImpl;
import architecturetool.impl.PortImpl;
import architecturetool.impl.PortsImpl;
import architecturetool.impl.RunnableImpl;
import architecturetool.impl.RunnablesImpl;
import architecturetool.impl.SubComponentImpl;

public class TreeDropListener extends ViewerDropAdapter {

	private Viewer viewer;
	private Object target;

	protected TreeDropListener(Viewer viewer) {
		super(viewer);
		// TODO Auto-generated constructor stub
		this.viewer = viewer;
	}

	@Override
	public void drop(DropTargetEvent event) {
		int location = this.determineLocation(event);
		target = determineTarget(event);

		String translatedLocation = "";

		System.out.println(translatedLocation);
		System.out.println("The drop was done on the element: " + target);
		super.drop(event);
	}

	@Override
	public boolean performDrop(Object data) {
		System.out.println(data.toString());
		IStructuredSelection selection = (IStructuredSelection) viewer.getSelection();
		Object firstElement = selection.getFirstElement();
		if (firstElement instanceof AttributeImpl && target instanceof DataStructureImpl) {
			Attribute attribute = (Attribute) firstElement;
			DataStructureImpl target2 = (DataStructureImpl) target;
			target2.getAttributes().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof AbsoluteRefrenceImpl && target instanceof DataStructureImpl) {
			AbsoluteRefrence attribute = (AbsoluteRefrence) firstElement;
			DataStructure target2 = (DataStructure) target;
			target2.getAbsolutereference().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof DataStructureImpl && target instanceof Generator) {
			DataStructure attribute = (DataStructure) firstElement;
			Generator target2 = (Generator) target;
			target2.getDatastructure().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof DataStructureImpl && target instanceof DataStructureImpl) {
			DataStructure attribute = (DataStructure) firstElement;
			DataStructure target2 = (DataStructure) target;
			target2.getStructs().add(attribute);
		} else if (firstElement instanceof LiteralImpl && target instanceof EnumImpl) {
			Literal attribute = (Literal) firstElement;
			Enum target2 = (Enum) target;
			target2.getLiteral().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof ComponentImpl && target instanceof MCCImpl) {
			Component attribute = (Component) firstElement;
			MCCImpl target2 = (MCCImpl) target;
			target2.getComponents().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof ParameterImpl && target instanceof MCCImpl) {
			Parameter attribute = (Parameter) firstElement;
			MCCImpl target2 = (MCCImpl) target;
			target2.getParameters().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof GeneratorImpl && target instanceof ComponentImpl) {
			Generator attribute = (Generator) firstElement;
			ComponentImpl target2 = (ComponentImpl) target;
			target2.getGenerator().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof SubComponentImpl && target instanceof ComponentImpl) {
			SubComponent attribute = (SubComponent) firstElement;
			ComponentImpl target2 = (ComponentImpl) target;
			target2.getSubcomponent().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof PortImpl && target instanceof PortsImpl) {
			Port attribute = (Port) firstElement;
			PortsImpl target2 = (PortsImpl) target;
			target2.getPort().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof RunnableImpl && target instanceof RunnablesImpl) {
			architecturetool.Runnable attribute = (architecturetool.Runnable) firstElement;
			RunnablesImpl target2 = (RunnablesImpl) target;
			target2.getRunnable().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof FlowImpl && target instanceof FlowsImpl) {
			Flow attribute = (Flow) firstElement;
			Flows target2 = (Flows) target;
			target2.getFlow().add(attribute);
			viewer.refresh();
		} else if (firstElement instanceof ParameterImpl && target instanceof ComponentImpl) {
			Parameter attribute = (Parameter) firstElement;
			ComponentImpl target2 = (ComponentImpl) target;
			target2.getParameters().add(attribute);
			viewer.refresh();
		}
		return true;
	}

	@Override
	public boolean validateDrop(Object target, int operation, TransferData transferType) {
		IStructuredSelection selection = (IStructuredSelection) viewer.getSelection();
		Object firstElement = selection.getFirstElement();
		if (firstElement instanceof AttributeImpl && target instanceof DataStructureImpl) {
			return true;
		} else if (firstElement instanceof AbsoluteRefrenceImpl && target instanceof DataStructureImpl) {
			return true;
		} else if (firstElement instanceof DataStructureImpl && target instanceof Generator) {
			return true;
		} else if (firstElement instanceof DataStructureImpl && target instanceof DataStructureImpl) {
			return true;
		} else if (firstElement instanceof LiteralImpl && target instanceof EnumImpl) {
			return true;
		} else if (firstElement instanceof ComponentImpl && target instanceof MCCImpl) {
			return true;
		} else if (firstElement instanceof ParameterImpl && (target instanceof ComponentImpl || target instanceof MCCImpl)) {
			return true;
		} else if (firstElement instanceof GeneratorImpl && target instanceof ComponentImpl) {
			return true;
		} else if (firstElement instanceof SubComponentImpl && target instanceof ComponentImpl) {
			return true;
		} else if (firstElement instanceof PortImpl && target instanceof PortsImpl) {
			return true;
		} else if (firstElement instanceof RunnableImpl && target instanceof RunnablesImpl) {
			return true;
		} else if (firstElement instanceof FlowImpl && target instanceof FlowsImpl) {
			return true;
		}

		return false;

	}

}
