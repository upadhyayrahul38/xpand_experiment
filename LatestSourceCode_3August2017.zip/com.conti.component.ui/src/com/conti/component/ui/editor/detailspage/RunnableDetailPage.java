package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EStructuralFeature.Setting;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.editor.ArchitectureToolMasterDetailBlock;
import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Port;
import architecturetool.Ports;
import architecturetool.Runnable;

public class RunnableDetailPage implements IDetailsPage, ModifyListener,VerifyListener {
	private class TableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Port) {
				Port port = (Port) element;
				switch (columnIndex) {
				case 0:
					return port.getName();
				case 1:
					return port.getPortDirection().toString();
				case 2:
					return (port.getType()==null)?"":port.getType().getName();
				}
			}
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtBehaviour;
	private Text txtTimeAvg;
	private Text txtTimeMax;
	private Text txtaccelerator;
	private Text txtName;
	private Table tablePorts;
	private Runnable runnable;
	private TableViewer tableViewer;
	private ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock;

	/**
	 * Create the details page.
	 * @param architectureToolMasterDetailBlock 
	 */
	


	public RunnableDetailPage(ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock) {
		this.architectureToolMasterDetailBlock = architectureToolMasterDetailBlock;
	}


	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		UtillVerifyListener verifyListener = new UtillVerifyListener();
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Empty Section");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(3, false));
		
				Label lblName = new Label(composite, SWT.NONE);
				toolkit.adapt(lblName, true, true);
				lblName.setText("Name");
		
				txtName = new Text(composite, SWT.BORDER);
				txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
				txtName.setData(ArchitecturetoolPackage.Literals.RUNNABLE__NAME);
				txtName.addModifyListener(this);
				toolkit.adapt(txtName, true, true);
		new Label(composite, SWT.NONE);

		Label lblHowToCall = new Label(composite, SWT.NONE);
		toolkit.adapt(lblHowToCall, true, true);
		lblHowToCall.setText("How To Called Behaviour ");

		txtBehaviour = new Text(composite, SWT.BORDER);
		txtBehaviour.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtBehaviour.setData(ArchitecturetoolPackage.Literals.RUNNABLE__HOW_TO_BECALLED_BEHAVIOUR);
		txtBehaviour.addModifyListener(this);
		txtBehaviour.addVerifyListener(verifyListener);
		toolkit.adapt(txtBehaviour, true, true);
		new Label(composite, SWT.NONE);

		Label lblNewLabel = new Label(composite, SWT.NONE);
		toolkit.adapt(lblNewLabel, true, true);
		lblNewLabel.setText("Needed Run Time Avg");

		txtTimeAvg = new Text(composite, SWT.BORDER);
		txtTimeAvg.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtTimeAvg.setData(ArchitecturetoolPackage.Literals.RUNNABLE__NEEDED_RUN_TIME_AVG);
		txtTimeAvg.addModifyListener(this);
		txtTimeAvg.addVerifyListener(verifyListener);
		toolkit.adapt(txtTimeAvg, true, true);
		new Label(composite, SWT.NONE);

		Label lblNeededRunTime = new Label(composite, SWT.NONE);
		toolkit.adapt(lblNeededRunTime, true, true);
		lblNeededRunTime.setText("Needed Run Time Max");

		txtTimeMax = new Text(composite, SWT.BORDER);
		txtTimeMax.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtTimeMax.setData(ArchitecturetoolPackage.Literals.RUNNABLE__NEEDED_RUN_TIME_MAX);
		txtTimeMax.addModifyListener(this);
		txtTimeMax.addVerifyListener(verifyListener);
		toolkit.adapt(txtTimeMax, true, true);
		new Label(composite, SWT.NONE);

		Label lblNeedAccelator = new Label(composite, SWT.NONE);
		toolkit.adapt(lblNeedAccelator, true, true);
		lblNeedAccelator.setText("Need Accelerator");

		txtaccelerator = new Text(composite, SWT.BORDER);
		txtaccelerator.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtaccelerator.setData(ArchitecturetoolPackage.Literals.RUNNABLE__NEED_ACCELERATOR);
		txtaccelerator.addModifyListener(this);
		txtaccelerator.addVerifyListener(verifyListener);
		toolkit.adapt(txtaccelerator, true, true);
		new Label(composite, SWT.NONE);
		new Label(composite, SWT.NONE);

		tableViewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION);
		tablePorts = tableViewer.getTable();
		tablePorts.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(tablePorts);
		toolkit.paintBordersFor(tablePorts);
		tablePorts.setHeaderVisible(true);
		tablePorts.setLinesVisible(true);

		TableColumn tblclmnPorts = new TableColumn(tablePorts, SWT.NONE);
		tblclmnPorts.setWidth(232);
		tblclmnPorts.setText("Port Name");
		
		TableColumn tblclmnPortType = new TableColumn(tablePorts, SWT.NONE);
		tblclmnPortType.setWidth(270);
		tblclmnPortType.setText("Port Direction");
		
		TableColumn tblclmnPortDirection = new TableColumn(tablePorts, SWT.NONE);
		tblclmnPortDirection.setWidth(270);
		tblclmnPortDirection.setText("Port Type");
		
		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1));
		toolkit.adapt(composite_1);
		toolkit.paintBordersFor(composite_1);
		composite_1.setLayout(new GridLayout(1, false));
		
		Button btnNewButton = new Button(composite_1, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ElementListSelectionDialog elementListSelectionDialog=new ElementListSelectionDialog(Display.getDefault().getActiveShell(), new LabelProvider(){
					@Override
					public String getText(Object element) {
						if (element instanceof Port) {
							Port port = (Port) element;
							Component eContainer = (Component) port.eContainer().eContainer();
							return port.getName()+"  (CMP: "+eContainer.getName()+",  Direction: "+port.getPortDirection().getName()+")";
							
						}
						return super.getText(element);
					}
					
					
				});
				NoNameElement noNameElem = null;
				Component component = (Component) runnable.eContainer().eContainer();
				EObject noNameElemCont = component.eContainer().eContainer();
				ArrayList<Port> allPortList = new ArrayList<Port>();
				if (noNameElemCont != null && noNameElemCont instanceof NoNameElement) {
					noNameElem = (NoNameElement) noNameElemCont;
				}
				allPortList.clear();
				EList<MCC> mcc = noNameElem.getMcc();
				for (Iterator<MCC> iterator = mcc.iterator(); iterator.hasNext();) {
					MCC mcc_Elem = iterator.next();
					TreeIterator<Object> allComponents = EcoreUtil.getAllContents(mcc_Elem.getComponents(), true);
					while (allComponents.hasNext()) {
						Object testObject = allComponents.next();
						if (testObject instanceof Port) {
							Port port = ((Port) testObject);
							if (port.getName() != null) {
								allPortList.add(port);
							}
						}
					}
				}
				Ports ports = component.getPorts();
				elementListSelectionDialog.setElements(allPortList.toArray());
				elementListSelectionDialog.open();
				Port firstResult = (Port) elementListSelectionDialog.getFirstResult();
				if(firstResult!=null)
				runnable.getPorts().add(firstResult);
				tableViewer.setInput(runnable.getPorts());
				tableViewer.refresh();
			}
		});
		toolkit.adapt(btnNewButton, true, true);
		btnNewButton.setText(".....");
		
		Button delBtn = new Button(composite_1, SWT.NONE);
		delBtn.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_ETOOL_DELETE));
		delBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
				if (!selection.isEmpty()) {
					Iterator<?> iterator = selection.iterator();
					while (iterator.hasNext()) {
						Object object = (Object) iterator.next();
						// EcoreUtil.remove(((Port)object).eContainer(),
						// ArchitecturetoolPackage.Literals.PORTS__PORT,
						// (Port)object);
						runnable.getPorts().remove(object);
						// EcoreUtil.remove((Port) object);
						// runnable.getPorts().remove(object);

					}
				}
				tableViewer.setInput(runnable.getPorts());
				tableViewer.refresh();
			}
		});
		toolkit.adapt(delBtn, true, true);

		tableViewer.setLabelProvider(new TableLabelProvider());
		tableViewer.setContentProvider(new ArrayContentProvider());
		tableViewer.addDoubleClickListener(new IDoubleClickListener() {

			@Override
			public void doubleClick(DoubleClickEvent event) {
				architectureToolMasterDetailBlock.select(event.getSelection());

			}
		});

	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		txtBehaviour.setText(String.valueOf(runnable.getHowToBecalledBehaviour()));
		txtTimeAvg.setText(String.valueOf(runnable.getNeededRunTimeAvg()));
		txtTimeMax.setText(String.valueOf(runnable.getNeededRunTimeMax()));
		txtaccelerator.setText(String.valueOf(runnable.getNeedAccelerator()));
		if (runnable.getName() != null)
			txtName.setText(runnable.getName());
		else
		{
			runnable.setName("");
			txtName.setText("");
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			runnable = (Runnable) structuredSelection.getFirstElement();
			if (runnable != null && runnable.getPorts() != null) {
				ArrayList<Port> pList = new ArrayList<Port>();
				pList.addAll(runnable.getPorts());
				if (pList.size() > 0) {
					Collections.sort(pList, new Comparator<Port>() {
						@Override
						public int compare(Port o1, Port o2) {
							     if(o1.getName()!=null && o2.getName()!=null) {
							    	 return o1.getName().compareToIgnoreCase(o2.getName());
							     }
								return 0;
						}
					});
					
				}
				tableViewer.setInput(pList);
				
			
			}
			tableViewer.refresh();
		} else
			runnable = null;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {
		Widget source = e.widget;
		if (source instanceof Text) {

			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					runnable.eSet(data, ((Text) source).getText());
				else if (eAttributeType.getName().equals("EInt"))
 					runnable.eSet(data, Integer.parseInt(((Text) source).getText()));
			}

		}

	}

	@Override
	public void verifyText(VerifyEvent e) {
		
	}

}
