package com.conti.component.ui.editor.detailspage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IContentProvider;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IOpenListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.OpenEvent;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.VerifyKeyListener;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.conti.component.ui.editor.ArchitectureToolMasterDetailBlock;
import com.conti.component.ui.util.UtillVerifyListener;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.AttributeTypeEnum;
import architecturetool.DataStructure;
import architecturetool.Generator;
import architecturetool.PhysicalUnitEnum;

public class DataStructureDetailPage implements IDetailsPage, ModifyListener,VerifyListener {
	private class AbsoluteTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof AbsoluteRefrence) {
				AbsoluteRefrence absoluteRefrence = (AbsoluteRefrence) element;
				return absoluteRefrence.getName();

			}
			return element.toString();
		}
	}

	private class RefrencesTableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof DataStructure) {
				DataStructure structure = (DataStructure) element;
				switch (columnIndex) {
				case 0:
					return structure.getName();
				}
			}
			return element.toString();
		}
	}

	private class TableLabelProvider extends LabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			if (element instanceof Attribute) {
				Attribute attribute = (Attribute) element;
				switch (columnIndex) {
				case 0:
					return attribute.getName();
					
				case 1:
					AttributeTypeEnum attributeType = attribute.getAttributeType();
					return attributeType.getName();
				}
			}
			return element.toString();
		}
	}

	private IManagedForm managedForm;
	private Text txtName;
	private Text txtDescription;
	private Text txtTypeAccuracy;
	private Text txtArraySize;
	private Text txtTypeText;
	private Combo cmbPhysicalUnit;
	private Text txtAccuracy;
	private Text txtInterfaceVersion;
	private DataStructure datastructure;
	private Table attributeTable;
	private Table refrencestable;
	private Table absoluteTable;
	private TableViewer attributeTableViewer;
	private TableViewer dataStructuresTableViewer;
	private TableViewer absoluteRefsTableViewer;
	private boolean isBtnClickedAttribute = false;
	private boolean isBtnClickedRef = false;
	private boolean isBtnClickedAbsRef = false;
	private ArrayList<Attribute> attribList = null;
	private ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock;
	

	/**
	 * Create the details page.
	 * @param architectureToolMasterDetailBlock 
	 * @wbp.parser.constructor
	 */
	public DataStructureDetailPage(ArchitectureToolMasterDetailBlock architectureToolMasterDetailBlock) {
		this.architectureToolMasterDetailBlock = architectureToolMasterDetailBlock;
		// Create the details page
	}
	
	public DataStructureDetailPage() {
		
	}
	

	/**
	 * Initialize the details page.
	 * 
	 * @param form
	 */
	public void initialize(IManagedForm form) {
		managedForm = form;
	}
	

	/**
	 * Create contents of the details page.
	 * 
	 * @param parent
	 */
	public void createContents(Composite parent) {
		UtillVerifyListener verifyListener=new UtillVerifyListener();
		FormToolkit toolkit = managedForm.getToolkit();
		parent.setLayout(new FillLayout());
		//
		Section section = toolkit.createSection(parent, ExpandableComposite.EXPANDED | ExpandableComposite.TITLE_BAR);
		section.setText("Data Structure");
		//
		Composite composite = toolkit.createComposite(section, SWT.NONE);
		toolkit.paintBordersFor(composite);
		section.setClient(composite);
		composite.setLayout(new GridLayout(2, false));

		Label lblName = new Label(composite, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblName, true, true);
		lblName.setText("Name");

		txtName = new Text(composite, SWT.BORDER);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtName.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__NAME);
		txtName.addModifyListener(this);
		toolkit.adapt(txtName, true, true);

		Label lblDescriotion = new Label(composite, SWT.NONE);
		lblDescriotion.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblDescriotion, true, true);
		lblDescriotion.setText("Description");

		txtDescription = new Text(composite, SWT.BORDER);
		txtDescription.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtDescription.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__DESCRIPTION);
		txtDescription.addModifyListener(this);
		toolkit.adapt(txtDescription, true, true);

		Label lblTypeAccuracy = new Label(composite, SWT.NONE);
		lblTypeAccuracy.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblTypeAccuracy, true, true);
		lblTypeAccuracy.setText("Type Accuracy");

		txtTypeAccuracy = new Text(composite, SWT.BORDER);
		txtTypeAccuracy.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtTypeAccuracy.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__TYPE_ACCURACY);
		txtTypeAccuracy.addModifyListener(this);
		txtTypeAccuracy.addVerifyListener(verifyListener);
		toolkit.adapt(txtTypeAccuracy, true, true);

		Label lblArraySize = new Label(composite, SWT.NONE);
		lblArraySize.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblArraySize, true, true);
		lblArraySize.setText("Array Size");

		txtArraySize = new Text(composite, SWT.BORDER);
		txtArraySize.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtArraySize.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__ARRAY_SIZE);
		txtArraySize.addModifyListener(this);
		txtArraySize.addVerifyListener(verifyListener);
		toolkit.adapt(txtArraySize, true, true);

		Label lblPhysicalUnit = new Label(composite, SWT.NONE);
		lblPhysicalUnit.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblPhysicalUnit, true, true);
		lblPhysicalUnit.setText("Physical Unit");

		cmbPhysicalUnit = new Combo(composite, SWT.READ_ONLY);
		cmbPhysicalUnit.setItems(new String[] { PhysicalUnitEnum.NOUNIT.toString(), PhysicalUnitEnum.METER.toString(),
				PhysicalUnitEnum.SQUAREMETER.toString(), PhysicalUnitEnum.SECOND.toString(),
				PhysicalUnitEnum.METERPERSECOND.toString(), PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED.toString(),
				PhysicalUnitEnum.METERPERSECONDSQUARED.toString(), PhysicalUnitEnum.METERPERSECONDCUBED.toString(),
				PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED.toString(), PhysicalUnitEnum.RADIAN.toString(),
				PhysicalUnitEnum.RADIANPERSECOND.toString(), PhysicalUnitEnum.RADIANPERSECONDSQUARED.toString(),
				PhysicalUnitEnum.NEWTON.toString(), PhysicalUnitEnum.DEGREECENTIGRADE.toString(),
				PhysicalUnitEnum.NEWTONMETER.toString(), PhysicalUnitEnum.NEWTONPERRAD.toString(),
				PhysicalUnitEnum.KILOGRAM.toString(), PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER.toString(),
				PhysicalUnitEnum.DECIBEL.toString(), PhysicalUnitEnum.CURVATURE.toString(),
				PhysicalUnitEnum.CURVATURERATE.toString(), PhysicalUnitEnum.KILOMETER.toString(),
				PhysicalUnitEnum.KILOMETERPERHOUR.toString(), PhysicalUnitEnum.DEGREE.toString(),
				PhysicalUnitEnum.PERCENT.toString(), PhysicalUnitEnum.MILLISECOND.toString(),
				PhysicalUnitEnum.DECIBELPERSQUAREMETER.toString(), PhysicalUnitEnum.DEGREEPERSECOND.toString(),
				PhysicalUnitEnum.PERCENTPERSECOND.toString(), PhysicalUnitEnum.PIXEL.toString(),
				PhysicalUnitEnum.MICROSECOND.toString(), PhysicalUnitEnum.BYTE.toString(),
				PhysicalUnitEnum.BIT.toString() });
		cmbPhysicalUnit.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		cmbPhysicalUnit.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__PHYSICAL_UNIT);
		cmbPhysicalUnit.addModifyListener(this);
		toolkit.adapt(cmbPhysicalUnit, true, true);

		Label lblAccuracy = new Label(composite, SWT.NONE);
		lblAccuracy.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblAccuracy, true, true);
		lblAccuracy.setText("Accuracy");

		txtAccuracy = new Text(composite, SWT.BORDER);
		txtAccuracy.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtAccuracy.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__ACCURACY);
		txtAccuracy.addModifyListener(this);
		txtAccuracy.addVerifyListener(verifyListener);
		toolkit.adapt(txtAccuracy, true, true);

		Label lblInterfaceVersion = new Label(composite, SWT.NONE);
		lblInterfaceVersion.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblInterfaceVersion, true, true);
		lblInterfaceVersion.setText("Interface Version");

		txtInterfaceVersion = new Text(composite, SWT.BORDER);
		txtInterfaceVersion.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtInterfaceVersion.setData(ArchitecturetoolPackage.Literals.COMPONENT_ATTRIBUTE__INTERFACE_VERSION);
		txtInterfaceVersion.addModifyListener(this);
		txtInterfaceVersion.addVerifyListener(verifyListener);
		toolkit.adapt(txtInterfaceVersion, true, true);
		
		Label typeLabel = new Label(composite, SWT.NONE);
		typeLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(typeLabel, true, true);
		typeLabel.setText("Type (only for legacy types)");
 
		txtTypeText = new Text(composite, SWT.BORDER);
		txtTypeText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtTypeText.setData(ArchitecturetoolPackage.Literals.DATA_STRUCTURE__TYPE);
		txtTypeText.addModifyListener(this);
		toolkit.adapt(txtTypeText, true, true);

		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setLayout(new GridLayout(6, false));
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		toolkit.adapt(composite_1);
		toolkit.paintBordersFor(composite_1);

		attributeTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		attributeTable = attributeTableViewer.getTable();
		attributeTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(attributeTable);
		toolkit.paintBordersFor(attributeTable);
		attributeTable.setHeaderVisible(true);
		attributeTable.setLinesVisible(true);
		
		
		attributeTableViewer.addDoubleClickListener(new IDoubleClickListener() {
			
			@Override
			public void doubleClick(DoubleClickEvent event) {
				architectureToolMasterDetailBlock.select(event.getSelection());
			}
		});

		TableColumn tblclmnNewColumn = new TableColumn(attributeTable, SWT.NONE);
		tblclmnNewColumn.setWidth(170);
		tblclmnNewColumn.setText("Attributes");

		TableColumn tblTypeNewColumn = new TableColumn(attributeTable, SWT.NONE);
		int borderWidth = attributeTable.getClientArea().width;
		tblTypeNewColumn.setWidth(120);
		tblTypeNewColumn.setText("Types");

		attributeTableViewer.setContentProvider(new ArrayContentProvider());
		attributeTableViewer.setLabelProvider(new TableLabelProvider());
		

		Composite composite_2 = new Composite(composite_1, SWT.NONE);
		composite_2.setLayout(new GridLayout(1, false));
		composite_2.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));
		toolkit.adapt(composite_2);
		toolkit.paintBordersFor(composite_2);
		
		Button btnUp = new Button(composite_2, SWT.NONE);
		GridData gd_btnUp = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_btnUp.widthHint = 43;
		btnUp.setLayoutData(gd_btnUp);
		btnUp.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int selectionIndex = attributeTableViewer.getTable().getSelectionIndex();
				
				
				EObjectContainmentEList<Attribute> input = (EObjectContainmentEList<Attribute>) attributeTableViewer.getInput();
				Attribute basicGet = input.basicGet(selectionIndex);
				input.remove(selectionIndex);
				input.add(selectionIndex-1, basicGet);
				attributeTableViewer.setInput(input);
				attributeTableViewer.refresh();
					}
		});
		toolkit.adapt(btnUp, true, true);
		btnUp.setText("UP");
		Button btnDown = new Button(composite_2, SWT.NONE);
		btnDown.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		
		btnDown.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
		int selectionIndex = attributeTableViewer.getTable().getSelectionIndex();
		System.out.println(selectionIndex);
		
		EObjectContainmentEList<Attribute> input = (EObjectContainmentEList<Attribute>) attributeTableViewer.getInput();
		Attribute basicGet = input.basicGet(selectionIndex);
		input.remove(selectionIndex);
		input.add(selectionIndex+1, basicGet);
		attributeTableViewer.setInput(input);
		attributeTableViewer.refresh();
			}
		});
		toolkit.adapt(btnDown, true, true);
		btnDown.setText("Down");

		
		
		Button btnAttribute = new Button(composite_2, SWT.NONE);
		GridData gd_btnAttribute = new GridData(SWT.FILL, SWT.TOP, false, false, 1, 1);
		gd_btnAttribute.widthHint = 43;
		btnAttribute.setLayoutData(gd_btnAttribute);
		isBtnClickedAttribute = false;
		btnAttribute.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				isBtnClickedAttribute = true;
//				
				Attribute createAttribute = ArchitecturetoolFactory.eINSTANCE.createAttribute();
				if (createAttribute != null) {
					createAttribute.setName("Set Attribute Name");
					datastructure.getAttributes().add(createAttribute);
				}
				attributeTableViewer.refresh();
			}
		});
		toolkit.adapt(btnAttribute, true, true);
		btnAttribute.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_OBJ_ADD));

		
		Button attributeDelBtn = new Button(composite_2, SWT.NONE);
		attributeDelBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		attributeDelBtn.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_ETOOL_DELETE));
		attributeDelBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IStructuredSelection selection = (IStructuredSelection) attributeTableViewer.getSelection();
				if (!selection.isEmpty()) {
					Iterator iterator = selection.iterator();
					while (iterator.hasNext()) {
						Object object = (Object) iterator.next();
						attribList = new ArrayList<Attribute>();
						Iterator<Attribute> iterator2 = datastructure.getAttributes().iterator();
						while (iterator2.hasNext()) {
							Attribute attribute = (Attribute) iterator2.next();
							if (!(attribute.equals((Attribute) object))) {
                               attribList.add(attribute);
							}
						}
						//attributeTableViewer.setInput(attribList);
						 datastructure.getAttributes().remove(object);
					}
				}
				attributeTableViewer.refresh();
			}
		});
		toolkit.adapt(attributeDelBtn, true, true);

		dataStructuresTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		refrencestable = dataStructuresTableViewer.getTable();
		refrencestable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(refrencestable);
		toolkit.paintBordersFor(refrencestable);
		refrencestable.setHeaderVisible(true);
		refrencestable.setLinesVisible(true);

		dataStructuresTableViewer.addDoubleClickListener(new IDoubleClickListener() {

			@Override
			public void doubleClick(DoubleClickEvent event) {
				architectureToolMasterDetailBlock.select(event.getSelection());
			}
		});
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(refrencestable, SWT.NONE);
		tblclmnNewColumn_1.setText("Data Structures");
		tblclmnNewColumn_1.setWidth(166);
		dataStructuresTableViewer.setLabelProvider(new RefrencesTableLabelProvider());
		dataStructuresTableViewer.setContentProvider(new ArrayContentProvider());
		
		dataStructuresTableViewer.getTable().addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
                 // hideExtraColumn(dataStructuresTableViewer);				
			}
		});
		Composite composite_3 = new Composite(composite_1, SWT.NONE);
		composite_3.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));
		toolkit.adapt(composite_3);
		toolkit.paintBordersFor(composite_3);
		composite_3.setLayout(new GridLayout(1, false));

		Button btnRefrences = new Button(composite_3, SWT.NONE);
		btnRefrences.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DataStructure createDataStructure = ArchitecturetoolFactory.eINSTANCE.createDataStructure();
				if (createDataStructure != null) {
					createDataStructure.setName("Set Data Structure Name");
					datastructure.getStructs().add(createDataStructure);
				}
				dataStructuresTableViewer.refresh();
			}
		});
		toolkit.adapt(btnRefrences, true, true);
		btnRefrences.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_OBJ_ADD));

		Button refDelButton = new Button(composite_3, SWT.NONE);
		refDelButton.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_ETOOL_DELETE));
		refDelButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IStructuredSelection selection = (IStructuredSelection) dataStructuresTableViewer.getSelection();
				if (!selection.isEmpty()) {
					Iterator<?> iterator = selection.iterator();
					while (iterator.hasNext()) {
						Object object = (Object) iterator.next();
						datastructure.getStructs().remove(object);

					}
				}
				dataStructuresTableViewer.refresh();
			}
		});
		toolkit.adapt(refDelButton, true, true);

		absoluteRefsTableViewer = new TableViewer(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		absoluteTable = absoluteRefsTableViewer.getTable();
		absoluteTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		toolkit.adapt(absoluteTable);
		toolkit.paintBordersFor(absoluteTable);
		absoluteTable.setHeaderVisible(true);
		absoluteTable.setLinesVisible(true);
		absoluteRefsTableViewer.addDoubleClickListener(new IDoubleClickListener() {
			
			@Override
			public void doubleClick(DoubleClickEvent event) {
                architectureToolMasterDetailBlock.select(event.getSelection());				
			}
		});

		TableColumn tblclmnNewColumn_2 = new TableColumn(absoluteTable, SWT.NONE);
		tblclmnNewColumn_2.setWidth(157);
		tblclmnNewColumn_2.setText("Absolute Reference ");
		absoluteRefsTableViewer.setLabelProvider(new AbsoluteTableLabelProvider());
		absoluteRefsTableViewer.setContentProvider(new ArrayContentProvider());
		
		absoluteRefsTableViewer.getTable().addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
                //hideExtraColumn(absoluteRefsTableViewer);				
			}
		});

		Composite composite_4 = new Composite(composite_1, SWT.NONE);
		composite_4.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));
		toolkit.adapt(composite_4);
		toolkit.paintBordersFor(composite_4);
		composite_4.setLayout(new GridLayout(1, false));

		Button btnAbsolute = new Button(composite_4, SWT.NONE);
		btnAbsolute.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				ElementListSelectionDialog dialog = new ElementListSelectionDialog(
						Display.getDefault().getActiveShell(), new LabelProvider() {
							@Override
							public String getText(Object element) {
								if (element instanceof AbsoluteRefrence) {
									AbsoluteRefrence absoluteRefrence = (AbsoluteRefrence) element;
									return absoluteRefrence.getName();

								}
								return super.getText(element);
							}
						});
				isBtnClickedAbsRef = true;
				EObject eContainer = datastructure;
				for(int i=0;;i++)
				{
					if (eContainer instanceof Generator) {
						Generator generator = (Generator) eContainer;
						break;
						
					}
					else
					{
					 eContainer = eContainer.eContainer();
					}
				}
				Generator genrator = (Generator) eContainer;
				EList<DataStructure> datastructurelist = genrator.getDatastructure();
				ArrayList<AbsoluteRefrence> arrayList = new ArrayList<AbsoluteRefrence>();
				for (DataStructure dataStructure : datastructurelist) {
					EList<AbsoluteRefrence> absolutereference = dataStructure.getAbsolutereference();
					arrayList.addAll(absolutereference);
				}
				dialog.setElements(arrayList.toArray());
				dialog.open();
				AbsoluteRefrence firstResult = (AbsoluteRefrence) dialog.getFirstResult();
				if(firstResult!=null)
				datastructure.getAbsolutereference().add(firstResult);
				absoluteRefsTableViewer.refresh();

			}
		});
		toolkit.adapt(btnAbsolute, true, true);
		btnAbsolute.setText(".....");

		Button absRefDelBtn = new Button(composite_4, SWT.NONE);
		absRefDelBtn.setImage(PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_ETOOL_DELETE));
		absRefDelBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IStructuredSelection selection = (IStructuredSelection) absoluteRefsTableViewer.getSelection();
				if (!selection.isEmpty()) {
					Iterator iterator = selection.iterator();
					while (iterator.hasNext()) {
						Object object = (Object) iterator.next();
						datastructure.getAbsolutereference().remove(object);

					}
				}
				absoluteRefsTableViewer.refresh();
			}
		});
		toolkit.adapt(absRefDelBtn, true, true);
	}
	
	private void hideExtraColumn(TableViewer tableViewer) {
		Table table = tableViewer.getTable();
		int columnsWidth = 0;
		for (int i = 0; i < table.getColumnCount() - 1; i++) {
	        columnsWidth += table.getColumn(i).getWidth();
	    }
		TableColumn lastColumn = table.getColumn(table.getColumnCount() - 1);
		lastColumn.pack();
		
	    
	    

	    Rectangle area = table.getClientArea();

	    Point preferredSize = table.computeSize(SWT.DEFAULT, SWT.DEFAULT);
	    int width = area.width - 2*table.getBorderWidth();

	    if (preferredSize.y > area.height + table.getHeaderHeight()) {
	        // Subtract the scrollbar width from the total column width
	        // if a vertical scrollbar will be required
	        Point vBarSize = table.getVerticalBar().getSize();
	        width -= vBarSize.x;
	    }

	    // last column is packed, so that is the minimum. If more space is available, add it.
	    if(lastColumn.getWidth() < width - columnsWidth) {
	        lastColumn.setWidth(width - columnsWidth);
	    }
	}

	public void dispose() {
		// Dispose
	}

	public void setFocus() {
		// Set focus
	}

	private void update() {
		if (datastructure.getType() != null) {
			txtTypeText.setText(datastructure.getType());
		} else {
			txtTypeText.setText("");
		}

		if (datastructure.getName() != null) {
			txtName.setText(datastructure.getName());
		} else {
			txtName.setText("");
		}
		if (datastructure.getPhysicalUnit() != null) {
			cmbPhysicalUnit.setText(datastructure.getPhysicalUnit().toString());
		}
		else {
			cmbPhysicalUnit.setText("");
		}
		txtAccuracy.setText(String.valueOf(datastructure.getAccuracy()));
		txtArraySize.setText(String.valueOf(datastructure.getArraySize()));
		if (datastructure.getDescription() != null) {
			txtDescription.setText(datastructure.getDescription());
		}
		else  {
			txtDescription.setText("");
		}
		txtTypeAccuracy.setText(String.valueOf(datastructure.getTypeAccuracy()));
		txtInterfaceVersion.setText(String.valueOf(datastructure.getInterfaceVersion()));

		if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.NOUNIT)) {
			cmbPhysicalUnit.select(0);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.METER)) {
			cmbPhysicalUnit.select(1);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.SQUAREMETER)) {
			cmbPhysicalUnit.select(2);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.SECOND)) {
			cmbPhysicalUnit.select(3);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECOND)) {
			cmbPhysicalUnit.select(4);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(5);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(6);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDCUBED)) {
			cmbPhysicalUnit.select(7);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED)) {
			cmbPhysicalUnit.select(8);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.RADIAN)) {
			cmbPhysicalUnit.select(9);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANPERSECOND)) {
			cmbPhysicalUnit.select(10);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANPERSECONDSQUARED)) {
			cmbPhysicalUnit.select(11);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTON)) {
			cmbPhysicalUnit.select(12);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREECENTIGRADE)) {
			cmbPhysicalUnit.select(13);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTONMETER)) {
			cmbPhysicalUnit.select(14);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.NEWTONPERRAD)) {
			cmbPhysicalUnit.select(15);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.KILOGRAM)) {
			cmbPhysicalUnit.select(16);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER)) {
			cmbPhysicalUnit.select(17);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.DECIBEL)) {
			cmbPhysicalUnit.select(18);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.CURVATURE)) {
			cmbPhysicalUnit.select(19);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.CURVATURERATE)) {
			cmbPhysicalUnit.select(20);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.KILOMETER)) {
			cmbPhysicalUnit.select(21);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.KILOMETERPERHOUR)) {
			cmbPhysicalUnit.select(22);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREE)) {
			cmbPhysicalUnit.select(23);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.PERCENT)) {
			cmbPhysicalUnit.select(24);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.MILLISECOND)) {
			cmbPhysicalUnit.select(25);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.DECIBELPERSQUAREMETER)) {
			cmbPhysicalUnit.select(26);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.DEGREEPERSECOND)) {
			cmbPhysicalUnit.select(27);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.PERCENTPERSECOND)) {
			cmbPhysicalUnit.select(28);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.PIXEL)) {
			cmbPhysicalUnit.select(29);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.MICROSECOND)) {
			cmbPhysicalUnit.select(30);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.BYTE)) {
			cmbPhysicalUnit.select(31);
		} else if (datastructure.getPhysicalUnit().equals(PhysicalUnitEnum.BIT)) {
			cmbPhysicalUnit.select(32);
		}
	}

	public boolean setFormInput(Object input) {
		return false;
	}

	public void selectionChanged(IFormPart part, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (structuredSelection.size() == 1) {
			datastructure = (DataStructure) structuredSelection.getFirstElement();
		} else
			datastructure = null;
//		 if(attribList!=null && !datastructure.getAttributes().isEmpty()) {
//			 attributeTableViewer.setInput(attribList);
//		 }
//		 else {
//			
//		 }
		 
		 attributeTableViewer.setInput(datastructure.getAttributes()); 
			
		//if (isBtnClickedRef)
			dataStructuresTableViewer.setInput(datastructure.getStructs());
		//if (isBtnClickedAbsRef)
			absoluteRefsTableViewer.setInput(datastructure.getAbsolutereference());
		
//		isBtnClickedAttribute = false;
//		isBtnClickedRef = false;
//		isBtnClickedAbsRef = false;
		update();
	}

	public void commit(boolean onSave) {
		// Commit
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isStale() {
		return false;
	}

	public void refresh() {
		update();
	}

	@Override
	public void modifyText(ModifyEvent e) {

		Widget source = e.widget;
		if (source instanceof Text) {
			EStructuralFeature data = (EStructuralFeature) source.getData();
			if (source.getData() instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("EString"))
					datastructure.eSet(data, ((Text) source).getText());
				else if (eAttributeType.getName().equals("EInt"))
					datastructure.eSet(data, Integer.parseInt(((Text) source).getText()));
				else if (eAttributeType.getName().equals("EFloat"))
					datastructure.eSet(data, Float.parseFloat(((Text) source).getText()));
			}
		} else if (source instanceof Combo) {
			EStructuralFeature structuralFeature = (EStructuralFeature) source.getData();
			if (structuralFeature instanceof EAttribute) {
				EDataType eAttributeType = ((EAttribute) source.getData()).getEAttributeType();
				if (eAttributeType.getName().equals("PhysicalUnitEnum"))
					datastructure.eSet(structuralFeature, PhysicalUnitEnum.get(((Combo) source).getText()));

			}
		}

	}

	@Override
	public void verifyText(VerifyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
