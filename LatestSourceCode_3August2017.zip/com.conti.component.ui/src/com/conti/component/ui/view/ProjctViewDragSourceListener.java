package com.conti.component.ui.view;

import org.eclipse.core.resources.IFile;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.dnd.DragSourceEvent;
import org.eclipse.swt.dnd.DragSourceListener;
import org.eclipse.swt.dnd.TextTransfer;

public class ProjctViewDragSourceListener implements DragSourceListener {

	private TreeViewer treeViewer;

	public ProjctViewDragSourceListener(TreeViewer treeViewer) {
		this.treeViewer = treeViewer;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dragStart(DragSourceEvent event) {

	}

	@Override
	public void dragSetData(DragSourceEvent event) {
		  IStructuredSelection selection = treeViewer.getStructuredSelection();
		  IFile firstElement = (IFile) selection.getFirstElement();

	        if (TextTransfer.getInstance().isSupportedType(event.dataType)) {
	            event.data = firstElement.toString();
	        }
		
	}

	@Override
	public void dragFinished(DragSourceEvent event) {

	}

}
