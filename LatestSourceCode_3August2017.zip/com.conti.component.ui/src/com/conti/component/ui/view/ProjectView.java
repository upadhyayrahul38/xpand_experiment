package com.conti.component.ui.view;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.editors.text.EditorsUI;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.internal.WorkbenchPlugin;
import org.eclipse.ui.internal.dialogs.ImportExportWizard;
import org.eclipse.ui.internal.dialogs.NewWizard;
import org.eclipse.ui.part.ViewPart;

import com.conti.component.ui.Activator;
import com.conti.component.ui.wizard.ArchitectureFileImportWizard;
import com.conti.component.ui.wizard.ArchitectureToolFileWizard;
import com.conti.component.ui.wizard.ArchitectureToolWizard;
import com.conti.component.ui.wizard.ExcelImportWizard;

public class ProjectView extends ViewPart implements ISelectionService {
	private static final String ID = "com.conti.component.ui.editor.ArchitectureEditor";
	private TreeViewer treeViewer;

	public static class ViewerLabelProvider extends LabelProvider {
		@Override
		public String getText(Object element) {
			System.out.println(element);
			if (element instanceof IContainer) {
				IContainer iProject = (IContainer) element;
				return iProject.getName();
			}
			if (element instanceof IFile) {
				IFile iFile = (IFile) element;
				return iFile.getName();
			}

			return super.getText(element);
		}

		@Override
		public Image getImage(Object element) {

			String imageKey = null;
			if (element instanceof IContainer) {
				imageKey = ISharedImages.IMG_OBJ_FOLDER;
			}
			if (element instanceof IFile) {

				imageKey = ISharedImages.IMG_OBJ_FILE;
				ImageDescriptor imageDescriptorFromPlugin = Activator.getDefault()
						.imageDescriptorFromPlugin(Activator.PLUGIN_ID, "icons\\at_16.gif");
				if (imageDescriptorFromPlugin != null) {
					Image createImage = imageDescriptorFromPlugin.createImage();
					return createImage;
				}
			}
			return PlatformUI.getWorkbench().getSharedImages().getImage(imageKey);
		}

	}

	private static class TreeContentProvider implements ITreeContentProvider {

		public Object[] getElements(Object inputElement) {
			IWorkspaceRoot root = ((IWorkspaceRoot) inputElement);

			return root.getProjects();
		}

		public Object[] getChildren(Object parentElement) {
			IContainer iProject = (IContainer) parentElement;
			try {
				return iProject.members();
			} catch (CoreException e) {
				e.printStackTrace();
			}
			return null;
		}

		public Object getParent(Object element) {

			return null;
		}

		public boolean hasChildren(Object element) {
			if (element instanceof IContainer) {
				IContainer iContainer = (IContainer) element;
				try {
					if (!(((IProject) iContainer).isOpen())) {
						((IProject) iContainer).open(new NullProgressMonitor());
					}
				} catch (CoreException e1) {
					e1.printStackTrace();
				}
				try {
					if (iContainer.members().length > 0) {
						return true;
					}
				} catch (CoreException e) {
					e.printStackTrace();
				}

			}

			return false;
		}

		@Override
		public void dispose() {

		}

		@Override
		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {

		}
	}

	public ProjectView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		treeViewer = new TreeViewer(parent, SWT.BORDER);

		Tree tree = treeViewer.getTree();
		tree.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		int operations = DND.DROP_COPY | DND.DROP_MOVE;
		Transfer[] transferTypes = new Transfer[] { TextTransfer.getInstance() };
		treeViewer.addDragSupport(operations, transferTypes, new ProjctViewDragSourceListener(treeViewer));
		treeViewer.addDropSupport(operations, transferTypes, new ProjctViewDropListener(treeViewer));

		org.eclipse.swt.widgets.Menu menu = new org.eclipse.swt.widgets.Menu(tree);
		tree.setMenu(menu);

		MenuItem mntmNewMenu = new MenuItem(menu, SWT.CASCADE);
		mntmNewMenu.setText("New");

		org.eclipse.swt.widgets.Menu menu_1 = new org.eclipse.swt.widgets.Menu(mntmNewMenu);
		mntmNewMenu.setMenu(menu_1);

		MenuItem mntmNewproj = new MenuItem(menu_1, SWT.NONE);
		mntmNewproj.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ArchitectureToolWizard architectureToolWizard = new ArchitectureToolWizard();
				WizardDialog wizardDialog = new WizardDialog(Display.getDefault().getActiveShell(),
						architectureToolWizard);
				wizardDialog.open();
				// parent.setEnabled(false);
			}
		});
		mntmNewproj.setText("Architecture Tool Project");

		MenuItem mntmNewArchiFile = new MenuItem(menu_1, SWT.NONE);
		mntmNewArchiFile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ArchitectureToolFileWizard architectureToolFileWizard = new ArchitectureToolFileWizard();
				WizardDialog wizardDialog = new WizardDialog(Display.getDefault().getActiveShell(),
						architectureToolFileWizard);
				wizardDialog.open();
			}

		});
		mntmNewArchiFile.setText("Architecture Tool File");

		MenuItem mntmOthers = new MenuItem(menu_1, SWT.NONE);
		mntmOthers.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				NewWizard newWizard = new NewWizard();
				Shell parent = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				WizardDialog dialog = new WizardDialog(parent, newWizard);
				IStructuredSelection selectionToPass = new StructuredSelection(treeViewer.getSelection());
				//
				newWizard.init(PlatformUI.getWorkbench(), selectionToPass);
				IDialogSettings workbenchSettings = WorkbenchPlugin.getDefault().getDialogSettings();
				IDialogSettings wizardSettings = workbenchSettings.getSection("Others"); //$NON-NLS-1$
				if (wizardSettings == null) {
					wizardSettings = workbenchSettings.addNewSection("Others"); //$NON-NLS-1$
				}
				newWizard.setDialogSettings(wizardSettings);
				newWizard.setForcePreviousAndNextButtons(true);
				dialog.create();
				dialog.getShell().setSize(Math.max(470, dialog.getShell().getSize().x), 550);
				dialog.open();

			}
		});
		mntmOthers.setText("Others");

		MenuItem mntmImport = new MenuItem(menu, SWT.CASCADE);
		mntmImport.setText("Import");

		Menu menu_2 = new Menu(mntmImport);
		mntmImport.setMenu(menu_2);

		MenuItem mntmExcel = new MenuItem(menu_2, SWT.NONE);
		mntmExcel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ExcelImportWizard excelImportWizard = new ExcelImportWizard();
				WizardDialog wizardDialog = new WizardDialog(Display.getDefault().getActiveShell(), excelImportWizard);
				wizardDialog.open();
			}
		});
		mntmExcel.setText("Excel");

		MenuItem mntmArchFileImport = new MenuItem(menu_2, SWT.NONE);
		mntmArchFileImport.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ArchitectureFileImportWizard architectureFileImportWizard = new ArchitectureFileImportWizard();
				WizardDialog wizardDialog = new WizardDialog(Display.getDefault().getActiveShell(),
						architectureFileImportWizard);
				wizardDialog.open();
			}
		});
		mntmArchFileImport.setText("ArchitectureToolFile");

		MenuItem mntmDelete = new MenuItem(menu, SWT.NONE);
		mntmDelete.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ISelection selection = treeViewer.getSelection();
				IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
				Object firstElement = iStructuredSelection.getFirstElement();
				if (firstElement instanceof IResource) {
					IResource iProject = (IResource) firstElement;
					try {
						iProject.delete(true, null);
						// ResourcesPlugin.getWorkspace().save(true, null);
					} catch (CoreException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		mntmDelete.setText("Delete");

		MenuItem mntmRefresh = new MenuItem(menu, SWT.NONE);
		mntmRefresh.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				treeViewer.refresh();
			}

		});
		mntmRefresh.setText("Refresh");

		MenuItem mntmImportProject = new MenuItem(menu, SWT.NONE);
		mntmImportProject.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ImportExportWizard wizard = new ImportExportWizard(ImportExportWizard.IMPORT);
				IStructuredSelection selectionToPass = new StructuredSelection(treeViewer.getSelection());
				wizard.init(PlatformUI.getWorkbench(), selectionToPass);
				IDialogSettings workbenchSettings = WorkbenchPlugin.getDefault().getDialogSettings();
				IDialogSettings wizardSettings = workbenchSettings.getSection("ImportExportAction"); //$NON-NLS-1$
				if (wizardSettings == null) {
					wizardSettings = workbenchSettings.addNewSection("ImportExportAction"); //$NON-NLS-1$
				}
				wizard.setDialogSettings(wizardSettings);
				wizard.setForcePreviousAndNextButtons(true);
				Shell parent = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				WizardDialog dialog = new WizardDialog(parent, wizard);

				dialog.create();
				dialog.getShell().setSize(Math.max(470, dialog.getShell().getSize().x), 550);
				dialog.open();
			}
		});
		mntmImportProject.setText("Import Project");

		MenuItem mntmExportProject = new MenuItem(menu, SWT.NONE);
		mntmExportProject.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ImportExportWizard wizard = new ImportExportWizard(ImportExportWizard.EXPORT);
				IStructuredSelection selectionToPass = new StructuredSelection(treeViewer.getSelection());

				wizard.init(PlatformUI.getWorkbench(), selectionToPass);
				IDialogSettings workbenchSettings = WorkbenchPlugin.getDefault().getDialogSettings();
				IDialogSettings wizardSettings = workbenchSettings.getSection("ImportExportAction"); //$NON-NLS-1$
				if (wizardSettings == null) {
					wizardSettings = workbenchSettings.addNewSection("ImportExportAction"); //$NON-NLS-1$
				}
				wizard.setDialogSettings(wizardSettings);
				wizard.setForcePreviousAndNextButtons(true);
				Shell parent = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				WizardDialog dialog = new WizardDialog(parent, wizard);
				dialog.create();
				dialog.getShell().setSize(Math.max(470, dialog.getShell().getSize().x), 550);
				dialog.open();
			}
		});
		mntmExportProject.setText("Export Project");
		treeViewer.setLabelProvider(new ViewerLabelProvider());
		treeViewer.setContentProvider(new TreeContentProvider());

		treeViewer.addFilter(new ViewerFilter() {

			@Override
			public boolean select(Viewer viewer, Object parentElement, Object element) {
				if (element instanceof IFile) {
					IFile file = (IFile) element;
					if (file.getFileExtension() != null && file.getFileExtension().equals("project")) {
						return false;
					}
				}
				return true;
			}
		});
		
		mntmNewMenu.setEnabled(true);
		mntmNewArchiFile.setEnabled(true);
		mntmDelete.setEnabled(false);
		mntmNewArchiFile.setEnabled(false);
		mntmImport.setEnabled(false);
		mntmImportProject.setEnabled(false);
		mntmExportProject.setEnabled(false);
		
		treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				ISelection selection = treeViewer.getSelection();
				IStructuredSelection iStructuredSelection = (IStructuredSelection) selection;
				Object firstElement = iStructuredSelection.getFirstElement();
				if (firstElement instanceof IFile) {
					mntmNewMenu.setEnabled(false);
					mntmNewproj.setEnabled(false);
					mntmImport.setEnabled(false);
					mntmImportProject.setEnabled(false);
					mntmExportProject.setEnabled(false);
					mntmNewArchiFile.setEnabled(false);

				} else if (firstElement instanceof IContainer) {
					mntmNewMenu.setEnabled(true);
					mntmNewproj.setEnabled(true);
					mntmNewArchiFile.setEnabled(true);
					mntmImport.setEnabled(true);
					mntmImportProject.setEnabled(true);
					mntmExportProject.setEnabled(true);
					mntmDelete.setEnabled(true);
				}
				if (firstElement == null) {
					mntmNewMenu.setEnabled(true);
					mntmNewArchiFile.setEnabled(true);
					mntmDelete.setEnabled(false);
					mntmNewArchiFile.setEnabled(false);
					mntmImport.setEnabled(false);
					mntmImportProject.setEnabled(false);
					mntmExportProject.setEnabled(false);

				}

			}
		});
		treeViewer.setInput(ResourcesPlugin.getWorkspace().getRoot());

		ResourcesPlugin.getWorkspace().addResourceChangeListener(new IResourceChangeListener() {
			@Override
			public void resourceChanged(IResourceChangeEvent event) {
				Runnable runnable = new Runnable() {
					public void run() {

						treeViewer.refresh();
					}
				};

				Display.getDefault().asyncExec(runnable);

			}
		});

		treeViewer.addDoubleClickListener(new IDoubleClickListener() {

			@Override
			public void doubleClick(DoubleClickEvent event) {
				ISelection selection = event.getSelection();
				try {
					Object firstElement = ((TreeSelection) selection).getFirstElement();
					IFile file = ((IFile) firstElement);
					if (!file.getFileExtension().equals("architecturetool") && !file.getFileExtension().equals("rp")) {
						IDE.openEditor(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage(), file,
								EditorsUI.DEFAULT_TEXT_EDITOR_ID);

					} else {
						IDE.openEditor(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage(), file, ID);
					}
				} catch (PartInitException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

	}

	@Override
	public void setFocus() {
		treeViewer.getControl().setFocus();

	}

	@Override
	public void addSelectionListener(ISelectionListener listener) {
		new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				super.widgetSelected(e);
			}
		};
	}

	@Override
	public void addSelectionListener(String partId, ISelectionListener listener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addPostSelectionListener(ISelectionListener listener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addPostSelectionListener(String partId, ISelectionListener listener) {
		// TODO Auto-generated method stub

	}

	@Override
	public ISelection getSelection() {
		ISelection selection = treeViewer.getSelection();
		return selection;
	}

	@Override
	public ISelection getSelection(String partId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeSelectionListener(ISelectionListener listener) {
		// IStructuredSelection iStructuredSelection=(IStructuredSelection)
		// listener;
		// Object firstElement = iStructuredSelection.getFirstElement();
		// if(firstElement!=null)
		// treeViewer.setSelection(null, true);
	}

	@Override
	public void removeSelectionListener(String partId, ISelectionListener listener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removePostSelectionListener(ISelectionListener listener) {

	}

	@Override
	public void removePostSelectionListener(String partId, ISelectionListener listener) {
		// TODO Auto-generated method stub

	}

}
