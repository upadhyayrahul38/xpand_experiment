package com.conti.component.ui.view;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerDropAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.TransferData;

public class ProjctViewDropListener extends ViewerDropAdapter {

	private Object target;
	private Viewer viewer2;

	protected ProjctViewDropListener(Viewer viewer) {
		
		super(viewer);
		// TODO Auto-generated constructor stub
		viewer2 = viewer;
	}
@Override
public void drop(DropTargetEvent event) {
	int location = this.determineLocation(event);
target = determineTarget(event);


super.drop(event);
}
	@Override
	public boolean performDrop(Object data) {
		IStructuredSelection selection = (IStructuredSelection) viewer2.getSelection();
		if (selection.getFirstElement() instanceof IFile) {
			IFile file=(IFile) selection.getFirstElement();
			
			IProject target2 = (IProject) target;
			try {
			    IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
			    for (int i = 0; i < projects.length; i++) {
					if(projects[i].getName().equals(target2.getName())) {
						if(projects[i].exists()) {
							IFile file2 = projects[i].getFile(file.getName());
							if(!file2.exists()) {
								FileInputStream fileInputStream;
								try {
									fileInputStream = new FileInputStream(file.getLocation().toOSString());
									file2.create(fileInputStream, true, null);
									file.delete(true, null);
								} catch (FileNotFoundException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
							}
						}
					}
				}
//				String resolvedLocationText = IDEResourceInfoUtils.getLocationText(target2);
//				String replace = resolvedLocationText.replace("\\", "/");
//				file.move(new Path(resolvedLocationText.substring(2,resolvedLocationText.length()-1)), true, new NullProgressMonitor());
				//File newProjectFolder = new File(target2.getLocation()+"/"+target2.getName());
				//target2.copy(target2.getFullPath(), true, null);
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			fullPath.append(file.getName());
			viewer2.refresh();
		}
		return true;
        
   }

	@Override
	public boolean validateDrop(Object target, int operation, TransferData transferType) {
		// TODO Auto-generated method stub
		return true;
	}

	

}
