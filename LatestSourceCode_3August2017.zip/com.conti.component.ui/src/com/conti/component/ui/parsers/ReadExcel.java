package com.conti.component.ui.parsers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import architecturetool.AbsoluteRefrence;
import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Attribute;
import architecturetool.AttributeTypeEnum;
import architecturetool.Component;
import architecturetool.DataStructure;
import architecturetool.DatatypeEnum;
import architecturetool.Enum;
import architecturetool.Generator;
import architecturetool.Literal;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Parameter;
import architecturetool.PhysicalUnitEnum;
import architecturetool.Root;

public class ReadExcel {
	private static String sheetName;
	private static String output;
	private static NoNameElement createNoNameElement;
	private static MCC createMCC;
	private static Component createComponent;
	private static Generator createGenerator;
	private static Root createRoot;
	private static DataStructure createDataStructure;

	public static void importExcel(String path,String savePath) {
		String excelFilePath = path;
		createRoot = ArchitecturetoolFactory.eINSTANCE.createRoot();
		createNoNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
		createMCC = ArchitecturetoolFactory.eINSTANCE.createMCC();
		createComponent = ArchitecturetoolFactory.eINSTANCE.createComponent();
		createComponent.setName("test");
		createGenerator = ArchitecturetoolFactory.eINSTANCE.createGenerator();
		FileInputStream inputStream = null;
		HSSFWorkbook workbook = null;
		try {
			inputStream = new FileInputStream(new File(excelFilePath));

			try {
				workbook = new HSSFWorkbook(inputStream);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HSSFSheet firstSheet = workbook.getSheet("Generator");
		Iterator<Row> iterator = firstSheet.iterator();

		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Iterator<Cell> cellIterator = nextRow.cellIterator();
			if (nextRow.getRowNum() == 0 || nextRow.getRowNum() > 31)
				continue;
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();

				if (cell.getColumnIndex() == 1) {
					sheetName = cell.getStringCellValue();
					System.err.print("\n" + sheetName + "\n");
					if (output != null)
						output = output + "<structs name=" + "\"" + cell.getStringCellValue() + "\"";
					else
						output = "<structs name=" + "\"" + cell.getStringCellValue() + "\"";

				}
				if (cell.getColumnIndex() == 2) {
					output = output + " description=" + "\"" + cell.getStringCellValue() + "\">";

					if (sheetName.isEmpty()) {
						continue;
					}

					linkedSheetDetail(workbook, sheetName);

				}

			}

			// System.out.println(createGenerator.getDatastructure());
		}
		saveXml(savePath);
		try {
			workbook.close();
			inputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void linkedSheetDetail(HSSFWorkbook workbook, String sheetName) {

		createRoot.getNonameelement().add(createNoNameElement);
		createNoNameElement.getMcc().add(createMCC);
		createMCC.getComponents().add(createComponent);
		createComponent.getGenerator().add(createGenerator);

		createDataStructure = null;
		if (sheetName.equals("FCTHEADOutputCustom")) {
			System.out.println("x");
		}
		HSSFSheet firstSheet = workbook.getSheet(sheetName);
		Iterator<Row> iterator = firstSheet.iterator();
		int dataTypeColumnIndex = -1;
		int dataElementColumnIndex = -1;
		int descriptionColumnIndex = -1;
		int arraySizeColumnIndex = -1;
		int accuracyColumnIndex = -1;
		int typeRangeColumnIndex = -1;
		int physicalUnitColumnIndex = -1;
		int staticVariableNameColumnIndex = -1;
		int staticVariablenmaerowIndex = -1;
		HashMap<String, List> levelStructMap = new HashMap<String, List>();
		while (iterator.hasNext()) {
			Row row = (Row) iterator.next();

			int outlineLevel = row.getOutlineLevel();
			int rowNum = row.getRowNum();
			if (rowNum == 0) {
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = (Cell) cellIterator.next();
					if (cell.getStringCellValue().equals("Data Type")) {
						dataTypeColumnIndex = cell.getColumnIndex();
					} else if (cell.getStringCellValue().equals("Data Element")) {
						dataElementColumnIndex = cell.getColumnIndex();
					} else if (cell.getStringCellValue().equals("Description")) {
						descriptionColumnIndex = cell.getColumnIndex();
					} else if (cell.getStringCellValue().equals("Array Size")) {
						arraySizeColumnIndex = cell.getColumnIndex();
					} else if (cell.getStringCellValue().equals("Accuracy")) {
						accuracyColumnIndex = cell.getColumnIndex();
					} else if (cell.getStringCellValue().equals("Typ. Range")) {
						typeRangeColumnIndex = cell.getColumnIndex();
					} else if (cell.getStringCellValue().equals("Physical Unit")) {
						physicalUnitColumnIndex = cell.getColumnIndex();
					}

				}
				continue;
			}

			if (sheetName.equals("Static Variables")) {
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = (Cell) cellIterator.next();

					switch (cell.getCellType()) {
					case 1:
						if (cell.getStringCellValue().equals("Name")) {
							staticVariableNameColumnIndex = cell.getColumnIndex();
							staticVariablenmaerowIndex = cell.getRowIndex();
							break;
						}
						break;
					}
				}

			}

			if (row.getCell(dataTypeColumnIndex) != null && !row.getCell(dataTypeColumnIndex).toString().isEmpty()) {
				String type = row.getCell(dataTypeColumnIndex).getStringCellValue();
				if (type.equals("struct")) {
					if (levelStructMap.containsKey(Integer.toString(outlineLevel))) {
						ArrayList<String> structRowNums = (ArrayList<String>) levelStructMap
								.get(Integer.toString(outlineLevel));
						structRowNums.add(Integer.toString(rowNum));
					} else {
						ArrayList<String> structRowNums = new ArrayList<String>();
						structRowNums.add(Integer.toString(rowNum));
						levelStructMap.put(Integer.toString(outlineLevel), structRowNums);
					}
					// }
				}
			}

		}

		iterator = firstSheet.iterator();
		DataStructure parentDataStructure = null;
		int previousOutlineNo = 0;
		Stack<DataStructure> dataStructureStack = new Stack<DataStructure>();
		while (iterator.hasNext()) {
			Row row = (Row) iterator.next();

			if (sheetName.equals("Static Variables")) {
				if (row.getRowNum() < staticVariablenmaerowIndex + 1) {
					continue;
				}
				if (row.getCell(staticVariableNameColumnIndex) != null
						&& !row.getCell(staticVariableNameColumnIndex).toString().isEmpty()) {
					Parameter createParameter = ArchitecturetoolFactory.eINSTANCE.createParameter();
					createParameter.setName(row.getCell(staticVariableNameColumnIndex).toString());
					createMCC.getParameters().add(createParameter);
				}
			}
			int outlineLevel = row.getOutlineLevel();
			int rowNum = row.getRowNum();
			if (rowNum == 52) {
				System.out.println("x");
			}
			if (rowNum == 0) {
				continue;
			}

			if (row.getCell(dataTypeColumnIndex) != null && !row.getCell(dataTypeColumnIndex).toString().isEmpty()) {
				String type = row.getCell(dataTypeColumnIndex).getStringCellValue();
				if (previousOutlineNo > outlineLevel) {
					int diff = previousOutlineNo - outlineLevel;
					if (diff == dataStructureStack.size()) {
						for (int i = 0; i < diff - 1; i++) {
							dataStructureStack.pop();
						}
					} else {
						if (diff < dataStructureStack.size()) {
							for (int i = 0; i < diff; i++) {
								dataStructureStack.pop();
							}
						} else {
							for (int i = 1; i < diff; i++) {
								dataStructureStack.pop();
							}
						}
					}

					if (!dataStructureStack.isEmpty()) {
						parentDataStructure = dataStructureStack.peek();
					} else {
						parentDataStructure = null;
					}
				}

				if (type.equals("struct")) {
					if (levelStructMap.containsKey(Integer.toString(outlineLevel))) {
						ArrayList<String> structRowNums = (ArrayList<String>) levelStructMap
								.get(Integer.toString(outlineLevel));
						if (structRowNums.contains(Integer.toString(rowNum))) {
							createDataStructure = ArchitecturetoolFactory.eINSTANCE.createDataStructure();
							createDataStructure.setName(row.getCell(dataElementColumnIndex).getStringCellValue());
							createDataStructure
									.setDescription(row.getCell(descriptionColumnIndex).getStringCellValue());
							createDataStructure.setType(createDataStructure.getName());
							if (parentDataStructure != null) {
								parentDataStructure.getStructs().add(createDataStructure);
								if (!dataStructureStack.contains(createDataStructure)) {
									dataStructureStack.push(createDataStructure);
								}
							} else {
								createGenerator.getDatastructure().add(createDataStructure);
								dataStructureStack.push(createDataStructure);
								parentDataStructure = dataStructureStack.peek();
							}
						}

					}

				} else {
					
					if (type.equals("ref")) {
						AbsoluteRefrence createAbsoluteRefrence = ArchitecturetoolFactory.eINSTANCE
								.createAbsoluteRefrence();
						createAbsoluteRefrence.setName(row.getCell(dataElementColumnIndex).getStringCellValue());
						createAbsoluteRefrence.setDescription(row.getCell(descriptionColumnIndex).getStringCellValue());
						String cellValue = row.getCell(physicalUnitColumnIndex).toString();
						if(cellValue!=null){
						if (cellValue.equals("-")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.NOUNIT);;
						} else if (cellValue.equals("m")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.METER);
						} else if (cellValue.equals("m^2")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.SQUAREMETER);
						} else if (cellValue.equals("s")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.SECOND);
						} else if (cellValue.equals("m/s")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.METERPERSECOND);
						} else if (cellValue.equals("(m/s)^2")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED);
						} else if (cellValue.equals("m/s^2")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.METERPERSECONDSQUARED);
						} else if (cellValue.equals("m/s^3")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.METERPERSECONDCUBED);
						} else if (cellValue.equals("(m/s^2)^2")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED);
						} else if (cellValue.equals("rad")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.RADIAN);
						} else if (cellValue.equals("rad/s")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.RADIANPERSECOND);
						} else if (cellValue.equals("(rad/s)^2")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.RADIANPERSECONDSQUARED);
						} else if (cellValue.equals("N")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.NEWTON);
						} else if (cellValue.equals("degC")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.DEGREECENTIGRADE);
						} else if (cellValue.equals("Nm")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.NEWTONMETER);
						} else if (cellValue.equals("N/raD")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.NEWTONPERRAD);
						} else if (cellValue.equals("kg")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.KILOGRAM);
						} else if (cellValue.equals("rads^2/m")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER);
						} else if (cellValue.equals("dBr")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.DECIBEL);
						} else if (cellValue.equals("1/m")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.CURVATURE);
						} else if (cellValue.equals("1/m^2")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.CURVATURERATE);
						} else if (cellValue.equals("km")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.KILOMETER);
						} else if (cellValue.equals("km/h")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.KILOMETERPERHOUR);
						} else if (cellValue.equals("deg")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.DEGREE);
						} else if (cellValue.equals("%")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.PERCENT);
						} else if (cellValue.equals("ms")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.MILLISECOND);
						} else if (cellValue.equals("dBsqm")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.DECIBELPERSQUAREMETER);
						} else if (cellValue.equals("deg/s")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.DEGREEPERSECOND);
						} else if (cellValue.equals("%/s")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.PERCENTPERSECOND);
						} else if (cellValue.equals("px")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.PIXEL);
						} else if (cellValue.equals("us")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.MICROSECOND);
						} else if (cellValue.equals("byte")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.BYTE);
						} else if (cellValue.equals("bit")) {
							createAbsoluteRefrence.setPhysicalUnit(PhysicalUnitEnum.BIT);
						}
						}
						parentDataStructure.getAbsolutereference().add(createAbsoluteRefrence);
					} else if (type.equals("enum")) {
						if (row.getOutlineLevel() == 0) {
							Enum createEnum = ArchitecturetoolFactory.eINSTANCE.createEnum();
							createEnum.setName(row.getCell(dataElementColumnIndex).getStringCellValue());
							createEnum.setDescription(row.getCell(descriptionColumnIndex).getStringCellValue());
							String stringCellValue = row.getCell(typeRangeColumnIndex).getStringCellValue();
							System.out.println(stringCellValue);
							String[] split = stringCellValue.split("\n");
							Literal literal = null;
							for (int i = 0; i < split.length; i++) {
								String splitStr = split[i];
								Literal createLiteral = ArchitecturetoolFactory.eINSTANCE.createLiteral();
								int indexOf = splitStr.indexOf("=");
								String splitStrr = splitStr.substring(0, indexOf - 1);
								createLiteral.setName(splitStrr);
								createLiteral.setValue(i);
								createEnum.getLiteral().add(createLiteral);
							}
							createGenerator.getEnum().add(createEnum);
						} else {
							Enum createEnum = ArchitecturetoolFactory.eINSTANCE.createEnum();
							createEnum.setName(row.getCell(dataElementColumnIndex).getStringCellValue());
							createEnum.setDescription(row.getCell(descriptionColumnIndex).getStringCellValue());
							String stringCellValue = row.getCell(typeRangeColumnIndex).getStringCellValue();
							System.out.println(stringCellValue);
							String[] split = stringCellValue.split("\n");
							Literal literal = null;
							for (int i = 0; i < split.length; i++) {
								String splitStr = split[i];
								Literal createLiteral = ArchitecturetoolFactory.eINSTANCE.createLiteral();
								int indexOf = splitStr.indexOf("=");
								if (indexOf < 0) {
									createLiteral.setName(splitStr);

								} else {
									String splitStrr = splitStr.substring(0, indexOf - 1);
									createLiteral.setName(splitStrr);
								}
								createLiteral.setValue(i);
								createEnum.getLiteral().add(createLiteral);
							}
							createGenerator.getEnum().add(createEnum);
							Attribute createAttribute = ArchitecturetoolFactory.eINSTANCE.createAttribute();
							createAttribute.setName(row.getCell(0).getStringCellValue());
							createAttribute.setDescription(row.getCell(descriptionColumnIndex).getStringCellValue());
							createAttribute.setAttributeType(AttributeTypeEnum.ENUM_TYPE);
							createAttribute.setEnum(createEnum);
							parentDataStructure.getAttributes().add(createAttribute);
						}
					} else if (type.equals("uint32") || type.equals("uint16") || type.equals("uint8") || type.equals("sin8")
							|| type.equals("sin16") || type.equals("sin32") || type.equals("float32")
							|| type.equals("boolean")) {
						
						Attribute createAttribute = ArchitecturetoolFactory.eINSTANCE.createAttribute();
						createAttribute.setName(row.getCell(dataElementColumnIndex).getStringCellValue());
						createAttribute.setDescription(row.getCell(descriptionColumnIndex).getStringCellValue());
						if(type.equals("uint32"))
						{
							createAttribute.setDataType(DatatypeEnum.UNIT32);
						}
						else if(type.equals("uint16"))
						{
							createAttribute.setDataType(DatatypeEnum.UNIT16);
						}
						else if(type.equals("uint8"))
						{
							createAttribute.setDataType(DatatypeEnum.UNIT8);
						}else if(type.equals("sin8"))
						{
							createAttribute.setDataType(DatatypeEnum.SINT8);
						}else if(type.equals("sin16"))
						{
							createAttribute.setDataType(DatatypeEnum.SINT16);
						}else if(type.equals("sin32"))
						{
							createAttribute.setDataType(DatatypeEnum.SINT32);
						}else if(type.equals("float32"))
						{
							createAttribute.setDataType(DatatypeEnum.FLOAT32);
						}else if(type.equals("boolean"))
						{
							createAttribute.setDataType(DatatypeEnum.BOOLEAN);
						}
						if( row.getCell(physicalUnitColumnIndex)==null || row.getCell(physicalUnitColumnIndex).toString().isEmpty()){
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.NOUNIT);
							}
						else{
						String cellValue = row.getCell(physicalUnitColumnIndex).toString();
						
						if (cellValue.equals("-")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.NOUNIT);;
						} else if (cellValue.equals("m")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.METER);
						} else if (cellValue.equals("m^2")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.SQUAREMETER);
						} else if (cellValue.equals("s")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.SECOND);
						} else if (cellValue.equals("m/s")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.METERPERSECOND);
						} else if (cellValue.equals("(m/s)^2")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.METERSQUAREDPERSECONDSQUARED);
						} else if (cellValue.equals("m/s^2")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.METERPERSECONDSQUARED);
						} else if (cellValue.equals("m/s^3")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.METERPERSECONDCUBED);
						} else if (cellValue.equals("(m/s^2)^2")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.METERPERSECONDSQUAREDSQUARED);
						} else if (cellValue.equals("rad")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.RADIAN);
						} else if (cellValue.equals("rad/s")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.RADIANPERSECOND);
						} else if (cellValue.equals("(rad/s)^2")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.RADIANPERSECONDSQUARED);
						} else if (cellValue.equals("N")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.NEWTON);
						} else if (cellValue.equals("degC")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.DEGREECENTIGRADE);
						} else if (cellValue.equals("Nm")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.NEWTONMETER);
						} else if (cellValue.equals("N/raD")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.NEWTONPERRAD);
						} else if (cellValue.equals("kg")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.KILOGRAM);
						} else if (cellValue.equals("rads^2/m")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.RADIANSECONSQUAREDPERMETER);
						} else if (cellValue.equals("dBr")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.DECIBEL);
						} else if (cellValue.equals("1/m")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.CURVATURE);
						} else if (cellValue.equals("1/m^2")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.CURVATURERATE);
						} else if (cellValue.equals("km")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.KILOMETER);
						} else if (cellValue.equals("km/h")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.KILOMETERPERHOUR);
						} else if (cellValue.equals("deg")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.DEGREE);
						} else if (cellValue.equals("%")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.PERCENT);
						} else if (cellValue.equals("ms")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.MILLISECOND);
						} else if (cellValue.equals("dBsqm")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.DECIBELPERSQUAREMETER);
						} else if (cellValue.equals("deg/s")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.DEGREEPERSECOND);
						} else if (cellValue.equals("%/s")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.PERCENTPERSECOND);
						} else if (cellValue.equals("px")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.PIXEL);
						} else if (cellValue.equals("us")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.MICROSECOND);
						} else if (cellValue.equals("byte")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.BYTE);
						} else if (cellValue.equals("bit")) {
							createAttribute.setPhysicalUnit(PhysicalUnitEnum.BIT);
						}
						}
						
						if (parentDataStructure != null)
							parentDataStructure.getAttributes().add(createAttribute);
					}
				}
			}

			if (outlineLevel > previousOutlineNo) {
				if (createDataStructure != null) {
					parentDataStructure = createDataStructure;
				} else {

				}
			} else {
				if (!dataStructureStack.isEmpty()) {
					parentDataStructure = dataStructureStack.peek();
				}
			}
			previousOutlineNo = outlineLevel;

		}

		System.out.println(createGenerator);

	}

	private static void saveXml(String savePath) {
		ResourceSetImpl rset = new ResourceSetImpl();
		rset.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
		rset.getResourceFactoryRegistry().getExtensionToFactoryMap().put("architecturetool", new XMIResourceFactoryImpl());

		String finalPath =savePath +".architecturetool";
		Resource resource = rset.createResource(URI.createFileURI(finalPath));

		resource.getContents().add(createRoot);
		try {
			resource.save(null);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
