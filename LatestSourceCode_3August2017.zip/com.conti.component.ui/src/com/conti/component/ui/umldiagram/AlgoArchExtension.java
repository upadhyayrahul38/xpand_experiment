package com.conti.component.ui.umldiagram;



import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

import com.telelogic.rhapsody.core.*;
import org.xml.sax.SAXException;


@SuppressWarnings("unchecked")
public class AlgoArchExtension extends RPUserPlugin {

  final String STEREOTYPE_SELECT = "MdbSelection";
  final static String NL = String.format("%n");

  protected IRPApplication  m_rhpApplication = null;

  public static void main(String[] args) {
    //create an instance of my plugin
    AlgoArchExtension myPlugin = new AlgoArchExtension ();
    //get Rhapsody application that is currently running
    IRPApplication app = RhapsodyAppServer.getActiveRhapsodyApplication();
    //init the plugin
    myPlugin.RhpPluginInit(app);
    //imitate a call to the plugin
    myPlugin.OnMenuItemSelect("AlgoArchExtension\\UpdateRteTypeSizes");
  }


  // called when the plug-in is loaded
  public void RhpPluginInit(final IRPApplication rpyApplication) {
    // keep the application interface for later use
    m_rhpApplication = rpyApplication;
    // String msg = "Hello world from SimplePlugin.RhpPluginInit." + NL;
    // m_rhpApplication.writeToOutputWindow("Log" , "Init AlgoArchExtension plugin." + NL);
  }

  // called when the plug-in menu item under the "Tools" menu is selected
  public void RhpPluginInvokeItem() {
    // m_rhpApplication.writeToOutputWindow("Log" , "Invoke AlgoArchExtension plugin." + NL);
  }

  // called when the plug-in pop-up menu (if applicable) is selected
  public void OnMenuItemSelect(String menuItem) {
    m_rhpApplication.writeToOutputWindow("Log", menuItem + NL);

    IRPModelElement element = m_rhpApplication.getSelectedElement();
    List<IRPModelElement> selection = new ArrayList<>(1);
    selection.add(element);
    if (element == null) {
      selection = m_rhpApplication.getListOfSelectedElements().toList();
    }

    if (menuItem.equals("AlgoArchExtension\\CreateCorrespondingRational")) { 
      CreateCorrespondingRational(selection);
    }
    else {
      for (IRPModelElement elem : selection) {
        m_rhpApplication.writeToOutputWindow("Log", "AlgoArchExtension called for element: " + elem.getName() + "  of type: " + elem.toString() + NL);

//        try {
////          if (menuItem.equals("AlgoArchExtension\\CreateExternalHeaders"))
////            CreateExternalHeaders(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\SpreadSafetyLevel"))
//            SpreadSafetyLevel(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\CreateInputFlow"))
//            CreateInputFlow(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\CorrectBasePortNames"))
//            CorrectBasePortNames(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\CorrectFlowNames"))
//            CorrectFlowNames(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\SimExport"))
//            SimExport(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\AddApplicationProjectTags"))
//            AddApplicationProjectTags(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\ImportMdbClusterNameForProvidePorts"))
//            ImportMdbClusterNameForProvidePorts(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\ExportGenericAdapterSetup"))
//            ExportGenericAdapterSetup(elem);
//
//          if (menuItem.equals("AlgoArchExtension\\CollectFlowsAndPopulateStructureDiagram"))
//            CollectFlowsAndPopulateStructureDiagram(elem);
//
          if (menuItem.equals("AlgoArchExtension\\UpdateRteTypeSizes"))
			try {
				UpdateRteTypeSizes(elem);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

//          if (menuItem.equals("AlgoArchExtension\\PrepareCheckpointRelease"))
//            PrepareCheckpointRelease(elem);
//        } catch (Exception exc) {
//          m_rhpApplication.writeToOutputWindow("Log", "Caught Exception: " + exc.getClass().toString() + NL);
//          StringWriter writer = new StringWriter();
//          PrintWriter printer = new PrintWriter(writer);
//          exc.printStackTrace(printer);
//          m_rhpApplication.writeToOutputWindow("Log", "Stack Trace:" + NL + writer.toString() + NL);
//        }
      }
    }
  }

  // called when the plug-in popup trigger (if applicable) fired
  public void OnTrigger(String trigger) {
    // m_rhpApplication.writeToOutputWindow("", "AlgoArchExtension called for trigger: " + trigger + NL);
  }

  // called when the project is closed - if true is returned the plugin will
  // be unloaded
  public boolean RhpPluginCleanup() {
    //JOptionPane.showMessageDialog(null,    "Hello world from SimplePlugin.RhpPluginCleanup");
    //cleanup
    m_rhpApplication = null;
    //return true so the plug-in will be unloaded now (on project close)
    return true;
  }

  // called when Rhapsody exits
  public void RhpPluginFinalCleanup() {
    //JOptionPane.showMessageDialog(null,  "Hello world from SimplePlugin.RhpPluginFinalCleanup");
  }

//  private void PrepareCheckpointRelease(IRPModelElement element) throws IOException, ParserConfigurationException, TransformerException {
//    CreateExternalHeaders(element);
//    SimExport(element);
//    ExportGenericAdapterSetup(element);
//    CollectFlowsAndPopulateStructureDiagram(element);
//  }

//  private void CreateExternalHeaders(IRPModelElement element) throws IOException {
//    String sHeader = "CreateExternalHeaders";
//    if (element == null) {
//      m_rhpApplication.writeToOutputWindow(sHeader, "No selected element" + NL);
//      return;
//    }
//    m_rhpApplication.writeToOutputWindow(sHeader, "Writing external headers for Block: " + element.getName() + NL);
//
//
//    IRPCollection rpBlocks = element.getNestedElementsByMetaClass("Class", -1);
//    List<IRPModelElement> blocks = rpBlocks.toList();
//    // filter for correct stereotype
//    IRPModelElement stereotype = m_rhpApplication.activeProject().findNestedElementRecursive("AlgoTask", "Stereotype");
//    blocks = blocks.stream().filter(b -> b.getStereotypes().toList().contains(stereotype)).collect(Collectors.toList());
//    // filter for blocks having ports
//    blocks = blocks.stream().filter(b -> b.getNestedElementsByMetaClass("SysMLPort", 0).getCount() > 0).collect(Collectors.toList());
//
//    m_rhpApplication.writeToOutputWindow(sHeader, "Writing for blocks: " + blocks.stream().map(b -> b.getName()).collect(Collectors.toList()).toString() + NL);
//
//
//    // get base path
//    String path = ((IRPUnit)m_rhpApplication.activeProject()).getCurrentDirectory();
//    path += "\\..\\..\\..\\..\\04_Engineering\\00_Projects\\MFC431\\GA\\";
//    Files.createDirectories(Paths.get(path));
//
//    m_rhpApplication.writeToOutputWindow(sHeader, "Writing to: " + path + NL);
//
//    InputStream stream = AlgoArchExtension.class.getResourceAsStream("template_ext.h");
//    ByteArrayOutputStream result = new ByteArrayOutputStream();
//    byte[] buffer = new byte[1024];
//    int length;
//    while ((length = stream.read(buffer)) != -1) {
//      result.write(buffer, 0, length);
//    }
//    String template_text = result.toString("UTF-8");
//    stream.close();
//
//    for (IRPModelElement block : blocks) {
//      String name = block.getName().toLowerCase();
//
//      String heading = new String(template_text);
//      heading = heading.replaceAll("<<file>>", name + "_ext.h");
//      heading = heading.replaceAll("<<comp>>", name.toUpperCase());
//
//      TmpFile file = new TmpFile(path + "\\" + name + "_ext.h");
//      file.setWritable(true);
//      file.createNewFile();
//      FileWriter writer = new FileWriter(file);
//
//      writer.write(heading);
//
//      String includeguard = "__" + name.toUpperCase() + "_EXT_H";
//      writer.write("" + NL + "#ifndef " + includeguard + "" + NL + "#define " + includeguard + NL + NL);
//      writer.write("#include \"algo_glob.h\"" + NL + NL);
//      writer.write("#ifdef __cplusplus" + NL + "extern \"C\"" + NL + "{" + NL + "#endif" + NL + NL);
//
//
//      String name_camel = "";
//      String[] parts = name.split("_");
//      for (String part : parts) {
//        part = part.toLowerCase();
//        part = part.substring(0, 1).toUpperCase() + part.substring(1);
//        name_camel += part;
//      }
//      String reqtype = "req" + name_camel + "PrtList_t";
//      String protype = "pro" + name_camel + "PrtList_t";
//
//      WritePortLists(block, writer, reqtype, protype, name_camel);
//
//      writer.write("" + NL + NL
//        + "/**" + NL
//        + " * Entry point for algo calculation." + NL
//        + " * @param reqPorts Input data for algo calculation." + NL
//        + " * @param proPorts Output data of algo calculation." + NL
//        + " * @param services Service functions available for usage." + NL
//        + " * @return Error code." + NL
//        + " */" + NL);
//      writer.write("BaseReturnCode_t " + name_camel + "Exec(const " + reqtype + "* const reqPorts, " + protype + "* const proPorts, const AS_t_ServiceFuncts* const services);" + NL + NL);
//
//      writer.write("#ifdef __cplusplus" + NL + "}" + NL + "#endif" + NL + NL);
//      writer.write("#endif  // " + includeguard + NL + NL);
//
//      writer.flush();
//      writer.close();
//      file.close();
//    }
//  }

  private void WritePortLists(IRPModelElement block, FileWriter writer, String reqtype, String protype, String name_camel) throws IOException {
    List<IRPModelElement> ports = block.getNestedElementsByMetaClass("SysMLPort", 0).toList();
    final Comparator<IRPModelElement> comp = (p1, p2) -> Integer.compare( ((IRPSysMLPort)p1).getType().getName().length(), ((IRPSysMLPort)p2).getType().getName().length() );
    int alignto = ((IRPSysMLPort)(ports.stream().max(comp).get())).getType().getName().length();
    List<IRPModelElement> reqs = ports.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("In")).collect(Collectors.toList());
    List<IRPModelElement> pros = ports.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("Out")).collect(Collectors.toList());
    List<IRPModelElement> inouts = ports.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("InOut")).collect(Collectors.toList());
    for (IRPModelElement p : inouts) {
      reqs.add(p);
      pros.add(p);
    }
    // sort and put base ports to the front
    reqs.sort((p1,p2) -> String.CASE_INSENSITIVE_ORDER.compare(p1.getName(), p2.getName()));
    pros.sort((p1,p2) -> String.CASE_INSENSITIVE_ORDER.compare(p1.getName(), p2.getName()));
    reqs = reqs.stream().filter(x -> !((IRPSysMLPort)x).getType().getName().equals("BaseCtrlData_t")).collect(Collectors.toList());
    pros = pros.stream().filter(x -> !((IRPSysMLPort)x).getType().getName().equals("AlgoCompState_t")).collect(Collectors.toList());
    try {
      IRPModelElement ctrldata = ports.stream().filter(x -> ((IRPSysMLPort) x).getType().getName().equals("BaseCtrlData_t")).collect(Collectors.toList()).get(0);
      IRPModelElement compstate = ports.stream().filter(x -> ((IRPSysMLPort) x).getType().getName().equals("AlgoCompState_t")).collect(Collectors.toList()).get(0);
      reqs.add(0, ctrldata);
      pros.add(0, compstate);
    }
    catch (Exception exc) {
      m_rhpApplication.writeToOutputWindow("Log", "Warning: Missing base port for comp: " + block.getName() + NL);
    }

    writer.write("//! Input sync structure providing info about received inputs on measfreeze channel." + NL);
    writer.write("typedef struct " + name_camel + "_SyncRef_s" + NL + "{" + NL);
    writer.write("  AlgoInterfaceVersionNumber_t uiVersionNumber;" + NL);
    writer.write("  SignalHeader_t               sSigHeader;" + NL);
    writer.write("  BaseCtrlData_t               sBaseCtrl;" + NL);
    for (IRPModelElement port : reqs) {
      if (!((IRPSysMLPort)port).getType().getName().equals("BaseCtrlData_t"))
        writer.write("  SignalHeader_t               " + port.getName() + ";" + NL);
    }
    writer.write("} " + name_camel + "_SyncRef_t;" + NL + NL);

    writer.write("//! List of input ports." + NL);
    writer.write("typedef struct " + reqtype.substring(0, protype.length() - 2) + "_s" + NL + "{" + NL);
    for (IRPModelElement port : reqs)
      WritePort(port, writer, alignto, true);
    writer.write("} " + reqtype + ";" + NL + NL);

    writer.write("//! List of output ports." + NL);
    writer.write("typedef struct " + protype.substring(0, protype.length() - 2) + "_s" + NL + "{" + NL);
    for (IRPModelElement port : pros)
      WritePort(port, writer, alignto, false);
    writer.write("} " + protype + ";" + NL + NL);
  }

  private void WritePort(IRPModelElement port, FileWriter writer, int alignto, boolean bConst) throws IOException {
    String line = "  ";
    if (bConst)
      line += "const ";
    line = String.format(line + "%-" + Integer.toString(alignto + 1) + "s", ((IRPSysMLPort)port).getType().getName() + "*");
    writer.write(line + " " + port.getName() + ";");
    if (port.getDescription().length() > 0)
      writer.write("    //!< " + port.getDescription().replace("" + NL, " ") + NL);
    else
      writer.write("" + NL);
  }

  private void SpreadSafetyLevel(IRPModelElement element) {
    final String sHeader = "SpreadSafetyLevel";
    if (element == null) {
      m_rhpApplication.writeToOutputWindow(sHeader, "No selected element" + NL);
      return;
    }

    List<IRPModelElement> list = element.getNestedElementsRecursive().toList();
    list.add(element);
    for (IRPModelElement elem: list) {
      IRPTag rpTag = elem.getTag("_SafetyRelevant");
      if (rpTag != null)
        RecurseThroughRelationsAndSpreadSafetyLevel(elem, rpTag.getValue(), 0);
    }
  }

  private void RecurseThroughRelationsAndSpreadSafetyLevel(IRPModelElement element, String value, int recursion_depth) {
    final String sHeader = "SpreadSafetyLevel";
    final int MAX_DEPTH = 20;
    if (recursion_depth >= MAX_DEPTH) {
      m_rhpApplication.writeToOutputWindow(sHeader, "Max recursion depth exceeded at element: " + element.getName() + NL);
      return;
    }
    m_rhpApplication.writeToOutputWindow(sHeader, "Spreading safety level for element: " + element.getName() + NL);

    recursion_depth++;

    for(Object ref: element.getReferences().toList())
    {
      if (ref instanceof IRPDependency)
      {
        IRPDependency dep = (IRPDependency)ref;
        IRPModelElement dependent = dep.getDependent();
        if ( !dependent.getGUID().equals(element.getGUID()) ) {
          IRPTag rpTag = dependent.getTag("_SafetyRelevant");
          if (rpTag != null) {
            String res_val = "";
            if (SetAndRetrieveResultingSafetyLevel(dependent, rpTag, value)) {
              m_rhpApplication.writeToOutputWindow(sHeader, "Updated safety tag for element: " + dependent.getName() + " -> " + value + NL);
              RecurseThroughRelationsAndSpreadSafetyLevel(dependent, res_val, recursion_depth);
            }
          }
        }
      }
    }
  }

  private boolean SetAndRetrieveResultingSafetyLevel(IRPModelElement elem, IRPTag tag, String value) {
    boolean ret = false;
    IRPType type = (IRPType)tag.getType();
    String current = tag.getValue();
    Integer cur = null;
    Integer val = null;
    List<IRPEnumerationLiteral> literals = type.getEnumerationLiterals().toList();
    for (IRPEnumerationLiteral lit: literals) {
      try {
        if (lit.getName().equals(value))
          val = new Integer(Integer.parseInt(lit.getValue()));
        if (lit.getName().equals(current))
          cur = new Integer(Integer.parseInt(lit.getValue()));
      }
      catch (NumberFormatException exc) {
        m_rhpApplication.writeToOutputWindow("", "Caught NumberFormatException: " + exc.getMessage() + NL);
      }
    }
    // check if both strings were found inside the enum definition
    if (cur != null && val != null) {
      // update if new value is higher
      if (val > cur) {
        elem.setTagValue(tag, value);
        ret = true;
      }
    }
    return ret;
  }

  private void CreateInputFlow(IRPModelElement element) {
    IRPSysMLPort port = (IRPSysMLPort)element;
    if (port.getPortDirection().equals("Out")) {
      m_rhpApplication.writeToOutputWindow("", "Nothing done for outgoing port!" + NL);
      return;
    }

    IRPModelElement block = element.getOwner();
    String flow_name = String.join("_", "to", block.getName(), element.getName());

    if (null != block.findNestedElement(flow_name, "Flow")) {
      m_rhpApplication.writeToOutputWindow("", "Nothing done flow with name '" + flow_name + "' already exists!" + NL);
      return;
    }

    IRPFlow flow = ((IRPClass)block).addFlows(flow_name);
    flow.addStereotype(STEREOTYPE_SELECT, "");
    flow.setDirection("toEnd2");
    // end 1 has to be set by user later on
    flow.setEnd2(element);
    flow.setDescription(port.getType().getName());

    m_rhpApplication.writeToOutputWindow("", "Added flow: " + flow_name + NL);
  }

  private void CorrectBasePortNames(IRPModelElement element) {

    List<IRPModelElement> baseCtrlPorts = element.getNestedElementsByMetaClass("SysMLPort", -1).toList();
    baseCtrlPorts = baseCtrlPorts.stream().filter(x -> ((IRPSysMLPort)x).getType().getName().equals("BaseCtrlData_t")).collect(Collectors.toList());
    // skip GS ports
    baseCtrlPorts = baseCtrlPorts.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("In")).collect(Collectors.toList());
    for (IRPModelElement p: baseCtrlPorts) {
      p.setName("pBaseCtrlData");
    }

    List<IRPModelElement> algoCompStates = element.getNestedElementsByMetaClass("SysMLPort", -1).toList();
    algoCompStates = algoCompStates.stream().filter(x -> ((IRPSysMLPort)x).getType().getName().equals("AlgoCompState_t")).collect(Collectors.toList());
    // skip GS ports
    algoCompStates = algoCompStates.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("Out")).collect(Collectors.toList());
    for (IRPModelElement p: algoCompStates) {
      p.setName("pAlgoCompState");
    }
  }

  private void CorrectFlowNames(IRPModelElement element) {

    List<IRPModelElement> flows = element.getNestedElementsByMetaClass("Flow", -1).toList();
    // filter for correct stereotype
    IRPModelElement stereotype = m_rhpApplication.activeProject().findNestedElementRecursive("MdbSelection", "Stereotype");
    flows = flows.stream().filter(b -> b.getStereotypes().toList().contains(stereotype)).collect(Collectors.toList());

    for (IRPModelElement elem: flows) {
      IRPFlow flow = (IRPFlow)elem;
      IRPModelElement reqport = null;
      if (flow.getDirection().equals("toEnd1"))
        reqport = flow.getEnd1();
      else if (flow.getDirection().equals("toEnd2"))
        reqport = flow.getEnd2();
      if (reqport == null) {
        m_rhpApplication.writeToOutputWindow("", "Flow with no direction or no requester set: " + flow.getName() + NL);
        continue;
      }

      // build consistent name
      String flow_name = String.join("_", "to", reqport.getOwner().getName(), reqport.getName());
      // check ownership
      if (!flow.getOwner().getGUID().equals(reqport.getOwner().getGUID())) {
        m_rhpApplication.writeToOutputWindow("", "Wrong owner for flow: " + flow_name + "   Shifting flow: " + flow.getOwner().getName() + " -> " + reqport.getOwner().getName() + NL);
        flow.setOwner(reqport.getOwner());
      }
      // check name
      if (!flow_name.equals(flow.getName())) {
        m_rhpApplication.writeToOutputWindow("", "Wrong name for flow: " + flow.getName() + "   Corrected to: " + flow_name + NL);
        flow.setName(flow_name);
      }
    }
  }

//  private void SimExport(IRPModelElement element) throws IOException{
//
//    List<IRPModelElement> cons = element.getNestedElementsByMetaClass("Flow", -1).toList();
//    IRPModelElement stereotype = m_rhpApplication.activeProject().findNestedElementRecursive("MdbSelection", "Stereotype");
//    cons = cons.stream().filter(x -> x.getStereotypes().toList().contains(stereotype)).collect(Collectors.toList());
//    // use tree map to have sorting
//    Map<IRPModelElement, List<IRPFlow>> mapped_cons = new TreeMap<>((p1,p2) -> String.CASE_INSENSITIVE_ORDER.compare(p1.getName(), p2.getName()));
//    for (IRPModelElement con: cons) {
//      IRPFlow flow = (IRPFlow)con;
//      IRPModelElement receiver = flow.getDirection().equals("toEnd2") ? flow.getEnd2().getOwner() : flow.getEnd1().getOwner();
//      List<IRPFlow> flows = mapped_cons.getOrDefault(receiver, new ArrayList<>());
//      flows.add(flow);
//      mapped_cons.putIfAbsent(receiver, flows);
//    }
//
//    // get base path
//    String path = ((IRPUnit)m_rhpApplication.activeProject()).getCurrentDirectory();
//    path += "\\..\\..\\..\\..\\05_Testing\\MTS\\mts_measurement\\cfg\\00_Projects\\MFC431\\GA\\";
//    Files.createDirectories(Paths.get(path));
//
//    m_rhpApplication.writeToOutputWindow("", "Writing to: " + path + NL);
//    TmpFile file = new TmpFile(path + "\\algo_architecture.simcon");
//    file.setWritable(true);
//    file.createNewFile();
//    FileWriter connection_file = new FileWriter(file);
//    connection_file.write("" + NL);
//    connection_file.write("[Request2ProvideConnections]" + NL);
//    connection_file.write("CfgSectionType=Request2ProvideConnection" + NL + NL);
//
//    TmpFile file_par = new TmpFile(path + "\\input_sync_port_cfg.par");
//    file_par.createNewFile();
//    FileWriter par_file = new FileWriter(file_par);
//    par_file.write("" + NL);
//    par_file.write("[SyncModeParameter].Type=simUI8_t" + NL);
//    par_file.write("[SyncModeParameter].Value=0" + NL);
//    par_file.write("[SyncModeParameter].ArrayLength=1" + NL);
//
//    for (IRPModelElement key: mapped_cons.keySet()) {
//      // write connection
//      connection_file.write("; ------------  TO " + key.getName().toUpperCase() + "  ------------" + NL);
//      List<IRPFlow> flows = mapped_cons.get(key);
//      flows.sort((x1,x2) -> String.CASE_INSENSITIVE_ORDER.compare(x1.getEnd2().getName(), x2.getEnd2().getName()));
//      int max_length = flows.stream().max( (x1, x2) -> Integer.compare(x1.getEnd2().getName().length(), x2.getEnd2().getName().length()) ).get().getEnd2().getName().length();
//      max_length += key.getName().length() + 2; // one for '.', one for space
//
//      String comment = "";
//      if (key.getOwner().getName().equals("SW")) {
//        comment = ";";
//      }
//
//      for (IRPFlow flow: flows) {
//        String entry = flow.getEnd2().getOwner().getName() + "." + flow.getEnd2().getName();
//        entry = String.format("%-" + Integer.toString(max_length) + "s", entry);
//        entry += "= " + flow.getEnd1().getOwner().getName() + "." + flow.getEnd1().getName();
//        entry += "" + NL;
//
//        connection_file.write(comment + entry);
//      }
//      connection_file.write("" + NL + NL);
//
//      // write selection parameter
//      for (IRPFlow flow: flows) {
//        String par_name = String.format("[%s.%s]", key.getName(), flow.getEnd2().getName());
//        String param = flow.getTag("SelectionOffset").getValue();
//        if (!flow.getTag("SelectFromEnd").getValue().equals("False")) {
//          param = "127";
//        }
//        par_file.write(par_name + ".Type=simI8_t" + NL);
//        par_file.write(par_name + ".Value=" + param + NL);
//        par_file.write(par_name + ".ArrayLength=1" + NL);
//      }
//
//    }
//
//    connection_file.flush();
//    connection_file.close();
//    file.close();
//    par_file.flush();
//    par_file.close();
//    file_par.close();
//  }

  private void CreateCorrespondingRational(List<IRPModelElement> selection) {
    boolean bContainsReq = false;
    IRPModelElement target = null;
    for (IRPModelElement elem : selection) {
      if (elem instanceof IRPRequirement) {
        bContainsReq = true;
      }
      else {
        if (target != null) {
          m_rhpApplication.writeToOutputWindow("Log", "Aborting operation! Multiple non requirement objects as target selected." + NL);
          return;
        } else {
          target = elem;
        }
      }
    }

    if (!bContainsReq || target == null)
      return;

    m_rhpApplication.writeToOutputWindow("Log", "Rationales will be added to: " + target.getName() + "  of type: " + target.toString() + NL);

    for (IRPModelElement elem : selection) {
      if (elem instanceof IRPRequirement) {
        IRPRequirement req = (IRPRequirement) elem;

        IRPComment rational = (IRPComment)target.addNewAggr("Comment", "Req_" + req.getName().replace(" - ", "_"));
        rational.addStereotype("rationale", "");
        rational.addStereotype("DOORS_ALGO", "");

        rational.addDependencyTo(req);

        rational.setDescription(req.getSpecification());

        rational.setTagValue(rational.getTag("_ObjectType"), "Requirement");
        rational.setTagValue(rational.getTag("_SafetyRelevant"), req.getTag("_SafetyRelevant").getValue());


        IRPType type = (IRPType)rational.getTag("_Project").getType();
        List<IRPEnumerationLiteral> types = type.getEnumerationLiterals().toList();
        List<String> type_vals = types.stream().map(x -> x.getName()).collect(Collectors.toList());

        List<IRPLiteralSpecification> vals = req.getTag("_Project").getValueSpecifications().toList();
        boolean bFirst = true;
        IRPTag newTag = null;
        for (IRPLiteralSpecification val: vals) {
          if (type_vals.contains(val.getValue())) {
            if (bFirst) {
              newTag = rational.setTagValue(rational.getTag("_Project"), val.getValue());
              bFirst = false;
            } else {
              newTag.addStringDefaultValue(val.getValue());
            }
          }
        }
      }
    }
  }

  private void AddApplicationProjectTags(IRPModelElement element) {
    if (element == null) {
      m_rhpApplication.writeToOutputWindow("", "No selected element" + NL);
      return;
    }

    List<IRPModelElement> list = element.getNestedElementsRecursive().toList();
    list.add(element);
    for (IRPModelElement elem: list) {
      try {
        IRPTag rpTag = elem.getTag("_Project");
        if (rpTag != null) {
          String val = rpTag.getValue();
          if (val.contains("MFC411") && !val.contains("MFC430HI17")) {
            rpTag.addStringDefaultValue("MFC430HI17");
          }
          if (val.contains("MFC431") && !val.contains("MFC431TA19")) {
            rpTag.addStringDefaultValue("MFC431TA19");
          }
          if (val.contains("MFC431") && !val.contains("EUNCAP18")) {
            rpTag.addStringDefaultValue("EUNCAP18");
          }
        }
      }
      catch (Exception ex) {
        m_rhpApplication.writeToOutputWindow("", "Failed to adapt: " + elem.getOwner().getName() + "." + elem.getName() + "  of type: " + elem.toString() + NL);
      }
    }
  }

  private void ImportMdbClusterNameForProvidePorts(IRPModelElement element) throws IOException, ParserConfigurationException, SAXException {
    if (element == null) {
      m_rhpApplication.writeToOutputWindow("", "No selected element" + NL);
      return;
    }

    // open mdb generic adapter config
    String path = ((IRPUnit)m_rhpApplication.activeProject()).getCurrentDirectory();
    path += "\\mdb";
    File inputFile = new File(path + "\\function_config_ga.xml");
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
    Document doc = dBuilder.parse(inputFile);
    m_rhpApplication.writeToOutputWindow("", "Root element :" + doc.getDocumentElement().getNodeName() + NL);

    NodeList nodeListComps = doc.getDocumentElement().getElementsByTagName("GaEntry");
    Map<String, Node> mapNodes = new HashMap();
    for (int i = 0; i < nodeListComps.getLength(); i++) {
      Node node = nodeListComps.item(i);
      mapNodes.put(((Element)node).getAttribute("component"), node);
    }

    // loop over comps and their provide ports and retrieve connected mdb cluster from generic adapter config
    List<IRPModelElement> blocks = element.getNestedElementsByMetaClass("Class", -1).toList();
    IRPModelElement stereoTask = m_rhpApplication.activeProject().findNestedElementRecursive("AlgoTask", "Stereotype");
    blocks = blocks.stream().filter(b -> b.getStereotypes().toList().contains(stereoTask)).collect(Collectors.toList());
    for (IRPModelElement elem: blocks) {
      Node comp = mapNodes.get(elem.getName().replaceAll("_", ""));
      if (comp != null) {
        NodeList ports = ((Element) comp).getElementsByTagName("ProPortEntry");
        for (int i = 0; i < ports.getLength(); i++) {
          Node port = ports.item(i);
          String name = ((Element) port).getAttribute("portName");
          String cluster = ((Element) port).getElementsByTagName("MdbClusterRef").item(0).getFirstChild().getNodeValue();

          IRPModelElement elemPort = elem.findNestedElement(name, "SysMLPort");
          if (elemPort != null) {
            elemPort.addStereotype("MdbClusterRef", "");
            elemPort.setTagValue(elemPort.getTag("ClusterName"), cluster);
          } else {
            m_rhpApplication.writeToOutputWindow("", "Failed to find port :" + elem.getName() + "." + name + NL);
          }
        }
      }
    }

    // check all provide ports with missing cluster ref and go through connected request ports to retrieve cluster info
    IRPModelElement stereoCluster = m_rhpApplication.activeProject().findNestedElementRecursive("MdbClusterRef", "Stereotype");
    List<IRPModelElement> sysports = element.getNestedElementsByMetaClass("SysMLPort", -1).toList();
    List<IRPModelElement> pros = sysports.stream().filter(x -> (((IRPSysMLPort)x).getPortDirection().equals("Out") || ((IRPSysMLPort)x).getPortDirection().equals("InOut"))).collect(Collectors.toList());
    pros = pros.stream().filter(x -> !x.getStereotypes().toList().contains(stereoCluster)).collect(Collectors.toList());

    for (IRPModelElement pro: pros) {
      List<IRPModelElement> connections = pro.getReferences().toList();
      connections = connections.stream().filter(x -> x instanceof IRPFlow).collect(Collectors.toList());
      for (IRPModelElement con: connections) {
        IRPFlow flow = (IRPFlow) con;
        IRPModelElement receiver = null;
        if (flow.getDirection().equals("toEnd2")) {
          receiver = flow.getEnd2();
        } else if (flow.getDirection().equals("toEnd1")) {
          receiver = flow.getEnd1();
        }

        Node comp = mapNodes.get(receiver.getOwner().getName().replaceAll("_", ""));
        if (comp == null) comp = mapNodes.get(receiver.getOwner().getName());
        if (comp != null) {
          NodeList ports = ((Element) comp).getElementsByTagName("ReqPortEntry");
          for (int i = 0; i < ports.getLength(); i++) {
            Node port = ports.item(i);
            String name = ((Element) port).getAttribute("portName");
            String cluster = ((Element) port).getElementsByTagName("MdbClusterRef").item(0).getFirstChild().getNodeValue();

            if (name.equals(receiver.getName())) {
              pro.addStereotype("MdbClusterRef", "");
              pro.setTagValue(pro.getTag("ClusterName"), cluster);
            }
          }

          // only look in first found connection
          break;
        }
      }
    }
  }


  private void ExportGenericAdapterSetup(IRPModelElement element) throws IOException, ParserConfigurationException, TransformerException {
    if (element == null) {
      m_rhpApplication.writeToOutputWindow("", "No selected element" + NL);
      return;
    }

    // open mdb generic adapter config
    String path = ((IRPUnit)m_rhpApplication.activeProject()).getCurrentDirectory();
    path += "\\mdb";
    new File(path).mkdir();
    File file = new File(path + "\\function_config_ga.xml");

    DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
    Document doc = docBuilder.newDocument();

    doc.setXmlVersion("1.0");

    Element rootElement = doc.createElement("GaConfig");
    rootElement.setAttribute("version", "1.0");
    doc.appendChild(rootElement);

    Element GaEntries = doc.createElement("GaEntries");
    rootElement.appendChild(GaEntries);

    List<IRPModelElement> blocks = element.getNestedElementsByMetaClass("Class", -1).toList();
    IRPModelElement stereoTask = m_rhpApplication.activeProject().findNestedElementRecursive("AlgoTask", "Stereotype");
    blocks = blocks.stream().filter(b -> b.getStereotypes().toList().contains(stereoTask)).collect(Collectors.toList());
    blocks = blocks.stream().filter(b -> b.getNestedElementsByMetaClass("SysMLPort", 0).getCount() > 0).collect(Collectors.toList());
    blocks = blocks.stream().filter(b -> !b.getName().equals("GS")).collect(Collectors.toList());

    for (IRPModelElement block: blocks) {
      Attr component = doc.createAttribute("component");
      component.setValue(block.getName());
      Attr enabled_true = doc.createAttribute("enabled");
      enabled_true.setValue("true");
      Element GaEntry = doc.createElement("GaEntry");
      GaEntry.setAttributeNode(component);
      GaEntry.setAttributeNode(enabled_true);
      GaEntries.appendChild(GaEntry);

      // add port list type name, ext header name and taks id for component
      Element ReqPortList = doc.createElement("ReqPort");
      Element ProPortList = doc.createElement("ProPort");
      Element Include = doc.createElement("Include");
      Element TaskId = doc.createElement("TaskId");

      String name_camel = "";
      String[] parts = block.getName().split("_");
      for (String part : parts) {
        part = part.toLowerCase();
        part = part.substring(0, 1).toUpperCase() + part.substring(1);
        name_camel += part;
      }
      String reqtype = "req" + name_camel + "PrtList_t";
      String protype = "pro" + name_camel + "PrtList_t";
      ReqPortList.appendChild(doc.createTextNode(reqtype));
      ProPortList.appendChild(doc.createTextNode(protype));
      Include.appendChild(doc.createTextNode(block.getName().toLowerCase() + "_ext.h"));
      TaskId.appendChild(doc.createTextNode("TASK_ID_" + block.getName()));

      GaEntry.appendChild(ReqPortList);
      GaEntry.appendChild(ProPortList);
      GaEntry.appendChild(Include);
      GaEntry.appendChild(TaskId);

      // add core mapping and asil level for component
      Element CoreMappings = doc.createElement("CoreMappings");
      Element CoreMapping = doc.createElement("CoreMapping");
      Element CoreId = doc.createElement("CoreId");
      Element QualityLevel = doc.createElement("QualityLevel");

      GaEntry.appendChild(CoreMappings);
      CoreMappings.appendChild(CoreMapping);
      Attr attr = doc.createAttribute("enabled");
      attr.setValue("true");
      CoreMapping.setAttributeNode(attr);
      CoreMapping.appendChild(CoreId);
      CoreMapping.appendChild(QualityLevel);
      List<IRPModelElement> rels = block.getReferences().toList();
      IRPModelElement stereoAlloc = m_rhpApplication.activeProject().findNestedElementRecursive("allocate", "Stereotype");
      rels = rels.stream().filter(b -> (b instanceof IRPDependency) && (b.getStereotypes().toList().contains(stereoAlloc))).collect(Collectors.toList());
      if (rels.size() != 1) {
        m_rhpApplication.writeToOutputWindow("", "Could not determine core allocation for: " + block.getName() + NL);
        CoreId.appendChild(doc.createTextNode("TBD"));
      } else {
        CoreId.appendChild(doc.createTextNode("CORE_" + rels.get(0).getOwner().getName().replaceAll("its", "")));
      }
      QualityLevel.appendChild(doc.createTextNode(block.getTag("_SafetyRelevant").getValue().replace(' ', '_')));


      List<IRPModelElement> ports = block.getNestedElementsByMetaClass("SysMLPort", 0).toList();
      List<IRPModelElement> reqs = ports.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("In")).collect(Collectors.toList());
      List<IRPModelElement> pros = ports.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("Out")).collect(Collectors.toList());
      List<IRPModelElement> inouts = ports.stream().filter(x -> ((IRPSysMLPort)x).getPortDirection().equals("InOut")).collect(Collectors.toList());
      for (IRPModelElement p : inouts) {
        reqs.add(p);
        pros.add(p);
      }

      Element ReqPorts = doc.createElement("ReqPorts");
      Element ProPorts = doc.createElement("ProPorts");

      GaEntry.appendChild(ReqPorts);
      GaEntry.appendChild(ProPorts);

      for (IRPModelElement req: reqs) {
        Element ReqPortEntry = doc.createElement("ReqPortEntry");
        ReqPorts.appendChild(ReqPortEntry);
        Attr portName = doc.createAttribute("portName");
        portName.setValue(req.getName());
        ReqPortEntry.setAttributeNode(portName);

        Element MdbClusterRef = doc.createElement("MdbClusterRef");
        Element Instance = doc.createElement("Instance");
        Element CrcProtection = doc.createElement("CrcProtection");
        ReqPortEntry.appendChild(MdbClusterRef);
        ReqPortEntry.appendChild(Instance);
        ReqPortEntry.appendChild(CrcProtection);

        List<IRPModelElement> connections = req.getReferences().toList();
        connections = connections.stream().filter(x -> x instanceof IRPFlow).collect(Collectors.toList());
        // TODO: fix in case of bi-directional ports
        if (connections.size() == 1) {
          IRPFlow flow = (IRPFlow) connections.get(0);
          IRPModelElement provider = null;
          if (flow.getDirection().equals("toEnd2")) {
            provider = flow.getEnd1();
          } else if (flow.getDirection().equals("toEnd1")) {
            provider = flow.getEnd2();
          }

          MdbClusterRef.appendChild(doc.createTextNode(provider.getTag("ClusterName").getValue()));
          if (flow.getTag("SelectFromEnd").getValue().equals("True")) {
            Instance.appendChild(doc.createTextNode("L"));
          } else {
            Instance.appendChild(doc.createTextNode(flow.getTag("SelectionOffset").getValue()));
          }
        } else {
          MdbClusterRef.appendChild(doc.createTextNode("MDB_e_NULL"));
          Instance.appendChild(doc.createTextNode("0"));
        }

        // TODO: decide depending on ASIL level
        CrcProtection.appendChild(doc.createTextNode("true"));
      }

      for (IRPModelElement pro: pros) {
        Element ProPortEntry = doc.createElement("ProPortEntry");
        ProPorts.appendChild(ProPortEntry);
        Attr portName = doc.createAttribute("portName");
        portName.setValue(pro.getName());
        ProPortEntry.setAttributeNode(portName);

        Element MdbClusterRef = doc.createElement("MdbClusterRef");
        ProPortEntry.appendChild(MdbClusterRef);
        MdbClusterRef.appendChild(doc.createTextNode(pro.getTag("ClusterName").getValue()));
      }

    }


    Transformer transformer = TransformerFactory.newInstance().newTransformer();
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    transformer.setOutputProperty(OutputKeys.METHOD, "xml");
    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(file);
    transformer.transform(source, result);
  }

  private void CollectFlowsAndPopulateStructureDiagram(IRPModelElement element) {
    List<IRPModelElement> flows = element.getNestedElementsByMetaClass("Flow", -1).toList();
    // filter for correct stereotype
    IRPModelElement stereotype = m_rhpApplication.activeProject().findNestedElementRecursive("MdbSelection", "Stereotype");
    flows = flows.stream().filter(b -> b.getStereotypes().toList().contains(stereotype)).collect(Collectors.toList());

    List<IRPModelElement> population = new ArrayList<>();

    for (IRPModelElement el: flows) {
      IRPFlow flow = (IRPFlow) el;
      IRPModelElement proport = null;
      IRPModelElement reqport = null;
      if (flow.getDirection().equals("toEnd2")) {
        proport = flow.getEnd1();
        reqport = flow.getEnd2();
      } else if (flow.getDirection().equals("toEnd1")) {
        proport = flow.getEnd2();
        reqport = flow.getEnd1();
      }

      IRPModelElement top_elem = GetLowestCommonElem(element, proport.getOwner(), reqport.getOwner());
      RecurseUpAndCreateFlows(top_elem, proport.getOwner(), reqport.getOwner(), proport, population);
    }

    List<IRPModelElement> blocks = element.getNestedElementsByMetaClass("Class", -1).toList();
    // filter for blocks having ports or sub blocks
    blocks = blocks.stream().filter(b -> b.getNestedElementsByMetaClass("SysMLPort", 0).getCount() + b.getNestedElementsByMetaClass("Class", 0).getCount() > 0).collect(Collectors.toList());

    IRPModelElement owner = element.getOwner();
    IRPStructureDiagram rpDiagram = (IRPStructureDiagram)owner.findNestedElement(owner.getName() + "_InternalStructure", "StructureDiagram");
    if (rpDiagram != null) rpDiagram.deleteFromProject();
    rpDiagram = (IRPStructureDiagram)owner.addNewAggr("StructureDiagram", owner.getName() + "_InternalStructure");
    rpDiagram.addStereotype("Internal Block Diagram", "");

    IRPCollection rpCollection = m_rhpApplication.createNewCollection();
    blocks.forEach(x -> rpCollection.addItem(x));
    //population.forEach(x -> rpCollection.addItem(x)); // currently added in AlignDiagram()

    IRPCollection relTypes = m_rhpApplication.createNewCollection();
    relTypes.setSize(1);
    relTypes.setString(1, "InformationFlow");
    rpDiagram.populateDiagram(rpCollection, relTypes, "fromto");

    AlignDiagram(rpDiagram, blocks, population);

    rpDiagram.openDiagram();

  }

  private void RecurseUpAndCreateFlows(IRPModelElement top_elem, IRPModelElement start, IRPModelElement end, IRPModelElement port, List<IRPModelElement> population) {
    IRPModelElement new_start = start;
    IRPModelElement new_end = end;
    if (start.getOwner().getGUID().equals(end.getOwner().getGUID())) {
      CheckCreateFlow(start.getOwner(), start, end, port, population);
    } else {
      if (!start.getOwner().getGUID().equals(top_elem.getGUID())) {
        CheckCreateFlow(start.getOwner(), start, start.getOwner(), port, population);
        new_start = start.getOwner();
      }
      if (!end.getOwner().getGUID().equals(top_elem.getGUID())) {
        CheckCreateFlow(end.getOwner(), end.getOwner(), end, port, population);
        new_end = end.getOwner();
      }

      RecurseUpAndCreateFlows(top_elem, new_start, new_end, port, population);
    }
  }

  private IRPModelElement GetLowestCommonElem(IRPModelElement top_elem, IRPModelElement start, IRPModelElement end) {
    List<String> from_start = new ArrayList<>();

    IRPModelElement tmp = start;
    do {
      tmp = tmp.getOwner();
      from_start.add(tmp.getGUID());
    } while (!tmp.getGUID().equals(top_elem.getGUID()));

    tmp = end;
    do {
      tmp = tmp.getOwner();
      if (from_start.contains(tmp.getGUID())) break;
    } while (!tmp.getGUID().equals(top_elem.getGUID()));

    return tmp;
  }

  private void CheckCreateFlow(IRPModelElement owner, IRPModelElement start, IRPModelElement end, IRPModelElement port, List<IRPModelElement> population) {
    String name = start.getName() + "_to_" + end.getName();
    IRPFlow superflow = (IRPFlow) owner.findNestedElement(name, "Flow");
    if (superflow != null && !population.contains(superflow)) {
      superflow.deleteFromProject();
      superflow = null;
    }
    if (superflow == null) {
      superflow = (IRPFlow) owner.addNewAggr("Flow", name);
      superflow.setDirection("toEnd2");

      if (start.findNestedElement("Out", "Port") == null) {
        start.addNewAggr("Port", "In").addStereotype("proxyPort", "");
        start.addNewAggr("Port", "Out").addStereotype("proxyPort", "");
      }
      if (end.findNestedElement("Out", "Port") == null) {
        end.addNewAggr("Port", "In").addStereotype("proxyPort", "");
        end.addNewAggr("Port", "Out").addStereotype("proxyPort", "");
      }

      String src, trg;
      if (end.getOwner().getGUID().equals(start.getGUID())) src = "In"; else src = "Out";
      if (start.getOwner().getGUID().equals(end.getGUID())) trg = "Out"; else trg = "In";
      superflow.setEnd1(start.findNestedElement(src, "Port"));
      superflow.setEnd2(end.findNestedElement(trg, "Port"));
      population.add(superflow);
    }

    try {
      superflow.addConveyed(port);
    } catch (Exception exc)
    {}
  }

  private void AlignDiagram(IRPStructureDiagram rpDiagram, List<IRPModelElement> blocks, List<IRPModelElement> flows) {
    for (IRPModelElement block: blocks) {
      IRPGraphNode node = (IRPGraphNode) rpDiagram.getCorrespondingGraphicElements(block).getItem(1);
      node.setGraphicalProperty("ShowStereotypeLabel", "False");

      Integer[] pos =  Arrays.asList(node.getGraphicalProperty("Position").getValue().split(",")).stream().map(x -> Integer.parseInt(x)).toArray(Integer[]::new);
      int width = Integer.parseInt(node.getGraphicalProperty("Width").getValue());
      int height = Integer.parseInt(node.getGraphicalProperty("Height").getValue());
      int size = 10;

      try {
        IRPGraphNode in  = rpDiagram.addNewNodeForElement(block.findNestedElement("In", "Port"), pos[0], pos[1] + height / 2, size, size);
        IRPGraphNode out = rpDiagram.addNewNodeForElement(block.findNestedElement("Out", "Port"), pos[0] + width, pos[1] + height / 2, size, size);
        in.setGraphicalProperty("ShowName", "None");
        out.setGraphicalProperty("ShowName", "None");
      } catch (RhapsodyRuntimeException exc)
      {}
    }

    for (IRPModelElement flow: flows) {
      IRPGraphNode source = (IRPGraphNode) rpDiagram.getCorrespondingGraphicElements(((IRPFlow)flow).getEnd1()).getItem(1);
      IRPGraphNode target = (IRPGraphNode) rpDiagram.getCorrespondingGraphicElements(((IRPFlow)flow).getEnd2()).getItem(1);

      Integer[] src_pos =  Arrays.asList(source.getGraphicalProperty("Position").getValue().split(",")).stream().map(x -> Integer.parseInt(x)).toArray(Integer[]::new);
      Integer[] trg_pos =  Arrays.asList(target.getGraphicalProperty("Position").getValue().split(",")).stream().map(x -> Integer.parseInt(x)).toArray(Integer[]::new);
      int src_offset = 1;
      int trg_offset = 1;

      int src_width = Integer.parseInt(source.getGraphicalProperty("Width").getValue());
      int src_height = Integer.parseInt(source.getGraphicalProperty("Height").getValue());
      int trg_width = Integer.parseInt(target.getGraphicalProperty("Width").getValue());
      int trg_height = Integer.parseInt(target.getGraphicalProperty("Height").getValue());

      int src_con_x, src_con_y, trg_con_x, trg_con_y;
      if (target.getGraphicalParent().equals(source)) {
        src_con_x = src_pos[0] + src_offset; src_con_y = src_pos[1] + src_height/2;
      } else {
        src_con_x = src_pos[0] + src_width - src_offset; src_con_y = src_pos[1] + src_height/2;
      }
      if (source.getGraphicalParent().equals(target)) {
        trg_con_x = trg_pos[0] + trg_width - trg_offset; trg_con_y = trg_pos[1] + trg_height/2;
      } else {
        trg_con_x = trg_pos[0] + trg_offset; trg_con_y = trg_pos[1] + trg_height/2;
      }

      IRPGraphEdge edge = rpDiagram.addNewEdgeForElement(flow, source, src_con_x, src_con_y, target, trg_con_x, trg_con_y);
      //edge.setGraphicalProperty("ShowName", "none");

      //Map<String, String> props = new HashMap<>();
      //edge.getAllGraphicalProperties().toList().forEach(x -> props.put(((IRPGraphicalProperty)x).getKey(), ((IRPGraphicalProperty)x).getValue()));
      //int i = 0;

      /**********
      IRPGraphEdge edge = (IRPGraphEdge) rpDiagram.getCorrespondingGraphicElements(flow).getItem(1);
      IRPGraphNode source = (IRPGraphNode) edge.getSource();
      IRPGraphNode target = (IRPGraphNode) edge.getTarget();

      edge.setGraphicalProperty("ShowStereotypeLabel", "False");

      Integer[] src_pos =  Arrays.asList(source.getGraphicalProperty("Position").getValue().split(",")).stream().map(x -> Integer.parseInt(x)).toArray(Integer[]::new);
      Integer[] trg_pos =  Arrays.asList(target.getGraphicalProperty("Position").getValue().split(",")).stream().map(x -> Integer.parseInt(x)).toArray(Integer[]::new);
      int src_offset = Integer.parseInt(source.getGraphicalProperty("LineWidth").getValue()) * 2;
      int trg_offset = Integer.parseInt(target.getGraphicalProperty("LineWidth").getValue()) * 2;


      int src_width = Integer.parseInt(source.getGraphicalProperty("Width").getValue());
      int src_height = Integer.parseInt(source.getGraphicalProperty("Height").getValue());
      int trg_width = Integer.parseInt(target.getGraphicalProperty("Width").getValue());
      int trg_height = Integer.parseInt(target.getGraphicalProperty("Height").getValue());

      if (target.getGraphicalParent().equals(source)) {
        edge.setGraphicalProperty("SourcePosition", String.format("%d, %d", src_pos[0] + src_offset            , src_pos[1] + src_height/2));
      } else {
        edge.setGraphicalProperty("SourcePosition", String.format("%d, %d", src_pos[0] + src_width - src_offset, src_pos[1] + src_height/2));
      }
      if (source.getGraphicalParent().equals(target)) {
        edge.setGraphicalProperty("TargetPosition", String.format("%d, %d", trg_pos[0] + trg_width - trg_offset, trg_pos[1] + trg_height/2));
      } else {
        edge.setGraphicalProperty("TargetPosition", String.format("%d, %d", trg_pos[0] + trg_offset            , trg_pos[1] + trg_height/2));
      }
      */
    }
  }
  
 


  private void UpdateRteTypeSizes(IRPModelElement element) throws IOException, InterruptedException, ParserConfigurationException, SAXException {
    // select engineering path
    String path_eng = "D:\\DiscussionFiles\\Ralf\\MFC431_Sandbox_5_05_201711"; //"D:\\Sandboxes\\MFC431_BASE\\06_Algorithm\\04_Engineering"
    // get base path
    String path = ((IRPUnit)m_rhpApplication.activeProject()).getCurrentDirectory();
    path += "\\pdo_tmp";
    new File(path).mkdir();

    File file = new File(path + "\\dummy.c");
    file.createNewFile();
    FileWriter writer = new FileWriter(file);
    writer.write("#include \"algo_type.h\"" + NL);
    writer.close();

    ProcessBuilder builder = new ProcessBuilder();
    builder.redirectErrorStream(true);
    builder.command(path_eng + "\\PDOTool_Sandbox_5_05_2017\\pdo_scan.exe"
            , "-I" + path_eng + "\\RTE_VH\\algo"
            , "-I" + path_eng + "\\RTE_VH\\include"
            , "-I" + path_eng + "\\GLOB_VH" //\\01_Source_Code\\common\\glob_vh
            , "-p"
            , "dummy_prep_out.i"
            , "-o"
            , "dummy.dat"
            , file.getPath());
    builder.directory(new File(path));

    Process process = builder.start();
    int exitcode = process.waitFor();
    // TODO: check outputs of pdo process

    String stderr = new BufferedReader(new InputStreamReader(process.getErrorStream())).lines().parallel().collect(Collectors.joining("" + NL));
    String stdout = new BufferedReader(new InputStreamReader(process.getInputStream())).lines().parallel().collect(Collectors.joining("" + NL));

    File inputFile = new File(path + "\\dummy.dat");
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
    Document doc = dBuilder.parse(inputFile);

    NodeList nodeListTypes = doc.getDocumentElement().getChildNodes();
    Map<String, String> mapSizes = new HashMap();
    for (int i = 0; i < nodeListTypes.getLength(); i++) {
      Node node = nodeListTypes.item(i);
      if (node.getNodeName().equals("NLE") && ((Element)node).getAttribute("sc").equals("typedef")) {
        NodeList childs = node.getChildNodes();
        for (int j = 0; j < childs.getLength(); j++) {
          Node child = childs.item(j);
          if (child.getNodeName().equals("TLE")) {
            String size = ((Element)child).getAttribute("size");
            mapSizes.put(((Element)node).getAttribute("name"), size);
          }
        }
      }
    } 
    
		Iterator<Entry<String, String>> iterator = mapSizes.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<?, ?> entry = (Entry<?, ?>) iterator.next();
//			System.err.println("Entry key is:: "+entry.getKey()+" Entry value is:: "+entry.getValue());
		}

		List<IRPModelElement> types = element.getNestedElementsByMetaClass("Type", -1).toList();
		for (IRPModelElement type : types) {
			if (mapSizes.get(type.getName()) != null) {
				type.addStereotype("MFC431_Type", "");
				IRPTag tag = type.getTag("MFC431_Size");
				if (!tag.getValue().equals(mapSizes.get(type.getName()))) {
					type.setTagValue(tag, mapSizes.get(type.getName()));
				}
			}
		}
	}

}

