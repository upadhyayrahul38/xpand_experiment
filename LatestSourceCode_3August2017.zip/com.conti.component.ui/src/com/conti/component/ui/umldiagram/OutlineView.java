package com.conti.component.ui.umldiagram;

import java.util.Iterator;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.part.ViewPart;

import com.conti.component.ui.Activator;

import architecturetool.Port;
import architecturetool.Runnable;
import architecturetool.impl.ComponentImpl;

public class OutlineView extends ViewPart implements ISelectionListener {

	private ComponentImpl component;
	private org.eclipse.draw2d.Label compClassLabel;
	private UMLClassFigure compClassFigure;
	private Image image;
	private Figure contents;

	@Override
	public void createPartControl(Composite parent) {
		Canvas canvas = new Canvas(parent, SWT.NONE);

		// Lightweight System and XY layout
		LightweightSystem lws = new LightweightSystem(canvas);

		contents = new Figure();

		image = Activator.imageDescriptorFromPlugin(Activator.PLUGIN_ID, "icons/comp.gif").createImage();
		Font classFont = new Font(null, "Arial", 12, SWT.BOLD);

		String name = component == null ? "" : component.getName();
		compClassLabel = new org.eclipse.draw2d.Label(name, image);
		compClassLabel.setFont(classFont);

		org.eclipse.draw2d.Label classLabel2 = new org.eclipse.draw2d.Label("Column", image);
		classLabel2.setFont(classFont);

		compClassFigure = new UMLClassFigure(compClassLabel);
		contents.add(compClassFigure);

		lws.setContents(contents);		
		getViewSite().getPage().addSelectionListener(this);

	}

	@Override
	public void dispose() {
		getSite().getPage().removeSelectionListener(this);
		
	}

	@Override
	public void setFocus() {

	}

	public OutlineView() {
		super();
	}

	@Override
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		XYLayout contentsLayout = new XYLayout();
		contents.setLayoutManager(contentsLayout);
		

		if (selection instanceof StructuredSelection ) { ///&& part.getTitle().equals("Model Explorer")
			Object firstElement = ((StructuredSelection) selection).getFirstElement();
			if (firstElement instanceof ComponentImpl) {
				contents.setVisible(true);

				component = (ComponentImpl) firstElement;
				if (component != null) {
					if (!(component.getPorts() != null && component.getPorts().getPort().isEmpty())
							|| !(component.getRunnables() != null
									&& component.getRunnables().getRunnable().isEmpty())) {
						contentsLayout.setConstraint(compClassFigure, new Rectangle(100, 100, -1, -1));
					} else {
						contentsLayout.setConstraint(compClassFigure, new Rectangle(100, 100, -1, 50));
					}
				}
				compClassLabel.setText(component.getName());
				compClassFigure.getAttributesCompartment().removeAll();
				compClassFigure.getMethodsCompartment().removeAll();
				compClassFigure.setVisible(true);
				if (component.getRunnables() != null) {
					EList<Runnable> itsRunnable = component.getRunnables().getRunnable();
					image = Activator.imageDescriptorFromPlugin(Activator.PLUGIN_ID, "icons/Operation.gif")
							.createImage();
					for (Iterator<Runnable> iterator = itsRunnable.iterator(); iterator.hasNext();) {
						Runnable runnable = (Runnable) iterator.next();
						org.eclipse.draw2d.Label runnableLabel = new org.eclipse.draw2d.Label(
								"Runnable-> " + runnable.getName(), image);
						compClassFigure.getMethodsCompartment().add(runnableLabel);
					}
				}
				if (component.getPorts() != null) {
					EList<Port> portList = component.getPorts().getPort();
					image = Activator.imageDescriptorFromPlugin(Activator.PLUGIN_ID, "icons/standardPort.gif")
							.createImage();
					for (Iterator<Port> iterator = portList.iterator(); iterator.hasNext();) {
						Port port = (Port) iterator.next();
						org.eclipse.draw2d.Label portLabel = new org.eclipse.draw2d.Label(
								"Port-> " + port.getName() + ":" + port.getPortDirection(), image);
						compClassFigure.getAttributesCompartment().add(portLabel);
					}
				}

				if (compClassLabel != null) {
					compClassLabel.setText(component.getName());
				}

			} else {
				contents.setVisible(false);
				compClassLabel.setText("");
				compClassFigure.getAttributesCompartment().removeAll();
				compClassFigure.getMethodsCompartment().removeAll();
			}
		}

	}

}
