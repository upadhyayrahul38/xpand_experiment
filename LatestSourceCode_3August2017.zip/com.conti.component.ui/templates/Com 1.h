#ifndef COM 1_MAIN_H_INCLUDED
#define COM 1_MAIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif
/*********************/
/* request port list */
/*********************/  
typedef struct {
    	const Port 1 *p_Port 1
	
    }Sample Runnable_t_reqportPtrList;
 
void Sample Runnable (Sample Runnable_t_reqportPtrList const*const reqPort, );

	
	#ifdef __cplusplus
}
#endif
#endif /*DAP_EXT_H_INCLUDED*/