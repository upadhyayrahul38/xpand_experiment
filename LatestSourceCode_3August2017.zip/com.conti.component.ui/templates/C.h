#ifndef C_MAIN_H_INCLUDED
#define C_MAIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif
/*********************/
/* request port list */
/*********************/  
typedef struct {
    	
if(P> 0)
 T *p_T;
#endif
	
    }R_t_reqportPtrList;
/*********************/
/* provide port list */
/*********************/
typedef struct {
    	
	
    }R_t_proportPtrList;
void R (R_t_reqportPtrList const*const reqPort,GS_t_SimInitDAP *const p_SimInit, GS_t_NonSimInitDAP *const p_NonSimInit, R_t_proportPtrList const*const proPort);

	
	#ifdef __cplusplus
}
#endif
#endif /*DAP_EXT_H_INCLUDED*/
