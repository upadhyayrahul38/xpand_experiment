#ifndef VDY_MAIN_H_INCLUDED
#define VDY_MAIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif
/*********************/
/* request port list */
/*********************/  
typedef struct {
    	const Student *p_Student
	
    }Execute_t_reqportPtrList;
 
void Execute (Execute_t_reqportPtrList const*const reqPort, );

	
	#ifdef __cplusplus
}
#endif
#endif /*DAP_EXT_H_INCLUDED*/