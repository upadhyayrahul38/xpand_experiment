package com.conti.component.application;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;

import architecturetool.ArchitecturetoolPackage;

/**
 * This class controls all aspects of the application's execution
 */
public class Application implements IApplication {

	public static Logger logger = Logger.getLogger(Application.class.getName());

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.equinox.app.IApplication#start(org.eclipse.equinox.app.
	 * IApplicationContext) To iterate appArgs use final.
	 */
	public Object start(IApplicationContext context) throws Exception {
		String userDirectory = System.getProperty("user.dir");
		final Map<?, ?> arguments = context.getArguments();
		final String[] appArgs = (String[]) arguments.get("application.args");
		if (appArgs.length > 0) {
			String userDir = System.getProperty("user.dir");
			Path basePath = FileSystems.getDefault().getPath(userDir);
			Path resolvedPath = null;
			Path outputPath = null;
			boolean artifactsGenerated = false;
			if (appArgs[0].equalsIgnoreCase("-Header")) {
				resolvedPath = basePath.resolve(appArgs[1]);
				Path absolutePath = resolvedPath.normalize();
				Path fileName = absolutePath.getFileName();
				int indexOf = fileName.toString().indexOf(".");
				String extension = fileName.toString().substring(indexOf + 1, fileName.toString().length());
				outputPath = FileSystems.getDefault().getPath(appArgs[2]);
			} else if (appArgs[0].equalsIgnoreCase("-EcuExtract")) {
				resolvedPath = basePath.resolve(appArgs[1]);
				Path absolutePath = resolvedPath.normalize();
				Path fileName = absolutePath.getFileName();
				int indexOf = fileName.toString().indexOf(".");
				String extension = fileName.toString().substring(indexOf + 1, fileName.toString().length());
				outputPath = FileSystems.getDefault().getPath(appArgs[2]);
			} else if (appArgs[0].equalsIgnoreCase("-rte")) {
				resolvedPath = basePath.resolve(appArgs[1]);
				Path absolutePath = resolvedPath.normalize();
				Path fileName = absolutePath.getFileName();
				int indexOf = fileName.toString().indexOf(".");
				String extension = fileName.toString().substring(indexOf + 1, fileName.toString().length());
				outputPath = FileSystems.getDefault().getPath(appArgs[2]);
			} else if (appArgs[0].equalsIgnoreCase("-sil")) {
				resolvedPath = basePath.resolve(appArgs[1]);
				Path absolutePath = resolvedPath.normalize();
				Path fileName = absolutePath.getFileName();
				int indexOf = fileName.toString().indexOf(".");
				String extension = fileName.toString().substring(indexOf + 1, fileName.toString().length());
				outputPath = FileSystems.getDefault().getPath(appArgs[2]);
			} else if (appArgs[0].equalsIgnoreCase("-par")) {
				resolvedPath = basePath.resolve(appArgs[1]);
				Path absolutePath = resolvedPath.normalize();
				Path fileName = absolutePath.getFileName();
				int indexOf = fileName.toString().indexOf(".");
				String extension = fileName.toString().substring(indexOf + 1, fileName.toString().length());
				outputPath = FileSystems.getDefault().getPath(appArgs[2]);
			}
			return IApplication.EXIT_OK;
		}
		Display display = PlatformUI.createDisplay();
		try {
			int returnCode = PlatformUI.createAndRunWorkbench(display, new ApplicationWorkbenchAdvisor());
			if (returnCode == PlatformUI.RETURN_RESTART)
				return IApplication.EXIT_RESTART;
			else
				return IApplication.EXIT_OK;
		} finally {
			display.dispose();
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.equinox.app.IApplication#stop()
	 */
	public void stop() {
		if (!PlatformUI.isWorkbenchRunning())
			return;
		final IWorkbench workbench = PlatformUI.getWorkbench();
		final Display display = workbench.getDisplay();
		display.syncExec(new Runnable() {
			public void run() {
				if (!display.isDisposed())
					workbench.close();
			}
		});
	}
}
