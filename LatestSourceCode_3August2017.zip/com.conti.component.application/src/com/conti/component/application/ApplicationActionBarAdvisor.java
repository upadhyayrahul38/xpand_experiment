package com.conti.component.application;

import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.ToolBarContributionItem;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.actions.ContributionItemFactory;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

public class ApplicationActionBarAdvisor extends ActionBarAdvisor {

	IWorkbenchAction aboutAction = null;
	IWorkbenchAction exitAction = null;
	IWorkbenchAction saveAction = null;
	private IContributionItem create;

	public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
	}

	protected void makeActions(IWorkbenchWindow window) {
		aboutAction = ActionFactory.ABOUT.create(window);
		register(aboutAction);
		
		exitAction = ActionFactory.QUIT.create(window);
		register(exitAction);
		
		saveAction = ActionFactory.SAVE.create(window);
		register(saveAction);
		
		create = ContributionItemFactory.VIEWS_SHORTLIST.create(window);
		
	}

	protected void fillMenuBar(IMenuManager menuBar) {
		MenuManager fileMenu = new MenuManager(" &File", IWorkbenchActionConstants.FILE_START);
		menuBar.add(fileMenu);
		fileMenu.add(exitAction);
		fileMenu.add(saveAction);

		MenuManager helpMenu = new MenuManager(" &Help", IWorkbenchActionConstants.M_HELP);
		menuBar.add(helpMenu);
		helpMenu.add(aboutAction);
		
		MenuManager otherMenu = new MenuManager(" &Window", IWorkbenchActionConstants.SHOW_EXT);
		menuBar.add(otherMenu);
		otherMenu.add(create);
		

	}
	
	@Override
	protected void fillCoolBar(ICoolBarManager coolBar) {
		// TODO Auto-generated method stub
		super.fillCoolBar(coolBar);
		IToolBarManager toolBarMgr = new ToolBarManager();
		coolBar.add(new ToolBarContributionItem(toolBarMgr));
		toolBarMgr.add(saveAction);
	}

}
