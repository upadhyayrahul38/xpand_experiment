package com.conti.component.application;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IActionDelegate;

import com.conti.component.ui.popup.GenerateARXMLAction;
import com.conti.component.ui.popup.GenerateHeaderfileAction;
import com.conti.component.ui.popup.GenerateRteHeaders;
import com.conti.component.ui.popup.GenerateSILArtifactsPar;
import com.conti.component.ui.popup.GenerateSimconFile;

import architecturetool.ArchitecturetoolFactory;
import architecturetool.ArchitecturetoolPackage;
import architecturetool.Component;
import architecturetool.MCC;
import architecturetool.NoNameElement;
import architecturetool.Root;

public class ConsoleUtil {

	public static void main(String[] args) {
		String extension = "xmi";
		String inputPath = "C:\\Users\\uid32315\\Desktop\\Documents_Michael_06_04_2017\\mainstream.xmi";
		String outputPath = "C:\\Users\\uid32315\\Desktop\\TestBuild\\GeneratedArtifacts\\PAR";
		String artifactType = "rte";
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(extension,
				new XMIResourceFactoryImpl());
		Resource resource = resourceSet.getResource(URI.createFileURI(inputPath), true);
		EObject eObject = resource.getContents().get(0);
		boolean runConsole = false;
		if (eObject != null) {
			if (eObject instanceof Root) {
				Root root = ((Root) eObject);
				if (artifactType.equals("rte")) {
					EList<NoNameElement> noNameElement = root.getNonameelement();
					for (Iterator<NoNameElement> iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						new GenerateRteHeaders(noNameElement2, outputPath,null).run();
					}
				}
				
				if (artifactType.equals("sil")) {
					EList<NoNameElement> noNameElement = root.getNonameelement();
					for (Iterator<NoNameElement> iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						new GenerateSimconFile(noNameElement2, outputPath,null).run();
					}
				}
				
				if (artifactType.equals("par")) {
					EList<NoNameElement> noNameElement = root.getNonameelement();
					for (Iterator<NoNameElement> iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						new GenerateSILArtifactsPar(noNameElement2, outputPath,null).run();
					}
				}
				
				
				// NoNameElement noNameElement = (NoNameElement)
				// mcc.eContainer();
				// EList<Component> components = mcc.getComponents();
				// Component comp_0 = components.get(0);
				// new GenerateRteHeaders(noNameElement, outputPath).run(null);
				//
				// for (Iterator<Component> iterator = components.iterator();
				// iterator.hasNext();) {
				// Component component = (Component) iterator.next();
				// if (artifactType.equalsIgnoreCase("header")) {
				// GenerateHeaderfileAction genHeaderFileAction = new
				// GenerateHeaderfileAction(component,
				// outputPath);
				// runConsole = genHeaderFileAction.runConsole();
				// }
				// if (artifactType.equalsIgnoreCase("ecuextract")) {
				// GenerateARXMLAction genArxmlAction = new
				// GenerateARXMLAction(component, outputPath);
				// genArxmlAction.run(null);
				// runConsole = genArxmlAction.isArxmlGenerated();
				// }
				// }
			}
			if(eObject instanceof MCC) {
				MCC mcc = ((MCC) eObject);
				if (mcc.eContainer() == null) {
					NoNameElement noNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
					noNameElement.getMcc().add(mcc);
				}
				if (artifactType.equalsIgnoreCase("rte")) {
					NoNameElement noNameElement = (NoNameElement) mcc.eContainer();
					GenerateRteHeaders genRteHeaders = new GenerateRteHeaders(noNameElement, outputPath,null);
					genRteHeaders.run();
					runConsole = genRteHeaders.isRteGenerated();
				}
				if (artifactType.equalsIgnoreCase("par")) {
					NoNameElement noNameElement = (NoNameElement) mcc.eContainer();
					GenerateSILArtifactsPar genSilFile = new GenerateSILArtifactsPar(noNameElement, outputPath,null);
					genSilFile.run();
					runConsole = genSilFile.isGenerated();
				}
			}
		}
		// return runConsole ? true : false;
	}

	public boolean generateArtifacts(String extension, String inputPath, String outputPath, String artifactType) {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getPackageRegistry().put(ArchitecturetoolPackage.eNS_URI, ArchitecturetoolPackage.eINSTANCE);
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(extension,
				new XMIResourceFactoryImpl());
		Resource resource = resourceSet.getResource(URI.createFileURI(inputPath), true);
		EObject eObject = resource.getContents().get(0);
		boolean runConsole = false;
		if (eObject != null) {
			if (eObject instanceof Root) {
				Root root = ((Root) eObject);
				EList<NoNameElement> noNameElement = root.getNonameelement();
				if (artifactType.equalsIgnoreCase("rte")) {
					for (Iterator iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						GenerateRteHeaders genRteHeaders = new GenerateRteHeaders(noNameElement2, outputPath,null);
						genRteHeaders.run();
						runConsole = genRteHeaders.isRteGenerated();
					}
				}
				if (artifactType.equalsIgnoreCase("sil")) {
					for (Iterator iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						GenerateSimconFile genSimconFile = new GenerateSimconFile(noNameElement2, outputPath,null);
						genSimconFile.run();
						runConsole = genSimconFile.isGenerated();
					}
				}
				if (artifactType.equalsIgnoreCase("par")) {
					for (Iterator iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						GenerateSILArtifactsPar genSILParArtifacts = new GenerateSILArtifactsPar(noNameElement2, outputPath,null);
						genSILParArtifacts.run();
						runConsole = genSILParArtifacts.isGenerated();
					}
				}
				if (artifactType.equalsIgnoreCase("header")) {
					for (Iterator iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						EList<MCC> mcc = noNameElement2.getMcc();
						for (Iterator iterator2 = mcc.iterator(); iterator2.hasNext();) {
							MCC mcc2 = (MCC) iterator2.next();
							EList<Component> components = mcc2.getComponents();
							for (Iterator iterator3 = components.iterator(); iterator3.hasNext();) {
								Component component = (Component) iterator3.next();
								GenerateHeaderfileAction genHeaderFileAction = new GenerateHeaderfileAction(component,
										outputPath);
								runConsole = genHeaderFileAction.runConsole();
							}
						}
					}
				}
				if (artifactType.equalsIgnoreCase("ecuextract")) {
					for (Iterator iterator = noNameElement.iterator(); iterator.hasNext();) {
						NoNameElement noNameElement2 = (NoNameElement) iterator.next();
						EList<MCC> mcc = noNameElement2.getMcc();
						for (Iterator iterator2 = mcc.iterator(); iterator2.hasNext();) {
							MCC mcc2 = (MCC) iterator2.next();
							EList<Component> components = mcc2.getComponents();
							for (Iterator iterator3 = components.iterator(); iterator3.hasNext();) {
								Component component = (Component) iterator3.next();
								GenerateARXMLAction genArxmlAction = new GenerateARXMLAction(component, outputPath);
								genArxmlAction.run();
								runConsole = genArxmlAction.isArxmlGenerated();
							}
						}
					}
				}
			}
			if (eObject instanceof MCC) {
				MCC mcc = ((MCC) eObject);
				if (mcc.eContainer() == null) {
					NoNameElement noNameElement = ArchitecturetoolFactory.eINSTANCE.createNoNameElement();
					noNameElement.getMcc().add(mcc);
				}
				if (artifactType.equalsIgnoreCase("rte")) {
					NoNameElement noNameElement = (NoNameElement) mcc.eContainer();
					GenerateRteHeaders genRteHeaders = new GenerateRteHeaders(noNameElement, outputPath,null);
					genRteHeaders.run();
					runConsole = genRteHeaders.isRteGenerated();
				}
				if (artifactType.equalsIgnoreCase("sil")) {
					NoNameElement noNameElement = (NoNameElement) mcc.eContainer();
					GenerateSimconFile genSimConFile = new GenerateSimconFile(noNameElement, outputPath,null);
					genSimConFile.run();
					runConsole = genSimConFile.isGenerated();
				}
				if (artifactType.equalsIgnoreCase("par")) {
					NoNameElement noNameElement = (NoNameElement) mcc.eContainer();
					GenerateSILArtifactsPar genSilParFile = new GenerateSILArtifactsPar(noNameElement, outputPath,null);
					genSilParFile.run();
					runConsole = genSilParFile.isGenerated();
				}
				EList<Component> components = mcc.getComponents();
				for (Iterator<Component> iterator = components.iterator(); iterator.hasNext();) {
					Component component = (Component) iterator.next();
					if (artifactType.equalsIgnoreCase("header")) {
						GenerateHeaderfileAction genHeaderFileAction = new GenerateHeaderfileAction(component,
								outputPath);
						runConsole = genHeaderFileAction.runConsole();
					}
					if (artifactType.equalsIgnoreCase("ecuextract")) {
						GenerateARXMLAction genArxmlAction = new GenerateARXMLAction(component, outputPath);
						genArxmlAction.run();
						runConsole = genArxmlAction.isArxmlGenerated();
					}
				}
			}
		}
		return runConsole ? true : false;
	}

}
